<?php
session_start();
$_SESSION['gamecp']['order_api']=true;

if(isset($_REQUEST["api"])){

	header("Content-type: text/xml");
	echo '<xml version="1.0" encoding="utf-8">';
echo "<gcp>";

}

/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/* 
GameCP Billing API 

CE ADDITIONS BY BILLY  2008
ORIGINAL SYSTEM DESIGN BY TRISTAN MORRIS 2005-2006

*/
$api_in_use = true;
if(!isset($_REQUEST['passphrase'])) die("Billing Settings missing passphrase.");
$noheader=true;
require_once("classes/core.inc.php");
require_once("../../includes/mysql.inc.php");
require_once("../../includes/config.inc.php");

$billurl=billurl;
if(isset($billurl)){
	$valid=false;
	$validurl=explode(",", $billurl);
	if(in_array($_SERVER['REMOTE_ADDR'], $validurl)) $valid=true;

	if($valid==false) die("You do not have the correct permission to access this location from ". $_SERVER['REMOTE_ADDR']);
	
}

/* removal of this code is illegal, a full or trial license is required for the API as our site clearly states */
if(preg_match("/Basic/s", gcplickey)) die("A Trial or Full license is required to enable the API.");


require_once("classes/connector.php");


if(!isset($_REQUEST["api"])){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>GameCP API Connector</title>
</head>
<body>
----------------------------------------<br />
<strong>GameCP API Connector</strong><br />
----------------------------------------<br />
Function to perform: <?php echo $account_function; ?><br />
Passed Security Checks: <?php echo $passed_security_check_friendly; ?><br />
Function Determination: <?php echo $function_determine; ?><br />
Required Variables Defined: <?php echo $passed_checks; ?><br />
<strong>Command Execution Result: <?php echo $execute_result_friendly; ?></strong><br />
<?php if ($show_result != false) echo "<br>Result: $show_result<br>";	?>
</body>
</html>
<?php

} else {



echo $execute_result;

if($execute_result == false && $results){
} 


echo "</gcp></xml>";



}

$Event->EventLogAdd('system', "API Connection ". $_REQUEST["action"]. " made from " . $_SERVER['REMOTE_ADDR'] . "  @ ". time());


?>