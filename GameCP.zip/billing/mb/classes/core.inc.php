<?php
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/* 
GameCP Billing API 

CE ADDITIONS BY BILLY  2008
ORIGINAL SYSTEM DESIGN BY TRISTAN MORRIS 2005-2006

*/




function array2xml($array){
	$cleanarray=array();
	$ii=0;
	foreach($array as $items_array){
		echo "<item>";
		$ii=0;
		foreach($items_array as $i => $a){
			if(!is_int($i)) echo "<$i>".htmlspecialchars($a)."</$i>";


		}
		$ii++;
		echo "</item>";
	}
}


function simpleArray2xml($array){
	$cleanarray=array();
	$ii=0;
	foreach($array as $it => $em){
		echo "<$it>$em</$it>";
	}
}



// Get MB Password
function GetMBPassword() {
		global $GameCP, $safesql;
	$sql = "SELECT settings.value
						FROM settings
						WHERE name = 'mbpassword'
						LIMIT 1";
						
	$results = mysql_query($sql) or die("MySQL Error: " . mysql_error());
	$pass = mysql_fetch_array($results);
	$pass = $pass["value"];
	return $pass;
}
// Get users GameCP id from customerid/packageid
function GetInfoFromID($id, $type) {
		global $GameCP, $safesql;
	if(isset($_REQUEST['idtype']) && $_REQUEST['idtype'] == "direct") return $id;
	if(!$id) return false;
	if($type == "customerid"){
		$query = mysql_query($safesql->query("SELECT id FROM users WHERE billingid = '%i' LIMIT 1", array($GameCP->whitelist($id, "int")))) or die("MySQL Error: " . mysql_error());
	}elseif($type == "gameid"){
		$query = mysql_query($safesql->query("SELECT id FROM usergames WHERE billingid = '%i' LIMIT 1", array($GameCP->whitelist($id, "int")))) or die("MySQL Error: " . mysql_error());
	}elseif($type == "voiceid"){
		$query = mysql_query($safesql->query("SELECT id FROM uservoice WHERE billingId = '%i' LIMIT 1", array($GameCP->whitelist($id, "int")))) or die("MySQL Error: " . mysql_error());
	}
	
	if($query && mysql_num_rows($query) == 1)
	{
		$rvalue = mysql_fetch_array($query);
		$rvalue = $rvalue["id"];
	}
	else{ $rvalue = null; }
	
	return $rvalue;
}

function GetUserServices($id) {
		global $GameCP, $safesql;
	if(!$id) return false;
	$uid=GetInfoFromID($id, "customerid");
	$games=  mysql_query($safesql->query("SELECT id FROM usergames WHERE cid = '%i'", array($GameCP->whitelist($uid, "int")))) or die("MySQL Error: " . mysql_error());
	$voice=  mysql_query($safesql->query("SELECT id FROM uservoice WHERE cid = '%i'", array($GameCP->whitelist($uid, "int")))) or die("MySQL Error: " . mysql_error());
	$g=mysql_num_rows($games);
	$v=mysql_num_rows($voice);
	$total=$g+$v;
	return  $total;
}

?>