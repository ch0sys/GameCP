<?php
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

$ok = "<span class=\"Green\">Ok</span>";
$fail = "<span class=\"Red\">Failed</span>";
$show_result=false;
$passed_checks=$fail;
$execute_result_friendly=$ok;

$debugging_enabled = @$_REQUEST['debugging'];
if ($debugging_enabled == "" OR NULL) {
	$debugging_enabled = false;
} else $debugging_enabled = true;

$account_function = @$_REQUEST["action"];
if ($account_function == "" OR NULL) $account_function = "Function Undefined";

$passed_security_check = false;
if ($_REQUEST["passphrase"] == GetMBPassword()) {
	$passed_security_check = TRUE;
	$passed_security_check_friendly = $ok;
} else {
	echo "<div class=\"infobox\">Attempted Password: " . $_REQUEST["passphrase"] . "</div>";
	$passed_security_check_friendly = $fail;
}

// Main Methods!
if ($passed_security_check && $account_function != "Function Undefined") {
	switch ($account_function) {
		case 'deletevoice':
			$packageid = $_REQUEST['packageid'];
			$gcp_voiceID = GetInfoFromID($packageid, 'voiceid');
			$GameCP->loadIncludes("voice");
			$Voice=new Voice();
			$results=$Voice->Remove($gcp_voiceID);
			if ($results){
				$execute_result = true;
				$execute_result_friendly = "Ok";
			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'suspendvoice':
			$packageid = $_REQUEST['packageid'];
			$gcp_voiceID = GetInfoFromID($packageid, 'voiceid');
			$GameCP->loadIncludes("suspend");
			$Suspend=new Suspend();
			$results=$Suspend->Voice($gcp_voiceID);

			if ($results){
				$execute_result = true;
				$execute_result_friendly = "Ok";
				
			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'unsuspendvoice':

			$packageid = $_REQUEST['packageid'];
			$gcp_voiceID = GetInfoFromID($packageid, 'voiceid');
			$GameCP->loadIncludes("suspend");
			$Suspend=new Suspend();
			$results=$Suspend->VoiceRestore($gcp_voiceID);

			if ($results){
				$execute_result = true;
				$execute_result_friendly = "Ok";
				
			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'create':
			$function_determine = $ok;
			$checks = true;

			$packageid = $_REQUEST['packageid'];
			$gcp_gameID = GetInfoFromID($packageid, 'gameid');

			if($gcp_gameID){
				echo "<div class=\"infobox\">Service already created</div>";
				$checks = false;
				exit;
			}

			// Default constructor values
			$todaysTimestamp = time (); 
			$today = date ('n/j/Y', $todaysTimestamp);
			$user_level = "0";
			$port_num = "";
			$client_url = "";
			$ts_user = "";
			$ts_password = "";
			$ts_port = "";
			$ts_ip = "";
			$queue = '';
			$voiceinstall = FALSE;
			$voicetype = FALSE;
			$voicemaxclients = FALSE;
			$display_order = "no";

			if(isset($_REQUEST['install_type'])){
				$install_type = $_REQUEST['install_type'];
			} else $install_type = "install";	

			if(isset($_REQUEST['add_bill'])){
				$add_bill = $_REQUEST['add_bill'];
			} else $add_bill = "no";	

			if(isset($_REQUEST['payment_cycle'])){
				$payment_cycle = $_REQUEST['payment_cycle'];
			} else $payment_cycle = "31";	

			if(isset($_REQUEST['payment_fee'])){
				$payment_fee = $_REQUEST['payment_fee'];
			} else $payment_fee = "0";	

			if(isset($_REQUEST['gross_payment'])){
				$gross_payment = $_REQUEST['gross_payment'];
			} else $gross_payment = "0";	

			if(isset($_REQUEST['payment_status'])){
				$payment_status = $_REQUEST['payment_status'];
			} else $payment_status = "Completed";	

			if(isset($_REQUEST['subscr_id'])){
				$subscr_id = $_REQUEST['subscr_id'];
			} else $subscr_id = FALSE;	

			$extra_info=$_REQUEST['extra_info'];
			$freseller=$_REQUEST['reseller'];
			$payment_method = $_REQUEST['payment_method'];
			$specpassword = urldecode($_REQUEST['specpassword']);

			if(isset($_REQUEST['start_server'])){
				$start_server = $_REQUEST['start_server'];
			} else $start_server = "yes";	
			
			if(isset($_REQUEST['email_server'])){
				$email_server = $_REQUEST['email_server'];
			} else $email_server = "yes";					
			
			$first_name = $_REQUEST['firstname'];
			$last_name = $_REQUEST['lastname'];
			$street_address = $_REQUEST['address'];
			$city = $_REQUEST['city'];
			$state = $_REQUEST['state'];
			$country = $_REQUEST['country'];
			$zip_code = $_REQUEST['zipcode'];
			$phone_number = $_REQUEST['phonenum'];


			$start_time= $_REQUEST['start_time'];
			$end_time= $_REQUEST['end_time'];

			
			// General User Information
			$username = strtolower($_REQUEST['username']);
			$email_address = $_REQUEST['emailaddr'];
			$password = $_REQUEST['password'];
			$customerid = $_REQUEST['customerid'];
			$packageid = $_REQUEST['packageid'];
			
			// Core Game Information
			$game_id = $_REQUEST['game_id'];
			$player_slots = $_REQUEST['max_players'];
			$public_private = $_REQUEST['pub_priv'];	
			$login_path = $_REQUEST['login_path'];	


			$bypass_ip=false;
			if(isset($_REQUEST['sv_ip'])){
				$ip_address = $_REQUEST['sv_ip'];
			} elseif($game_id == "1001" && usedarkstarvent == "yes"){
				$ip_address="";
				if($_REQUEST['sv_location']) $ip_address=$_REQUEST['sv_location'];
				$bypass_ip=true;
			} else {
				$GameCP->loadIncludes("ip");
				$IP=new IP();
				$ip_address=$IP->GetIP($game_id, $player_slots, $_REQUEST['sv_location']);
			}

			if(!$ip_address && $bypass_ip == false){
				// new! failure if no ip found, bad local? no slots?
				echo "<div class=\"infobox\">Unable to determine ip address, check location, slot's and quota settings.</div>";
				$checks = false;
			}

			/* adjusted to work with on/off values from whmcs */
			if($public_private == "on") $public_private = "1";
			if($login_path == "on"){
				$login_path = "no";
			} else if ($login_path == "" OR NULL) $login_path="no";

			$fmanager = $_REQUEST['file_manager'];

			$affinty = $_REQUEST['affinty'];

			// Addon Based Things
			$privpass = urldecode($_REQUEST['priv_password']);
			$rconpass = urldecode($_REQUEST['rcon_password']);
			$hostname = urldecode($_REQUEST['hostname']);
			$motd =		urldecode($_REQUEST['motd']);
			$website =  urldecode($_REQUEST['website']);
			

			// Server Config
			$config_file = $_REQUEST['config_file'];
			$server_port = $_REQUEST['port'];
			$start_map = $_REQUEST['map'];

			if($_REQUEST['subdir']){ 
				$subdir=$_REQUEST['subdir'];
			} else $subdir="yes";
			
			
			/* generate addons sent from the clientexec system */
			$addonsArray = array();
			$addons = array();
			$game_addons = array();
			$addonsArray=unserialize(stripslashes($_REQUEST['addons']));
			$addons='';
			$game_addons='';
			if(is_array($addonsArray)){
				foreach($addonsArray as $adnvar => $adnval){
					if(preg_match("/addon_/i", $adnvar)){
						if(($adnvar != "sv_slots") AND ($adnvar != "sv_location")) $addons[$adnvar]=$adnval;					
					} else if(preg_match("/game_/i", $adnvar)) $game_addons[]=array("cvar"=>strtoupper($adnvar), "value"=>$adnval);
				}
			}

			// Mark IP used yes/no
			$mark_ip_used = $_REQUEST['mark_ip_used'];
			
			// Perform checks on variables
			if ($username == "" OR NULL) {
				$totalClientsQ = sql_query("SELECT Auto_increment FROM information_schema.tables WHERE table_name='users';") or die(mysql_error()); 
				$totalClients=mysql_fetch_array($totalClientsQ);
				$lastId=$totalClients[0];
				$username=userprefix.$lastId;
			} 
			
		// Continue Processing & Execute if checks ok				
			if ($checks == false) {
				$passed_checks = $fail;

			} else {
				$passed_checks = $ok;
				
				$GameCP->loadIncludes("user");
				$User=new User();

				ob_start();
				if($debugging_enabled == true) define('debugging', '1'); // Show debugging output in case of errors.
				
				$gcp_cid = GetInfoFromID($customerid, 'customerid');
				
				if($gcp_cid){
					// What to look for to check if user was successfuly added or not
					$haystack = "UGID";

					$User->AddGame(	$username, $gcp_cid, $game_id, $ip_address, $server_port,
									$fqueryport, '', 'yes', $player_slots, $public_private,
									'0', '+1', $subdir, $start_map, $rconpass,
									$specpass, $privpass, $hostname, $motd, $website,
									$config_file, 'install', $start_server, $addons, $game_addons, 
									$affinity, FALSE,
									$start_time,
									$end_time,
									FALSE,
									$packageid, $email_server, FALSE, FALSE, FALSE, $mark_ip_used
					);




				} else {

					// What to look for to check if user was successfuly added or not

					/* check for this username, if it exists append it */
					$unameQ = mysql_query($safesql->query("SELECT name FROM users where name='%s'", array($username))) or die(mysql_error());
					$uname = mysql_fetch_row($unameQ);

					if($uname > 0){
						$totalClientsQ = mysql_query("SELECT id FROM users ORDER BY id DESC LIMIT 1;") or die(mysql_error()); 
						$totalClients=mysql_fetch_array($totalClientsQ);
						$lastId=$totalClients['id'];
						$username="server" . $lastId++;
					}

					if (strlen($username) < 3)  $username=$username."game";

					$haystack = "uid:";
					$User->Add($username, $email_address, $game_id, $username, $user_level, $password, 
								 $ip_address, $port_num, $phone_number, $street_address, $city, $state, $country,
								 $zip_code, $client_url, $install_type, $extra_info, $first_name, $last_name, $payment_method, $street_address,
								 $ts_ip, $login_path, $today, $config_file, $ip_address, $server_port,
								 $start_map, $player_slots, $public_private, $today, $payment_status, $gross_payment,
								 $payment_fee, $payment_cycle, $install_type, $start_server, $email_server,
								 $add_bill, $display_order, $game_id, $mark_ip_used, $queue, $voiceinstall, 
								 $voicetype, $voicemaxclients, $rconpass, $specpass, $privpass, $subscr_id,
								 $hostname, $motd, $website, $freseller,
								$start_time,
								$end_time,
								FALSE, 
								 $addons, $game_addons, $affinity, FALSE, FALSE, FALSE, $subdir, $customerid, $packageid,FALSE, FALSE, $fmanager);
				}

				
				$results = ob_get_contents();
				ob_end_clean();
				echo $results;
				if (preg_match("/$haystack/i", $results)){
					$execute_result = true;
					$execute_result_friendly = "Ok";
					
				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}

		break;
	
		case 'suspendgame':
			$function_determine = $ok;

			$packageid = $_REQUEST['packageid'];
			$gcp_gameID = GetInfoFromID($packageid, 'gameid');
			if(!$gcp_gameID){
				$execute_result = false;
				$execute_result_friendly = "Failed";
				$results="Unable to locate service";
			} else {
				$passed_checks = $ok;
				$GameCP->loadIncludes("suspend");
				$Suspend=new Suspend();
				$results=$Suspend->Game($gcp_gameID);

				if ($results){
					$execute_result = true;
					$execute_result_friendly = "Ok";
					
				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}
		break;

		case 'unsuspendgame':
			$function_determine = $ok;

			$packageid = $_REQUEST['packageid'];
			$gcp_gameID = GetInfoFromID($packageid, 'gameid');
			if(!$gcp_gameID){
				$execute_result = false;
				$execute_result_friendly = "Failed";
				$results="Unable to locate service";
			} else {
				$passed_checks = $ok;
				$GameCP->loadIncludes("suspend");
				$Suspend=new Suspend();
				$results=$Suspend->GameRestore($gcp_gameID);

				if ($results){
					$execute_result = true;
					$execute_result_friendly = "Ok";
					
				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}
		break;

		case 'delete':
			$function_determine = $ok;
			
			$customerid = $_REQUEST["customerid"];
			$packageid = $_REQUEST['packageid'];
			
			if ($customerid != "" OR NULL) { 
				$checks = true;
			} else { 
				$checks = false;
			}
			if (!$checks) { 
				$passed_checks = $fail;
			} else {
				$passed_checks = $ok;
				ob_start();

				if($debugging_enabled == true) define('debugging', '1'); // Show debugging output in case of errors.
				$gcp_gameID = GetInfoFromID($packageid, 'gameid');
					
				$execute_result = false;
				$execute_result_friendly = "Failed";

				if($gcp_gameID){
					// What to look for to check if user was successfuly removed or not
					$GameCP->loadIncludes("user");
					$User=new User();

					if($User->RemoveGame($gcp_gameID, "no", "yes", "yes", true, true, true, true) == "removed"){
						$execute_result = true;
						$execute_result_friendly = "Ok";
					}


				// user has no services left, trigger account removal
				} else if (GetUserServices($customerid) == 0) {
					// What to look for to check if user was successfuly removed or not
					$gcp_cid = GetInfoFromID($customerid, 'customerid');
					if($gcp_cid){
						$GameCP->loadIncludes("user");
						$User=new User();
						if($User->Remove($gcp_cid, true, true)){
							$execute_result = true;
							$execute_result_friendly = "Ok";
						}
					}
				} 
			}
		break;
		
		case 'suspend':
			$function_determine = $ok;
			$customerid = $_REQUEST["customerid"];
			
			if ($customerid != "" OR NULL) { $checks = true; } 
			else { $checks = false; }
			if (!checks) {
				$passed_checks = $fail;
			} else {
				$passed_checks = $ok;
				ob_start();
				if($debugging_enabled == true) define('debugging', '1'); // Show debugging output in case of errors.
				
				$gcp_cid = GetInfoFromID($customerid, 'customerid');
				if(!$gcp_cid){
					$execute_result = false;
					$execute_result_friendly = "Failed";
					$results="Unable to locate user";
				} else {
					$GameCP->loadIncludes("suspend");
					$Suspend=new Suspend();
					$exec_result = $Suspend->User($gcp_cid);
									
					$results = ob_get_contents();
					ob_end_clean();
							
					if ($exec_result == TRUE){
						$execute_result = true;
						$execute_result_friendly = "Ok";
						
					} else {
						$execute_result = false;
						$execute_result_friendly = "Failed";
					}
				}
			}
			
		break;
		
		case 'unsuspend':
			$function_determine = $ok;
			$customerid = $_REQUEST["customerid"];
			
			if ($customerid != "" OR NULL) { $checks = true; } 
			else { $checks = false; }
			if (!checks) { $passed_checks = $fail; } 
			else {
				
				$gcp_cid = GetInfoFromID($customerid, 'customerid');
				if(!$gcp_cid){
					$execute_result = false;
					$execute_result_friendly = "Failed";
					$results="Unable to locate user";
				} else {
					$passed_checks = $ok;
					ob_start();
					$GameCP->loadIncludes("suspend");
					$Suspend=new Suspend();
					$exec_result = $Suspend->UserRestore($gcp_cid);
					$results = ob_get_contents();
					ob_end_clean();
					if ($exec_result == TRUE){
						$execute_result = true;
						$execute_result_friendly = "Ok";
					} else {
						$execute_result = false;
						$execute_result_friendly = "Failed";
					}
				}
			}			
		break;
		
		case 'stop':
			$function_determine = $ok;
			$GameCP->loadIncludes("control");
			$Control=new Control();

			$packageid = $_REQUEST['packageid'];
			$gcp_gameID = GetInfoFromID($packageid, 'gameid');
			if(!$gcp_gameID){
				$execute_result = false;
				$execute_result_friendly = "Failed";
				$results="Unable to locate service";
			} else {
				$passed_checks = $ok;
				ob_start();
				$Control->Usergame($gcp_gameID, "stop");
				$results = ob_get_contents();
				ob_end_clean();
				if($results){
					$execute_result = false;
					$execute_result_friendly = "Failed";
				} else {
					$execute_result = true;
					$execute_result_friendly = "Ok";
				}
			}
				
		break;

		case 'start':
			$function_determine = $ok;
			$GameCP->loadIncludes("control");
			$Control=new Control();

			$packageid = $_REQUEST['packageid'];
			$gcp_gameID = GetInfoFromID($packageid, 'gameid');
			if(!$gcp_gameID){
				$execute_result = false;
				$execute_result_friendly = "Failed";
				$results="Unable to locate service";
			} else {
				$passed_checks = $ok;
				ob_start();
				$Control->Usergame($gcp_gameID, "start");
				$results = ob_get_contents();
				ob_end_clean();
				if($results){
					$execute_result = false;
					$execute_result_friendly = "Failed";
				} else {
					$execute_result = true;
					$execute_result_friendly = "Ok";
				}
			}
				
		break;

		case 'restart':
			$function_determine = $ok;
			$GameCP->loadIncludes("control");
			$Control=new Control();

			$packageid = $_REQUEST['packageid'];
			$gcp_gameID = GetInfoFromID($packageid, 'gameid');
			if(!$gcp_gameID){
				$execute_result = false;
				$execute_result_friendly = "Failed";
				$results="Unable to locate service";
			} else {
				$passed_checks = $ok;
				ob_start();
				$Control->Usergame($gcp_gameID, "restart");
				$results = ob_get_contents();
				ob_end_clean();
				if($results){
					$execute_result = false;
					$execute_result_friendly = "Failed";
				} else {
					$execute_result = true;
					$execute_result_friendly = "Ok";
				}
			}
				
		break;

		case 'changeplayers':
			$function_determine = $ok;
			$player_slots = $_REQUEST['max_players'];
			$addons = $_REQUEST['addons'];

			$packageid = $_REQUEST['packageid'];
			$gcp_gameID = GetInfoFromID($packageid, 'gameid');
			if(!$gcp_gameID){
				$execute_result = false;
				$execute_result_friendly = "Failed";
				$results="Unable to locate service";
			} else {
				$passed_checks = $ok;
				mysql_query($safesql->query("UPDATE usergames SET maxplayers = '%i', clientplayers='%i' WHERE id = '%i' LIMIT 1", array($player_slots, $player_slots, $gcp_gameID)));
				$execute_result = true;
				$execute_result_friendly = "Ok";

				$addonsArray = array();
				$addons = array();
				$game_addons = array();
				$addonsArray=unserialize(stripslashes($_REQUEST['addons']));

				if(is_array($addonsArray) && count($addonsArray) > 0){
					foreach($addonsArray as $adnvar => $adnval){
						if(preg_match("/addon_/i", $adnvar)){
							if(($adnvar != "sv_slots") AND ($adnvar != "sv_location")) $addons[$adnvar]=$adnval;					
						} else if(preg_match("/game_/i", $adnvar)) $game_addons[]=array("cvar"=>strtoupper($adnvar), "value"=>$adnval);
					}

					$gameInfoQ= sql_query($safesql->query("SELECT customvars FROM usergames WHERE id = '%i' LIMIT 1;", array($GameCP->whitelist($gcp_gameID, "int")))) or die(mysql_error());
					$gameInfo = mysql_fetch_array($gameInfoQ);
					$userCustomVars=unserialize($gameInfo['customvars']);

					$GameCP->loadIncludes("game");
					$Game=new Game();
					$final_game_addons=$Game->MergeVars($userCustomVars, $game_addons, true);

					mysql_query($safesql->query("UPDATE usergames SET addons = '%s', customvars='%s' WHERE id = '%i' LIMIT 1", array(serialize($addons), serialize($final_game_addons), $gcp_gameID)));
				}
			}

		break;

		case 'usergameview':
			$function_determine = $ok;
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();


			$packageid = $_REQUEST['packageid'];
			$gcp_gameID = GetInfoFromID($packageid, 'gameid');

			if(!$gcp_gameID){
				$execute_result = false;
				$execute_result_friendly = "Failed";
				$results="Unable to locate service";
			} else {

				$usergameid = $_REQUEST["usergameid"];
				$userGameInfo=$Panel->GetUserGame($gcp_gameID);
				if(is_array($userGameInfo)){
					$passed_checks = $ok;
					$GameCP->loadIncludes("query");
					$Query=new Query();
					$serverStatus=$Query->GameQ($gcp_gameID);
					$userGameInfo['total']=$serverStatus[0];
					$userGameInfo['active']=$serverStatus[1];
					$userGameInfo['status']=$serverStatus[2];
					$userGameInfo['sp']=$serverStatus[3];
					$userGameInfo['stats']=$serverStatus[4];

					$results = simpleArray2xml($userGameInfo);

					$execute_result = true;
					$execute_result_friendly = "Ok";

				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}		
		break;

		case "userinfo":
			if(isset($customerid) && $customerid > 0){
				$function_determine = $ok;
				$gcp_cid = GetInfoFromID($customerid, 'customerid');
				if($gcp_cid && $gcp_cid > 0){
					$passed_checks = $ok;
					$GameCP->loadIncludes("panel");
					$Panel=new Panel();
					$userInfo=$Panel->GetUser($gcp_cid);

					echo "PASS: $userInfo[password] ::<br>"; 
					echo "USER: $userInfo[username] ::<br>"; 
					$execute_result = true;
					$execute_result_friendly = "Ok";

				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}
		break;

		case "gamevalidation":
			if($packageid){
				$function_determine = $ok;
				$gcp_cid = GetInfoFromID($packageid, 'gameid');
				if($gcp_cid){
					$passed_checks = $ok;
					$execute_result = true;
					$execute_result_friendly = "Ok";

				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}
		break;


		case "ceuservalidation":
			if($customerid){
				$function_determine = $ok;
				$gcp_cid = GetInfoFromID($customerid, 'customerid');
				if($gcp_cid){
					$passed_checks = $ok;
					$GameCP->loadIncludes("panel");
					$Panel=new Panel();
					$userInfo=$Panel->GetUser($gcp_cid);

					echo "PASS: $userInfo[password] ::<br>"; 
					echo "USER: $userInfo[username] ::<br>"; 

				}
			}
			if($packageid){
				$ugid = GetInfoFromID($packageid, 'gameid');
				if($ugid){
					$passed_checks = $ok;
					$execute_result = true;
					$execute_result_friendly = "Ok";

				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}

		break;




		case "uservalidation":
			$function_determine = $ok;
			$passed_checks = $ok;

			if($GameCP->Login($_REQUEST['email'], $_REQUEST['password']) == 0){
				$execute_result = true;
				$execute_result_friendly = "Ok";
				
			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'userview':
			$function_determine = $ok;

			$GameCP->loadIncludes("panel");
			$Panel=new Panel();

			$gcp_cid = GetInfoFromID($customerid, 'customerid');
			if(!$gcp_cid){
				$execute_result = false;
				$execute_result_friendly = "Failed";
				$results="Unable to locate user";
			} else {
				$userInfo = $Panel->GetUser($gcp_cid);
				$passed_checks = $ok;
				if(is_array($userInfo)){
					$execute_result = true;
					$execute_result_friendly = "Ok";
					$results = simpleArray2xml($userInfo);
				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}
		break;

		case 'search':
			$sq="";
			if($_REQUEST['string']){
				$string=$_REQUEST['string'];
			} else $string="";

			switch($_REQUEST['function']){
				case "users";
					if($_REQUEST['string']) $sq = "WHERE (`username` LIKE '$string' OR `email` LIKE '$string' OR `firstname` LIKE '$string' OR `lastname` LIKE '$string')";
					$searchQ = sql_query($safesql->query("SELECT * FROM users $sq", array())) or die(mysql_error());
				break;
				case "bills";
					if($_REQUEST['string']) $sq = "WHERE (`cid` LIKE '$string' OR `subscr_id` LIKE '$string' OR `status` LIKE '$string' OR `date` LIKE '$string')";
					$searchQ = sql_query($safesql->query("SELECT * FROM billing $sq", array())) or die(mysql_error());
				break;
				case "tickets";
					if($_REQUEST['string']) $sq = "WHERE (`cid` LIKE '$string' OR `reply` LIKE '$string' OR `status` LIKE '$string' OR `date` LIKE '$string' OR `games` LIKE '$string' OR `subject` LIKE '$string')";
					$searchQ = sql_query($safesql->query("SELECT * FROM ttsystem $sq", array())) or die(mysql_error());
				break;
				case "games";
					if($_REQUEST['string']) $sq = "WHERE (`cid` LIKE '$string' OR `ip` LIKE '$string' OR `port` LIKE '$string' OR `status` LIKE '$string' OR `active` LIKE '$string')";
					$searchQ = sql_query($safesql->query("SELECT * FROM usergames $sq", array())) or die(mysql_error());
				break;

				case "voice";
					if($_REQUEST['string']) $sq = "WHERE (`cid` LIKE '$string' OR `ip` LIKE '$string' OR `port` LIKE '$string' OR `active` LIKE '$string')";
					$searchQ = sql_query($safesql->query("SELECT * FROM uservoice $sq", array())) or die(mysql_error());
				break;

			}

			if(mysql_num_rows($searchQ) > 0){
				$listResult=array();
				while($userList=mysql_fetch_array($searchQ)) $listResult[]=$userList;
				if(is_array($listResult)){
					$results = array2xml($listResult);
					$execute_result = true;
					$execute_result_friendly = "Ok";
				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'billview':
			$billid = $_REQUEST["billid"];
			if($billid){
				$billInfoQ = sql_query($safesql->query("SELECT U.name, B.* FROM billing B, users U WHERE B.id='%i' AND B.cid = U.id ORDER BY `date` DESC", array($billid))) or die(mysql_error());
				$billInfo=mysql_fetch_assoc($billInfoQ);

				if(is_array($billInfo)){
					$execute_result = true;
					$execute_result_friendly = "Ok";
					$results = simpleArray2xml($billInfo);
				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}
		break;

		case 'billadd':
			$function_determine = $ok;
			$passed_checks = $ok;

			sql_query($safesql->query("INSERT INTO billing SET gross='%s', fee='%s', cid='%i', date='%s', status='%s', `update`='%s', daystill='%s', subscr_id='%s', suspend='%i';",
							array($_REQUEST['gross'],$_REQUEST['fee'],$_REQUEST['clientid'], $_REQUEST['date'], $_REQUEST['status'], $_REQUEST['update'], $_REQUEST['daystill'], $_REQUEST['subscr_id'], $_REQUEST['suspend']))) or die(mysql_error());
			$bid=mysql_insert_id();

			if(is_numeric($bid)){
				$execute_result = true;
				$execute_result_friendly = "Ok";
				$show_result=$bid;
			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'billremove':
			$function_determine = $ok;

			$billid = $_REQUEST["billid"];

			if($billid){
				$passed_checks = $ok;
				$GameCP->loadIncludes("billing");
				$Billing=new Billing();

				$Billing->Remove($billid);
				$billInfoQ = sql_query($safesql->query("SELECT * FROM billing WHERE id='%i'", array($billid))) or die(mysql_error());
				if(mysql_num_rows($billInfoQ) == "0"){
					$execute_result = true;
					$execute_result_friendly = "Ok";

				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'billupdate':
			$function_determine = $ok;

			$billid = $_REQUEST["billid"];
			if($billid){
				$passed_checks = $ok;

				sql_query($safesql->query("UPDATE billing  SET cid='%i', date='%s', status='%s', `update`='%s', daystill='%s', subscr_id='%s', suspend='%i' WHERE id='%i';",
								array($_REQUEST['clientid'], $_REQUEST['date'], $_REQUEST['status'], $_REQUEST['update'], $_REQUEST['daystill'], $_REQUEST['subscr_id'], $_REQUEST['suspend'], $billid))) or die(mysql_error());

				$execute_result = true;
				$execute_result_friendly = "Ok";
			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'notify':
			$function_determine = $ok;
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$GameCP->loadIncludes("email");
			$Email=new Email();

			$userid = $_REQUEST["userid"];
			$userInfo = $Panel->GetUser($userid);
			if(is_array($userInfo)){

				$Email->userid = $userInfo['id'];
				
				$show_result=$userInfo['email'];

				$Email->emailsubject = $_REQUEST["subject"];
				$Email->emailbody = $_REQUEST["body"];

				$Email->usegamedata = true;
				$Email->usevoicedata = true;
				$Email->usebilldata = true;

				$Email->ReplaceStuff();
				$Email->send();

				$execute_result = true;
				$execute_result_friendly = "Ok";

			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'ticketopen':
			$function_determine = $ok;
			$passed_checks = $ok;

			$GameCP->loadIncludes("support");
			$Support=new Support();
			$tid=$Support->Create($_REQUEST['userid'], $_REQUEST['title'], $_REQUEST['subject'], $_REQUEST['summary'], $_REQUEST['message'], $_REQUEST['reply']);

			if(is_numeric($tid)){
				$execute_result = true;
				$execute_result_friendly = "Ok";
				$show_result=$tid;
			} else {
				$execute_result = false;
				$execute_result_friendly = "Failed";
			}
		break;

		case 'ticketview':
			$tid = $_REQUEST["tid"];
			if($tid){
				$billInfoQ = sql_query($safesql->query("SELECT 
												U.username as user, T.*, T.id as 'tid', U.id  as 'uid' FROM ttsystem T, users U WHERE
												T.id='%i' and U.id = T.cid $cQuery
												LIMIT 1", array($tid))) or die(mysql_error());
				$billInfo=mysql_fetch_assoc($billInfoQ);

				if(is_array($billInfo)){
					$execute_result = true;
					$execute_result_friendly = "Ok";
					$results = simpleArray2xml($billInfo);
				} else {
					$execute_result = false;
					$execute_result_friendly = "Failed";
				}
			}
		break;

		case 'ticketreply':
			$function_determine = $ok;
			$passed_checks = $ok;

			$GameCP->loadIncludes("support");
			$Support=new Support();
			$Support->Reply($_REQUEST['userid'], $_REQUEST['tid'], $_REQUEST['status'], $_REQUEST['resolved'], $_REQUEST['reply'], $_REQUEST['summary']);

			$execute_result = true;
			$execute_result_friendly = "Ok";
		break;

		/* wish list */
		case 'addonexecute':
		break;

		case "whosonline":
		break;

		case 'userupdate':
		break;


		default:
			$function_determine = $fail;
	}			
	
} else $exit = TRUE;

	

?>