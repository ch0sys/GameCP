<?php
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.



	This script is created using FPDF, a free lib to help assist pdf creation.

*/

$noheader=true;
require('../../includes/core/includes/user/session.inc.php');
require('../../includes/config.inc.php');

/* language displayed in pdf */
	$txt_total="Total";
	$txt_time="Time";
	$txt_paidby="Paid By";
	$txt_invoiceitem="Invoice Item";
	$txt_daterange="Date Range";
	$txt_price="Price";
	$txt_invoicenum="Invoice #";
	$txt_paymentmethod="Payment Method: ";
	$txt_duedate="Due Date: ";
	$txt_status="Status: ";
	$txt_login="Login to view and pay your bills @ ";

	// slovak language
	if($_SESSION['gamecp']['lang']=="sk"){

		$txt_total="Celkom";
		$txt_time="Čas";
		$txt_paidby="Zaplatené:";
		$txt_invoiceitem="Fakturačná položka";
		$txt_daterange="Obdobie";
		$txt_price="Cena";
		$txt_invoicenum="Faktúra #";
		$txt_paymentmethod="Spôsob platby: ";
		$txt_duedate="Dátum splatnosti: ";
		$txt_status="Stav: ";
		$txt_login="Prehlad faktúr nájdete po prihlásení na : ";

	}

	// czech language
	if($_SESSION['gamecp']['lang']=="cz"){
		$txt_total="Celkem";
		$txt_time="Čas";
		$txt_paidby="Zaplacené:";
		$txt_invoiceitem="Fakturační položka";
		$txt_daterange="Období";
		$txt_price="Cena";
		$txt_invoicenum="Faktura #";
		$txt_paymentmethod="Spůsob platby: ";
		$txt_duedate="Datum splatnosti: ";
		$txt_status="Stav: ";
		$txt_login="Přehled faktur najdete po přihlásení na : ";
	}
/* language displayed in pdf */

require('tfpdf.php');

$GameCP->loadIncludes("panel");
$Panel=new Panel();
$GameCP->loadIncludes("billing");
$Billing=new Billing();

if($bid || $cid) $Billing->ValidateUser($cid, $bid);

$cidQ = sql_query($safesql->query("SELECT cid FROM billing WHERE id='%i'", array($GameCP->whitelist($bid, "int")))) or die(mysql_error());
$cidQ = mysql_fetch_array($cidQ);
$cid=$cidQ[0];
$cid=$GameCP->whitelist($cid, "int");
$bid=$GameCP->whitelist($bid, "int");

$userInfo=$Panel->GetUser($cid);

if($userInfo['currency']){
	$result = sql_query("SELECT * FROM currencies WHERE code='".$userInfo['currency']."'") or die(mysql_error());
	$exchange = mysql_fetch_array($result);
	$currencyChar=$exchange['prefix'];
	$currencyChar2=$exchange['suffix'];

} else {
	$currencyChar=currencyChar;
	$currencyChar2=currencyChar2;
}



if($currencyChar == "&pound;") $currencyChar="£";
if($currencyChar2 == "&pound;") $currencyChar2="£";

if($currencyChar == "&euro;") $currencyChar="€";
if($currencyChar2 == "&euro;") $currencyChar2="€";

//$currencyChar=iconv('UTF-8', 'windows-1252', currencyChar);
//$currencyChar2=iconv('UTF-8', 'iso-8859-2', currencyChar2);


$invoicedata=$Billing->InvoiceData($cid, $bid);
$mainBill=$invoicedata[2];
$dueDate=$invoicedata[4];


if(taxEnable == "yes" && $userInfo['taxed'] == "1") $invoicedata[1]=$Billing->TaxReduction($invoicedata[1]);


$header2=array($txt_total,$txt_time, $txt_paidby);
$data2=$invoicedata[0];
$header=array($txt_invoiceitem, $txt_daterange, $txt_price);
$data=$invoicedata[1];
$total=$currencyChar.$Panel->FormatNumber($mainBill['gross'], $cid).$currencyChar2;
$billuser=$mainBill['cid'];
$billStatus=$mainBill['status'];
$paymentMethod=$userInfo['payment'];

foreach($data as $da => $ta) $data[$da][2]=$currencyChar.$Panel->FormatNumber($ta[2], $cid).$currencyChar2;

$pdf=new tFPDF();

$pdf->AddFont('DejaVu','','DejaVuSansCondensed.ttf',true);
$pdf->SetFont('DejaVu','',20);

$pdf->AddPage();
$pdf->SetLeftMargin(40);
$pdf->Image('logo.gif',10,12,30,0,'',$url);

if($billStatus == "Completed"){
	$pdf->Image('paid.gif',90,10,35,0,'',$url);
	$paidDate=true;
}else $paidDate=false;

$pdf->SetLeftMargin(0);
$pdf->SetFontSize(14);

$pdf->SetFont('','', 12);
$pdf->SetY(10);

$pdf->Cell(0,10,domainName .' '. $txt_invoicenum .$bid,0,0,'R');
$pdf->Ln();

$pdf->SetY(15);
$pdf->SetFont('','', 8);

if($paymentMethod){
	$pdf->Cell(0,10,$txt_paymentmethod. $paymentMethod,0,0,'R');
	$pdf->Ln();
}

if($paidDate){
	$pdf->SetY(21);
	$pdf->Cell(0,10,$txt_status. $billStatus,0,0,'R');
	$pdf->Ln();
	$pdf->SetY(18);
	$pdf->Cell(0,10,$txt_duedate. $dueDate,0,0,'R');
	$pdf->Ln();
} else {
	$pdf->SetY(18);
	$pdf->Cell(0,10,$txt_duedate. $dueDate,0,0,'R');
	$pdf->Ln();
}





$pdf->SetY(42);

	$ix=10;
	$pdf->SetX($ix-3);
	$pdf->SetFont('','', 9);

	$pdf->Cell(0,"5","Invoice To",0,0,'L');
	$pdf->Ln();

	$pdf->SetFont('','', 8);
	
	$pdf->SetX($ix);
	$pdf->Cell(0,"5",$userInfo['firstname']." " . $userInfo['lastname'],0,0,'L');
	$pdf->Ln();

	$pdf->SetX($ix);
	$pdf->Cell(0,"5",$userInfo['address'],0,0,'L');
	$pdf->Ln();

if($userInfo['address2']){
	$pdf->SetX($ix);
	$pdf->Cell(0,"5",$userInfo['address2'],0,0,'L');
	$pdf->Ln();
}

	$pdf->SetX($ix);
	$pdf->Cell(0,"5",$userInfo['city'],0,0,'L');
	$pdf->Ln();

	$pdf->SetX($ix);
	$pdf->Cell(0,"5",$userInfo['state'],0,0,'L');
	$pdf->Ln();

	$pdf->SetX($ix);
	$pdf->Cell(0,"5",$userInfo['zip'],0,0,'L');
	$pdf->Ln();


	$pdf->SetX($ix);
	$pdf->Cell(0,"5",$userInfo['country'],0,0,'L');
	$pdf->Ln();
 
	$pdf->SetX($ix);
	$pdf->Cell(0,"5",$userInfo['taxid'],0,0,'L');
	$pdf->Ln();




if(INVOICEHEADER){
	$pdf->SetY(42);
	$ix=100;
	$pdf->SetX($ix-3);
	$pdf->SetFont('','', 9);

	$pdf->Cell(0,"5","Invoice From",0,0,'L');
	$pdf->Ln();

	$pdf->SetFont('','', 8);
	$hd=explode("\n", strip_tags(INVOICEHEADER));
	$ht="5";
	if(is_array($hd)){
		foreach($hd as $h => $d){
			$pdf->SetX($ix);
			$pdf->Cell(0,$ht,$d,0,0,'L');
			$pdf->Ln();
		}
	} else { 
		$pdf->SetX($ix);
		$pdf->Cell(0,$ht,INVOICEHEADER,0,0,'L');
		$pdf->Ln();
	}
}




$pdf->SetY(90);
$pdf->FancyTable($header,$data);


if(taxEnable == "yes" && $userInfo['taxed'] == "1"){
	/* taxes */
	$taxitems=unserialize($mainBill['taxes']);
	$total=$currencyChar.$Panel->FormatNumber($mainBill['gross']+$mainBill['taxtotal'], $cid).$currencyChar2;

	foreach($taxitems as $t => $i){
		$pdf->SetFillColor(204,204,204);
		$pdf->SetTextColor(0);
		$fill=true;
		$pdf->SetX(7);
		$pdf->Cell('170',6,$i['description']." (".$i['rate']."%)".':','LRB',0,'R',$fill);
		$pdf->Cell('26',6,$currencyChar.$Panel->FormatNumber($i['total'], $cid).$currencyChar2,'LRB',0,'R',$fill);
		$pdf->Ln();
	}

}



/* total */
$pdf->SetFillColor(204,204,204);
$pdf->SetTextColor(0);
$fill=true;
$pdf->SetX(7);
$pdf->Cell('170',6,$txt_total.':','LRB',0,'R',$fill);
$pdf->Cell('26',6,$total,'LRB',0,'R',$fill);
$pdf->Ln();

$pdf->SetFont('DejaVu','',8);
$pdf->Cell(0,10,$txt_login.url,0,0,'C');

$pdf->Output();

?>