<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your system.
	
	

	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


$billingPage=true;
require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

if(!isset($mode) || isset($mode) && !$mode) $mode = "edit";

$GameCP->CheckPermissions('donations');

$GameCP->SetURLCookie();

if(usebilling != "1"){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("This feature is not enabled. (donations)");
}

if(isset($_SESSION['gamecp']['basic']) && $_SESSION['gamecp']['basic'] == "1"){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("This feature is not enabled with the current license. (donations)");
}

if($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
	$dq = "AND cid='".$_SESSION['gamecp']['userinfo']['id']."'";
} $dq="";

// users cant add, edit or remove, only list
if($_SESSION['gamecp']['userinfo']['ulevel'] != "0"){

	if ($mode == "update" && DEMO != "yes") { 
		sql_query($safesql->query("UPDATE donations SET 
										cid='%s',
										gateway='%s',
										gross='%s',
										fee='%s',
										paid='%s',
										transactionid='%s',
										status='%s',
										ipaddr='%s',
										email='%s',
										date='%s'
						WHERE id='%i' ", array(
						$GameCP->whitelist($donationcid, "int"),
										$GameCP->whitelist($gateway, "clean"),
										$GameCP->whitelist($gross, "clean"),
										$GameCP->whitelist($fee, "clean"),
										$GameCP->whitelist($paid, "clean"),
										$GameCP->whitelist($transactionid, "clean"),
										$GameCP->whitelist($status, "clean"),
										$GameCP->whitelist($ipaddr, "clean"),
										$GameCP->whitelist($email, "clean"),
										time(),	
						$GameCP->whitelist($donationid, "int")))) or die(mysql_error());
		$smarty->assign("showSaved", true);
		if(debugging == "0"){
			$mode = "edit";
		} else echo "Saved";
	}

	if ($mode == "add" && DEMO != "yes") {
		sql_query($safesql->query("INSERT INTO donations SET 
										cid='%s',
										gateway='%s',
										gross='%s',
										fee='%s',
										paid='%s',
										transactionid='%s',
										status='%s',
										ipaddr='%s',
										email='%s',
										date='%s'", array(
						$GameCP->whitelist($donationcid, "int"),
										$GameCP->whitelist($gateway, "clean"),
										$GameCP->whitelist($gross, "clean"),
										$GameCP->whitelist($fee, "clean"),
										$GameCP->whitelist($paid, "clean"),
										$GameCP->whitelist($transactionid, "clean"),
										$GameCP->whitelist($status, "clean"),
										$GameCP->whitelist($ipaddr, "clean"),
										$GameCP->whitelist($email, "clean"),
										time()))) or die(mysql_error());

		$smarty->assign("showSaved", true);
		if(debugging == "0"){
			$mode = "edit";
		} else echo "Saved";
	}

	if ($mode == "remove" && DEMO != "yes") {
		sql_query($safesql->query("DELETE FROM donations WHERE id='%i' LIMIT 1", array($GameCP->whitelist($donationid, "int")))) or die(mysql_error());
		$smarty->assign("showSaved", true);
		$mode = "edit";
	}
}

	if($mode == "edit") { 

		if($_SESSION['gamecp']['userinfo']['ulevel'] != "0" && isset($_REQUEST['cid'])) $dq="AND cid='".$GameCP->whitelist($_REQUEST['cid'], "int")."'";

		$donations=array();
		$result = sql_query("SELECT * FROM donations WHERE id !='' $dq ORDER BY id ASC") or die(mysql_error());
		while ($row = mysql_fetch_array($result)){
			$unq = sql_query("SELECT name FROM users WHERE id = '".$row['cid']."' LIMIT 1") or die(mysql_error());
			$un = mysql_fetch_array($unq);
			$row['name']=$un[0];
			$donations[]=$row;
		}

		$smarty->assign("categoryList",$donations);
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$smarty->assign("Panel",$Panel);
		$smarty->display("donations/donation-list.tpl");
	} 


	if($mode == "edit2" || $mode =="new") {
		if($mode == "edit2"){
			$info = sql_query($safesql->query("SELECT * FROM donations WHERE id = '%i' $dq LIMIT 1", array($GameCP->whitelist($donationid, "int")))) or die(mysql_error());
			$categoryInfo = mysql_fetch_array($info);
			$smarty->assign("categoryInfo",$categoryInfo);
			$smarty->assign("donationid",$donationid);
		} else {
			$categoryInfo=array();
			$categoryInfo['gateway']='';
		}

		$gateways=array();
		$result = sql_query("SELECT * FROM gateways ORDER BY 'fullname'") or die(mysql_error());
		while ($row = mysql_fetch_array($result)){
			if($row['name']==$categoryInfo['gateway'])$row['selected']=true;
			$gateways[]=$row;
		}
		$smarty->assign("gatewayList",$gateways);
		$smarty->display("donations/donation-edit.tpl");
	}



require_once(path.'/includes/core/editable/footer.inc.php');


?>