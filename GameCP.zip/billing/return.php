<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

if(!isset($loaded)){
	require('../includes/core/includes/user/session.inc.php');
	require('../includes/config.inc.php');
	$GameCP->loadIncludes("billing");
	$Billing=new Billing();
}

if($_SESSION['gamecp']['billing']['payment']==false){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("Request has failed, payment already applied");
}

if(isset($_REQUEST['paymentcode'])) $paymentCode=$GameCP->whitelist($_REQUEST['paymentcode']);
$paymentCode=$GameCP->whitelist($paymentCode, "useredit");

if(!$paymentCode || isset($_REQUEST['orderStatus']) || isset($_REQUEST['responseMessage'])){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("Request has failed, unable to load gateway");
} else {

	if(isset($orderStatus)) $orderStatus=$GameCP->whitelist($orderStatus);

	$paidPrice="";
	$paidFee="";
	$transactionid="";
	$subid="";
	$responseMessage="";
	$bid=$_SESSION['gamecp']['payment']['bid'];
	$cid=$_SESSION['gamecp']['payment']['cid'];

	$Billing->ValidateUser($cid, $bid);
	
	$_SESSION['gamecp']['billing']['payment']=false;

	if(isset($paymentCode) && $paymentCode != "") $Billing->LoadGateway($paymentCode, true);

	if(isset($_SESSION['gamecp']['subuser']['id'])) $subid=$_SESSION['gamecp']['subuser']['id'];

	$GameCP->loadIncludes("billing");
	$Billing=new Billing();

	if($_SESSION['gamecp']['payment']['free'] == true) $orderStatus = "Completed";

	switch($orderStatus){
		case "Failed":
			$Billing->NotifyPayment($cid, true, $bid, $orderStatus, $paidPrice, $responseMessage);
		break;

		case "Completed":
			if($bid) $Billing->AddPayment($bid, $paidPrice, $subid, $transactionid, $paymentCode, $paidFee);		
			$responseMessage = "Payment Completed";
		break;
		
		case "Pending":
			if($bid){
				$Billing->AddPayment($bid, $paidPrice, $subid, $transactionid, $paymentCode, $paidFee);
				sql_query($safesql->query("UPDATE billing SET status = 'Pending' WHERE id = '%i'", array($GameCP->whitelist($bid, "int"))));
			}
			$responseMessage = "Payment Pending";
		break;

		case "IPN":
			$responseMessage = "Your payment has been received and will be processed shortly.";
		break;
	}


	$smarty->assign("reply", $responseMessage);
	$smarty->display("billing/payment-reply.tpl");
	unset($_SESSION['gamecp']['payment']);
}


require_once(path.'/includes/core/editable/footer.inc.php');

?>