<?php
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


$billingPage=true;
require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');


$GameCP->CheckPermissions('payment');

if(usebilling != "1"){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("This feature is not enabled. (payments)");
}

if(isset($_SESSION['gamecp']['basic']) && $_SESSION['gamecp']['basic'] == "1"){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("This feature is not enabled with the current license. (payments)");
}

if(isset($_SESSION['gamecp']['payment'])) unset($_SESSION['gamecp']['payment']);
$_SESSION['gamecp']['billing']['payment']=true;

$GameCP->loadIncludes("billing");
$Billing=new Billing(); 

$GameCP->loadIncludes("order");
$Order=new Order();
$smarty->assign("Order", $Order);

$mode=$GameCP->whitelist($mode);
$bid=$GameCP->whitelist($bid);
$idd=$GameCP->whitelist($idd);

if(!isset($mode) || isset($mode) && !$mode) { 
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();  
	$Panel->ErrorExit("Please go back to billing and select your payment option");
} 

if(!$bid || !$idd){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();  
	$Panel->ErrorExit("There was an error while trying to pay this bill");
}

if($bid || $cid) $Billing->ValidateUser($cid, $bid);

$billInformation = sql_query($safesql->query("SELECT B.gross, U.*, B.daystill, B.taxtotal, B.taxes FROM billing B, users U WHERE B.status = 'Pending' AND B.cid = U.id AND U.id = '%i' AND B.id = '%i'", array($GameCP->whitelist($idd, "int"),$GameCP->whitelist($bid, "int")))) or die(mysql_error());
$info = mysql_fetch_array($billInformation);

$billInformation = sql_query($safesql->query("SELECT sum(total) FROM payments WHERE bid = '%i'", array($GameCP->whitelist($bid, "int")))) or die(mysql_error());
$info2 = mysql_fetch_array($billInformation);

if($info['currency']){
	$result = sql_query("SELECT * FROM currencies WHERE code='".$info['currency']."'") or die(mysql_error());
	$exchange = mysql_fetch_array($result);
	$smarty->assign('currencyName', $exchange['code']);
	$smarty->assign('currencyChar', $exchange['prefix']);
	$smarty->assign('currencyChar2', $exchange['suffix']);

}

$credit=$info['credit'];
$grossDue=$info['gross'];
$grossPaid=$info2[0];
$totalDue=$grossDue-$grossPaid;
$acctcredit="";
if($credit > 0){
	if($credit >= $totalDue){
		$acctcredit=$totalDue;
		$free=true;
		$totalDue="0";

	} else {
		$totalDue=$totalDue-$credit;
		$acctcredit=$credit;
	}
	if($acctcredit > 0) $Billing->Credit($bid, $acctcredit);
}

$GameCP->loadIncludes("panel");
$Panel=new Panel();

if(!$totalDue){
	$free=true;
	$totalDue="0.00";
} else $free=false;

if(taxEnable == "yes" && $info['taxtotal'] && $info['taxed'] == "1"){
	$totalDue=$totalDue+$info['taxtotal'];
	$tax=unserialize($info['taxes']);
	$taxx=array();
	foreach($tax as $t=>$a){
		$a['total']=$Panel->FormatNumber($a['total'], $idd);
		$taxx[]=$a;
	}
	$smarty->assign("taxitems",$taxx);
}

$info['gross']=$Panel->FormatNumber($totalDue, $idd);
$info['plaingross']=$Panel->RemFormatNumber($totalDue);
$info['credit']=$Panel->FormatNumber($credit, $idd);

$_SESSION['gamecp']['orderDetails']=$_SESSION['gamecp']['userinfo'];
$_SESSION['gamecp']['payment']['bid']=$bid;
$_SESSION['gamecp']['payment']['cid']=$cid;
$loadOut="internal";


$smarty->display("billing/payment-header.tpl");

$smarty->assign("info",array($info));
$smarty->assign("bid",$bid);
$smarty->assign('urlstring', "&payId=$bid&credit=$credit");
$smarty->assign('return', "/billing/return.php");
$smarty->assign('MAILINGADDRESS', nl2br(MAILINGADDRESS));
$smarty->assign("today", time());
if(paypalSubscriptions == "yes") $smarty->assign("paypalSubscriptions", "true");

if($info['daystill'] == "0") { $monthlyterm="0"; } else
if($info['daystill'] <= "31") { $monthlyterm="1"; } else
if($info['daystill'] > "31" && $info['daystill'] <= "91") { $monthlyterm="3"; } else
if($info['daystill'] > "91" && $info['daystill'] <= "182") { $monthlyterm="6"; } else
if($info['daystill'] > "182" && $info['daystill'] <= "365") { $monthlyterm="12"; } else
if($info['daystill'] > "365" && $info['daystill'] <= "730") { $monthlyterm="24"; } else $monthlyterm="1"; 
$smarty->assign("monthlyterm", $monthlyterm);

$Billing->InvoiceDescription('invoice', array('name' => $info['username'], 'bid' =>$bid));

$smarty->display("billing/tos.tpl");

if($free == true){
	$smarty->display("billing/payment-free.tpl");
	$_SESSION['gamecp']['payment']['free']=true;
} else {
	if(isset($_SESSION['gamecp']['payment']['free'])) unset($_SESSION['gamecp']['payment']['free']);

	$gateway=$Billing->LoadGateway($mode);

	$smarty->assign('gatewayTesting', $gateway['testing']);
	$smarty->assign('privkey', urlencode(md5($gateway['value1'].$bid)));
	$smarty->assign('value1', $gateway['value1']);
	$smarty->assign('value2', $gateway['value2']);
	$smarty->assign('value3', $gateway['value3']);
	$smarty->assign('gateway', $gateway);

	$smarty->display("gateways/".$mode."/form.tpl");
}



$smarty->display("billing/payment-footer.tpl");


require_once(path.'/includes/core/editable/footer.inc.php');

?>