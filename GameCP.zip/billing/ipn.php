<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


/* 

- Updated 3/11/2009 
Used paypals new code generator to get updated code


*/

require('../includes/config.inc.php');
$GameCP->loadIncludes("billing");
$Billing=new Billing();
require_once(path.'/includes/core/classes/gamecp/event.inc.php');

$Event = new Event();
$ipnNotifyEmail=emailNotify;

$instance=substr(time(), 5);
$Event->EventLogAdd('', "#$instance - IPN system was triggered, notifications sent to $ipnNotifyEmail - ". date('l jS \of F Y h:i:s A'));

error_reporting(0);

$GameCP->loadIncludes("email");


$gatewayDetailsQ = sql_query("SELECT testing FROM gateways WHERE name - 'PayPal' LIMIT 1") or die(mysql_error());
$gatewayDetails = mysql_fetch_array($gatewayDetailsQ);

if($gatewayDetails['testing'] == "1"){
	$authType = "2"; 
} else $authType = "1"; 





if (!$_POST['txn_type']){ 
	header("HTTP/1.0 404 Not Found");
	exit;
}


// read the post from PayPal system and add 'cmd'
$req = 'cmd=_notify-validate';

foreach ($_POST as $key => $value) {
	$value = urlencode(stripslashes($value));
	$req .= "&$key=$value";
}


// post back to PayPal system to validate
$header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";

if($authType == 1){
	$port = fsockopen ("ssl://www.paypal.com", 443, $errno, $errstr, 15);
} elseif ($authType == 2){
	$port = fsockopen ("ssl://www.sandbox.paypal.com", 443, $errno, $errstr, 15);
} else {
	$Email->emailto = $ipnNotifyEmail;
	$Email->emailsubject = "PayPal IPN Invalid access";
	$Email->emailbody = "Invalid access was made to your ipn.php - here are the details:<br><br>".serialize($_POST)." <br><br> -  Your GameCP IPN";
	$Email->send();
	$Event->EventLogAdd('', "#$instance - IPN system received invalid auth type - ". date('l jS \of F Y h:i:s A'));
	exit; 
}


$Event->EventLogAdd('', "#$instance - IPN system connected to PayPal - ". date('l jS \of F Y h:i:s A'));

// Assign all variables.
	$business = $_POST['business'];
	$receiver_email = $_POST['receiver_email'];
	$item_name = $_POST['item_name'];
	$item_number = $_POST['item_number'];
	$quantity = $_POST['quantity'];
	$invoice = $_POST['invoice'];
	$custom = $_POST['custom'];
	$memo = $_POST['memo'];
	$tax = $_POST['tax'];
	$option_name1 = $_POST['option_name1'];
	$option_selection1 = $_POST['option_selection1'];
	$option_name2 = $_POST['option_name2'];
	$option_selection2 = $_POST['option_selection2'];
	$num_cart_items = $_POST['num_cart_items'];
	$payment_status = $_REQUEST['payment_status'];
	$pending_reason = $_POST['pending_reason'];
	$reason_code = $_POST['reason_code'];
	$payment_date = $_POST['payment_date'];
	$txn_id = $_POST['txn_id'];
	$txn_type = $_POST['txn_type'];
	$payment_type = $_POST['payment_type'];
	$mc_gross = $_POST['mc_gross'];
	$mc_fee = $_POST['mc_fee'];
	$mc_currency = $_POST['mc_currency'];
	$settle_amount = $_POST['settle_amount'];
	$settle_currency = $_POST['settle_currency'];
	$exchange_rate = $_POST['exchange_rate'];
	$payment_gross = $_POST['payment_gross'];
	$payment_fee = $_POST['payment_fee'];
	$for_auction = $_POST['for_auction'];
	$auction_buyer_id = $_POST['auction_buyer_id'];
	$auction_closing_date = $_POST['auction_closing_date'];
	$auction_multi_item = $_POST['auction_multi_item'];
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$address_name = $_POST ['address_name'];
	$address_street = $_POST['address_street'];
	$address_city = $_POST['address_city'];
	$address_state = $_POST['address_state'];
	$address_zip = $_POST['address_zip'];
	$address_country = $_POST['address_country'];
	$address_status = $_POST['address_status'];
	$payer_email = $_POST['payer_email'];
	$payer_id = $_POST['payer_id'];
	$payer_status = $_POST['payer_status'];
	$notify_version = $_POST['notify_version'];
	$verify_sign = $_POST['verify_sign'];
	$subscr_date = $_POST['subscr_date'];
	$subscr_effective = $_POST['subscr_effective'];
	$period1 = $_POST['period1'];
	$period2 = $_POST['period2'];
	$period3 = $_POST['period3'];
	$amount1 = $_POST['amount1'];
	$amount2 = $_POST['amount2'];
	$amount3 = $_POST['amount3'];
	$mc_amount1 = $_POST['mc_amount1'];
	$mc_amount2 = $_POST['mc_amount2'];
	$mc_amount3 = $_POST['mc_amount3'];
	$recurring = $_POST['recurring'];
	$reattempt = $_POST['reattempt'];
	$retry_at = $_POST['retry_at'];
	$recur_times = $_POST['recur_times'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$subscr_id = $_POST['subscr_id'];
	$qid=$_REQUEST['qid'];
	$test_ipn = $_POST['test_ipn'];
	$payment_amount = $_POST['mc_gross'];
	$credit = $_POST['credit'];





if (!$port && !$errstr) {
	$Email->emailto = $ipnNotifyEmail;
	$Email->emailsubject = "PayPal IPN Failed";
	$Email->emailbody = "The GameCP IPN was unable to communicate to the paypal server ssl://www.paypal.com. There was no error message provided. <br><br><b>Report:</b><br> ".serialize($_REQUEST)." <br><br> -  Your GameCP IPN";
	$Email->send();
	$Event->EventLogAdd('', "#$instance - IPN system failed to connect to PayPal 1 - ". date('l jS \of F Y h:i:s A'));
	exit;
} else if(!$port){
	$Email->emailto = $ipnNotifyEmail;
	$Email->emailsubject = "PayPal IPN Failed.";
	$Email->emailbody = '<br>The GameCP IPN was unable to communicate to the paypal server ssl://www.paypal.com. There was no error message provided.<br><br><b>Error #:</b> $errno <br><br><b>Error Message:</b><br> $errstr <br><br><br><br>Report: '.serialize($_REQUEST).' <br>';
	$Email->send();
	$Event->EventLogAdd('', "#$instance - IPN system failed to connect to PayPal 2 - ". date('l jS \of F Y h:i:s A'));
	exit;
} else {
	fputs ($port, $header . $req);
	while (!feof($port)) {
		$response = fgets ($port, 2048);
		$response = trim ($response);
	}

	if(!$response){
		$Email->emailto = $ipnNotifyEmail;
		$Email->emailsubject = "PayPal IPN Failed.";
		$Email->emailbody = '<br>The GameCP IPN did not receive a response from PayPal.<br><br>Report: '.serialize($_REQUEST).' <br>';
		$Email->send();
		$Event->EventLogAdd('', "#$instance - IPN system failed to connect to PayPal 3 - ". date('l jS \of F Y h:i:s A'));
		exit;
	} elseif (!strcmp ($response, "VERIFIED") || $test_ipn == "1"){
		// item was signed-up
		if($txn_type == "subscr_signup" || ($txn_type == "web_accept" && $qid)){
			$Event->EventLogAdd('', "#$instance - IPN system received sign-up - ". date('l jS \of F Y h:i:s A'));

			$Email->emailto = $ipnNotifyEmail;
			if($_REQUEST['subscr_id'] != ""){
				$Email->emailsubject = "New Client Subscription Sign-up";
			} else $Email->emailsubject = "New Client Sign-up";

			$Email->emailbody = "<br>The GameCP IPN system was triggered:<br><hr>Joined: ".date('l jS \of F Y h:i:s A')."<hr><br><b>Report:</b> ". serialize($_REQUEST) ."<hr>- Your GameCP IPN";
			$Email->send();

			if($_REQUEST['qid']){	
				$qid=$_REQUEST['qid'];
				$Event->EventLogAdd('', "#$instance - Queue #$qid detected - ". date('l jS \of F Y h:i:s A'));

				$checkQ = sql_query("SELECT user, status, `mod` FROM queue where id='".$qid."'") or die(mysql_error()); 
				$qInfo=mysql_fetch_row($checkQ);

				if($payment_status == "Completed"){ 
					$Event->EventLogAdd('', "#$instance - Queue #$qid payment completed $payment_amount, ".$mod['gross'].", ". $qInfo[1]." @ ". date('l jS \of F Y h:i:s A'));
					$mod=unserialize($qInfo[2]);
					if($payment_amount >= $mod['gross']) $mod['status']="Completed";
					$mod['paidPrice']=$payment_amount;
					$mod['fee']=$mc_fee;
					$mod['subscr_id']=$subscr_id;
					sql_query("UPDATE queue SET `mod`='".serialize($mod)."' where id='".$qid."'") or die(mysql_error()); 
					if($payment_amount >= $mod['gross'] && $qInfo[1] == "3"){
						$Event->EventLogAdd('', "#$instance - Queue #$qid executed - ". date('l jS \of F Y h:i:s A'));
						$GameCP->loadIncludes("panel");
						$Panel=new Panel();
						$Panel->ExecQueue($qid);
					}
				}
			} elseif(isset($_REQUEST['payId'])){
				//this is a sub-signup but not a new order, this is a sub-signup on a bill payment
				// take the sub-id and apply it to the bill
				$Event->EventLogAdd('', "#$instance - Bill #$qid detected, applying subscription id - ". date('l jS \of F Y h:i:s A'));
				sql_query("UPDATE billing SET subscr_id='$subscr_id' WHERE id='".$_REQUEST['payId']."'") or die(mysql_error()); 
			}
		}

		if($txn_type == "subscr_payment" || ($txn_type == "web_accept" && $_REQUEST['payId'])){
			$Event->EventLogAdd('', "#$instance - IPN system received payment - ". date('l jS \of F Y h:i:s A'));
				
			// sub payment = always
			// web_accept = one time + payId = bill payment
			if($payment_status == "Completed"){ 

				if($subscr_id){

					$subbased_idQ = sql_query("SELECT id FROM billing WHERE subscr_id='$subscr_id' LIMIT 1;") or die(mysql_error()); 

					$checkQ = sql_query("SELECT user, status, `mod` FROM queue where id='".$qid."'") or die(mysql_error()); 
					$qInfo=mysql_fetch_row($checkQ);

					if(mysql_num_rows($subbased_idQ) == "1"){
						$bInfo=mysql_fetch_row($subbased_idQ);
						$totalWithPaid=$Billing->AddPayment($bInfo[0], $payment_amount, $subscr_id, $txn_id, 'PayPal', $mc_fee, false, false, true, false);
					} elseif(isset($_REQUEST['donationid'])){
$Event->EventLogAdd('', "#$instance - Donation to $donationid detected - ". date('l jS \of F Y h:i:s A'));
$Billing->AddDonation($donationid, 'PayPal', $_REQUEST['gross'], $mc_fee, $payment_amount, $txn_id, 'Completed', '', $payer_email);
					} elseif(isset($_REQUEST['payId'])){
						$Billing->AddPayment($_REQUEST['payId'], $payment_amount, $subscr_id, $txn_id, 'PayPal', $mc_fee, false, false, true, false);
					} elseif($qInfo[1] == "3"){
						$mod=unserialize($qInfo[2]);
						if($payment_amount >= $mod['gross']) $mod['status']="Completed";
						$mod['paidPrice']=$payment_amount;
						$mod['suspend_notpaid']=true;
						$mod['fee']=$mc_fee;
						$mod['subscr_id']=$subscr_id;
						sql_query("UPDATE queue SET `mod`='".serialize($mod)."' where id='".$qid."'") or die(mysql_error()); 
						if($payment_amount >= $mod['gross'] && $qInfo[1] == "3"){
							$GameCP->loadIncludes("panel");
							$Panel=new Panel();
							$Panel->ExecQueue($qid);
						}
					} else {
						$Email->emailto = $ipnNotifyEmail;
						$Email->emailsubject = "PayPal Transaction Failed";
						$Email->emailbody = "This payment was accepted but could not be processed.<br><hr>Total Paid: $payment_amount<br>Time: ".date('l jS \of F Y h:i:s A')."<br>Subscription ID: $subscr_id <br> ".serialize($_REQUEST)."<hr>- Your GameCP IPN<br>";
						$Email->send();
						exit;
					}
				} elseif(isset($_REQUEST['payId'])) $Billing->AddPayment($_REQUEST['payId'], $payment_amount, $subscr_id, $txn_id, 'PayPal', $mc_fee, false, false, true, false);
				
			} // end completed status
		} // end payment only options

		// subscription canceleld
		if($txn_type == "subscr_cancel"){
			//$Event->EventLogAdd('', "#$instance - IPN system received cancellation bill #$billId - ". date('l jS \of F Y h:i:s A'));
			$Email->emailto = $ipnNotifyEmail;
			$Email->emailsubject = "A subscription has been canceled.";
			$Email->emailbody = "This subscription has been canceled.<br>GameCP IPN does not automatically cancel users accounts when they cancel subscriptions.<br>Please validate this and cancel the account.<hr>Invoice ID: ". $_POST['item_name']. "<br>Subscription ID: "  .$_REQUEST['subscr_id'] ."<br>Time: ".date('l jS \of F Y h:i:s A')."<hr>- Your GameCP IPN ";
			$Email->send();
		}

		// item is pending
		if($payment_status == "Pending"){	
			if(isset($_REQUEST['donationid'])){
				$Event->EventLogAdd('', "#$instance - Donation to $donationid detected - ". date('l jS \of F Y h:i:s A'));
				$Billing->AddDonation($donationid, 'PayPal', $_REQUEST['gross'], $mc_fee, $payment_amount, $txn_id, 'Pending', '', $payer_email);
			} 
			$Email->emailto = $ipnNotifyEmail;
			$Email->emailsubject = "PayPal Payment Pending";
			$Email->emailbody = "<br>This payment is marked as pending from PayPal, server bill will need to be updated when the payment has been accepted from PayPal.<br><br>".date('l jS \of F Y h:i:s A')."<br><br>Subscription ID: $subscr_id <br><br> ".serialize($_REQUEST)."";
			$Email->send();
		}

		// item refunded
		if($payment_status == "Refunded"){
			$Email->emailto = $ipnNotifyEmail;
			$Email->emailsubject = "PayPal Payment Refunded";
			$Email->emailbody = "<br>This payment is marked as refunded from PayPal, Please manually adjust your GameCP billing to reflect this change.<br><br>".date('l jS \of F Y h:i:s A')."<br><br>Subscription ID: $subscr_id <br><br> ".serialize($_REQUEST)."";
			$Email->send();
		}


	} elseif (!strcmp ($response, "INVALID")){
		$Email->emailto = $ipnNotifyEmail;
		$Email->emailsubject = "PayPal Invalid IPN Transaction.";
		$Email->emailbody = '<br>PayPal Invalid IPN Transaction.<br><br>Report: '.serialize($_REQUEST).' <br>';
		$Email->send();
	} else {
		$Email->emailto = $ipnNotifyEmail;
		$Email->emailsubject = "PayPal IPN Error.";
		$Email->emailbody = '<br>FATAL error has occurd.<br><br>Report: '.serialize($_REQUEST).' <br>';
		$Email->send();
	}

	fclose ($port);
	exit;
}
?>