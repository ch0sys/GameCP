<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

if (isset($_REQUEST['mode']) && ($_REQUEST['mode'] == "print")) $noheader=true;

require('../includes/core/includes/user/session.inc.php');

if(@$_SESSION['gamecp']['view']['userbill'] != "" && @$_REQUEST['update'] == "status") $noheader=true;

$billingPage=true;
require('../includes/config.inc.php');

$GameCP->CheckPermissions('billing');

$GameCP->SetURLCookie();

if(usebilling != "1" || isset($_SESSION['gamecp']['basic'])){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("This feature is not enabled. (billing i)");
}

if(isset($_SESSION['gamecp']['subaccount']) && !in_array('8', $_SESSION['gamecp']['subuser']['perms'])){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("Invalid access");
}


$GameCP->loadIncludes("billing");
$Billing=new Billing();

if(isset($bid) || isset($cid)) $Billing->ValidateUser(@$cid, @$bid);


if(isset($_REQUEST['bid'])) $_REQUEST['bid']=$GameCP->whitelist($_REQUEST['bid'], "int");
if(isset($_REQUEST['mode'])) $_REQUEST['mode']=$GameCP->whitelist($_REQUEST['mode']);
if(isset($_REQUEST['view'])) $_REQUEST['view']=$GameCP->whitelist($_REQUEST['view']);
if(isset($_SESSION['gamecp']['view']['userbill']) && isset($update) && $update != "status") unset($_SESSION['gamecp']['view']['userbill']);

if(isset($_REQUEST['mode']) && $_REQUEST['mode'] == "print"){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$GameCP->loadIncludes("billing");
	$Billing=new Billing();

	$cid=$GameCP->whitelist($idd, "int");
	$bid=$GameCP->whitelist($bid, "int");

	$userInfo=$Panel->GetUser($cid);
	$invoicedata=$Billing->InvoiceData($cid, $bid);
	$mainBill=$invoicedata[2];
	$dueDate=$invoicedata[4];
	$total=$Panel->FormatNumber($mainBill['gross'], $cid, true);

	if(taxEnable == "yes" && $userInfo['taxed'] == "1"){
		$invoicedata[1]=$Billing->TaxReduction($invoicedata[1]);
		$total=$Panel->FormatNumber($mainBill['gross']+$Panel->RemFormatNumber($mainBill['taxtotal']), $cid, true);
		$smarty->assign("taxitems", unserialize($mainBill['taxes']));
		$smarty->assign("totaltax", $mainBill['taxtotal']);
	} 


	$smarty->assign("zero", $Panel->FormatNumber("0.00", $cid, true));
	$smarty->assign("total", $total);
	$smarty->assign("Panel", $Panel);
	$smarty->assign("cid", $cid);
	$smarty->assign("payments", $invoicedata[0]);
	$smarty->assign("package", $invoicedata[1]);
	$smarty->assign("userInfo", $userInfo);
	$smarty->assign("mainBill", $mainBill);
	$smarty->assign("dueDate", $dueDate);
	$smarty->display("billing/print.tpl");
	exit;
}


if ($_SESSION['gamecp']['userinfo']['ulevel'] == "1") { 
	if(!isset($_REQUEST['noheader']) && !isset($_REQUEST['mini'])){
		$aresultGross = sql_query("SELECT sum(gross) FROM billing WHERE status='Pending'", "total gross") or die(mysql_error()); 
		$unpaid = mysql_fetch_array($aresultGross);

		$bresultGross = sql_query("SELECT sum(gross) FROM billing WHERE status='Completed'", "total gross") or die(mysql_error()); 
		$paid = mysql_fetch_array($bresultGross);

		$resultGross = sql_query("SELECT sum(gross) FROM billing WHERE status!='Refunded' AND status!='Canceled'", "total gross") or die(mysql_error()); 
		$sumGross = mysql_fetch_array($resultGross);

		$resultFee = sql_query("SELECT sum(fee) FROM billing WHERE status!='Refunded' AND status!='Canceled'", "total fee") or die(mysql_error());
		$sumFee = mysql_fetch_array($resultFee);
		$total = $sumGross[0] - $sumFee[0];

		$resultCharge = sql_query("SELECT sum(sum) FROM charges", "total charges") or die(mysql_error());
		$sumCharge = mysql_fetch_array($resultCharge);

		$totalCharge = $total - $sumCharge[0];


		// This will update the status of a bill from the select box on the main page.
		if (isset($_REQUEST['update'])){
			$update = $_REQUEST['update']; 
		} else $update = ""; 

		if ($update == "status"){
			sql_query($safesql->query("UPDATE billing SET status ='%s' WHERE cid='%i' AND id='%i'", array($GameCP->whitelist($billStatus, "clean"),$GameCP->whitelist($idd, "int"),$GameCP->whitelist($bidd, "int")))) or die(mysql_error()); 

			if(isset($_SESSION['gamecp']['view']['userbill']) && $_SESSION['gamecp']['view']['userbill'] != ""){
				header("location: $url/manage/billing/index.php?mode=view&idd=".$_SESSION['gamecp']['view']['userbill']);
				exit;
			} 
		}
		
		if(isset($_SESSION['gamecp']['viewmanagebillsalt']) && $_SESSION['gamecp']['viewmanagebillsalt']) $view=$_SESSION['gamecp']['viewmanagebillsalt'];

		$showtoday=date(dateformat, strtotime("now"));
		$montha_01=date(dateformat, strtotime("-1 month"));


		/* could use updating */
		$compAdmin2 = "date <= '$showtoday' AND date > '$montha_01' AND"; 
		$acompAdmin2 = "B.date <= '$showtoday' AND B.date > '$montha_01' AND"; 

		$oddate=date(dateformat, strtotime("-".suspendDays . "day"));
		$overDueQ = sql_query("SELECT sum(gross) FROM billing WHERE date <= '$oddate' AND status='Pending'", "total month") or die(mysql_error());
		$overDue = mysql_fetch_array($overDueQ); 

		$aoverDueQ = sql_query("SELECT count(*) FROM billing WHERE date <= '$oddate' AND status='Pending'", "total month") or die(mysql_error());
		$aoverDue = mysql_fetch_array($aoverDueQ); 

		$completedGross2 = sql_query("SELECT sum(gross) FROM billing WHERE $compAdmin2 status='Completed'", "total month") or die(mysql_error());
		$completedFee2 = sql_query("SELECT sum(fee) FROM billing WHERE $compAdmin2 status='Completed'", "fee month") or die(mysql_error());
		$completedGrossRes2 = mysql_fetch_array($completedGross2); 
		$completedFeeRes2 = mysql_fetch_array($completedFee2);
		$completedTotal2 = $completedGrossRes2[0] - $completedFeeRes2[0]; 

		$acompletedGross2 = sql_query("SELECT sum(P.total) FROM billing B, payments P WHERE status!='Refunded' AND B.id=P.bid", "total month") or die(mysql_error());
		$acompletedFee2 = sql_query("SELECT sum(P.fee) FROM billing B, payments P WHERE status!='Refunded' AND B.id=P.bid", "fee month") or die(mysql_error());
		$acompletedGrossRes2 = mysql_fetch_array($acompletedGross2); 
		$acompletedFeeRes2 = mysql_fetch_array($acompletedFee2);

		$aacompletedGross2 = sql_query("SELECT sum(P.total-P.fee) FROM billing B, payments P WHERE UNIX_TIMESTAMP(P.time) <= '".strtotime("now")."' AND UNIX_TIMESTAMP(P.time) > '".strtotime("-1 month")."' AND status!='Refunded' AND B.id=P.bid", "total month") or die(mysql_error());
		$aacompletedGrossRes2 = mysql_fetch_array($aacompletedGross2); 
		$aamonthTotal = $aacompletedGrossRes2[0];

		$aaacompletedGross2 = sql_query("SELECT sum(P.total-P.fee) FROM billing B, payments P WHERE P.time = '$showtoday' AND status!='Refunded' AND B.id=P.bid", "total month") or die(mysql_error());
		$aaacompletedGrossRes2 = mysql_fetch_array($aacompletedGross2); 
		$atodayTotal = $aaacompletedGrossRes2[0];

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$smarty->assign("sumGross", $Panel->FormatNumber($sumGross[0]));
		$smarty->assign("sumFee", $Panel->FormatNumber($sumFee[0]));
		$smarty->assign("total", $Panel->FormatNumber($total));
		$smarty->assign("sumCharge", $Panel->FormatNumber($sumCharge[0]));
		$smarty->assign("totalCharge", $Panel->FormatNumber($totalCharge));

		$smarty->assign("atodayTotal", $Panel->FormatNumber($atodayTotal));
		$smarty->assign("amonthTotal", $Panel->FormatNumber($aamonthTotal));
		$smarty->assign("asumGross", $Panel->FormatNumber($acompletedGrossRes2[0]));
		$smarty->assign("asumFee", $Panel->FormatNumber($acompletedFeeRes2[0]));
		$smarty->assign("overdue", $Panel->FormatNumber($overDue[0]));
		$smarty->assign("overduetotal", $aoverDue[0]);
		$smarty->assign("paid", $Panel->FormatNumber($paid[0]));
		$smarty->assign("unpaid", $Panel->FormatNumber($unpaid[0]));
		$smarty->assign("monthTotal", $Panel->FormatNumber($completedTotal2));

		$Billing->ShowSpent();
	}
}

/* track so when redirected we go to best tab */
if(isset($_REQUEST['view']) && $_REQUEST['view']){
	$_SESSION['gamecp']['viewmanagebillsalt']=$_REQUEST['view'];
	$view=$_REQUEST['view'];
}elseif(isset($_SESSION['gamecp']['viewmanagebillsalt'])){
	$view=$_SESSION['gamecp']['viewmanagebillsalt'];
}else $view="pending";
if(!$view) $view="pending";

/* remember we wanted to see all, right? */
if(isset($_REQUEST['show']) && $_REQUEST['show'] == "all"){
	$_SESSION['gamecp']['view']['managebills']="all";
}elseif(isset($_REQUEST['do']) && $_REQUEST['do'] == "reset") $_SESSION['gamecp']['view']['managebills']="";
if(isset($_SESSION['gamecp']['view']['managebills']) && $_SESSION['gamecp']['view']['managebills'] == "all" && $view != "showall") $_REQUEST['show']="all";

$GameCP->loadIncludes("panel");
$Panel=new Panel();
$smarty->assign("view", $view);
$smarty->display("billing/bill-index.tpl");



require_once(path.'/includes/core/editable/footer.inc.php');

?>