<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Linux{

	function SubmitScreen($screenName, $cccommand, $fname, $sid){
		global $Backend;
		$Backend->QueryResponse($sid, '', "command:_:screen -p 0 -S $screenName -X stuff \"$cccommand\$(printf \\\\r)\"", $fname);
	}

	
	function MoveFTP($user, $fpassword, $sida, $sidb, $foldera, $folderb, $id, $fi, $type="ftp", $ftpport='21'){
		global $Backend, $GameCP, $safesql;
if($type=="lftp"){
	$movecmd="#!/bin/bash    
lftp -c \"set ftp:list-options -a;
open ftp://$user:$fpassword@$sidb:$ftpport; 
lcd $foldera;
cd $folderb;
mirror --reverse --delete --verbose\"";

} else $movecmd="ftp -n $sidb $ftpport << END_SCRIPT
quote USER ".$user."
quote PASS ".$fpassword."
passive off
mkdir ".$foldera."
cd ".$foldera."
binary
put ".$folderb."/$fi $fi
quit
END_SCRIPT";

		if($user){
			$home="/home/$user";
		} else $home="/root";
		$Backend->QueryResponse($sida,'', "writefile:_:$home/ftpcmd".$id.".sh:_:$movecmd", $user);
		$Backend->Query($sida,'', "command:_:dos2unix $home/ftpcmd".$id.".sh", $user);
	}

	function SSHAccess($idd, $bash, $update=FALSE){
		global $GameCP, $safesql;
		/* grab info for all machines this user owns */
		$row = sql_query($safesql->query("SELECT distinct(I.sid), U.name, S.os, U.demo FROM users U, iptable I, usergames UG, servers S WHERE U.id= '%i' AND I.ip = UG.ip AND UG.cid=U.id AND I.sid = S.sid", array($GameCP->whitelist($idd, "int")))) or die(mysql_error());
		while($srv=mysql_fetch_row($row)){
			$sid=$srv[0];
			$user=$srv[1];
			$os=$srv[2];
			$demo=$srv[3];
	
			$GameCP->loadIncludes("user");
			$User=new User();
			$ubash = $User->GetShell($bash, $demo);

			/* disable ssh on machine */
			if($os != "1"){
				$GameCP->loadIncludes("backend");
				$Backend=new Backend();
				$Backend->Query($sid, '', "changeshell:_:$user:_:$ubash");
			}
			
			
		}
		if($update) sql_query($safesql->query("UPDATE users SET bash = '%s' WHERE id = '%i';", array($bash, $idd)));
	}

	function Password($idd, $password){
		global $GameCP, $safesql;

		$password=$GameCP->whitelist($password, 'password');
		$row = sql_query($safesql->query("SELECT distinct(I.sid), U.name, S.os FROM users U, iptable I, usergames UG, servers S WHERE U.id= '%i' AND I.ip = UG.ip AND UG.cid=U.id AND I.sid = S.sid", array($GameCP->whitelist($idd, "int")))) or die(mysql_error());
		while($srv=mysql_fetch_array($row)){
			$sid=$srv[0];
			$user=$srv[1];
			$os=$srv[2];

			$GameCP->loadIncludes("backend");
			$Backend=new Backend();

			if($os == "1"){
				// yes this is linux class but we gonna updateftp here on password server side chante */
				$Backend->UpdateFTP($sid);
			} else $Backend->Query($sid, '', "changepass:_:$user:_:$password");
		}
	}


	function RemoveScreenLog($sid, $ggid, $fname=FALSE, $runaseuser=false){
		global $GameCP;
		if($runaseuser == true){
			$ff=$fname;
		} else $ff ="";

		if($fname){
			$dir="/home/$fname";
		} else $dir="/root";

		$screenlog="$dir/.screenrc.watch$ggid";
		$screenlog2="$dir/screenwatch$ggid.log";

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$Backend->Query($sid,'', "deletefile:_:$screenlog", $ff);
		$Backend->Query($sid,'', "deletefile:_:$screenlog2", $ff);
	}



	function Screen($sid, $command, $ggid, $fname=FALSE, $runaseuser=false){
		global $GameCP;
		if($runaseuser == true){
			$ff=$fname;
		} else $ff ="";

		if($runaseuser){
			$dir="/home/$fname";
		} else $dir="/root";


		$screenlog="$dir/.screenrc.watch$ggid";
		$screencontent= "logfile $dir/screenwatch$ggid.log\nlog on";

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$Backend->QueryResponse($sid,'', "writefile:_:$screenlog:_:$screencontent", $ff);
		echo $Backend->QueryResponse($sid,'', "command:_:screen -c $screenlog -mdLS screenwatch$ggid bash -c \"$command\"", $ff);
	}

	function Watch($sid, $ggid, $fname=FALSE, $runaseuser=false, $showlog=true, $alt=true){
		if($alt == true){
			$alt=" | tac";
		} else $alt="";
		global $GameCP;
		if($runaseuser == true){
			$ff=$fname;
		} else $ff ="";

		if($fname){
			$dir="/home/$fname";
		} else $dir="/root";

		$screencheck="screen -wipe > /dev/null ; screen -list | grep screenwatch$ggid | awk -F . '{ print $1 }' | sed -e s/.//";

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$screenStatus=$Backend->QueryResponse($sid,'', "command:_:$screencheck", $ff);
		if($showlog==true){
			$screenLog=$Backend->QueryResponse($sid,'', "command:_:cat $dir/screenwatch$ggid.log $alt", $ff);
		} else $screenLog="";

		return array($GameCP->whitelist($screenStatus, 'int'), $screenLog);
	}

	function extractCWD($code, $sid){
		if(preg_match('/[[:blank:]]*cd[[:blank:]]+([^;]+)/', $code, $regs)){
			($regs[1][0] == '/') ? $new_dir = $regs[1] : $new_dir = $_SESSION['gamecp']['terminal'][$sid]['pwd'] . '/' . $regs[1];
			while (strpos($new_dir, '/./') !== false) $new_dir = str_replace('/./', '/', $new_dir);
			while (strpos($new_dir, '//') !== false) $new_dir = str_replace('//', '/', $new_dir);
			while (preg_match('|/\.\.(?!\.)|', $new_dir)) $new_dir = preg_replace('|/?[^/]+/\.\.(?!\.)|', '', $new_dir);
			if(empty($new_dir)): $new_dir = "/"; endif;

			$_SESSION['gamecp']['terminal'][$sid]['pwd'] = trim($new_dir);
		}
	}


}
?>