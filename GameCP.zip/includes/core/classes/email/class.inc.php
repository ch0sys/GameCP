<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/**
 * Email
 * 
 * This class creates all required mail items to send to PHPMailer
 *
 */


/*
	Usage:

	$Email->templatename = "Tech-non-private";
	$Email->userid = 2;
	$Email->ugameid = 73;
	$Email->usegamedata = true;
	$Email->ReplaceStuff();
	$Email->SendtoAllManagers();

	Usage2:

	$Email->emailto = "whee@me.com";
	$Email->emailsubject = 'Account has been cancelled';
	$Email->emailbody = 'Your account $UserName has been cancelled';
	$Email->userid = 5;
	$Email->ReplaceStuff();
	$Email->send();

 */



/**
 * Email class manages all email options including building templates, mailing users/admins/support and more
 *
 */

class Email{

	var $bcc = "";

	var $usegamedata = false; // Weather or not to preg_replace game stuff
	var $usevoicedata = false; // Weather or not to preg_replace voice stuff
	var $usebilldata = false; // Weather or not to preg_replace voice stuff
	
	var $emailto = "";
	var $smsemail = "";
	var $emailfrom = "";
	
	// misc
	var $gameid = ""; // game id from `game` table
	var $ugameid = ""; // users game id from `usergames` table
	var $username = ""; // users username
	var $userid = ""; // users userid
	var $uvoiceid = ""; // users voice id from `voice` table
	var $ubillid = ""; // users voice id from `voice` table
	
	// template
	var $templatename = "";
	
	// normal
	var $emailbody = "";
	var $smsbody = "";
	var $emailsubject = "";
	var $userdb="users";

	var $attachment='';
	var $attachmentname='';


	/**
	 * get all template related items, must set a templatename
	 */
	function GetTemplateStuff(){
		global $GameCP, $safesql;
		if($this->templatename != ""){
			if(is_numeric($this->templatename)){
					$emailStuffQ = sql_query($safesql->query("SELECT subject, body, sms, title FROM emails WHERE id ='%i' LIMIT 1", array($GameCP->whitelist($this->templatename, "clean")))) or die(mysql_error());
			} else $emailStuffQ = sql_query($safesql->query("SELECT subject, body, sms FROM emails WHERE title ='%s' LIMIT 1", array($GameCP->whitelist($this->templatename, "clean"))))or die(mysql_error());
			if($emailStuffQ && mysql_num_rows($emailStuffQ) == 1){
				$emailStuff = mysql_fetch_array($emailStuffQ);
				/* set the template name if not defined */
				if(is_numeric($this->templatename)) $this->templatename = $emailStuff['title'];
				if($this->emailsubject == "") $this->emailsubject = $emailStuff['subject'];
				if($this->emailbody == "") $this->emailbody = $emailStuff['body'];
				if($this->smsbody == "") $this->smsbody = $emailStuff['sms'];
			}
		}
	}

	/**
	 * attach a file to the email
	 * @param string $file full file with path
	 * @param string $filename name to attach as
	 */
	function AddAttachment($file, $filename){
		$this->attachment = $file;
		$this->attachmentname = $filename;
	}
	
	/**
	 * search and replace email variables in the array
	 * @param string $extravars array of variables
	 */
	function ReplaceStuff($extravars=FALSE)
	{
		global $GameCP, $url, $domain, $safesql, $smarty;
			$convert=array();

		if(EMAIL == "text/html") {
			$linevar = "<br />";
		} else $linevar = "\r\n";

		
		// Replace global variable stuff
		$this->emailsubject = str_replace("\$url", $url, $this->emailsubject);
		$this->emailsubject = str_replace("\$domain", $domain, $this->emailsubject);
		$this->emailsubject = str_replace("\$today", date("m/d/Y g:i a"), $this->emailsubject);
		$this->emailsubject = str_replace("\$currency", currencyChar, $this->emailsubject);
		$this->emailsubject = str_replace("\$currencysuffix", currencyChar2, $this->emailsubject);

		$convert[]=array("var" => "\$url", "value" => $url);
		$convert[]=array("var" => "\$domain", "value" => $domain);
		$convert[]=array("var" => "\$currency", "value" => currencyChar);
		$convert[]=array("var" => "\$currencysuffix", "value" => currencyChar2);
		$convert[]=array("var" => "\$today", "value" => date("m/d/Y g:i a"));
		
		/* extra vars */
		if(is_array($extravars)){
			foreach($extravars as $evi => $ev){
				$this->emailbody = str_replace($extravars[$evi]['var'], $extravars[$evi]['value'], $this->emailbody);
				$this->smsbody = str_replace($extravars[$evi]['var'], $extravars[$evi]['value'], $this->smsbody);
				$this->emailsubject = str_replace($extravars[$evi]['var'], $extravars[$evi]['value'], $this->emailsubject);
			}
		}



		// Lets start by replacing the user stuff
		if($this->userid != "" || $this->username != "")
		{
			if($this->userid != "")
			{
				$UserInfoQ = sql_query($safesql->query("SELECT * FROM `%s` WHERE id='%s' LIMIT 1", array($GameCP->whitelist($this->userdb, "clean"),$GameCP->whitelist($this->userid, "clean"))));
			}
			elseif($this->username != "")
			{
				$UserInfoQ = sql_query($safesql->query("SELECT * FROM `%s` WHERE username='%s' LIMIT 1", array($GameCP->whitelist($this->userdb, "clean"),$GameCP->whitelist($this->username, "clean"))));
			}
			if($UserInfoQ && mysql_num_rows($UserInfoQ) == 1)
			{

				$GameCP->loadIncludes("user");
				$User=new User();
				$userPassword=$User->Password($this->userid, $this->userdb);


				$UserInfo = mysql_fetch_array($UserInfoQ);
				if($UserInfo['firstname'] == "") $UserInfo['firstname']=$UserInfo['name'];
				if($UserInfo['lastname'] == "") $UserInfo['lastname']="";

				$clientFullName=$UserInfo['firstname']." ".$UserInfo['lastname'];

				$this->emailsubject = str_replace("\$UserFullName", $clientFullName, $this->emailsubject);
				$this->emailsubject = str_replace("\$UserEmail", $UserInfo['email'], $this->emailsubject);
				$this->emailsubject = str_replace("\$UserCPName", $UserInfo['name'], $this->emailsubject);
				$this->emailsubject = str_replace("\$UserFirstName", $UserInfo['firstname'], $this->emailsubject);
				$this->emailsubject = str_replace("\$UserLastName", $UserInfo['lastname'], $this->emailsubject);
				$this->emailsubject = str_replace("\$UserID", $UserInfo['id'], $this->emailsubject);

				$convert[]=array("var" => "\$UserFullName", "value" => $clientFullName);
				$convert[]=array("var" => "\$UserCPName", "value" => $UserInfo['name']);
				$convert[]=array("var" => "\$UserEmail", "value" => $UserInfo['email']);
				$convert[]=array("var" => "\$UserPassword", "value" => $userPassword);

				/* all profile fields */
				$convert[]=array("var" => "\$UserFirstName", "value" => $UserInfo['firstname']);
				$convert[]=array("var" => "\$UserLastName", "value" => $UserInfo['lastname']);
				$convert[]=array("var" => "\$UserClan", "value" => $UserInfo['clan']);
				$convert[]=array("var" => "\$UserPhone", "value" => $UserInfo['phone']);
				$convert[]=array("var" => "\$UserAddress", "value" => $UserInfo['address']);
				$convert[]=array("var" => "\$UserAddress2", "value" => $UserInfo['address2']);
				$convert[]=array("var" => "\$UserCity", "value" => $UserInfo['city']);
				$convert[]=array("var" => "\$UserState", "value" => $UserInfo['state']);
				$convert[]=array("var" => "\$UserZip", "value" => $UserInfo['zip']);
				$convert[]=array("var" => "\$UserCountry", "value" => $UserInfo['country']);
				$convert[]=array("var" => "\$UserWebsite", "value" => $UserInfo['website']);
				$convert[]=array("var" => "\$UserNotes", "value" => $UserInfo['extranotes']);
				$convert[]=array("var" => "\$UserJoinDate", "value" =>  @date(dateformat, $UserInfo['joindate']));
				$convert[]=array("var" => "\$UserSignature", "value" => $UserInfo['signature']);

				/* be nice to some templates */
				if($this->templatename == "Lost-Password") $convert[]=array("var" => "\$Var1", "value" => $userPassword);
			
				$smarty->assign('User', $UserInfo);


			}
		}



		if($this->usebilldata == true){
			if($this->ubillid != ""){
				$userBillQ = sql_query($safesql->query("SELECT * FROM billing WHERE id='%i' LIMIT 1;", array($GameCP->whitelist($this->ubillid, "int")))) or die(mysql_error());
			} else $userBillQ = sql_query($safesql->query("SELECT * FROM billing WHERE cid='%i';", array($GameCP->whitelist($this->userid, "int")))) or die(mysql_error());
			
			$res=array();
			while($userBill = mysql_fetch_array($userBillQ)){


				$GameCP->loadIncludes("panel");
				$Panel=new Panel();

				/* main bill */
				$convert[]=array("var" => "\$BillId", "value" => $userBill['id']);
				$convert[]=array("var" => "\$BillDate", "value" => $userBill['date']);
				$convert[]=array("var" => "\$BillStatus", "value" => $userBill['status']);
				if(taxEnable == "yes" && $UserInfo['taxed'] == "1"){
					$convert[]=array("var" => "\$BillGross", "value" => $Panel->FormatNumber($userBill['gross']+$userBill['taxtotal']));
				} else 	$convert[]=array("var" => "\$BillGross", "value" => $Panel->FormatNumber($userBill['gross']));
				$convert[]=array("var" => "\$BillTax", "value" => $Panel->FormatNumber($userBill['taxtotal']));
				$convert[]=array("var" => "\$BillFee", "value" => $Panel->FormatNumber($userBill['fee']));
				$convert[]=array("var" => "\$BillTotalDays", "value" => $userBill['daystill']);
				$convert[]=array("var" => "\$BillSubscription", "value" => $userBill['subscr_id']);

				if($userBill['daystill'] == "31") { $BillingTerm="Monthly"; } else
				if($userBill['daystill'] == "91") { $BillingTerm="Quarterly"; } else
				if($userBill['daystill'] == "182") { $BillingTerm="Semi-Annually"; } else
				if($userBill['daystill'] == "365") { $BillingTerm="Anually"; } else
				if($userBill['daystill'] == "730") { $BillingTerm="2-Years"; } else $BillingTerm="Other"; 


				if(taxEnable == "yes" && $UserInfo['taxed'] == "1"){
					$userBill['gross']=$Panel->FormatNumber($userBill['gross']+$userBill['taxtotal']);
				} else $userBill['gross']=$Panel->FormatNumber($userBill['gross']);
				$userBill['taxtotal']=$Panel->FormatNumber($userBill['taxtotal']);
				$userBill['fee']=$Panel->FormatNumber($userBill['fee']);

				$userBill['term']=$BillingTerm;

				$GameCP->loadIncludes("billing");
				$Billing=new Billing();

				$convert[]=array("var" => "\$BillDaysTill", "value" => str_replace("-", "", $Billing->DateDifference(date(dateformat, strtotime($userBill['date'])), date(dateformat, strtotime('now')))));
				$convert[]=array("var" => "\$BillingTerm", "value" => $BillingTerm);
				$BillDetails="";

				/* sub bills */
				$sub=array();
				$billDetailsQ = sql_query("SELECT P.name as 'package', UB.gross, UB.id as 'ubid', UP.name as 'product', UB.fee, UB.description FROM userbills UB, prices P, packages UP WHERE UB.bid = '".$userBill['id']."' AND UB.pid = P.id AND P.pid = UP.id ORDER BY P.name");
				while($billDetails = mysql_fetch_array($billDetailsQ)){
					$sub[]=$billDetails;
					$mailmode="bill";
					require(path."/includes/core/editable/mail-gameinfo.php");
				}
				$userBill['subbills']=$sub;
				$res=$userBill;
			}
			$smarty->assign('Bill', $res);

			$convert[]=array("var" => "\$BillDetails", "value" => @$BillDetails);
		}


		// Lets replace game stuff
		if($this->usegamedata == true && $this->ugameid != "")
		{

			$UserGameInfoQ = sql_query($safesql->query("SELECT UG.ip, UG.port, S.sid, S.alias, UG.rconpass, G.name FROM usergames UG, iptable I, servers S, game G WHERE G.id = UG.gid AND cid='%i' AND I.ip=UG.ip AND I.sid=S.sid AND UG.id='%i' LIMIT 1", array($GameCP->whitelist($this->userid, "int"),$GameCP->whitelist($this->ugameid, "int")))) or die(mysql_error());
			$UserIPInfo = mysql_fetch_array($UserGameInfoQ);

			/* user game info */
			$convert[]=array("var" => "\$UserGameIp", "value" => $UserIPInfo['ip']);
			$convert[]=array("var" => "\$UserGamePort", "value" => $UserIPInfo['port']);
			$convert[]=array("var" => "\$UserGameServer", "value" => $UserIPInfo['name']);
			$convert[]=array("var" => "\$UserGameAlias", "value" => $UserIPInfo['alias']);
			$convert[]=array("var" => "\$UserGameRcon", "value" => $UserIPInfo['rconpass']);

			/* game info */
			$convert[]=array("var" => "\$GameName", "value" => $UserIPInfo['name']);
			$smarty->assign('Service', $UserIPInfo);


			$UserGameInfo="";
			$mailmode="game";
			require(path."/includes/core/editable/mail-gameinfo.php");
			$convert[]=array("var" => "\$UserGameInfo", "value" => $UserGameInfo);




		}elseif($this->usegamedata == true && !$this->ugameid)
		{
			$UserGameInfo="";
			$UserIPQ = mysql_query($safesql->query("SELECT UG.ip, UG.port, S.sid, S.alias, UG.rconpass, G.name, I.internal, I.useinternal FROM usergames UG, iptable I, servers S, game G WHERE G.id = UG.gid AND cid='%i' AND I.ip=UG.ip AND I.sid=S.sid", array($GameCP->whitelist($this->userid, "int")))) or die(mysql_error());
			
				$UserIP="";
				$UserSID="";
				$RCONPASSWORD ="";
				$UserGameName="";
				$UserGameInfo="";
			if(mysql_num_rows($UserIPQ) > 1){
				$res=array();
				while ($UserIPInfo = mysql_fetch_array($UserIPQ)){
					/* grab info for the array */
					$res[]=$UserIPInfo;
					$UserSIDQ=$UserIPInfo['sid'];
					$UserAlias=$UserIPInfo['alias'];
					if($UserAlias) $UserSIDQ=$UserAlias; 


					$UserIP .= $UserIPInfo[0].":".$UserIPInfo[1] . $linevar;
					$UserSID .= $UserSIDQ . $linevar;
					$RCONPASSWORD .= $UserIPInfo["rconpass"] . $linevar;
					$UserGameName .= $UserIPInfo["name"] . $linevar;
					
					$mailmode="game";
					require(path."/includes/core/editable/mail-gameinfo.php");
				}

				$smarty->assign('Service', $res);
				$convert[]=array("var" => "\$UserGameInfo", "value" => $UserGameInfo);

			} else {
				/* user game info */
				$UserIPInfo=mysql_fetch_array($UserIPQ);

				$convert[]=array("var" => "\$UserGameIp", "value" => $UserIPInfo['ip']);
				$convert[]=array("var" => "\$UserGameInternalIp", "value" => $UserIPInfo['internal']);
				$convert[]=array("var" => "\$UserGamePort", "value" => $UserIPInfo['port']);
				$convert[]=array("var" => "\$UserGameServer", "value" => $UserIPInfo['name']);
				$convert[]=array("var" => "\$UserGameAlias", "value" => $UserIPInfo['alias']);
				$convert[]=array("var" => "\$UserGameRcon", "value" => $UserIPInfo['rconpass']);
				$smarty->assign('Service', array($UserIPInfo));

				$UserGameInfo="";
				$mailmode="game";
				require(path."/includes/core/editable/mail-gameinfo.php");
				$convert[]=array("var" => "\$UserGameInfo", "value" => $UserGameInfo);


			}

		}
		if($this->usevoicedata == true && $this->uvoiceid != "")
		{
			$UserIPQ = sql_query($safesql->query("SELECT user, maxclients, ip, port, tssid, servername, vid, id, pass, voicetype, ts3token FROM uservoice WHERE cid='%i' AND id='%i' LIMIT 1;", array($GameCP->whitelist($this->userid, "int"),$GameCP->whitelist($this->uvoiceid, "int")))) or die(mysql_error());
			$UserVoiceInfo = mysql_fetch_array($UserIPQ);
			
			if($UserVoiceInfo['tssid']){ 
				if($UserVoiceInfo['voicetype'] == "ts3"){ 
					$voiceType = "Teamspeak 3";
				} else $voiceType = "Teamspeak 2";
			} else $voiceType="Ventrilo";

			$UserVoiceInfo['type']=$voiceType;
			
			$convert[]=array("var" => "\$VoiceServerName", "value" => $UserVoiceInfo['servername']);
			$convert[]=array("var" => "\$VoicePort", "value" => $UserVoiceInfo['port']);
			$convert[]=array("var" => "\$VoiceIP", "value" => $UserVoiceInfo['ip']);
			$convert[]=array("var" => "\$VoiceMaxClients", "value" => $UserVoiceInfo['maxclients']);
			$convert[]=array("var" => "\$VoiceUser", "value" => $UserVoiceInfo['user']);
			$convert[]=array("var" => "\$VoicePass", "value" => $UserVoiceInfo['pass']);
			$convert[]=array("var" => "\$Ts3Token", "value" => $UserVoiceInfo['ts3token']);
			$convert[]=array("var" => "\$UservoiceType", "value" => $voiceType);
			$smarty->assign('Voice', array($UserVoiceInfo));

		} elseif($this->usevoicedata == true && !$this->uvoiceid)
		{
			$UserGameInfo="";
			$UserIPQ = sql_query($safesql->query("SELECT user, maxclients, ip, port, tssid, servername, vid, id, pass, voicetype, ts3token FROM uservoice WHERE cid='%i';", array($GameCP->whitelist($this->userid, "int"))))or die(mysql_error());
			$res=array();
			while ($UserIPInfo = mysql_fetch_array($UserIPQ)){
				if($UserIPInfo['tssid']){ 
					if($UserIPInfo['voicetype'] == "ts3"){ 
						$voiceType = "Teamspeak 3";
					} else $voiceType = "Teamspeak 2";
				} else $voiceType="Ventrilo";
				
				$UserIPInfo['type']=$voiceType;

				$convert[]=array("var" => "\$VoiceServerName", "value" => $UserIPInfo['servername']);
				$convert[]=array("var" => "\$VoicePort", "value" => $UserIPInfo['port']);
				$convert[]=array("var" => "\$VoiceIP", "value" => $UserIPInfo['ip']);
				$convert[]=array("var" => "\$VoiceMaxClients", "value" => $UserIPInfo['maxclients']);
				$convert[]=array("var" => "\$VoiceUser", "value" => $UserIPInfo['user']);
				$convert[]=array("var" => "\$VoicePass", "value" => $UserIPInfo['pass']);
				$convert[]=array("var" => "\$Ts3Token", "value" => $UserIPInfo['ts3token']);
				$convert[]=array("var" => "\$UservoiceType", "value" => $voiceType);
				$res[]=$UserIPInfo;

				$mailmode="voice";
				require(path."/includes/core/editable/mail-gameinfo.php");
			}

			$smarty->assign('Voice', $res);
			$convert[]=array("var" => "\$UserVoiceInfo", "value" => $UserGameInfo);
		}

		foreach($convert as $cvt) $smarty->assign($cvt['var'], $cvt['value']);
		$this->smsbody=$smarty->fetch('string:'.$this->smsbody);
		$this->emailbody=$smarty->fetch('string:'.$this->emailbody);
		$this->emailsubject=$smarty->fetch('string:'.$this->emailsubject);

		foreach($convert as $cvt){
			$this->emailsubject = str_replace($cvt['var'], $cvt['value'], $this->emailsubject);
			$this->emailbody = str_replace($cvt['var'], $cvt['value'], $this->emailbody);
			$this->smsbody = str_replace($cvt['var'], $cvt['value'], $this->smsbody);
		}

		if(EMAIL != "text/html"){
			$this->emailbody=str_replace("</p>", "\r\n",$this->emailbody);
			$this->emailbody=str_replace("<br />", "\r\n",$this->emailbody);
			$this->emailbody=str_replace("<br>", "\r\n",$this->emailbody);
			$this->emailbody=strip_tags($this->emailbody);
		}



		if(debugging != "0") echo "<div class='debuggingwindow'>Debugging:<br>".$this->emailto."<br><textarea style='width: 300px; height: 300px;'>".$this->emailbody."</textarea></div>";
		return array($this->emailsubject, $this->emailbody);
	}
	

	/**
	 * send email to all mangers
	 */
	function SendtoAllManagers()
	{
		global $GameCP, $safesql;
		if(emailAdmin == "yes"){ $q=" OR userlevel = '1' AND active='1'"; } else $q="";
		$adminEmailsQ = sql_query("SELECT email FROM users WHERE userlevel = '2' AND active='1' $q;") or die(mysql_error());
		while ($row = mysql_fetch_array($adminEmailsQ)){ 
			if($row['email'] != ""){
				$this->emailto = $row['email'];
				$this->send(false);
			}
		}
	}
	
	
	/**
	 * send email to all clients
	 */
	function SendtoAllClients()
	{
		// Lets query all clients here
		// also send the email
	}
	
	/**
	 * get the users email and smsemail
	 */
	function GetUserEmail()
	{
		global $GameCP, $safesql;

		if($this->userdb == "users"){
			$sms=", smsaddress";
		} else $sms="";
		if($this->userid != "" || $this->username != "")
		{
			if($this->userid != "")
			{
				$UserInfoQ = sql_query($safesql->query("SELECT email $sms FROM `%s` WHERE id='%i' LIMIT 1", array($GameCP->whitelist($this->userdb, "clean"),$GameCP->whitelist($this->userid, "int"))));
			}
			elseif($this->username != "")
			{
				$UserInfoQ = sql_query($safesql->query("SELECT email $sms smsaddress FROM `%s` WHERE username='%s' LIMIT 1", array($GameCP->whitelist($this->userdb, "clean"),$GameCP->whitelist($this->username, "clean"))));
			}
			
			if($UserInfoQ && mysql_num_rows($UserInfoQ) == 1)
			{
				$UserInfo = mysql_fetch_array($UserInfoQ);
				$this->emailto = $UserInfo['email'];
				$this->smsemail = $UserInfo['smsaddress'];
			}
		}
	}
	
	/**
	 * send the email
	 */
	function send($doreset=true,$queue=true, $log=true){
		global $cfg_vars, $GameCP, $Event;
		if($this->emailto == "") $this->GetUserEmail();
		if($this->emailfrom == "") $this->emailfrom = emailSendFrom;

		//if(!$this->check_email_address($this->emailto)) return false;
		$m = new PHPMailer; 

		if(isset($_SESSION['gamecp']['lang'])) $m->SetLanguage($_SESSION['gamecp']['lang'], path."/includes/core/classes/email/language/");
	
		$m->From = $this->emailfrom;
		$m->FromName = emailUserName;

		$m->AddReplyTo(emailSendReply);
		if($this->emailto) $m->AddAddress($GameCP->whitelist($this->emailto)); 

		if(isset($this->bcc)){
			if(is_array($this->bcc)){
				foreach($this->bcc as $bcmail){
					if($this->check_email_address($bcmail)) $m->addBCC($bcmail);
				}
			} else if($this->check_email_address($this->bcc))$m->addBCC($this->bcc);
		}
		//if(debugging != "0") print_r($this->bcc);

		if(bccmails){
			if(preg_match("/,/s", bccmails)){
				$bc=explode(",", bccmails);
				foreach($bc as $b => $cc) $m->addBCC(trim($cc));
			} else $m->addBCC(bccmails);
		}
		//if(debugging != "0") echo bccmails;

		$m->Subject = $this->emailsubject;
	
		$m->MsgHTML($this->emailbody);

		if($this->userid){
			$usr=$this->userid;
		} elseif ($this->username){
			$usr=$this->username;
		} else $usr="system";

		$Event->EventLogAdd($usr, serialize(array("EMAILSENT",$this->emailto,$this->emailsubject,$this->emailbody)));


		if($this->attachment) $m->AddAttachment($this->attachment, $this->attachmentname);


		if(EMAIL == "text/html") $m->IsHTML(true);
		
		if(!$cfg_vars['LNG_CHARSET']) $cfg_vars['LNG_CHARSET']='UTF-8';
		$m->CharSet = $cfg_vars['LNG_CHARSET'];

		switch(USESMTP){
			case "1":
				$m->IsSMTP();
			break;
			case "2":
				$m->IsQmail();
			break;
			case "3":
				$m->IsSendmail();
			break;
			default:
				$m->IsMail();
			break;
		}
	
		if(popserver && popuser )
		{
			$m->SMTPAuth   = true;                 

			$m->SMTPSecure = popauth;               
			$m->Host       = popserver;      
			$m->Port       = popport;  
			if(debugging) $m->SMTPDebug  = 2; 

			$m->Username   = popuser;  
			$m->Password   = poppw;          
		}

		if(queue_mail == "0") $queue=false;

		if($log == true) $this->log($queue);

		if($queue == false){
			if($this->bcc != "" || $this->emailto != ""){
				if(!$m->Send()){
					if(debugging != "0") echo  "<div class='debuggingwindow'>".$m->ErrorInfo."</div>";
					return false;
				} 
				/* reg mail sent, now send sms mail if its there */
				if($this->smsbody && $this->check_email_address($this->smsemail)){
						if($this->smsemail) $m->AddAddress($this->smsemail); 
						$m->MsgHTML(nl2br($this->smsbody));
					if(!$m->Send()){
						if(debugging != "0")  echo  "<br>".$m->ErrorInfo;
						return false;
					} 
				}
			}
		}


		if($doreset) $this->resetDetails();
	}


	function log($queue=false){
		global $GameCP, $Event, $safesql;

		$cache=serialize(array(
			"emailto" => $this->emailto,
			"bcc" => $this->bcc,
			"smsemail" => $this->smsemail,
			"emailfrom" => $this->emailfrom,
			"emailbody" => $this->emailbody,
			"smsbody" => $this->smsbody,
			"emailsubject" => $this->emailsubject,
			"userid" => $this->userid,
			"attachment" => $this->attachment,
			"templatename" => $this->templatename
		));

		if(isset($_SESSION['gamecp']['userinfo']['id'])){
			$sessionid=$_SESSION['gamecp']['userinfo']['id'];
		} else $sessionid='';

		sql_query($safesql->query("INSERT INTO `emailqueue` SET content='%s', subject='%s', time='%s', user='%s', effected='%s', queue='%i'", 
			array($cache, $this->emailsubject, time(), $sessionid, $this->userid, $queue)));

		$Event->EventLogAdd('System', serialize(array("EMAILCACHED",$this->emailto,$this->emailsubject,$this->emailbody)));

	}

	function runqueue($qid){
		global $safesql;

		$qinfo=	sql_query($safesql->query("SELECT * FROM `emailqueue` WHERE id='%s' LIMIT 1", 
			array($qid)))or die(mysql_error());
		$qinfod=mysql_fetch_assoc($qinfo);
		$cache=unserialize($qinfod['content']);
		$this->emailto = $cache['emailto'];
		$this->bcc  = $cache['bcc'];
		$this->smsemail = $cache['smsemail'];
		$this->emailfrom = $cache['emailfrom'];
		$this->emailbody = $cache['emailbody'];
		$this->smsbody = $cache['smsbody'];
		$this->emailsubject = $cache['emailsubject'];
		$this->userid = $cache['userid'];
		$this->attachment = $cache['attachment'];
		$this->templatename = $cache['templatename'];

		$this->send(true,false,false);

		sql_query($safesql->query("UPDATE `emailqueue` SET queue='0' WHERE id='%s'", 
			array($qid)));

	}



	/**
	 * reset all class vars
	 */
	function resetDetails(){
		$this->emailto = "";
		$this->bcc = "";
		$this->smsemail = "";
		$this->emailfrom = "";
		$this->emailbody="";
		$this->smsbody="";
		$this->emailsubject="";
		$this->attachment="";
		$this->userid="";
		$this->templatename="";
	}

	/**
	 * return if this is a good email
	 */
	function check_email_address($email) {
		return true;
	}


	function SendPackageDetails($cid, $eid, $convert){
		global $GameCP;
		if(!$cid) return false;
		$this->userid = $cid;
		$this->templatename = $eid;
		$this->GetTemplateStuff();
		$this->ReplaceStuff($convert);
		$this->send();
	}


	/**
	 * sends server details
	 */
	function SendDetails($cid){
		global $GameCP;
		if(!$cid) return false;

		$this->userid = $cid;
		$this->templatename = "Server Information.";
		$this->GetTemplateStuff();
		$this->usegamedata = true;
		$this->usevoicedata = true;
		$this->usebilldata = true;
		$this->ReplaceStuff();
		$this->send();

		if(emailadminewserver == "yes"){
			if(is_file(path.'/includes/core/editable/newserveremail.inc.php')){
				require_once(path.'/includes/core/editable/newserveremail.inc.php');
				$adminEmailsQ = sql_query("SELECT email FROM users WHERE userlevel = '1'") or die(mysql_error());
				while ($row = mysql_fetch_array($adminEmailsQ)){ 
					$this->emailto = $row[0];
					$this->emailsubject = $subject;
					$this->emailbody = $email;
					$this->send();
				}
			}
		}
		return true;
	}


	/**
	 * show confirmation page, used in the templates
	 */
	function Confirm($mode, $idd, $predefined, $subject=FALSE, $body=FALSE){
		global $smarty;
		
		$smarty->assign("idd", $idd);
		$smarty->assign("mode", $mode);
		$smarty->assign("predefined", $predefined);
		$smarty->assign("subject", $subject);
		$smarty->assign("body", $body);

		$smarty->display("notify/mailconfirm.tpl");

	}

}


?>