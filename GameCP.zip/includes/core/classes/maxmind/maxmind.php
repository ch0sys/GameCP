<?php
/*
	GameCP MaxMind Fraud Detection Plugin

	Created November 2009 by William Bowman based off the default code from maxmind - that didnt do all that much

*/

function maxMindCCDetection($maxLicence, $proxyScoreLimit="3", $scoreLimit="5", $rejectFreeMail="no", $rejectCountry="no", $rejectHighRiskCountry="no", $rejectanonymousProxy="no", $useSSL="no", $bypassIfNoCredits="yes"){
	global $GameCP;
	
	$_SESSION['maxmind']='';

	require("CreditCardFraudDetection.php");
	$ccfs = new CreditCardFraudDetection;
	$h["license_key"] = $maxLicence;
	$dm=explode("@", $_REQUEST['email']);
	$h["domain"] = $dm[1];		// Email domain
	$h["i"] = $_SERVER['REMOTE_ADDR'];	// X-Forwarded-For or Client-IP HTTP Header
	$h["emailMD5"] = $_REQUEST['email'];
	$h["usernameMD5"] = $_REQUEST['firstname']; 
	$h["passwordMD5"] = $_REQUEST['lastname']; 
	$h["custPhone"] = $_REQUEST['phone'];
	$h["requested_type"] = "premium";
	$h["city"] = $_POST['city'];
	$h["region"] = $_POST['state'];
	$h["postal"] = $_POST['zip'];
	$h["country"] = $_POST['country'];
	if(isset($_POST['bid'])) $h["txnID"] = $_POST['bid'];
	$h["sessionID"] = session_id();
	$h["accept_language"] = $_SESSION['gamecp']['lang'];
	$h["user_agent"] = $_SERVER['HTTP_USER_AGENT'];

	if($useSSL != "no") $ccfs->isSecure = 1;
	$ccfs->timeout = 3;
	$ccfs->useDNS = 0;
	$ccfs->isSecure = 0;
	$ccfs->input($h);
	$ccfs->query();
	$h = $ccfs->output();

	if($h['queriesRemaining'] < 20){
		$GameCP->loadIncludes("email");
		$Email=new Email();
		$Email->emailto = emailNotify;
		$Email->emailsubject = "Your MaxMind queries are low";
		$Email->emailbody = 'The total queries you have left are: '.$h['queriesRemaining'].' <br><br>';
		$Email->send();
	}

	if($bypassIfNoCredits == "yes" && $h['queriesRemaining'] <= 1) return "passed";
	
	$_SESSION['gamecp']['fraud_check']=$h;
	$_SESSION['gamecp']['fraud_ref_code']=$h['maxmindID'];

	if($h['err']){ 
		if($h['err'] == "CITY_NOT_FOUND"){
			return 7;
		} else {
			$_SESSION['maxmind']['error']= "Maxmind error: ". $h['err'];
			return 8;
		}
	} else {

		if($h['proxyScore'] >= $proxyScoreLimit){
			return 1;
		} elseif($h['score'] >= $scoreLimit){
			return 2;
		} elseif($h['freeMail'] == "Yes" && $rejectFreeMail !="no"){
			return 3;
		} elseif($h['countryMatch'] != "Yes" && $rejectCountry =="yes"){
			return 4;
		} elseif($h['highRiskCountry'] == "Yes" && $rejectHighRiskCountry !="no"){
			return 5;
		} elseif($h['anonymousProxy'] == "Yes" && $rejectanonymousProxy !="no"){
			return 6;
		} else {
			$_SESSION['maxmind']=$h;
			return "passed";
		}
	}

	return 0;
}


function maxMindPhoneDetection($maxLicence, $useSSL="no", $callCode="5783"){
	// See http://www.maxmind.com/app/telephone_form for more details on the input fields
	require("TelephoneVerification.php");

	$tv = new TelephoneVerification;

	$h["l"] = $maxLicence;
	$h["phone"] = $_POST['phone'];
	$h["verify_code"] = $callCode;
	$tv->isSecure = 0;
	@set_time_limit(120);
	$tv->timeout = 60;

	$ccfs->useDNS = 0;

	$tv->input($h);
	$tv->query();
	$h = $tv->output();

	if($h['err']){ 
		// if there are no credits just pass
		if($h['err'] == "Insufficient funds to make call"){

		} else {
			echo "Maxmind error: ". $h['err'];
			return false;
		}
	} elseif($h['refid']) {
		if($h['phoneType']){
			//  http://www.maxmind.com/app/phone_id_codes

			switch($h['phoneType']){
				case 0:
					return "passed";
				break;
				case 1:
					return "passed";
				break;
				case 2:
					return "passed";
				break;
				case 3:
					return "passed";
				break;
				case 4:
					return false;
				break;
				case 5:
					return false;
				break;
				case 6:
					return false;
				break;
				case 7:
					return false;
				break;
				case 8:
					return false;
				break;
				case 9:
					return false;
				break;
				case 10:
					return "passed";
				break;
				case 11:
					return false;
				break;
				case 20:
					return false;
				break;
			}
		}
		return true;
	}
}



function maxmind(){
	global $fraudError;
	$fraudFailed=false;

	/* maxmind! */
	if(maxEnable != "no"){
		$maxmindCC=maxMindCCDetection(maxLicence, maxProxyScoreLimit, maxScoreLimit, maxRejectFreeMail,maxRejectCountry,maxRejectHighRiskCountry,maxRejectanonymousProxy,maxUseSSL, bypassIfNoCredits);

		if($maxmindCC != "passed"){

			$fraudFailed = true;

			switch($maxmindCC){
				case "0":
					$fraudError= "Maxmind failed.";
				break;
				case "1":
					$fraudError= "Maxmind has determined that you are using a high risk proxy.";
				break;
				case "2":
					$fraudError= "Maxmind has determined the risk of your order is to high.";
				break;
				case "3":
					$fraudError= "Free e-mail services may not be used. This includes services such as gmail.com &amp; yahoo.com.";
				break;
				case "4":
					$fraudError= "Maxmind reported mismatched country. Your billing country does not match your browsing country.";
				break;
				case "5":
					$fraudError= "Maxmind reported high you are in a risk country.";
				break;
				case "6":
					$fraudError= "Maxmind detected you are using an anonymous proxy.";
				break;
				case "7":
					$fraudError= "Maxmind could not determine your City. Please correct this information.";
				break;
				case "8":
					$fraudError= $_SESSION['maxmind']['error'];
				break;
			}
		}
	}

	if(maxPhoneAuth != "no"){
		if(maxEnable == "no" || (maxEnable == "yes" && $maxmindCC == "passed")){
			$callCode=rand();
			$_SESSION['gamecp']['orderDetails']['callCode']=$callCode;
			$maxmindPhone=maxMindPhoneDetection(maxLicence,maxUseSSL, $callCode);
			if($maxmindPhone != "passed"){
				$fraudFailed = true;
				$fraudError= "Maxmind did not pass basic authentication on your phone number.";
			}
		}
	}

	if($fraudFailed == true){
		$_SESSION['gamecp']['fraud_error']=$fraudError;
	}

	return $fraudFailed;
}

?>