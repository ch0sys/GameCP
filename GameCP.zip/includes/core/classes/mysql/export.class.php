<?php 

/*************************************************************** 
 * SQL_Export class 
 * By Adam Globus-Hoenich, 2004 (adam@phenaproxima.net) 
 * Use this class as freely as you like. It is 100% free and 
 * modifiable :) 
***************************************************************/ 

class SQL_Export 
{ 
    var $table; 
    var $tables; 
    var $exported; 

    function SQL_Export($tables) 
    { 
        $this->tables = $tables; 

    } 


    function export() 
    { 
        foreach($this->tables as $t) 
        { 
            $this->table = $t; 
            $header = $this->create_header(); 
            $data = $this->get_data(); 
            $this->exported .= "###################\n# Dumping table $t\n###################\n\n$header" . $data . "\n"; 
        } 

        return($this->exported); 
    } 

    function create_header() 
    { 

		$data=mysql_query("SHOW CREATE TABLE ". $this->table);
		$da=mysql_fetch_assoc($data);
		return str_replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS", $da['Create Table']).";\n\n";
    } 

    function get_data() 
    { 
       set_time_limit(99999);
	   $d = null; 

		$data = mysql_query("SELECT * FROM `" . $this->table . "` WHERE 1") or $this->error(mysql_error()); 
         
        while($cr = mysql_fetch_array($data, MYSQL_NUM)) 
        { 
            $d .= "INSERT INTO `" . $this->table . "` VALUES ("; 

            for($i=0; $i<sizeof($cr); $i++) 
            { 
                if($cr[$i] == '') { 
                    $d .= '\'\','; 
                } else { 
                   $d .= "'".addslashes($cr[$i])."',"; 
                } 
            } 

            $d = substr($d, 0, strlen($d) - 1); 
            $d .= ");\n"; 
        } 

        return($d); 
    } 

    function error($err) 
    { 
        die($err); 
    } 
} 

?>