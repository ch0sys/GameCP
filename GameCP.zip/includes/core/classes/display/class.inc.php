<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/**
 * Display class helps with the template system to show items
 * 
 * This class can return lists of ip's, intitals and sort an array by field
 *
 */

class Display{

	/**
	 * returns array of servers owned by a reseller user
	 */
	function ResellerIPQuery(){
		$serversowned=array();
		$resultClient = sql_query("SELECT servers FROM users WHERE userlevel='4' AND servers !='';") or die(mysql_error()); 
			while ($clientInfo = mysql_fetch_array($resultClient)){
				if ($clientInfo['servers']) {
					$unser=unserialize($clientInfo['servers']);
					foreach($unser as $u => $s) if(!in_array($s, $serversowned))$serversowned[]=$s;
				}
			}
		return $serversowned;
	}

	/**
	 * returns array of ip addresses in a defined location
	 * @param string $local location name
	 */
	function LocationIPQuery($local){
		global $GameCP, $safesql;
		$ipr=array();
		// removed AND I.assigned !='1'
		$ipListQ = sql_query($safesql->query("SELECT I.ip FROM iptable I, servers S WHERE I.sid = S.sid AND S.location='%s' ;", array($GameCP->whitelist($local, "clean")))) or die(mysql_error());
		while($iplist = mysql_fetch_array($ipListQ)) $ipr[]=$iplist[0];
		return $ipr;
	}

	/**
	 * returns html of the voice ip list
	 */
	function VoiceIPList($type=FALSE){
		global $GameCP, $safesql, $LNG_TEAMSPEAK3, $LNG_TEAMSPEAK, $LNG_VENTRILO;

		$ret="";

		if(!$type || $type == "1000"){
			if(!$type) $ret= "<option value=\"\" class='selecttile'>".$LNG_TEAMSPEAK." 2</option>";
			$serverNameQ = sql_query("SELECT ip, name, sid FROM servers WHERE ts2='1' ORDER BY quota - used  DESC") or die(mysql_error());
			while ($serverName = mysql_fetch_array($serverNameQ)){
				$ret.= "<option value=\"". $serverName['ip'] ."\">&nbsp;". $serverName['name'] ."</option>";
				$nsid = $serverName['sid'];
				
				$serverIPQ = sql_query("SELECT ip, assigned FROM iptable WHERE sid = '$nsid'") or die(mysql_error());
				while ($serverIP = mysql_fetch_array($serverIPQ)){
					if ($serverIP["assigned"] != 0) {
						$isassigned = "[assigned]";
					} else {
						$isassigned = "";
					}
					$ret.= "<option value=\"". $serverIP['ip'] ."\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;". $serverIP['ip'] ." $isassigned</option>";
				}
			}
		}

		if(!$type || $type == "1002"){

			if(!$type) $ret.= "<option value=\"\" class='selecttile'>".$LNG_TEAMSPEAK3."</option>";
			$serverNameQ = sql_query("SELECT ip, name, sid FROM servers WHERE ts3host='1' ORDER BY quota - used  DESC") or die(mysql_error());
			while ($serverName = mysql_fetch_array($serverNameQ)){
					$ret.= "&nbsp;<option value=\"". $serverName['ip'] ."\">&nbsp;". $serverName['name'] ."</option>";
					$nsid = $serverName['sid'];
					
					$serverIPQ = sql_query("SELECT ip, assigned FROM iptable WHERE sid = '$nsid'") or die(mysql_error());
					while ($serverIP = mysql_fetch_array($serverIPQ)){
						if ($serverIP["assigned"] != 0) {
							$isassigned = "[assigned]";
						} else {
							$isassigned = "";
						}
						$ret.= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<option  value=\"". $serverIP['ip'] ."\">- ". $serverIP['ip'] ." $isassigned</option>";
					}
			}
		}

		if(!$type || $type == "1001"){

			if(!$type) $ret.= "<option value=\"\" class='selecttile'>".$LNG_VENTRILO."</option>";

			if (usedarkstarvent == "yes"){
				$GameCP->loadIncludes("darkstarllc");
				$darkstar=darkstar_getLocations();
				$list=unserialize($darkstar['result']);
				if(is_array($list)){
					foreach($list as $res) $ret.= "<option value=\"". $res['id'] ."\">&nbsp;&nbsp;&nbsp;". $res['name'] ."</option>";
				}

			}else{
				$serverNameQ = sql_query("SELECT ip, name, sid FROM servers WHERE vent='1' ORDER BY quota - used  DESC") or die(mysql_error());
				while ($serverName = mysql_fetch_array($serverNameQ)){
					$ret.= "<option value=\"". $serverName['ip'] ."\">&nbsp;". $serverName['name'] ."</option>";
					$nsid = $serverName['sid'];
					
					$serverIPQ = sql_query("SELECT ip, assigned FROM iptable WHERE sid = '$nsid'") or die(mysql_error());
					while ($serverIP = mysql_fetch_array($serverIPQ)){
						if ($serverIP["assigned"] != 0) {
							$isassigned = "[assigned]";
						} else {
							$isassigned = "";
						}
						$ret.= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<option  value=\"". $serverIP['ip'] ."\">- ". $serverIP['ip'] ." $isassigned</option>";
					}
				}
			}
		}
		return $ret;
	}

	function LocationValid($locationIP, $installedon){
		if(is_array($locationIP)){
			foreach($locationIP as $lo => $lip){
				if(in_array($lip, $installedon)) return true;
			}
		} else if(in_array($locationIP, $installedon)) return true;
		return false;
	}

	/**
	 * can either echo or return a list
	 * @param string $list define to return, blank to echo
	 * @param string $current ip address to select as default
	 * @param string $nosid  dont display selected sid
	 */
	function MachineIPList($list=FALSE, $current=FALSE, $nosid=FALSE, $os=FALSE, $onlyme=FALSE, $assigned="yes", $installedon=false){
		global $GameCP, $safesql;
		$ret="";

		if( $_SESSION['gamecp']['userinfo']['ulevel'] == "4" || $_SESSION['gamecp']['userinfo']['ulevel'] == "5"){
			$ret="";
			$specialid = $_SESSION['gamecp']['userinfo']['id'];

			$resultClient = sql_query("SELECT * FROM users WHERE id='$specialid' LIMIT 1;") or die(mysql_error()); 
			$clientInfo=mysql_fetch_array($resultClient);
			if ($clientInfo['servers']) {
				$serversdoh=array();
				$serversowned=unserialize($clientInfo['servers']);
				
				$locationQ = sql_query("SELECT distinct location FROM servers WHERE gamehost = 'yes'") or die(mysql_error());
				while ($location = mysql_fetch_array($locationQ)){ 

					$locationIP=$this->LocationIPQuery($location['location']);
					if($locationIP && $this->LocationValid($locationIP, $serversowned) == true){
						if($list){
							$ret.="<option class='selecttile'>". $location['location']."</option>";
						} else echo  "<option class='selecttile'>". $location['location']."</option>";

						$result = sql_query("SELECT sid, name, quota-used as available, ip FROM servers WHERE gamehost = 'yes' AND location='".$location['location']."' ORDER BY 'available' DESC") or die(mysql_error());
						while ($row = mysql_fetch_array($result)){ 
							if(in_array($row['sid'], $serversowned)){
								if($list){
									$ret.="<option class='selectmachine' value=\"". $row['ip'] ."\">&nbsp;". $row['name']." &nbsp;".$row['available']."</option>";
								}else echo "<option class='selectmachine' value=\"". $row['ip'] ."\">&nbsp;". $row['name']." &nbsp;".$row['available']."</option>";
							}
							
							$ipListQ = sql_query("SELECT ip FROM iptable WHERE sid='" .$row['sid'] ."'") or die(mysql_error());
							while ($iplist = mysql_fetch_array($ipListQ)){ 
								if(in_array($iplist['ip'], $serversowned)){
									$ipgames = sql_query("SELECT id FROM usergames WHERE ip='". $iplist['ip'] ."'") or die(mysql_error());
									$ipgame=mysql_num_rows($ipgames);

									if($list){
										$ret.="<option class='selectip' value=\"". $iplist['ip'] ."\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;". $iplist['ip']." (".$ipgame.")</option>";
									} else echo "<option class='selectip' value=\"". $iplist['ip'] ."\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;". $iplist['ip']." (".$ipgame.")</option>";
								} 
							}
						}
					}
				}
			}

		} else {

			if($nosid){
				$nosidq=$safesql->query(" AND sid != '%s'", array($GameCP->whitelist($nosid)));
			} else $nosidq="";

			if($onlyme) {
				$onlymeq=$safesql->query(" AND sid = '%s'", array($GameCP->whitelist($onlyme)));
			} else $onlymeq="";

			if($assigned == "yes"){
				$assigned=" AND assigned = '0'";
			} else $assigned="";
	
			if($os){
				$os=" AND os != '$os'";
			} else $os="";

			/* update the quota for servers and slots */
			$GameCP->loadIncludes("game");
			$Game=new Game();
			$Game->UpdateUsage();

			$ResellerIPQuery=$this->ResellerIPQuery();

			$locationQ = sql_query("SELECT distinct location FROM servers WHERE gamehost = 'yes' AND active='1' $nosidq $os $onlymeq") or die(mysql_error());
			while ($location = mysql_fetch_array($locationQ)){
				if($location['location']){
					$local=$location['location'];
				} else $local="Other";

				$locationIP=$this->LocationIPQuery($location['location']);
				if($locationIP){
					if(is_array($installedon) && $this->LocationValid($locationIP, $installedon) == true || !is_array($installedon)){
						if($list){
							$ret.="<option class='selecttile' value=\"\">". $local."</option>";
						} else echo  "<option class='selecttile'  value=\"\">". $local."</option>";

						$serverNameQ = sql_query($safesql->query("SELECT sid, name, quota-used as available, slotquota-slotused as slots, ip FROM servers WHERE gamehost = 'yes' AND active='1' AND location='%s' $nosidq $onlymeq ORDER BY 'available' DESC", array($GameCP->whitelist($location['location'], "clean")))) or die(mysql_error());

						while ($serverName = mysql_fetch_array($serverNameQ)){
							$nsid = $serverName['sid'];
							$serverIPQ = sql_query("SELECT ip, assigned FROM iptable WHERE sid = '$nsid' ") or die(mysql_error());

							if(is_array($installedon) && in_array($serverName['ip'], $installedon)  || !is_array($installedon)){
								if($list){
									$ret.="<option class='selectmachine' value=\"". $serverName['ip'] ."\">&nbsp;". $serverName['name'] ." &nbsp;".$serverName['available']."/".$serverName['slots']."</option>";
								}else echo "<option class='selectmachine'  value=\"". $serverName['ip'] ."\">&nbsp; ". $serverName['name'] ." &nbsp;".$serverName['available']."/".$serverName['slots']."</option>";
								
								
								while ($serverIP = mysql_fetch_array($serverIPQ)){

									if(!in_array($serverIP['ip'], $ResellerIPQuery) || $current || (isset($_SESSION['gamecp']['user']['mainadmin']) && $_SESSION['gamecp']['user']['mainadmin'] == true)){	
										if(is_array($installedon) && in_array($serverIP['ip'], $installedon)  || !is_array($installedon)){
											$ipgames = sql_query("SELECT COUNT(*) FROM usergames WHERE ip='". $serverIP['ip'] ."'") or die(mysql_error());
											$ipgame=mysql_fetch_row($ipgames);
											$ipgame=$ipgame[0];

											if(is_array($current) && in_array($serverIP['ip'], $current)){
												$select="selected=\"selected\"";
											} else $select="";

											if($assigned != "yes" && $serverIP['assigned'] == "1"){
												$as=" [assigned]";
											} else $as="";

											if($list){
												$ret.="<option class='selectip' value=\"". $serverIP['ip'] ."\" $select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;". $serverIP['ip'] ." ($ipgame)$as</option>";
											} else echo "<option class='selectip' value=\"". $serverIP['ip'] ."\" $select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;". $serverIP['ip'] ." ($ipgame)$as</option>";
										}
									}
								}
							}
						}
					
					}
				}
			}
		}

		if($list) return $ret;
	}

	/**
	 * can either echo or return a list
	 * @param string $list  define to return, blank to echo
	 */
	function GameIPList($list=FALSE){
		global $GameCP, $safesql;
		$ret="";
		if($_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
			$specialid = $_SESSION['gamecp']['userinfo']['id'];
			$ret="";
			$resultClient = sql_query("SELECT * FROM users WHERE id='$specialid' LIMIT 1;") or die(mysql_error()); 
			$clientInfo=mysql_fetch_array($resultClient);
			if ($clientInfo['games']) {
				$serversdoh=array();
				$serversowned=unserialize($clientInfo['games']);
				$result = sql_query("SELECT id, name FROM game WHERE active='1' ORDER BY 'name' ASC") or die(mysql_error());
				while ($row = mysql_fetch_array($result)){ 
					if(in_array($row['id'], $serversowned)){
						if($list){
							$ret.="<option value=\"". $row['id'] ."\">". $row['name']."</option>";
						} else echo "<option value=\"". $row['id'] ."\">". $row['name']."</option>";
					}
				}
			}
		} else {
			/* update the quota */
			$serverNameQ = sql_query("SELECT id, name FROM game WHERE active='1' ORDER BY name ASC") or die(mysql_error());
			while ($serverName = mysql_fetch_array($serverNameQ)){
				if($list){
					$ret.="<option value=\"". $serverName['id'] ."\">". $serverName['name'] ."</option>";
				} else echo "<option value=\"". $serverName['id'] ."\">". $serverName['name'] ."</option>";
			}
		}
		if($list) return $ret;
	}

	/**
	 * returns an array of initials for the set sent
	 * @param string $_data array of names
	 */
	function Initials($_data){
		/* Build array of initials we want to select */
		$array_initials = array();
		for ($letter_counter = 1; $letter_counter < 27; $letter_counter++) {
			$array_initials[chr($letter_counter + 64)] = FALSE;
		}

		/* Build array based on SQL result to get initials we have */
		$user_initial=array();
		if(is_array($_data)){
			foreach($_data as $data_row){
				$array_initials[strtoupper($data_row['name'][0])] = TRUE;
			}
		}

		/* Sort so its nice */
		uksort($array_initials, "strnatcasecmp");
		reset($array_initials);

		/* Build array that shows what initials are found and what are not */
		$initial_array=array();

		foreach ($array_initials as $tmp_initial => $initial_was_found) {
			if ($initial_was_found) {
				 $initial_array[]=array("initial" => $tmp_initial, "used" =>"1");
			} else {
				 $initial_array[]=array("initial" => $tmp_initial, "used" =>"0");
			}
		}

		return $initial_array;
	}


	/**
	 * sort an array by its field
	 * @param string $original the array to sort
	 * @param string $field the field to start
	 * @param string $descending set to be decending
	 */
	function ArraySort($original, $field, $descending = false){
		$sortArr = array();

		foreach ( $original as $key => $value) $sortArr[ $key ] = $value[ $field ];
		
		if ( $descending ){
			arsort( $sortArr ); 
		} else asort( $sortArr );
		

		$resultArr = array();
		foreach ( $sortArr as $key => $value ) $resultArr[  ] = $original[ $key ];
		
		return $resultArr;
	}           



}
?>