<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Query{

	function Status($sid){
		global $GameCP;
		$restatus=false;
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$result=$Backend->QueryResponse($sid, '', "version:_:");
		$res=explode(".", $result);
		if (is_array($res) && count($res) == 4) $restatus=true;

		return $restatus;
	}

	function Ping($sid, $os){
		global $GameCP;

		if(isset($_SESSION['gamecp']['servers']['ping'][$sid]['data']) && (time() - $_SESSION['gamecp']['servers']['ping'][$sid]['time']) < cachedelay ) return $_SESSION['gamecp']['servers']['ping'][$sid]['data'];
		
		
		$ip=$GameCP->MasterIP();

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$machineInfo=$Panel->GetServer($sid);
		
		$qport=$machineInfo['winport'];

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$status=$Backend->QueryResponse($sid, $qport, "ping:_:".$ip);

		if($status == "Unable to connect to the remote" || preg_match('/Remote/i', $status)) return false;
		if($status == "Received incorrect SID" || preg_match('/Received incorrect/i', $status)) return false;

		$data='';
		if($os == "1"){
			$st=explode("Average =", $status);
			if(isset($st[1])) (int)$data=$st[1];
		} else (int)$data= $status;

		$_SESSION['gamecp']['servers']['ping'][$sid]['data']=$data;
		$_SESSION['gamecp']['servers']['ping'][$sid]['time']=time();

		if(is_integer($data)){ 
			return $GameCP->whitelist($data, 'int')."ms";
		} else return '';
	}

	function StatsRemoteDown($error,$sid){
		global $GameCP, $safesql;
		sql_query($safesql->query("UPDATE servers SET statscache='%s', statstime='%s' WHERE sid='%s'", array(json_encode(array($error)), time(), $sid))) or die(mysql_error());
		return array($error);
	}

	function Stats($sid, $os){
		global $GameCP, $safesql;

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if($os == "0"){
			$load0=array();
			$meminfo=trim($Backend->QueryResponse($sid, '', "readfile:_:/proc/meminfo"));
			if($meminfo == "Unable to connect to the remote" || preg_match('/Remote/i', $meminfo)) return $this->StatsRemoteDown("Unable to connect to the remote", $sid);
			if($meminfo == "Received incorrect SID" || preg_match('/Received incorrect/i', $meminfo)) return $this->StatsRemoteDown("Unable to connect to the remote, incorrect sid", $sid);

			$swapinfo=$Backend->QueryResponse($sid, '', "readfile:_:/proc/swaps");
			$loadinfo=$Backend->QueryResponse($sid, '', "readfile:_:/proc/loadavg");
			$idleinfo=$Backend->QueryResponse($sid, '', "command:_:vmstat 1 2");
			
			/*
				$diskinfo=$Backend->QueryResponse($sid, '', "command:_:df");
				$cores=$Backend->QueryResponse($sid, '', "command:_:cat /proc/cpuinfo | grep processor -c");

				$diskusage=array();
				$diskres = preg_split("/\n/", trim($diskinfo), -1, PREG_SPLIT_NO_EMPTY);
				unset($diskres[0]);	
				foreach($diskres as $r){
					$d=array();
					$t = preg_split('/\s+/', $r, -1, PREG_SPLIT_NO_EMPTY);
					if(count($t) == 5){
						$d['partition']=$t['4'];
						$d['sized']=$t['0'];
						$d['used']=$t['1'];
						$d['available']=$t['2'];
						$d['use']=$t['3'];
						$diskusage[]=$d;
					} elseif(count($t) == 6){
						$d['partition']=$t['5'];
						$d['sized']=$t['1'];
						$d['used']=$t['2'];
						$d['available']=$t['3'];
						$d['use']=$t['4'];
						$diskusage[]=$d;
					}
				}
			*/

            $memres = preg_split("/\n/", $meminfo, -1, PREG_SPLIT_NO_EMPTY);
            foreach ($memres as $memdata) {
                if (preg_match('/^MemTotal:\s+(.*)\s*kB/i', $memdata, $memout)) {
                    $load0[4]=$memout[1];
                } elseif (preg_match('/^MemFree:\s+(.*)\s*kB/i', $memdata, $memout)) {
                    $load0[1]=$memout[1];
                } elseif (preg_match('/^Cached:\s+(.*)\s*kB/i', $memdata, $memout)) $load0[2]=$memout[1];                 
            }
			$swapres = preg_split("/\n/", $swapinfo, -1, PREG_SPLIT_NO_EMPTY);
			unset($swapres[0]);
			foreach ($swapres as $swap) {
				$sd=preg_split('/\s+/', $swap, 5);
				if(isset($sd[3])){
					if(isset($load0[0])){
						$load0[0]=$load0[0]+$sd[3];
					}else $load0[0]=$sd[3];
				}
			}

			$load=preg_split('/\s+/', $loadinfo, 5);
			$load0[5]=$load[0];

			$idleres = preg_split("/\n/", trim($idleinfo), -1, PREG_SPLIT_NO_EMPTY);
			unset($idleres[0]);

			if(isset($idleres[1]) && isset($idleres[3])){
				$findid=preg_split('/\s+/', $idleres[1]);
				$key='15';
				foreach($findid as $k => $v){
					if($v == 'us') $key=$k;
				}

				$loadinf=preg_split('/\s+/', $idleres[3]);
				$load0[3]=$loadinf[$key];
				if(!$load0[3])$load0[3]='0';
			} else $load0[3]='';
		}else{
			$load=$Backend->QueryResponse($sid, '', "sysstats:_:");
			$load0=explode("::", $load);
			if($load == "Unable to connect to the remote" || preg_match('/Remote/i', $load)) return $this->StatsRemoteDown("Unable to connect to the remote", $sid);
			if($load == "Received incorrect SID" || preg_match('/Received incorrect/i', $load)) return $this->StatsRemoteDown("Unable to connect to the remote, incorrect sid", $sid);
		}

		if($os != "1"){
			if(isset($load0[0]))$swap=$Panel->FormatSize(trim($load0[0])); 
			if(isset($load0[1])){
				$free=$Panel->FormatSize(trim($load0[1]));
				$rawfree=trim($load0[1]);
			}
			if(isset($load0[2]))$cache=$Panel->FormatSize(trim($load0[2]));
			if(isset($load0[3]))$cpuid=$load0[3];
			if(isset($load0[4])){
				$total=$Panel->FormatSize(trim($load0[4]));
				$rawtotal=trim($load0[4]);
			}
			if(isset($load0[5]))$loadavg=$load0[5];
		} else { 
			if(isset($load0[0]))$swap=$Panel->FormatSize(trim($load0[0]*1024));  // virtualfree
			if(isset($load0[1])){
				$free=$Panel->FormatSize(trim($load0[1]*1024));
				$rawfree=trim($load0[1]*1024);
			}
			if(isset($load0[2]))$cpuid=$load0[2];
			if(isset($load0[3])){
				$total=$Panel->FormatSize(trim($load0[3]*1024));
				$rawtotal=trim($load0[3]*1024);
			}
			$loadavg="";
			$load="";
			$useage=""; 
		}

		if(isset($free) && isset($total)){
			$memusage=round(($rawfree/$rawtotal)*100);
		} else $memusage="";

		$array=array(@$swap, @$free, @$cache, @$cpuid, @$total, @$loadavg, @$memusage, @$diskusage, @$cores);
		$_SESSION['gamecp']['servers']['cache'][$sid]['data']=$array;
		$_SESSION['gamecp']['servers']['cache'][$sid]['time']=time();

		sql_query($safesql->query("UPDATE servers SET statscache='%s', statstime='%s' WHERE sid='%s'", array(json_encode($array), time(), $sid))) or die(mysql_error());

		return $array;
	}

	function Port($ip, $port, $type="tcp"){
		$fp=@fsockopen($type."://".$ip, $port, $errno, $errstr, 1);
		if(!$fp){ 
			$r= "down";
		} else {
			$r= "up";
			fclose($fp);
		}
		return $r;
	}

	function GameQ($ugid, $player=FALSE, $cache=true, $forcecache=false){
		global $GameCP, $url, $safesql;
		if(!$ugid){	
			echo "GameQ: Missing user game id.";
			return false;
		}

		$serverInfoQ = sql_query($safesql->query("SELECT UG.ip, UG.port, G.gameQcode, UG.queryport, UG.maxplayers, UG.pubpriv, UG.clientplayers, UG.lastplayers, UG.lastplytime, UG.status, UG.logfile as 'log', G.logfile, UG.subdirectory, S.os, G.winappdir, G.install, U.username, S.sid, UG.lastactivetime
		FROM users U, usergames UG, game G, iptable I, servers S WHERE UG.id='%i' AND U.id = UG.cid AND  UG.gid = G.id  AND I.ip = UG.ip AND I.sid = S.sid LIMIT 1;", array($GameCP->whitelist($ugid, "int")))) or print(mysql_error());
		$serverInfo = mysql_fetch_array($serverInfoQ);
		if(mysql_num_rows($serverInfoQ) == 0){ 
			echo "GameQ: Unable to locate users game."; 
			return false;
		}

		if(($forcecache == true && isset($serverInfo['lastplayers']) && reload_ajax_pages == "true") ||
			(isset($serverInfo['lastplayers']) && (( time() - $serverInfo['lastplytime']) < cachedelay) && $cache==true && $player == false)){
			return unserialize($serverInfo['lastplayers']);
		}


		//session_write_close();

		$status="";
		$total="";
		$fs="";
		$fip=$serverInfo[0];
		$fport=$serverInfo[1];
		$gcode=$serverInfo['gameQcode']; 
		$log=$serverInfo['log']; 
		$logfile=$serverInfo['logfile']; 
		$subdirectory=$serverInfo['subdirectory']; 
		$fname=$serverInfo['username']; 
		$sid=$serverInfo['sid']; 
		$os=$serverInfo['os']; 
		$fqport=$serverInfo[3];
		$allowed=$serverInfo[4];
		$pubpriv=$serverInfo[5];
		$clientplayers=$serverInfo[6];
		$ipport=$fip.":".$fport; 
		$stats='';
		$lastplayers=unserialize($serverInfo['lastplayers']);
		if($fqport) $fport=$fqport;
		$lastactivetime=$serverInfo['lastactivetime'];

		if($os == "1"){
			$installdir2=$serverInfo['winappdir'];
		} else $installdir2=$serverInfo['install'];

		if($subdirectory == "yes"){ 
			if(ipsubdir == "true"){
				$thesubdir=$fip."-".$fport . "/$installdir2";
			} else $thesubdir="service".$ugid ."/$installdir2";
		} 


		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$ipInfo=$Panel->GetIP($fip);
		if($ipInfo['useinternal'] == "1" && queryinternalip == "yes") $fip=$ipInfo['internal'];


		/*$gcode="cod2";
		$fip="";
		$fport="28960";*/


		if($gcode == "tcp" || $gcode == "udp"){
			if($player != false) return false;
			$status=$this->Port($fip, $fport, $gcode);
		} else if($gcode == "murmur") {
			if($player != false) return false;
			return $this->Mumble($fip, $fport);
		} else if($gcode == "lfs") {
			if($player != false) return false;

			if($os == "1"){
				$fold=str_replace("/","\\", "\$MAINDIR/home/$fname/$thesubdir/host$fport.txt");
				$da=$Backend->QueryResponse($sid, '', "readfile:_:$fold");
				if($da){
					$queryfile=explode("\n",$da);
					foreach($queryfile as $q){
						$a=explode("=", $q);
						if($a[0] == "guests") $results['server']['gq_numplayers']=$a[1];
						if($a[0] == "maxguests") $results['server']['gq_maxplayers']=$a[1];
						if($a[0] == "host") $results['server']['hostname']=$a[1];
						if($a[0] == "pass") $results['server']['gq_password']=$a[1];
						if($a[0] == "status"){
							if($a[1] == "online"){
								$status="up";
							} else $status="down";
						}
					}
				} else $status=$this->Port($fip, $fport, "tcp");
			}


		} else if($gcode == "querylog") {
			if($player != false) return false;
			$status=$this->Port($fip, $fport, "tcp");
			
			sleep(1);

			if($log || $logfile){
				if(!$log && $logfile) $log=$logfile;
				$GameCP->loadIncludes("backend");
				$Backend=new Backend();
				if($os == "1"){
					$fold=str_replace("/","\\", "\$MAINDIR/home/$fname/$thesubdir");
					$filelist=$Backend->QueryResponse($sid, '', "filelist:_:$fold");
					$file=str_replace(":_:", "GC_PC", $filelist);
					$file=explode("::" , $file);
					if(is_array($file)){
						for ($i = 0; $i < count($file); $i++){
							$filesub = explode("GC_PC", $file[$i]);
							if($filesub[0] == $log) $fs=$filesub[1];
						}
					}					
				} else {
					$str=str_replace("//", "/", "command:_:ls -al /home/$fname/$thesubdir/$log");
					$cmd=$Backend->QueryResponse($sid, '', $str, $fname);
					$foldersize=preg_split("/\s+/",	$cmd);
					if(isset($foldersize[4])){
						$fs=$foldersize[4];
					} else $fs='';
					unset($str,$cmd);
				}

				if($fs > $lastplayers['filesize']){
					$status="up";
				} else {
					$status="down";
				}
			}
		} else if($gcode == "minecraftgs4") {
			if($player != false) return false;
			require_once(path."/includes/core/classes/query/minecraft/MinecraftQuery_Simple.php");
			if(!$data=QueryMinecraft($fip, $fport, '90')){
				$status="down";
			} else {
				$results['server']['gq_numplayers']=$data['Players'];
				$results['server']['gq_maxplayers']=$data['MaxPlayers'];
				$results['server']['hostname']=$data['HostName'];
				$results['server']['gq_password']='';
				$status="up";
			}
		} else if($gcode == "mohawk") {
			if($player != false) return false;
			require_once(path."/includes/core/classes/query/mohawkVoice.inc.php");
			$Mohawk=new Mohawk();
			//@$report_slots_used,@$report_slots_avail,@$server_name,@$report_uptime, $status);
			return $Mohawk->mohawkVoice($fip, $fport);
		} else if($gcode == "ivmp") {
			require_once(path."/includes/core/classes/query/ivmp.inc.php");
			$q = new IVMPQuery;		
			if(!$q->Query($fip, $fport,$errno,$errstr,2)){
				$status="down";
			}else{
				if($player != false) return $q->Players();
				$data=$q->ServerData();
				$q->Close();
				$results['server']['gq_numplayers']=$data['players'];
				$results['server']['gq_maxplayers']=$data['maxplayers'];
				$results['server']['hostname']=$data['hostname'];
				$results['server']['gq_password']=$data['passworded'];
				$status="up";

			}
		} else if($gcode == "shoutcast") {
			if($player != false) return false;
			return $this->Shoutcast($fip, $fport);
		} else if($gcode == "tmania") {
			if($player != false) return false;
			return $this->TrackMania($fip, $fport);
		} else {
			if(!$gcode) return false;

			$v2codes=array('cssource' => 'css', 'cs' => 'cs16');
			if(isset($v2codes[$gcode])) $gcode=$v2codes[$gcode];
			require_once(path."/includes/core/classes/gameq2/GameQ.php");
			$servers = array(array('id' => 'server', 'type' => $gcode, 'host' => $fip.":".$fport));
			$gq = new GameQ();
			$gq->addServers($servers);
			$gq->setOption('timeout', qstattimeout);
			$gq->setFilter('normalise');
			$results = $gq->requestData();

			if($results['server']['gq_online'] != "1"){
				$status = "down";	
			} else $status = "up";		
						
			if($player == "rules"){
				return $results['server'];
			} else if($player == "player") return $results['server']['players'];
		}

		if($status == "down") { 
			$altstatus="down";
		} else { 
			if($pubpriv == "private"){ 
				$status="up";
				$altstatus="upprivate";
			} else {
				$status="up";
				$altstatus="up";
			}
		}

		if($status != "down"){
			if(isset($results['server']['gq_maxplayers'])){
				if("10" > $results['server']['gq_maxplayers'] && $results['server']['gq_maxplayers'] >= "1") $results['server']['gq_maxplayers'] = "0".$results['server']['gq_maxplayers'];
				$stats=$results['server']['gq_maxplayers'];
				$total=$results['server']['gq_maxplayers'];
			}else $total="0";

			if($gcode == "bf1942"){
				if($results['server']['gq_numplayers'] == "2"){
					foreach($results['server']['players'] as $u => $p){
						if($p['teamname'] == "allied" || $p['teamname'] == "axis") unset($results['server']['players'][$u]);
					}
					$results['server']['gq_numplayers']=count($results['server']['players']);
				}
			}

			if(isset($results['server']['gq_numplayers'])){
				if($stats){
					if(!$results['server']['gq_numplayers']) $results['server']['gq_numplayers'] = "0";
					$stats=$results['server']['gq_numplayers']."/".$stats; 
				} else $stats=$results['server']['gq_numplayers'];
				$active=$results['server']['gq_numplayers'];
			}else $active="0";


			if(!$total || $total == "") $total="0";
			if(!$active || $active == "") $active="0";


			if($total > $clientplayers){
				$diff=$total-$allowed;
				$stats="<div style=\"color: red;\" title=\"+".$diff." over\" class=\"tooltips\">". $stats. "</div>";
			} elseif($allowed > $total && $total != "0" && $total){
				$diff=$allowed-$total;
				$stats="<div style=\"color: green;\" title=\"-".$diff." under\" class=\"tooltips\">". $stats. "</div>";
			} 
		}
		
		// map was once cycled threw 'rules'
/*
			$livestats2=$Query->GameQ($ggid, 'rules');
			if($livestats2['gq_mapname'])$map=$livestats2['gq_mapname'];
			if($livestats2['sv_map'])$map=$livestats2['gq_mapname'];
			if($livestats2['g_map'])$map=$livestats2['gq_mapname'];

*/

		if(!isset($results['server']['hostname']) && isset($results['server']['gq_hostname'])) $results['server']['hostname']=$results['server']['gq_hostname'];
		if(!isset($results['server']['map']) && isset($results['server']['gq_mapname'])) $results['server']['map']=$results['server']['gq_mapname'];
		if(!isset($results['server']['map']) && isset($results['server']['sv_map'])) $results['server']['map']=$results['server']['sv_map'];
		if(!isset($results['server']['map']) && isset($results['server']['g_map'])) $results['server']['map']=$results['server']['g_map'];

		if(isset($results['server']['map'])){
			$results['server']['map']=str_replace("obj/",'',$results['server']['map']);
			$results['server']['map']=str_replace("mp/",'',$results['server']['map']);
			$results['server']['map']=str_replace("dm/",'',$results['server']['map']);
			$results['server']['map']=str_replace("maps/",'',$results['server']['map']);
			$results['server']['map']=str_replace(".entities",'',$results['server']['map']);
		}

		if(!isset($total) || $total == "") $total="0";
		if(!isset($active) || $active == "") $active="0";
		if(isset($nomap))$results['server']['map']="";

		if(!isset($results['server']['map'])) $results['server']['map']="";
		if(!isset($results['server']['hostname'])) $results['server']['hostname']="";
		if(!isset($results['server']['gq_password'])) $results['server']['gq_password']="";

		if(is_array($lastplayers) && isset($lastplayers[10])){
			$hourly=$lastplayers[10];
		} else $hourly=array();

		$hourly[date("H")]=$active;

		if($lastactivetime == "") $lastactivetime=time();
		if($active > "0" ) $lastactivetime=time();

		$array=array($total, $active, $status, '', $stats, $ipport, $results['server']['map'], $results['server']['hostname'], $altstatus, $results['server']['gq_password'], $hourly, "filesize" => $fs);
		sql_query($safesql->query("UPDATE usergames SET lastplayers='%s', lastplytime='%s', lastactivetime='%s' WHERE id='%i' LIMIT 1;", 
			array(serialize($array), 
			time(), 
			$lastactivetime,
			$GameCP->whitelist($ugid, "int"))));

		return $array;
	}

	function Ventrilo($ip, $port){
		global $GameCP;
		
		//session_write_close();


		require_once(path."/includes/core/classes/gameq2/GameQ.php");
		$servers = array(array('id' => 'server', 'type' => 'ventrilo', 'host' => $ip.":".$port));
		$gq = new GameQ();
		$gq->addServers($servers);
		$gq->setOption('timeout', qstattimeout);
		$gq->setFilter('normalise');
		$results = $gq->requestData();


		if(isset($results['server']['gq_maxplayers']))$total=$results['server']['gq_maxplayers'];
		if(isset($results['server']['gq_numplayers']))$active=$results['server']['gq_numplayers']; 
		if(isset($results['server']['gq_hostname']))$hostname=$results['server']['gq_hostname']; 
		if(!$active) $active="0";
		if($results['server']['gq_online'] != "1") return false;

		return array($total, $active, "up", $hostname);
	}

	function Teamspeak($ip, $superpass, $superuser, $serverport, $voicetype="ts2"){
		global $GameCP;

		//session_write_close();

		if(!$voicetype) $voicetype="ts2";
		if($voicetype != "ts2"){
			/* by-pass gameq for ts3 as its the pits */
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$machineInfo=$Panel->GetServer('', $ip);

			$adminport=$machineInfo['ts3port'];
			require_once(path.'/includes/core/classes/voice/ts3admin.class.php');
			//$tsAdmin = new ts3admin($machineInfo['ip'], $adminport, '2');
			$tsAdmin = new ts3admin($ip, $adminport, '2');
			if($tsAdmin->getElement('success', $tsAdmin->connect())) {
				$tsAdmin->login($superuser, $superpass);
				$tsAdmin->selectServer($serverport);
				$results=$tsAdmin->serverInfo();
				$results=$results['data'];
				unset($tsAdmin);
				if(!is_array($results)) return false;
				return array($results['virtualserver_maxclients'], $results['virtualserver_clientsonline']-1, "up", $results['virtualserver_name'], $results['virtualserver_id']);
			} else return false;
		}

		require_once(path."/includes/core/classes/gameq/GameQ.php");
		$servers = array('server' => array($voicetype, $ip, $serverport));
		$gq = new GameQ();
		$gq->addServers($servers);
		$gq->setOption('timeout', 900);
		$gq->setOption('sockets', 900);
		$gq->setFilter('normalise');
		$gq->setFilter('stripcolor');

		$results = $gq->requestData();

		if(isset($results['server']['gq_maxplayers']))$total=$results['server']['gq_maxplayers'];
		if(isset($results['server']['num_players'])){
			$active=$results['server']['num_players']; 
		}elseif(isset($results['server']['gq_numplayers']))$active=$results['server']['gq_numplayers']; 

		if(!$active) $active="0";

		if(isset($results['server']['gq_hostname']))$hostname=$results['server']['gq_hostname']; 


		if($voicetype== "ts2"){
			if($results['server']['gq_online'] != "1" || !$results['server']['server_id']) return false;
		} else {
			if($results['server']['gq_online'] != "1") return false;
		}

		return array($total, $active, "up", $hostname, $results['server']['server_id']);
	}

	function Shoutcast($ip, $port, $type="s"){
		$streamdata=array();

		$scurl = "http://". $ip.":".$port."/index.html";
		$durl = "http://". $ip.":".$port."/7.html";

		/* page 7 tells us some good data */
		$details=$this->GetURL($durl);
		$scdetail=explode(",", $details);

		if(isset($scdetail[5])) $streamdata['Bitrate'] = $scdetail[5];
		if(isset($scdetail[3])) $streamdata['Max Listeners'] = $scdetail[3];
		if(isset($scdetail[4])) $streamdata['Total Listeners'] = $scdetail[4];
		if(isset($scdetail[1])) $streamdata['Streams'] = $scdetail[1];

		/* Grab all the public data */
		$scdata=$this->GetURL($scurl);

		if($scdata){
			$scarray=explode("</td></tr>", $scdata);

			if(is_array($scarray)){

				foreach ($scarray as $scinfo){
					$scinfo=strip_tags($scinfo);

					if ($dp = strpos($scinfo, ":")){

						$var = substr($scinfo, 0, $dp);
						$value = trim(substr($scinfo, ($dp+1)));

						if (preg_match("/Server Status/i", $scinfo)) $streamdata['Server Status'] = $value;
						if (preg_match("/Stream Status/i", $scinfo)) $streamdata['Stream Status'] = $value;
						if (preg_match("/Listener Peak/i", $scinfo)) $streamdata['Listener Peak'] = $value;
						if (preg_match("/Average Listen Time/i", $scinfo)) $streamdata['Average Listen Time'] = $value;
						if (preg_match("/Stream Title/i", $scinfo)) $streamdata['Stream Title'] = $value;
						if (preg_match("/Content Type/i", $scinfo)) $streamdata['Content Type'] = $value;
						if (preg_match("/Stream Genre/i", $scinfo)) $streamdata['Stream Genre'] = $value;
						if (preg_match("/Stream URL/i", $scinfo)) $streamdata['Stream URL'] = $value;
						if (preg_match("/Stream AIM/i", $scinfo)) $streamdata['Stream AIM'] = $value;
						if (preg_match("/Stream IRC/i", $scinfo)) $streamdata['Stream IRC'] = $value;
						if (preg_match("/Current Song/i", $scinfo)) $streamdata['Current Song'] = $value;
					}
				}
				return($streamdata);


			} else return false;
		} else return false;
	}

	function GetURL( $url ) {
		 /* found from php.net by redvader at yandex dot ru & changed up a little to be more streamline & bugfree*/
	   $url_parsed = parse_url($url);
	   $host = $url_parsed["host"];
	   $port = $url_parsed["port"];
	   $path = $url_parsed["path"];
	   $content="";

		if(!$host || !$port || !$path) return false;

	   if (isset($url_parsed["query"]) && $url_parsed["query"] != "") $path .= "?".$url_parsed["query"];

	   $out = "GET $path HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.4) Gecko/2008102920 Firefox/3.0.4\r\nAccept: */*\r\nHost: ".$host."\r\n\r\n";
	   if(@$fp = fsockopen($host, $port, $errno, $errstr, 2)){
		   fwrite($fp, $out);
		   while (!feof($fp))$content.=fgets($fp, 128);
		   fclose($fp);
		
			$content=str_replace("\r", "\n", str_replace("\r\n", "\n", $content));
			$content=str_replace("<BR>", "\n", $content);
		   return $content;
	   } else return false;
	}

	function TrackMania($ip, $port){
		require_once(path."/includes/core/classes/query/gbxRemote.inc.php");
		$client = new IXR_Client_Gbx;
		if (!$client->InitWithIp($ip,$port)) {
			$client->Terminate();
			return true;
		} else return false;
	}

	function Mumble($ip, $port) {
		require_once 'Ice.php'; //include from /usr/share/Ice-3.4.2/php/lib
		require_once 'Murmur.php'; //generated with slice2php from Murmur.ice
		
		try {
			$secret = array('secret'=>'PasswordHere');
			
			$ICE = Ice_initialize();
			$base = $ICE->stringToProxy("Meta:tcp -h $ip -p $port");
			$meta = $base->ice_checkedCast("::Murmur::Meta")->ice_context($secret);

			$default = $meta->getDefaultConf();
			$total = $default['users'];
			$hostname = $default['registername'];

			$users = $meta->getServer(1)->ice_context($secret)->getUsers();
			$active = sizeof($users);			
		   
			return array($total, $active, "up", $hostname);
		} catch (Ice_Exception $ex) {
				return FALSE;
		}
	}


}
?>