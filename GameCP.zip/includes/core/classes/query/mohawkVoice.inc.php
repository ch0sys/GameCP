<?php

/**
 * @access private 
 * @internal
 */
	/**
	//****************************************************************************************
	//
	//	MohawkVoice PHP Monitor
	//	support@mohawkvoice.com
	//	www.mohawkvoice.com
	//
	
	 This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

	//****************************************************************************************
	**/
class Mohawk{
	function mohawkVoice($server_ip, $server_port){
		$query = "";
		$q_result = "";
		$count_channels = 0;
		$count_entity = 0;

					
		//Change this to a */ to comment out the form.
		if(!empty($server_ip))
		{
			//Opening connection to server on port 9152
			$mohawk_server =@fsockopen($server_ip, $server_port, $errno, $errstr, 3);
			
			/**
			The following errors out if no connection can be made to the server information provided.
			If it is successful, we run the status\r\n command to start building our arrays and displaying it on the page
			**/
			If (!$mohawk_server) {
			
				return false;
			
			} else {
			
				$query = fwrite($mohawk_server, "status\r\n");

					while (!feof($mohawk_server)) {
					
						$q_result .= fread($mohawk_server, 4096);
						
					}

				$status="up";

				//Building the status information in to array($info)
				$info = explode("\r\n", $q_result);
				
				ForEach ($info as $lines) {
				
					$data = explode(",", $lines);
					
					Switch ($data[0]) {
					
						//Grabbing Server Name Information
						Case "N":
							
							If ($data[1] == "R") {
							
								$server_name = $data[2];
								
								//Stripping quotations around the value
								If ($server_name[0] == '"') {
								
									$server_name = substr($server_name, 1);
									$server_name = substr($server_name, 0, -1);
								
								}
							
							}
							
							break;
					
						//Grabbing Server Version
						Case "V":
						
							$report_version = $data[1];
							break;
					
						//Grabbing Server Uptime and formatting it properly
						Case "U":
						
							//Report Uptime
							$uptime = explode(":", $data[1]);
							
							//Stripping the leading zeros
							$hours = $uptime[0];
							$minutes = $uptime[1];
							$h_count = 0;
							$m_count = 0;
							
							$h_length = (strlen($hours) - 1);
							$m_length = (strlen($minutes) - 1);
							
							While ($h_count < $h_length) {
							
								If ($hours['$h_count'] == "0") {
								
									$hours = substr($hours, 1);
								
								}
								
								$h_count++;
							
							}
							
							While ($m_count < $m_length) {
							
								If ($minutes['$m_count'] == "0") {
								
									$minutes = substr($minutes, 1);
								
								}
								
								$m_count++;
							
							}
							
							$report_uptime = "$hours Hours $minutes Minutes";
							break;
						
						//Grabbing Users Logged in and formatting
						Case "C":
						
							$slots = $data[1];
							$s_count = 0;
							
							If ($slots <> "100") {
							
								While ($s_count < "2") {
								
									If ($slots['$s_count'] == "0") {
									
										$slots = substr($slots, 1);
									
									}
									
									$s_count++;
								
								}
							
							}
							
							$report_slots_used = $slots;			
							break;
						
						//Grabbing slots available
						Case "M":
						
							//Report available slots
							$report_slots_avail = $data[1];
							break;
					
					}
					
				
				}
				
			}

			fclose($mohawk_server);
			if($report_slots_avail){
				return array(@$report_slots_used,@$report_slots_avail,@$server_name,@$report_uptime, $status);
			} else return false;
			
		}
		
		return false;
	}
}
?>