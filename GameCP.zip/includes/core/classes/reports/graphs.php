<?php 

class Graphs
{
    public $dir = "";
    public $graph_name = "graph.rrd";
    public $graph_style = "-c BACK#ffffff -c GRID#cccccc -c MGRID#cccccc -c FRAME#cccccc -c ARROW#000000";

    public function Update($item = array(  ))
    {
        $stringq = "";
        foreach( $item as $it => $em ) 
        {
            $stringq .= "" . ":" . $em;
        }
        return "rrdtool update " . $this->graph_name . "" . " N" . $stringq . "\r" . "\n";
    }

    public function Create($item, $time)
    {
        if( !is_array($item) ) 
        {
            $item = array(  );
        }

        if( !$time ) 
        {
            $time = time();
        }

        $stringq = "";
        foreach( $item as $it => $em ) 
        {
            $stringq .= " DS:" . $it . ":GAUGE:" . stepdelay * 2 . ":U:U";
        }
        return "rrdtool create " . $this->graph_name . " --step " . stepdelay . "" . " --start " . $time . " " . $stringq . " RRA:AVERAGE:0.5:1:288 RRA:AVERAGE:0.5:6:336 RRA:AVERAGE:0.5:24:372 RRA:AVERAGE:0.5:288:351\r\n";
    }

    public function Graph($img_name, $start, $vertlabel = "default", $item, $h = "45", $w = "180")
    {
        if( !$vertlabel ) 
        {
            $vertlabel = "default";
        }

        $stringq = "";
        $stringq2 = "";
        foreach( $item as $it => $em ) 
        {
            $stringq .= " DEF:" . $em["item"] . "=" . $this->graph_name . ":" . $em["item"] . ":AVERAGE";
            $stringq2 .= " " . $em["type"] . ":" . $em["item"] . $em["color"] . ":" . $em["label"];
        }
        return "" . "rrdtool graph " . $img_name . " " . $this->graph_style . "" . " --start -" . $start . " -a PNG --units-exponent 0 --alt-y-mrtg -w " . $w . " -h " . $h . " --vertical-label " . $vertlabel . " " . $stringq . " " . $stringq2 . "\r" . "\n";
    }

    public function GraphImages($items)
    {
        global $LNG_HOURLY;
        global $LNG_DAILY;
        global $LNG_WEEKLY;
        global $LNG_MONTHLY;
        global $LNG_ANNUALLY;
        $gr .= $this->Graph("hourly_graph.png", "1h", $LNG_HOURLY, $items);
        $gr .= $this->Graph("daily_graph.png", "1d", $LNG_DAILY, $items);
        $gr .= $this->Graph("weekly_graph.png", "1w", $LNG_WEEKLY, $items);
        $gr .= $this->Graph("monthly_graph.png", "1m", $LNG_MONTHLY, $items);
        $gr .= $this->Graph("yearly_graph.png", "1y", $LNG_ANNUALLY, $items);
        return $gr;
    }

    public function Build($item, $graph_items)
    {
        if( !is_array($item) ) 
        {
            $item = array(  );
        }

        if( DIRECTORY_SEPARATOR == "\\" ) 
        {
            $this->dir = str_replace("/", "\\", $this->dir);
        }

        if( !is_dir($this->dir) && !mkdir($this->dir) ) 
        {
            return false;
        }

        if( !is_writeable($this->dir) ) 
        {
            return false;
        }

        chdir($this->dir);
        $gr = "";
        if( !is_file($this->graph_name) ) 
        {
            $data = array(  );
            foreach( $item as $it => $em ) 
            {
                $data[$it] = "0";
            }
            $gr .= $this->Create($item, time());
            $gr .= $this->Update($data);
        }
        else
        {
            $gr .= $this->Update($item);
        }

        $gr .= $this->GraphImages($graph_items);
        return $this->ExecGraph($this->dir, $gr);
    }

    public function ExecGraph($dir, $gr)
    {
        global $Backend;
        global $GameCP;
        if( rrdUseEXEC == "true" ) 
        {
            if( DIRECTORY_SEPARATOR == "\\" ) 
            {
                $dir = str_replace("/", "\\", $dir);
                $gr = str_replace("rrdtool", path . "\\includes\\cron\\rrdtool.exe", $gr);
                $gr .= "\r\nexit";
                $filename = "" . $dir . "\\run-stats.bat";
                $cmd = "cmd /c " . $filename;
            }
            else
            {
                $gr = "" . "#!/bin/bash\r\n" . $gr;
                $gr = str_replace("\r", "", $gr);
                $filename = "" . $dir . "/run-stats.sh";
                $cmd = "bash " . $filename;
            }

            if( is_writable($dir) && ($handle = fopen($filename, "w+")) ) 
            {
                if( fwrite($handle, $gr) === FALSE ) 
                {
                    echo "" . "--- Couldnt create stats script (" . $filename . ")";
                }
                else
                {
                    chdir($dir);
                    exec($cmd);
                    exec($cmd) . "\n";
                    chdir(path);
                }

                fclose($handle);
            }

            if( is_file($filename) ) 
            {
                unlink($filename);
                return NULL;
            }

        }
        else
        {
            $GameCP->loadIncludes("panel");
            $Panel = new Panel();
            $sid = $Panel->GetMasterID();
            if( $sid ) 
            {
                if( DIRECTORY_SEPARATOR == "\\" ) 
                {
                    $dir = str_replace("/", "\\", $dir);
                    $gr = "" . "cd " . $dir . "\r" . "\n" . $gr;
                    $Backend->QueryResponse($sid, "", "" . "writefile:_:\$MAINDIRgamecp-graph.bat:_:" . $gr . "\r" . "\ndel /F gamecp-graph.bat\r\nexit");
                    $Backend->Query($sid, "", "\$MAINDIRgamecp-graph.bat");
                    return NULL;
                }

                $gr = "" . "#!/bin/bash\r\ncd " . $dir . "\r" . "\n" . $gr;
                $gr = str_replace("\r", "", $gr);
                $Backend->QueryResponse($sid, "", "" . "writefile:_:gamecp-graph.sh:_:" . $gr);
                $Backend->Query($sid, "", "command:_:bash gamecp-graph.sh ; rm -f gamecp-graph.sh ");
            }

        }

    }

}


