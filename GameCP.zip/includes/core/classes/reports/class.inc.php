<?php 

class Reports
{
    public function UserGame($ugid)
    {
    }

    public function ViewsImpressions($views, $impressions)
    {
        $Graphs = new Graphs();
        $Graphs->dir = path . "/includes/reports/views";
        $graph_items = array(  );
        $data = array( "views" => $views, "impressions" => $impressions );
        $graph_items[] = array( "type" => "LINE", "item" => "views", "label" => "views", "color" => "#000000" );
        $graph_items[] = array( "type" => "AREA", "item" => "impressions", "label" => "impressions", "color" => "#CCCCCC" );
        $result = $Graphs->Build($data, $graph_items);
        return $result;
    }

}


