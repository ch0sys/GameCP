<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Support{

	function Remove($tid){
		global $GameCP, $safesql;

		if(ALLOWTICKETUPLOADS == "yes" && TICKETUPLOADPATH){

			$ticketResult = sql_query($safesql->query("SELECT U.username as user, T.*, T.id as 'tid' FROM ttsystem T, users U WHERE T.id='%i' and U.id = T.cid LIMIT 1", array($GameCP->whitelist($tid, "int")))) or die(mysql_error());
			$ticketResult = mysql_fetch_array($ticketResult);

			if(isset($ticketResult['files'])){
				$filesdel=explode(",", $ticketResult['files']);
				foreach($filesdel as $delfile){
					$file=TICKETUPLOADPATH."/".$delfile;
					if(is_file($file)) unlink($file);
				}
			}
		}

		sql_query($safesql->query("DELETE FROM ttsystem WHERE id = '%i' LIMIT 1", array($GameCP->whitelist($tid, "int")))) or die(mysql_error());

	}


	function parseMail($parse){
		global $Support;
		$method="";
		foreach($parse as $email){

			$body=explode("\n",$email[3]);
			$br="";
			foreach($body as $bd => $b){
				if($b[0] != ">") $br.="$b\n";
			}
			$email[3]=$br;

			$cid=$this->returnID($email[1]);
			if(!$cid){
				if(ttuid){
					$cid=ttuid;
				} else {
					$mainadminQ=sql_query("SELECT id FROM users WHERE userlevel='1' AND mainadmin='1' LIMIT 1");
					$mainadmin=mysql_fetch_array($mainadminQ);
					$cid=$mainadmin[0];
				}
			}else $email[1]=false;

			if(!$cid){
				echo "No client id available - importing failed. Please enable an admin with main admin checked or set a ticket user id in settings.\r\n";
				break;
			}
			if(preg_match('/\[(?P<name>\w+): (?P<digit>\d+)\]/', $email[2], $mat)){
				$tid=$mat['digit'];
				echo "Reply: ticket #$tid by userid #$cid - ".$email[1] ."\r\n";
				if($this->CheckTicket($tid) == "1"){
					$method="Reply";
				} else $method="Create";
			} else {
				echo "New: userid #$cid - ".$email[1] ."\r\n";
				$method="Create";
			}

			$files="";

			if($method=="Create"){
				$this->Create($cid, $title, $email[2], $email[2], nl2br($email[3]), '', $files, $email[1]);
			} elseif($method=="Reply") $this->Reply($cid, $tid, 'Open', '', nl2br($email[3]), '', $email[1]);
		}
	}

	function returnID($mail){
		global $safesql;
		$userInfoQ=sql_query($safesql->query("SELECT id FROM users WHERE email='%s' LIMIT 1", array($mail)));
		$userInfo=mysql_fetch_array($userInfoQ);
		return $userInfo['id'];
	}

	function CheckTicket($tid){
		global $safesql;
		$ticketResult = sql_query($safesql->query("SELECT id FROM ttsystem WHERE id='%i' LIMIT 1;", array($tid))) or die(mysql_error());
		return mysql_num_rows($ticketResult);
	}

	function Reply($cid, $tid, $status, $resolved, $ticketReply, $summary, $mail_address=FALSE, $title=FALSE, $assignedto=FALSE){
		global $sig, $GameCP, $safesql, $Email, $Event;

		$ticketReply = $GameCP->whitelist($ticketReply, "wysiwyg");
		$cid = $GameCP->whitelist($cid, "int");
		$tid = $GameCP->whitelist($tid, "int");

		if(!$cid) $cid=ttuid;

		$GameCP->loadIncludes("email");

		$UserNameQ = sql_query($safesql->query("SELECT name, userlevel FROM users WHERE id = '%i' LIMIT 1;", array($GameCP->whitelist($cid, "int"))));
		$UserName = mysql_fetch_row($UserNameQ); 
		$User = $UserName[0];
		$UserLevel = $UserName[1];

		$Event->EventLogAdd($User, "Trouble Ticket Edited: cid:".$cid." ticket: ". $tid. " ip:".@$_SERVER['REMOTE_ADDR']);

		/* DEFINE TICKET ITEMS */
		if(isset($_SESSION['gamecp']['userinfo']['ulevel'])){
			if(!$cid) $cid=$_SESSION['gamecp']['userinfo']['id'];
			$cQuery='';
			if ($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2" && $_SESSION['gamecp']['userinfo']['ulevel'] != "3"  && $_SESSION['gamecp']['userinfo']['ulevel'] != "4" && $_SESSION['gamecp']['userinfo']['ulevel'] != "5") { $cQuery=" AND U.id='$cid'"; }
			if($_SESSION['gamecp']['userinfo']['ulevel'] == "4") $cQuery="AND U.rsid='".$_SESSION['gamecp']['userinfo']['id']."'";
			$ticketResult = sql_query($safesql->query("SELECT U.username as user, T.*, T.id as 'tid' FROM ttsystem T, users U WHERE T.id='%i' and U.id = T.cid $cQuery LIMIT 1", array($tid))) or die(mysql_error());
		} else $ticketResult = sql_query($safesql->query("SELECT T.*, T.id as 'tid' FROM ttsystem T WHERE T.id='%i' LIMIT 1", array($tid))) or die(mysql_error());


		$ticketResult = mysql_fetch_array($ticketResult);
		$message=$ticketResult['message'];
		$usercid=$ticketResult['cid'];
		$subject=$ticketResult['subject'];
		/* END TICKET ITEMS */

		if(isset($_REQUEST['status'])){
			$status = $_REQUEST['status']; 
		} else $status="In Progress";

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$userInfo=$Panel->GetUser($cid);
		$uname=$userInfo['name'];

		if(!$summary) $summary=$ticketResult['summary'];
		if(!$resolved) $resolved=$ticketResult['resolved'];
		if(!$status) $status=$ticketResult['status'];
		if(!$title) $title=$ticketResult['title'];

		/* Mail reply */
		if($mail_address){
			if($sig) $sig="<br>".nl2br($sig);
			$status="Reply";
			if($ticketReply) $addon = "<div class='customerreply'>".$mail_address. " replied to ticket on " .date("F j, Y, g:i a") ."</div><div class='ticketcontent'>". $ticketReply.$sig."</div>";
			$it=$addon.$message;
			sql_query($safesql->query("UPDATE ttsystem SET status='Reply', message='%s',updated='%s' 
											WHERE id = '%i';", 
												array($GameCP->whitelist($it, "wysiwyg"),
														time(), $tid))) or die(mysql_error());


		/* Admn reply */
		}elseif ((!isset($_SESSION['gamecp']['userinfo']['ulevel']) && ($UserLevel == "1" || $UserLevel == "2" || $UserLevel == "3" || $UserLevel == "4" || $UserLevel == "5")) || ($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "3" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4" || $_SESSION['gamecp']['userinfo']['ulevel'] == "5")) {
			if($ticketReply){
				if($sig) $sig="<br>".nl2br($sig);

				$addon = "<div class='adminreply'>".$uname. " replied to ticket on: " .date("F j, Y, g:i a") ."</div><div class='ticketcontent'>". $ticketReply.$sig."</div>"; 
				$it=$addon."<br>".$message;
			} else $it=$message;


			sql_query($safesql->query("UPDATE ttsystem SET 
				status='%s',
				resolved='%s',
				message='%s',
				updated='%s',
				summary='%s',
				assigned='%i',
				title='%s'
			WHERE id = '%i';", array($status, $resolved, $GameCP->whitelist($it, "wysiwyg"), time(), $GameCP->whitelist($summary, "useredit"), $GameCP->whitelist($assignedto, "int"), $GameCP->whitelist($title, "useredit"), $tid))) or die(mysql_error());

		} else {
		/* All reply */
			$status="Reply";
			if($sig) $sig="<br>".$sig;
			if($ticketReply) $addon = "<div class='customerreply'>".$uname. " replied to ticket on  " .date("F j, Y, g:i a") ."</div><div class='ticketcontent'>". $ticketReply.$sig."</div>";
			$it=$addon.$sig.$message;
			sql_query($safesql->query("UPDATE ttsystem SET status='Reply', message='%s',updated='%s' 
											WHERE id = '%i';", 
												array($GameCP->whitelist($it, "wysiwyg"),
														time(),$tid))) or die(mysql_error());
		}



		/* EMAIL TICKET REPLY */
		if(emailAdmin == "yes"){
			$q=" OR userlevel = '1'"; 
		} else $q="";

		if ($_SESSION['gamecp']['userinfo']['ulevel'] == "0" || $UserLevel == "0") { 
			$managerEmailsQ = sql_query("SELECT email FROM users WHERE (userlevel = '3' $q) AND active='1';") or die(mysql_error());
			$bcc=array();
			while ($row = mysql_fetch_array($managerEmailsQ)) $bcc[]=$row[0];
			$Email->bcc=$bcc;
		} 

		if($ticketResult['mail_address']){ 
			$Email->userid=$cid;
			$Email->emailto=$ticketResult['mail_address'];
		} else $Email->userid = $usercid;
		
		if ($mail_address == false && (!isset($_SESSION['gamecp']['userinfo']['ulevel']) && ($UserLevel == "1" || $UserLevel == "2" || $UserLevel == "3" || $UserLevel == "4" || $UserLevel == "5")) || ($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "3" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4" || $_SESSION['gamecp']['userinfo']['ulevel'] == "5")) {
			$Email->templatename = "Tech-ReplyTicket";
		} else $Email->templatename = "User-ReplyTicket";

		$Email->GetTemplateStuff();

		$Email->usegamedata = true;
		$Email->usevoicedata = true;
		$Email->usebilldata = true;

		$extravars=array();
		$extravars[]=array("var" => "\$Var1", "value" => $title);
		$extravars[]=array("var" => "\$Var2", "value" => $ticketReply.$sig);
		$extravars[]=array("var" => "\$Var3", "value" => $tid);
		$extravars[]=array("var" => "\$subject", "value" => $summary);
		$extravars[]=array("var" => "\$status", "value" => $status);
		$Email->ReplaceStuff($extravars);

		if($ticketReply) $Email->send();

		return true;
	}


	function CreateMonitor($cid, $template, $servicetype, $serviceid, $ip, $port, $servicename){
		global $GameCP, $safesql;

		$Email=new Email();


		$Email->templatename = $template;
		$Email->userid = $cid;
		$Email->GetTemplateStuff();

		$Email->usegamedata = true;
		$Email->usevoicedata = true;

		$Var1=$ip.":".$port;
		$gamename=array();
		$gamename[]= $servicetype." #".$serviceid." ". $servicename ." @ ". $ip.":".$port;
		$games=serialize($gamename);

		$extravars=array();
		$extravars[]=array("var" => "\$Var1", "value" => $Var1);

		$ticket=$Email->ReplaceStuff($extravars);
		$subject=$ticket[0];
		$checkTTQ = sql_query("SELECT * FROM ttsystem WHERE cid = '$cid' AND resolved = 'No' AND subject = '$subject' AND reply = '' AND status = 'Open' LIMIT 1;");

		if((usetickets == "1" && mysql_num_rows($checkTTQ) == "0") || (usetickets == "4" || usetickets == "5")) { 

			if((usetickets == "4" || usetickets == "5")  && tteSupportMail) $Email->bcc = tteSupportMail;
			if(sm_emailNotify == "0") $Email->send(true);

			if(usetickets == "1"){
				$message = "<div class='newticket'>Ticket created on: " .date("F j, Y, g:i a") ."</div><div class='ticketcontent'>". $ticket[1]."</div>";
				sql_query($safesql->query("INSERT INTO ttsystem SET 
							title='%s',
							subject='%s',
							date='%s',
							games='%s',
							cid='%i',
							status='Open',
							resolved='No',
							message='%s',
							updated='%s',
							reply='%s',
							summary='%s',
							files='%s',
							mail_address='%s'", array(
								'Server Monitor',
								$GameCP->whitelist($subject, 'useredit'),
								time(),
								$games,
								$GameCP->whitelist($cid, 'int'),
								$GameCP->whitelist($message, 'wysiwyg'),
								time(),
								'',
								$GameCP->whitelist($subject, 'useredit'),
											
								'', ''))) or die(mysql_error());
			}
		}

	}

	function CreateQuota($cid, $template, $machine){
		global $GameCP, $safesql;

		$Email=new Email();


		$Email->templatename = $template;
		$Email->userid = $cid;
		$Email->GetTemplateStuff();

		$Email->usegamedata = true;
		$Email->usevoicedata = true;

		$Var1=$machine;

		$extravars=array();
		$extravars[]=array("var" => "\$Var1", "value" => $Var1);

		$ticket=$Email->ReplaceStuff($extravars);
		$subject=$ticket[0];
		$checkTTQ = sql_query("SELECT * FROM ttsystem WHERE cid = '$cid' AND resolved = 'No' AND subject = '$subject' AND reply = '' AND status = 'Open' LIMIT 1;");

		if((usetickets == "1" && mysql_num_rows($checkTTQ) == "0") || (usetickets == "4" || usetickets == "5")) { 

			if((usetickets == "4" || usetickets == "5")  && tteSupportMail) $Email->bcc = tteSupportMail;
			if(sm_emailNotify == "0") $Email->send(true);

			if(usetickets == "1"){
				$message = "<div class='newticket'>Ticket created on: " .date("F j, Y, g:i a") ."</div><div class='ticketcontent'>". $ticket[1]."</div>";
				sql_query($safesql->query("INSERT INTO ttsystem SET 
							title='%s',
							subject='%s',
							date='%s',
							games='%s',
							cid='%i',
							status='Open',
							resolved='No',
							message='%s',
							updated='%s',
							reply='%s',
							summary='%s',
							files='%s',
							mail_address='%s'", array(
								'Quota Monitor',
								$GameCP->whitelist($subject, 'useredit'),
								time(),
								'',
								$GameCP->whitelist($cid, 'int'),
								$GameCP->whitelist($message, 'wysiwyg'),
								time(),
								'',
								$GameCP->whitelist($subject, 'useredit'),
											
								'', ''))) or die(mysql_error());
			}
		}

	}

	function Create($cid, $title, $subject, $summary, $message, $reply, $files=FALSE, $mail_address=FALSE){
		global $sig, $GameCP, $safesql, $Email;

		if(!$cid) $cid=ttuid;

		$GameCP->loadIncludes("email");
		$Email=new Email();

		if(!$title) $title="Support";

		$UserNameQ = sql_query($safesql->query("SELECT name FROM users WHERE id = '%i' LIMIT 1;", array($GameCP->whitelist($cid, "int"))));
		$UserName = mysql_fetch_row($UserNameQ); $User = $UserName[0];


		$message = $GameCP->whitelist($message, "wysiwyg");
		$reply = $GameCP->whitelist($reply, "useredit");
		$title = $GameCP->whitelist($title, "useredit");
		$subject = $GameCP->whitelist($subject, "useredit");
		$summary = $GameCP->whitelist($summary, "useredit");
		
		$message = "<div class='newticket'>Ticket created on: " .date("F j, Y, g:i a") ."</div><div class='ticketcontent'>". $message.$sig."</div>";

		if(isset($_POST['game'])){
			$games=serialize($_POST['game']);
		} else $games=array();
		
		if((usetickets == "4" || usetickets == "5")  && tteSupportMail){

			$Email->emailto = tteSupportMail;
			$Email->emailsubject = $title . " " . $summary;
			$Email->emailbody = $message.$sig;
			$Email->send();

		} elseif(usetickets == "1"){

			/* only use tickets if set to use gamecp */
			sql_query($safesql->query("INSERT INTO ttsystem SET 
						title='%s',
						subject='%s',
						date='%s',
						games='%s',
						cid='%i',
						status='Open',
						resolved='No',
						message='%s',
						updated='%s',
						reply='%s',
						summary='%s',
						files='%s',
						mail_address='%s'", array(
							$GameCP->whitelist($title, 'useredit'),
							$GameCP->whitelist($subject, 'useredit'),
							time(),
							$games,
							$GameCP->whitelist($cid, 'int'),
							$GameCP->whitelist($message, 'wysiwyg'),
							time(),
							$GameCP->whitelist($reply, 'wysiwyg'),
							$GameCP->whitelist($summary, 'useredit'),
										
							$GameCP->whitelist($files, 'web'), $mail_address))) or die(mysql_error());

			$tid = mysql_insert_id();
			if(!$tid){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel-ErrorExit('Unable to create ticket');
			}

			if(emailAdmin == "yes"){
				$q=" OR userlevel = '1'"; 
			} else $q="";

			if ($_SESSION['gamecp']['userinfo']['ulevel'] == "0" || $mail_address) { 
				$managerEmailsQ = sql_query("SELECT email FROM users WHERE (userlevel = '3' $q) AND active='1';") or die(mysql_error());
				$bcc=array();
				while ($row = mysql_fetch_array($managerEmailsQ)) $bcc[]=$row[0];
				$Email->bcc=$bcc;
			} 

			$extravars=array();

			if($mail_address){ 
				$extravars[]=array("var" => "\$UserFirstName", "value" => "");
				$extravars[]=array("var" => "\$UserLastName", "value" => "");
				//$Email->userid=$cid;
				$Email->emailto=$mail_address;
			} else $Email->userid = $cid;

			$Email->templatename = "Tech-NewTicket";
			$Email->GetTemplateStuff();

			$Email->usegamedata = true;
			$Email->usevoicedata = true;
			$Email->usebilldata = true;

			$extravars[]=array("var" => "\$Var1", "value" => $title);
			$extravars[]=array("var" => "\$Var2", "value" => $message);
			$extravars[]=array("var" => "\$Var3", "value" => $tid);
			$extravars[]=array("var" => "\$subject", "value" => $summary);
			$extravars[]=array("var" => "\$status", "value" => "Open");

			$Email->ReplaceStuff($extravars);

			$Email->send();
		}

		if(ALLOWTICKETUPLOADS == "yes" && TICKETUPLOADPATH){
			if(isset($_REQUEST['filesdel'])){
				$filesdel=explode(",", $_REQUEST['filesdel']);
				foreach($filesdel as $delfile){
					$file=TICKETUPLOADPATH."/".$delfile;
					if(is_file($file)) unlink($file);
				}
			}
		}
		return $tid;
	}

}
?>