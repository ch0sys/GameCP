<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/**
 * Control class to manage services, stop, start, restart & build
 * 
 * This class manages services with stop start or restart
 * Use Ventrilo, Teamspeak, Teamspeak3, Usergame, Game, Username, UserID
 * 
 */

class Control{



	/**
	 * checks if a service is within its time alloted
	 * @param integer $ugid user game id
	 */
	function Timer($ugid, $ignorestop=false, $returntime=false){
		global $GameCP;

		$GameCP->loadIncludes("game");
		$Game=new Game();

		$userGameInfo=$Game->GetService($ugid);

		if($userGameInfo['use_sched'] == "1" ){
			$start_stamp=$userGameInfo['start_time'];
			$end_stamp=$userGameInfo['end_time'];
						
			if($returntime) return $start_stamp;

			if(isset($start_stamp) && time() < $start_stamp) {
				return false;
			} else if(isset($end_stamp) && time() > $end_stamp && $ignorestop == false) return false;
		}
		return true;
	}

	/**
	 * execute the commands to stop/start/restart regular services
	 * @param string $user username
	 * @param string $sid - server id (ip)
	 * @param integer $ugid user game id
	 * @param integer $os servers os
	 * @param string $sci service name - if defined will use new name
	 * @param string $method - start/stop/restart
	 * @param string $fip - ip of server
	 * @param string $fport  - port of server
	 * @param integer $status - status to set, 0/1/2/3 off/on/repairing/installing
	 * @param integer $reporterr 
	 */
	function Run($user, $sid, $ugid, $os, $sci, $method, $fip, $fport, $status, $reporterr=FALSE){
		global $smarty, $GameCP, $Event, $safesql, $hook_vars;

		if(DEMO == 'yes') return false;

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$GameCP->loadIncludes("game");
		$Game=new Game();
		$usr=$user;

		$ugid=$GameCP->whitelist($ugid, "int");
		$sid=$GameCP->whitelist($sid, "clean");

		if(isset($_SESSION['gamecp']['userinfo']['name'])){
			$whochanged=$_SESSION['gamecp']['userinfo']['name'];
		} else $whochanged="System";

		$Event->EventLogAdd($user, "Game $ugid was told to $method by ".$whochanged);

		if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes"){
			switch($method){
				case "stop":
					$permcode="3";
				break;
				case "start":
					$permcode="2";
				break;
				case "restart":
					$permcode="4";
				break;
			}
			if(in_array($permcode, $_SESSION['gamecp']['subuser']['perms'])) $doControl=true;
			if(!in_array($ugid, $_SESSION['gamecp']['subuser']['games'])) $doControl=false;

		} else $doControl = true;

		if($doControl != true){
			$smarty->assign("serverError", "denied");
			$smarty->display("manageusergames/server-error.tpl");
			return false;
		}
		
		$userGameInfo=$Game->GetService($ugid);
			$rconpass=$userGameInfo['rconpass'];
			//$winsci=$userGameInfo['scontrol'];
			$priority=$userGameInfo['priority'];
			$winport=$userGameInfo['winport'];
			$postmode=$userGameInfo['postmode'];
			$winpostmode=$userGameInfo['winpostmode'];
			$winexec=$userGameInfo['winexec'];
			$installdir=$userGameInfo['install'];
			$wininstalldir=$userGameInfo['wininstall'];
			$winappdir=$userGameInfo['winappdir'];
			$pidstop=$userGameInfo['pidstop'];
			$exestop=$userGameInfo['exestop'];
			$flimit=$userGameInfo['flimit'];
			$cid=$userGameInfo['cid'];
			$stopmode=$userGameInfo['stopmode'];
			$winstopmode=$userGameInfo['winstopmode'];
			$stopconsole=$userGameInfo['stopconsole'];
			$winstopconsole=$userGameInfo['winstopconsole'];
			$lsofcheck=$userGameInfo['lsofcheck'];
			$ugeac=$userGameInfo['eac'];
			$winsci="gcp-$usr-$ugid";
				
			if($userGameInfo['winpremode']){
				$winpremode = $userGameInfo['winpremode'];
			}elseif($userGameInfo['gamewinpremode']){
				$winpremode = $userGameInfo['gamewinpremode'];
			} else $winpremode="";


		if(!$sci){	
			$ugsci=$userGameInfo['scontrol'];
			$gsci=$userGameInfo['scontrolname'];
			if($ugsci){ $sci=$ugsci; } else { 
				$sci=$gsci.".".$ugid; 
				sql_query($safesql->query("UPDATE usergames SET scontrol = '%s' WHERE id = '%i'", array($sci, $ugid))) or die(mysql_error());
			}
		}

		if($userGameInfo['subdirectory'] == "yes"){ 
			if(ipsubdir == "true"){
				$thesubdir=$fip."-".$fport;
			} else $thesubdir="service".$ugid;				
			$homepath="/home/$user/$thesubdir";
		} else $homepath="/home/$user";

		if($os == "1"){ 
			$homepath=str_replace("/", "\\", $homepath);
			if($wininstalldir) $homepath=$homepath."/$winappdir";
		} else if($installdir) $homepath=$homepath."/$installdir";

		$nixaffinity=rtrim($userGameInfo['affinity'], ",");
		
		$winpostscript="gamecp-postmode$ugid.bat";
		$linpostscript=".gamecp-postmode$ugid.sh";

		$GameCP->loadIncludes("user");
		$Userc=new User();
		$totalUserServers=$Userc->GetServers($cid, $ugid, $flimit);
		$activeServers=$totalUserServers[0];
		
		if($method != "stop" && $activeServers >= $flimit){ 
			$limitreached="true"; 	
		} else $limitreached="false";

		if($limitreached == "true"){
			$smarty->assign("serverLimit", $flimit);
			$smarty->assign("ugid", $ugid);
			$smarty->display("manageusergames/server-limit.tpl");
			return false;
		} 

		if(($method == "start" || $method == "restart") && $userGameInfo['gactive'] == "2"){
			$smarty->assign("serverError", "suspended");
			$smarty->display("manageusergames/server-error.tpl");
			return false;
		}

		if(($method == "start" || $method == "restart") && $userGameInfo['active'] != "1"){
			$smarty->assign("serverError", "usersuspended");
			$smarty->display("manageusergames/server-error.tpl");
			return false;
		}

		if($method == "restart" || $method == "start"){
			$autoCfg = sql_query($safesql->query("SELECT id FROM userconfigs WHERE ugid = '%i' AND autoexec ='1';", array($ugid))) or die(mysql_error());
			while($execfg = mysql_fetch_array($autoCfg)) $Game->ConfigCreate($ugid, $execfg['id'], false);			
		}

		if($this->Timer($ugid) == true || $method == "stop"){
			if($os == "1"){ 
				$installdir=$winappdir;
				$winhome=str_replace("/","\\", $homepath);
				if($method != "stop") $this->Build($ugid, 'update');

				if($winpremode && $method != "stop"){
					$winpremode = $Game->ReplaceAllVars($ugid, $winpremode);
					$winpremode="cd /d \$MAINDIR".ltrim($winhome, "\\")."\r\n$winpremode\r\n";
					$Game->Exec($user, $os, $sid, $winport, ".gamecp-premode.sh", "premode.bat", $winpremode);
				}

				$startok = true;
				if($method == "restart" || $method == "stop"){

					if($winstopmode){
						$winstopmode = $Game->ReplaceAllVars($ugid, $winstopmode);
						$winstopmode="cd /d \$MAINDIR$winhome\r\n$winstopmode\r\n";
						$Game->Exec($user, $os, $sid, $winport, ".gamecp-stopmode.sh", "stopmode.bat", $winstopmode);
					}

					$Backend->Query($sid, $winport, "stop:_:$winsci");
					if(!$this->PidStop($pidstop, $sid, $winport, $homepath) || !$this->ExeStop($exestop, $sid, $winport, $homepath)){
						echo "Service was not properly stopped";
						// removed since it just made shit not work well..
						//$startok = false;
					} 
				}

				if($startok == true && ($method == "restart" || $method == "start")) $Backend->Query($sid, $winport, "start:_:$winsci");

				/* change the service to be on/off auto boot */
				if($method == "stop"){
					$Backend->Query($sid, $winport, "sc:_:config $winsci start= demand");			
				} else if($method == "start") $Backend->Query($sid, $winport, "sc:_:config $winsci start= auto");
				

				if($userGameInfo['status'] == "1") $this->Build($ugid, 'debug');
				
				if($winpostmode && $method != "stop"){
					$winpostmode = $Game->ReplaceAllVars($ugid, $winpostmode);
					$winpostmode="cd /d \$MAINDIR$winhome\r\n$winpostmode\r\n";
					$Game->Exec($user, $os, $sid, $winport, ".gamecp-postmode.sh", "postmode.bat", $winpostmode, true);
				}

			} else {

				if($priority){
					switch($priority){
						case "1":
							$prior="19";						
						break;	
						case "2":
							$prior="15";						
						break;	
						case "3":
							$prior="10";						
						break;	
						case "4":
							$prior="0";						
						break;	
						case "5":
							$prior="-10";						
						break;	
						case "6":
							$prior="-15";						
						break;	
						case "7":
							$prior="-20";						
						break;	
					}
				} else $prior="";

				$data=$this->Build($ugid, 'nothing');
				$gameExec=explode(" ", $data['startmode']);
				if(!isset($gameExec[0])) $gameExec[0]=$gameExec;
				$gameExec=str_replace("./", "", $gameExec[0]);

				$data['premode'] = $Game->ReplaceAllVars($ugid, $data['premode']);

				if(isset($_SESSION['gamecp']['subaccount'])){
					$whostarted=$_SESSION['gamecp']['subuser']['name'];
				} else if(isset($_SESSION['gamecp']['userinfo']['name'])){
					$whostarted=$_SESSION['gamecp']['userinfo']['name'];
				} else $whostarted='System';

				$Backend->QueryResponse($sid, $winport, "command:_:echo \"\r\n####### SERVICE ".strtoupper($method)." AT ".date (dateformat. " H:i", time())." BY ". strtoupper($whostarted) ." #######\r\n\" >> /home/$user/screenlog.$ugid", $user);

				if($method == "stop" || $method == "restart"){
					if($stopconsole){
						$GameCP->loadIncludes("linux");
						$Linux=new Linux();
						$Linux->SubmitScreen("service$ugid", $stopconsole, $user, $sid);
						sleep(5);
					}

					if($stopmode){
						$stopmode = $Game->ReplaceAllVars($ugid, $stopmode);
						$stopmode="cd $homepath ; ". $stopmode;
						$Game->Exec($user, $os, $sid, $winport, ".gamecp-stopmode.sh", "stopmode.bat", $stopmode);
					}

					$reply=trim($Backend->QueryResponse($sid, $winport, "stop:_:".$ugid.":_:".$gameExec.":_:cd $homepath ;", $user));
					if($lsofcheck) $Backend->QueryResponse($sid, $winport, "command:_:kill -9 `lsof -nti @$fip:$fport`");
				} 
				if($method == "start" || $method == "restart"){
					if($method == "restart") sleep(2);

					/* new! check if the sreen is started, linux */
					$screen=trim($Backend->QueryResponse($sid, $winport, "screen -wipe > /dev/null ; SCREENPID=`screen -list | grep service$ugid | awk -F . '{ print $1 }' | sed -e s/.//` ; if [ \$SCREENPID ] ; then echo \$SCREENPID; fi;:_:", $user));
					if(is_numeric($screen)){
						echo "Service is already started."; 
						return false;
					}

					$reply=trim($Backend->QueryResponse($sid, $winport, "start:_:".$ugid.":_:".str_replace("'","\'",$data['startmode']).":_:".$data['premode'].":_::_:".$prior.":_:".$nixaffinity.":_:".$gameExec, $user));
				}

				$gr=str_replace("\r", "", $data['premode']." ". @$data['startmode']);
				if($userGameInfo['status'] == "1") $Backend->Query($sid, $winport, "writefile:_:$homepath/debug$ugid.sh:_:$gr", $user);


				switch($reply){
					case "Server was attempted to be started":
						echo $reply;
					break;
					case "Server has no executable":
						$GameCP->loadIncludes("linux");
						$Linux=new Linux();
						$c=explode(";", $data['premode']);
						foreach($c as $d) $Linux->extractCWD($d, "ug".$ugid);
						$thedir=$_SESSION['gamecp']['terminal']["ug".$ugid]['pwd'];
						unset($_SESSION['gamecp']['terminal']["ug".$ugid]['pwd']);
						if(substr($gameExec, 0, 2) == "./"){
							$bin="$thedir/$gameExec";
						} else $bin="$gameExec";
						if(!$reporterr) echo "Service Binary Missing: $bin";
					break;
					case "Server did not start":
						if(!$reporterr) echo $reply;
					break;
					case "Service screen does not exist after 2 seconds":
						if(!$reporterr){
							if (isset($_SESSION['gamecp']['userinfo']['ulevel']) && ($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "3"  || $_SESSION['gamecp']['userinfo']['ulevel'] == "4" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4")){
								echo "Service failed to start. <a href=\"#\" onclick=\"controlGame('repair', '$ugid', 'true');\">Enable repairing mode</a>";
							}
						}
					break;
				}

				if($postmode && $method != "stop"){
					$postmode = $Game->ReplaceAllVars($ugid, $postmode);
					$postmode="cd $homepath ; ". $postmode;
					$Game->Exec($user, $os, $sid, $winport, $linpostscript, $winpostscript, $postmode, true);
				}

			}

			if(!$status) $status="0";
			sql_query($safesql->query("UPDATE usergames SET active = '%s', restarted ='".time()."', lastplytime='', lastplayers='', lastactivetime='' WHERE id = '%i'", array($status, $ugid))) or die(mysql_error());

			if(eac == "1") {
				require_once(path.'/includes/core/classes/games/eac.inc.php');
				$EAC = new EAC();
				if($EAC->Check($userGameInfo['gameid'])) $EAC->Build();
			}
		} else { 
			if(!$reporterr){
				$smarty->assign("serverError", "expired");
				$smarty->display("manageusergames/server-error.tpl");
				return false;
			}
		}

		$hook_vars=$userGameInfo;
		run_hook("control_service");

		return true;
	}


	function PidStop($pidstop, $sid, $winport, $homepath){
		global $Backend;
		if($pidstop){
			$homepath=str_replace("/", "\\", $homepath);
			$pidstop=str_replace("/", "\\", $pidstop);
			$r="";
			$pid=$Backend->QueryResponse($sid, $winport, "readfile:_:\$MAINDIR$homepath\\$pidstop");
			$pids=explode("\n", $pid);
			foreach($pids as $ap => $p){
				if(trim($p) != "") $r.=$Backend->QueryResponse($sid, $winport, "taskkill:_:/F /PID ".trim($p));
			}

			if(!preg_match("/has been terminated/i", $r)) return false;
		}
		return true;
	}

	function ExeStop($exestop, $sid, $winport, $homepath){
		global $Backend;
		if($exestop){
			$script="\$MAINDIRwhatismydir.bat";
			$batch="@echo OFF\r\n ECHO \$MAINDIR\r\nexit\r\n";
			$Backend->Query($sid, '', "writefile:_:$script:_:$batch");
			$maindir=$Backend->QueryResponse($sid, '', "$script:_:");
			$Backend->Query($sid, '', "deletefile:_:$script");
			$homepath=rtrim(trim($maindir),"\\").$homepath;
			$homepath=str_replace("/", "\\", $homepath);
			$exestop=str_replace("/", "\\", $exestop);
			$final=str_replace("\\", "\\\\", "$homepath\\$exestop");

			$r="";
			$pid=$Backend->QueryResponse($sid, $winport, "wmic:_:process where ExecutablePath='$final' get ProcessId");
			$pids=explode("\n", $pid);
			foreach($pids as $ap => $p){
				if(trim($p) != "ProcessId" && trim($p) != "") $r.=$Backend->QueryResponse($sid, $winport, "taskkill:_:/F /PID ".trim($p));
			}
			if(!preg_match("/has been terminated/i", $r)) return false;
		}
		return true;
	}

	/**
	 * create the service scripts/registry key
	 * @param integer $ugid user game id
	 * @param string $mode add/update/debug 
	 * @param string $oldport define to change
	 * @param string $oldip define to change
	 */
	function Build($ugid, $mode, $oldport=FALSE, $oldip=FALSE){
		global  $Event, $GameCP, $safesql;
		$ugid=$GameCP->whitelist($ugid);
		$mode=$GameCP->whitelist($mode);
		$oldport=$GameCP->whitelist($oldport);
		$oldip=$GameCP->whitelist($oldip);

		$GameCP->loadIncludes("game");
		$Game=new Game();
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$replaceParams=array();
		$paramList=array();

		if(!$ugid){
			echo "Internal Error: missing user game id.";
			return false;
		}

		$gameInfo = $Game->GetService($ugid);

		$sid = $gameInfo['sid'];
		$ip = $gameInfo['ip'];

		$port = $gameInfo['port'];
		$defaultport = $gameInfo['defaultport'];

		$startmode = $gameInfo['sci'];
		$usr = $gameInfo['username'];
		$maxplayers = $gameInfo['maxplayers'];
		$startmap = $gameInfo['startmap'];
		$config = $gameInfo['config'];
		$gid = $gameInfo['gameid'];
		$gcode = $gameInfo['gcode'];
		$gamestartmode = stripslashes($gameInfo['gamestartmode']);
		$wingamestartmode = $gameInfo['winstartmode'];
		$install = $gameInfo['install'];
		$rconpassword = $gameInfo['rconpass'];
		$fpubpriv = $gameInfo['pubpriv'];
		$winstopconsole = $gameInfo['winstopconsole'];
		$vars = @unserialize($gameInfo['vars']);
		$ugvars = @unserialize($gameInfo['ugvars']);
		$customvars = @unserialize($gameInfo['customvars']);
		$defaultinfo = @unserialize($gameInfo['defaultinfo']);
		$winsci="gcp-$usr-$ugid";

		if($gameInfo['premode']){
			$premode = $gameInfo['premode'];
		}elseif($gameInfo['gamepremode']){
			$premode = $gameInfo['gamepremode'];
		} else $premode="";


		$game = $gameInfo['game'];
		$sci = $gameInfo['scontrol'];
		$os = $gameInfo['os'];
		$sid = $gameInfo['sid'];
		$subdirectory = $gameInfo['subdirectory'];
		$addons = @unserialize($gameInfo['addons']);

		/* windows */
		$winexec = $gameInfo['winexec'];
		$winappdir = $gameInfo['winappdir'];
		$exedir = $gameInfo['exedir'];
		$winuser = $gameInfo['winuser'];
		$winadminpass = $gameInfo['winadminpass'];
		$winport = $gameInfo['winport'];

		if($gameInfo['useinternal'] == "1"){
			$internal=$gameInfo['internal'];
		} else $internal = $ip;

		if($os == "1") $install=$winappdir;


		if($sci == "") $sci="scontrol-$ugid";
		

		if(!$startmode){
			if($os != "1"){ 
				$startmode=$gamestartmode;
			} else $startmode=$wingamestartmode;
		}	
		if(!$startmode && $os == "1") $startmode = " ";


		if($subdirectory == "yes"){ 
			if(ipsubdir == "true"){
				$thesubdir=$ip."-".$port;
			} else $thesubdir="service".$ugid;
			
			
			if(!$install){
				$homepath="/home/$usr/$thesubdir";
			} else $homepath="/home/$usr/$thesubdir/$install";

		} else {
			if(!$install){
				$homepath="/home/$usr";
			} else $homepath="/home/$usr/$install";
		}

		if($os != "1"){
			$premode=str_replace("cd service$ugid ;", "", $premode);
			if($premode && substr(trim($premode), -1) != ";")$premode.=";";
			$premode= "cd $homepath ; ". $premode;
		}

		if($gameInfo['basepath']){
			$basepath=$gameInfo['basepath'];
		} else $basepath="/usr/local/games/$install";


		$premode = $Game->ReplaceAllVars($ugid, $premode);

		if(eac == "1" && $gameInfo['eac'] == "1") {
			require_once(path.'/includes/core/classes/games/eac.inc.php');
			$EAC = new EAC();
			if($EAC->Check($gameInfo['gameid'], 'cod4')){
				if(!preg_match("/-insecure/", $startmode)) $startmode.=" -insecure";
			}
		}

		if($os != "1"){ 
				
			$startmode = $Game->ReplaceAllVars($ugid, $startmode);
			
			$data=array('#','&','|','*','<','>','^','(',')','[',']');
			foreach($data as $d) $startmode=str_replace($d, "\\".$d, $startmode);
			

			if($mode == "add"){
				$Backend->QueryResponse($sid, $winport, "addserver:_:$ugid", $usr);
				// temporary hack till we fix backend to do both!
				$Backend->Query($sid, $winport, "command:_:chmod 644 /etc/logrotate.d/$usr; chmod 700 /home/$usr");
			}

			return array("startmode" => $startmode, "premode" => $premode, "startdir" => $homepath);
		/* end linux */
		} else {
			$basepath = $homepath;

			if($exedir){ 
				if(preg_match("/:/", $exedir)){
					$winappdir=$exedir;
					$basepath = $exedir;
				} else $winappdir="\$MAINDIR".ltrim($homepath, "/")."\\".$exedir;
			} else $winappdir="\$MAINDIR".ltrim($homepath, "/");

			$winparams=$startmode;
			$homepath=rtrim(str_replace("/", "\\", "\$MAINDIR".$homepath), "\\");
			$winappdir=rtrim(str_replace("/", "\\", $winappdir), "\\");
			$doshared="no";

			$winparams = $Game->ReplaceAllVars($ugid, $winparams);

			if(!$winuser) $winuser="LocalSystem";
 
			switch($gameInfo['priority']){
				case "1":
					$winpriority="Below Normal";						
				break;	
				case "2":
					$winpriority="Idle";						
				break;	
				case "3":
					$winpriority="Below Normal";						
				break;	
				case "4":
					$winpriority="Normal";						
				break;	
				case "5":
					$winpriority="Above Normal";						
				break;	
				case "6":
					$winpriority="High";						
				break;	
				case "7":
					$winpriority="Real Time";						
				break;	
				default:
					$winpriority="Normal";
			}

			$winffinity=rtrim($gameInfo['affinity'], ",");

			if($mode == "update"){
				$Backend->Query($sid, $winport, "updateserver:_:$winsci:_:$winexec:_:$doshared:_:$winappdir:_:$winparams:_:User: $usr IP:Port: $internal:$port:_:$winstopconsole:_:$winpriority:_:$winffinity");
			} elseif($mode == "add"){
				$Backend->QueryResponse($sid, $winport, "addserver:_:$winsci:_:$winexec:_:$doshared:_:$winappdir:_:$winparams:_:User: $usr IP:Port: $internal:$port:_:$winuser:_:$winadminpass:_:$winstopconsole:_:$winpriority:_:$winffinity");
				$Backend->Query($sid, $winport, "sc:_:config $winsci start= demand");

			} elseif($mode == "debug"){
				$batCommand=$winappdir."\\".$winexec." ". $winparams;				
				$Backend->Query($sid, $winport, "writefile:_:$homepath\debug$ugid.bat:_:$batCommand");
				$Backend->Query($sid, $winport, "updateserver:_:$winsci:_:$winexec:_:$doshared:_:$winappdir:_:$winparams:_:User: $usr IP:Port: $internal:$port:_:$winstopconsole:_:$winpriority:_:$winffinity");
			}
		} /* end windows */

		if(isset($_SESSION['gamecp']['userinfo']['name'])){
			$whochanged=$_SESSION['gamecp']['userinfo']['name'];
		} else $whochanged="System";

		$Event->EventLogAdd($usr, "Game $ugid had its scontrol changed by ".$whochanged);

		return true;
	}

	/**
	 * stop/start/restart
	 * @param string $ip voice server ip
	 * @param string $port voice server port
	 * @param string $method start/stop/restart
	 */
	function Ventrilo($ip, $port, $method){
		global $GameCP,  $safesql;

		$ip=$GameCP->whitelist($ip, "clean");
		$port=$GameCP->whitelist($port, "int");

		if(usedarkstarvent == "yes"){
			$voiceResult = sql_query($safesql->query("SELECT id, billingId, ip, port, tssid, api_id FROM uservoice WHERE ip = '%s' AND port = '%s' LIMIT 1", array($ip, $port))) or die(mysql_error());
			$voiceResults = mysql_fetch_array($voiceResult);
			if(is_array($voiceResults)){
				$GameCP->loadIncludes("darkstarllc");

				switch($method){
					case "stop":
						$result=darkstar_StopServer($voiceResults['api_id']);
						$active="0";
					break;
					case "start":
						$result=darkstar_ReStartServer($voiceResults['api_id']);
						$active="1";
					break;
					case "restart":
						$result=darkstar_ReStartServer($voiceResults['api_id']);
						$active="1";
					break;
				}
			} else{
				echo "Unable to determine server.";
				return false;
			}
		} else {

			$GameCP->loadIncludes("backend");
			$Backend=new Backend();
			
			if($method == "stop" || $method == "restart") $Backend->Query($ip, '', "command:_:cd /home/vent/$ip\:$port ; PIDOF=`pwd`/ventrilo_srv; kill -9 `pidof \$PIDOF` ", 'vent');
			if($method == "restart") sleep(1);
			if($method != "stop") $Backend->Query($ip, '', "command:_:cd /home/vent/$ip\:$port ; ./ventrilo_srv -R/usr/local/gcp/licensekey &>/dev/null", 'vent');
			
			if($method == "stop"){
				$active="0";
			} else $active="1";
		}
		
		sql_query($safesql->query("UPDATE uservoice SET active='%i' WHERE ip='%s' AND port='%s';", array($active, $ip, $port))) or die(mysql_error());
	}

	/**
	 * stop/start/restart
	 * @param string $ip voice server ip
	 * @param string $port voice server port 
	 * @param string $method start/stop/restart
	 * @param string $tssid voice service id, in gamecp
	 */
	function Teamspeak($ip, $port, $method, $tssid){
		global $GameCP, $safesql;

		$ip=$GameCP->whitelist($ip, "clean");
		$port=$GameCP->whitelist($port, "int");

		$userVoiceQ=sql_query($safesql->query("SELECT voicetype from uservoice WHERE ip='%s' AND port='%s'", array($ip, $port)));
		$userVoice=mysql_fetch_array($userVoiceQ);
		$voicetype=$userVoice['voicetype'];
		if($voicetype =="ts3") return $this->Teamspeak3($ip, $port, $method, $tssid);

		$adminport="51234";
		$userport="8767";

		/* server info */
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$machineInfo=$Panel->GetServer('', $ip);
		$superpass=$machineInfo['tspass'];
		$superuser=$machineInfo['tsadmin'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }

		$fp=@fsockopen($ip, $adminport);

			if (!$fp) {
			   echo "Unable to connect to the TeamSpeak 2 server.<br>";
			   return false;
			} else {
				stream_set_timeout($fp, 2);
				fwrite($fp,"slogin ".$superuser." ".$superpass."\n");
				$output.= fread($fp, 26);
				fwrite($fp,"sel ".$port."\n");
				$output.= fread($fp, 26);

			if($method == "restart"){

				fwrite($fp,"serverstop" ." " . $tssid ."\n");
				$output.= fread($fp, 26);
				fwrite($fp,"serverstart" ." " . $tssid ."\n");
				$output.= fread($fp, 26);

			} else if($method == "stop"){

				fwrite($fp,"serverstop" ." " . $tssid ."\n");
				$output.= fread($fp, 26);

			} else if($method == "start"){

				fwrite($fp,"serverstart" ." " . $tssid ."\n");
				$output.= fread($fp, 26);

			}
			$output.= fread($fp, 26000);
			fclose($fp);

			}

			$output = explode("\n", $output);
			while (list($key, $val) = each($output)) {
				if($key == "1" && $val != "OK\r"){ echo "Unable to login as a Team Speak superuser.<br>";$err="1"; }
				if($key == "2" && $val != "ERROR, invalid id\r" && $err !="1"){  echo "Unable to select server.<br>"; $err="1";}
			}

			if($err) return false;


		return true;
	}

	/**
	 * stop/start/restart
	 * @param string $ip voice server ip
	 * @param string $port voice server port
	 * @param string $method start/stop/restart
	 * @param string $tssid voice service id, in gamecp
	 */
	function Teamspeak3($ip, $port, $method, $tssid){
		global $GameCP, $safesql;
		$userport="9988";

		$ip=$GameCP->whitelist($ip, "clean");
		$port=$GameCP->whitelist($port, "int");

		/* server info */
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$machineInfo=$Panel->GetServer('', $ip);
		$superpass=$machineInfo['ts3pass'];
		$adminport=$machineInfo['ts3port'];
		$superuser=$machineInfo['ts3admin'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }

		require_once(path.'/includes/core/classes/voice/ts3admin.class.php');
		$tsAdmin = new ts3admin($ip, $adminport);
		$tsAdmin->connect();
		$tsAdmin->login($superuser, $superpass);
			
		$active="1";
		if($method == "restart"){
			$tsAdmin->serverStop($tssid);
			$tsAdmin->serverStart($tssid);
		} else if($method == "stop"){
			$tsAdmin->serverStop($tssid);
			$active="0";
		} else if($method == "start") $tsAdmin->serverStart($tssid);

	
		sql_query($safesql->query("UPDATE uservoice SET active='%i' WHERE ip='%s' AND port='%s';", array($active, $ip, $port))) or die(mysql_error());

		return true;
	}

	function Uservoice($vid, $cmd){
		global $GameCP, $safesql;

		$vid=$GameCP->whitelist($vid, "int");
		$cmd=$GameCP->whitelist($cmd, "clean");

        $status = $cmd;
        $ts2Result = sql_query($safesql->query("SELECT uservoice.ip, uservoice.port, iptable.sid, uservoice.tssid FROM uservoice, iptable WHERE uservoice.id='%i' AND iptable.ip = uservoice.ip LIMIT 1;", array($vid))) or die(mysql_error());
        $tsResult = mysql_fetch_array($ts2Result);
        $fip = $tsResult[0];
        $fport = $tsResult[1];
        $sid = $tsResult[2];
        $tssid = $tsResult[3];
        $active="1";
        if($cmd == "stop") $active="0";
        
		$GameCP->loadIncludes("control");
		$Control=new Control();

		if($vid && !$tssid){
			if(usedarkstarvent == "yes"){
				$ts2Result = sql_query($safesql->query("SELECT ip, port FROM uservoice WHERE id='%i' LIMIT 1;", array($vid))) or die(mysql_error());
				$tsResult = mysql_fetch_array($ts2Result);
				$fip = $tsResult[0];
				$fport = $tsResult[1];
			}
			$Control->Ventrilo($fip, $fport, $cmd);
		} else $Control->Teamspeak($fip, $fport, $cmd, $tssid); 
		
		sql_query($safesql->query("UPDATE uservoice SET `active`='%s' WHERE id='%i' LIMIT 1;", array($active, $vid))) or die(mysql_error());
		return true;
	}

	/**
	 * stop/start/restart per user game, or billingid
	 * @param string $ugid user game id
	 * @param string $mode start/stop/restart
	 * @param string $billid if define control by billingid
	 */
	function Usergame($ugid, $mode="restart", $billid=FALSE, $err=false){
		global $GameCP, $safesql;
		$ugid=$GameCP->whitelist($ugid, 'int');
		$mode=$GameCP->whitelist($mode);
		$billid=$GameCP->whitelist($billid);

		if(!$ugid){ echo "Error: missing ugid."; return false; }
		if($billid == true){
			$where=" AND UG.billingid = '$ugid'";
		} else $where=" AND UG.id='$ugid'";


		$uinfoQ = sql_query($safesql->query("SELECT U.name, S.sid, S.os, UG.id as 'ugid', UG.scontrol  as 'sci', UG.ip, UG.port, U.name FROM usergames UG, iptable I, servers S, users U WHERE I.sid=S.sid AND UG.cid=U.id AND UG.ip=I.ip $where", array())) or die(mysql_error()); 
		$uinfo = mysql_fetch_array($uinfoQ);
		return $this->Run($uinfo['name'], $uinfo['sid'], $uinfo['ugid'], $uinfo['os'], $uinfo['sci'], $mode, $uinfo['ip'], $uinfo['port'], $this->SetStatus($mode), $err);
	}

	/**
	 * stop/start/restart per game id
	 * @param string $gid game id
	 * @param string $mode start/stop/restart
	 */
	function Game($gid, $mode="restart"){
		global $GameCP, $safesql;
		if(!$gid){ die("Error: missing gid."); }
		$gid=$GameCP->whitelist($gid, 'int');
		$uinfoQ = sql_query($safesql->query("SELECT S.sid, S.os, UG.id as 'ugid', UG.scontrol  as 'sci', UG.ip, UG.port, U.name FROM usergames UG, iptable I, servers S, users U, game G WHERE I.sid=S.sid AND UG.cid=U.id AND UG.ip=I.ip AND G.id='%i'", array($gid))) or die(mysql_error()); 
		while($uinfo = mysql_fetch_array($uinfoQ))
			$this->Run($uinfo['name'], $uinfo['sid'], $uinfo['ugid'], $uinfo['os'], $uinfo['sci'], $mode, $uinfo['ip'], $uinfo['port'], $this->SetStatus($mode));
	}

	/**
	 * stop/start/restart per server id
	 * @param string $sid server id
	 * @param string $mode start/stop/restart
	 */
	function Server($sid, $mode="restart"){
		global $GameCP;
		if(!$sid){ die("Error: missing sid."); }
		$sid=$GameCP->whitelist($sid, 'int');
		$uinfoQ = sql_query($safesql->query("SELECT S.sid, S.os, UG.id as 'ugid', UG.scontrol  as 'sci', UG.ip, UG.port, U.name FROM usergames UG, iptable I, servers S, users U WHERE I.sid=S.sid AND UG.cid=U.id AND UG.ip=I.ip AND S.sid='%s'", array($sid))) or die(mysql_error()); 
		while($uinfo = mysql_fetch_array($uinfoQ))
			$this->Run($uinfo['name'], $uinfo['sid'], $uinfo['ugid'], $uinfo['os'], $uinfo['sci'], $mode, $uinfo['ip'], $uinfo['port'], $this->SetStatus($mode));
	}

	/**
	 * stop/start/restart per username
	 * @param string $username username
	 * @param string $mode start/stop/restart
	 */
	function Username($username, $mode="restart"){
		global $GameCP, $safesql;
		if(!$username){ die("Error: missing username."); }
		$username=$GameCP->whitelist($username, 'username');
		$uinfoQ = sql_query($safesql->query("SELECT S.sid, S.os, UG.id as 'ugid', UG.scontrol  as 'sci', UG.ip, UG.port, U.name FROM usergames UG, iptable I, servers S, users U WHERE I.sid=S.sid AND UG.cid=U.id AND UG.ip=I.ip AND U.username='%s'", array($username))) or die(mysql_error()); 
		while ($uinfo = mysql_fetch_array($uinfoQ))
			$this->Run($username, $uinfo['sid'], $uinfo['ugid'], $uinfo['os'], $uinfo['sci'], $mode, $uinfo['ip'], $uinfo['port'], $this->SetStatus($mode));
	}

	/**
	 * stop/start/restart per user id
	 * @param string $uid user id
	 * @param string $mode start/stop/restart
	 */
 	function UserID($uid, $mode="restart"){
		global $GameCP, $safesql;
		if(!$uid){ die("Error: missing user id."); }
		$uid=$GameCP->whitelist($uid, 'int');
		$uinfoQ = sql_query($safesql->query("SELECT S.sid, S.os, UG.id as 'ugid', UG.scontrol  as 'sci', UG.ip, UG.port, U.name FROM usergames UG, iptable I, servers S, users U WHERE I.sid=S.sid AND UG.cid=U.id AND UG.ip=I.ip AND U.id='%i'", array($uid))) or die(mysql_error()); 
		while ($uinfo = mysql_fetch_array($uinfoQ))
			$this->Run($uinfo['name'], $uinfo['sid'], $uinfo['ugid'], $uinfo['os'], $uinfo['sci'], $mode, $uinfo['ip'], $uinfo['port'], $this->SetStatus($mode));
		
	}

	function SetStatus($mode){
		if($mode == "stop"){
			return "0";
		} else return "1";
	}


}
?>