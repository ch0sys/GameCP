<?php 

class GameCP
{
    public $ranNavStats = NULL;
    public $ranUserList = NULL;
    public $tools = array(  );
    public $key = "gamecpuniquekey";
    public $sentKey = "i1gruasdfc3padsr5abeccdada2s8r9oe0k1e2y3s4e5pn6t7t8opm0e";


    public function __construct()
    {
        $this->UsersOnline();
    }

    public function ClientPermissions()
    {
        $mp = array(  );
        $mp["voice"] = array( "removeban", "removeallbans", "addban", "teamspeak", "control", "managevent", "edit", "savevent" );
        $mp["services"] = array( "taskschedule", "timeschedule", "mass", "fastdl", "edit", "edit2", "backup", "saveSched", "deleteSched", "restoreconfigs", "editgame", "addaddon", "addaddon2" );
        $mp["support"] = array( "massupdate", "update", "add", "edit", "new", "view", "viewc", "viewreply", "viewactive", "all", "deletetmpfiles", "download", "uploadfile" );
        $mp["maps"] = array( "install", "uninstall" );
        $mp["clients"] = array( "changepw", "removesubuser", "update", "edit", "updatesub", "editsubaccount", "newsubaccount", "addsubacct", "edit2", "cancel", "update", "viewsubaccount" );
        $mp["dashboard"] = array(  );
        $mp["files"] = array( "download", "wget", "remove", "upload", "doextract", "quickmanage", "edit", "cd", "rename", "mkdir", "mkfile", "addshortcut", "removeshortcut", "Save Changes" );
        $mp["donations"] = array(  );
        $mp["console"] = array(  );
        $mp["configs"] = array( "add", "new", "edit", "execute", "update", "remove", "editconfigs", "builder", "builderedit", "builderrun" );
        $mp["cmdbackend"] = array( "mass", "submitscreen", "viewlog", "downloadlog" );
        $mp["billing"] = array( "print", "view" );
        $mp["serverstatus"] = array(  );
        $mp["process"] = array(  );
        $mp["payment"] = array(  );
        $mp["profile"] = array(  );
        $mp["modules"] = array( "edit", "edit2" );
        $mp["subusers"] = array( "removesubuser", "updatesub", "newsubaccount", "editsubaccount", "addsubacct", "viewsubaccount" );
        return $mp;
    }

    public function AdminPermissions()
    {
        $mp = array(  );
        $mp["payment"] = array(  );
        $mp["donations"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["taxes"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["promotions"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["products"] = array( "view", "new", "newproduct", "addprice", "newprice", "reorder", "viewpackages" );
        $mp["productaddons"] = array( "remove", "removetype", "save", "edit" );
        $mp["gateways"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["currencies"] = array( "updaterates", "update", "edit", "add", "remove", "edit2", "new" );
        $mp["billingcategories"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["update"] = array( "run", "download" );
        $mp["ttcategories"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["tools"] = array( "custom", "autoip", "submitautoip", "sql", "submitsql", "backup", "backupv2", "cron", "cleanup", "optimize", "run_optimize", "phpinfo", "phpinfo2", "portcheck", "checkport" );
        $mp["terminal"] = array(  );
        $mp["settings"] = array( "edit", "logs", "testmail", "disableMaintenance", "update" );
        $mp["schedule"] = array( "remove", "save" );
        $mp["portal"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["orders"] = array( "edit", "run", "remove", "pending", "fraud", "paid", "saveq", "edit2" );
        $mp["online"] = array(  );
        $mp["notify"] = array( "edit", "sendmasspre", "sendmass", "send", "sendpre", "sendall" );
        $mp["newservice"] = array( "new", "add" );
        $mp["news"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["newmachine"] = array( "add", "new" );
        $mp["machines"] = array( "edit", "syncvoice", "updateftpd", "installcron", "updatebackend", "massremip", "edit2", "remove", "removeip", "updateip", "update", "addrange", "addip", "editip", "graphs", "migrate", "migrate2", "migrate3", "migrate4", "directions", "viewdetail" );
        $mp["installgames"] = array(  );
        $mp["gameupdates"] = array( "remove", "manage", "run", "view", "addedit", "doupdate" );
        $mp["games"] = array( "export", "import", "clone", "removeGame", "edit", "edit2", "add", "update", "new" );
        $mp["emails"] = array( "update", "edit", "add", "add2", "edit3", "edit2", "remove", "edit2", "new", "sendtest" );
        $mp["configbuilder"] = array( "updateitems", "removeitem", "edit2", "edit" );
        $mp["commands"] = array( "pre", "save", "sendsave", "send", "remove" );
        $mp["admins"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["addons"] = array( "update", "edit", "add", "remove", "clone", "new" );
        $mp["addoncategories"] = array( "update", "edit", "add", "remove", "edit2", "new" );
        $mp["subusers"] = array( "removesubuser", "updatesub", "newsubaccount", "editsubaccount", "addsubacct", "viewsubaccount" );
        $mp["voice"] = array( "removeban", "removeallbans", "addban", "unsuspend", "suspend", "teamspeak", "control", "managevent", "edit", "savevent", "remove" );
        $mp["services"] = array( "taskschedule", "timeschedule", "mass", "fastdl", "edit", "edit2", "backup", "saveSched", "deleteSched", "changeuser", "unsuspend", "suspend", "restoreconfigs", "editgame", "addaddon", "addaddon2", "newgame2" );
        $mp["support"] = array( "massupdate", "update", "add", "edit", "new", "view", "viewc", "viewreply", "viewactive", "all", "deletetmpfiles", "download", "uploadfile" );
        $mp["maps"] = array( "install", "uninstall" );
        $mp["clients"] = array( "changepw", "removesubuser", "update", "edit", "add", "remove", "clone", "new", "updatesub", "editsubaccount", "newsubaccount", "export", "import", "resetpassword", "addsubacct", "edit2", "cancel", "update", "moveuser", "move2", "move3", "swapshell", "viewsubaccount" );
        $mp["dashboard"] = array(  );
        $mp["files"] = array( "download", "wget", "remove", "upload", "doextract", "quickmanage", "edit", "cd", "rename", "mkdir", "mkfile", "addshortcut", "removeshortcut", "Save Changes" );
        $mp["console"] = array(  );
        $mp["serverstatus"] = array(  );
        $mp["process"] = array(  );
        $mp["payment"] = array(  );
        $mp["configs"] = array( "add", "new", "edit", "execute", "update", "remove", "editconfigs", "builder", "builderedit", "builderrun" );
        $mp["cmdbackend"] = array( "mass", "submitscreen", "viewlog", "downloadlog" );
        $mp["billing"] = array( "print", "view" );
        $mp["modules"] = array( "update", "edit", "action", "remove", "edit2", "new" );
        return $mp;
    }

    public function CheckPermissions($page)
    {
        global $mode;
        global $opt;
        global $noheader;
        if( !isset($_REQUEST["mode"]) ) 
        {
            $_REQUEST["mode"] = "";
        }

        if( !isset($_REQUEST["mode"]) && isset($mode) ) 
        {
            $_REQUEST["mode"] = $mode;
        }

        $failed = false;
        $perms = $_SESSION["gamecp"]["userinfo"]["permissions"];
        if( $_SESSION["gamecp"]["userinfo"]["ulevel"] == "0" ) 
        {
            $mainperms = $this->ClientPermissions();
            if( !isset($mainperms[$page]) ) 
            {
                $failed = true;
            }

        }
        else
        {
            $mainperms = $this->AdminPermissions();
            if( !array_key_exists($page, $mainperms) ) 
            {
                return true;
            }

            if( !empty($_REQUEST["mode"]) && !isset($mainperms[$page][$_REQUEST["mode"]]) ) 
            {
                return true;
            }

        }

        if( !is_array($perms) || !array_key_exists($page, $perms) ) 
        {
            $failed = true;
        }

        if( !empty($_REQUEST["mode"]) ) 
        {
            if( !in_array($_REQUEST["mode"], $mainperms[$page]) ) 
            {
                return true;
            }

            if( !isset($perms[$page][$_REQUEST["mode"]]) ) 
            {
                $failed = true;
            }

        }

        if( $failed ) 
        {
            if( !$noheader ) 
            {
                $this->loadIncludes("panel");
                $Panel = new Panel();
                $Panel->ErrorExit("" . "You do not have permission to view this page. (" . $page . ")");
            }
            else
            {
                exit();
            }

        }

    }

    public function RegisterTool($title, $tool)
    {
        $this->tools[$tool] = $title;
    }

    public function GetTools()
    {
        return $this->tools;
    }

    public function SecureHome($fname, $afile)
    {
        $ofile = str_replace("..", "", $afile);
        if( strpos($afile, "" . "/home/" . $fname) === false ) 
        {
            return FMError("You do not have permission to view this location, error: FILE3a.");
        }

    }

    public function GetSessionKey()
    {
        return md5(md5($_SESSION["gamecp"]["userinfo"]["id"]) . $_SESSION["gamecp"]["userinfo"]["name"] . md5("GCP" . $this->whitelist($_SERVER["REMOTE_ADDR"], "int")));
    }

    public function ConvertBytes($size)
    {
        $unit = array( "bytes", "KB", "MB", "GB", "TB", "PB" );
        return @round($size / @pow(1024, $i = @floor(@log($size, 1024))), 2) . " " . $unit[$i];
    }

    public function ConvertToBytes($size)
    {
        $var = explode(" ", $size);
        if( $var[1] == "MB" ) 
        {
            return $var[0] * 1024 * 1024;
        }

        if( $var[1] == "GB" ) 
        {
            return round($var[0] * 1024 * 1024 * 1024);
        }

    }

    public function LoginSession()
    {
        if( isset($_SESSION["gamecp"]["lang"]) ) 
        {
            $lang = $_SESSION["gamecp"]["lang"];
        }

        if( isset($_SESSION["gamecp"]["upgrades"]) ) 
        {
            $upgrades = $_SESSION["gamecp"]["upgrades"];
        }

        if( isset($_SESSION["gamecp"]["copyright"]) ) 
        {
            $copyright = $_SESSION["gamecp"]["copyright"];
        }

        if( isset($_SESSION["gamecp"]["basic"]) ) 
        {
            $clanmode = $_SESSION["gamecp"]["basic"];
        }

        if( isset($lang) ) 
        {
            $_SESSION["gamecp"]["lang"] = $lang;
        }

        if( isset($upgrades) ) 
        {
            $_SESSION["gamecp"]["upgrades"] = $upgrades;
            unset($upgrades);
        }

        if( isset($clanmode) ) 
        {
            $_SESSION["gamecp"]["basic"] = $clanmode;
            unset($clanmode);
        }

        if( isset($copyright) ) 
        {
            $_SESSION["gamecp"]["copyright"] = $copyright;
            unset($copyright);
        }

        if( isset($_SESSION["gamecp"]["subaccount"]) ) 
        {
            $_SESSION["gamecp"]["subaccount"] = "yes";
        }

        if( is_file(path . DIRECTORY_SEPARATOR . "includes" . DIRECTORY_SEPARATOR . "basicmode.php") ) 
        {
            $_SESSION["gamecp"]["basic"] = "1";
        }

    }

    public function PrettyUserID($name, $details = FALSE)
    {
        global $safesql;
        global $GameCP;
        if( $details ) 
        {
            $u = $details;
        }
        else
        {
            $uq = sql_query($safesql->query("SELECT firstname, lastname, email, name FROM users WHERE id='%i'", array( $name ))) or exit( mysql_error() );
            $u = mysql_fetch_assoc($uq);
        }

        if( $u["firstname"] || $u["lastname"] ) 
        {
            return $u["firstname"] . " " . $u["lastname"];
        }

        if( $u["email"] ) 
        {
            return $u["email"];
        }

        return $u["name"];
    }

    public function PrettyUser($name, $details = FALSE)
    {
        global $safesql;
        global $GameCP;
        if( $details ) 
        {
            $u = $details;
        }
        else
        {
            $uq = sql_query($safesql->query("SELECT firstname, lastname, email, name FROM users WHERE name='%s'", array( $name ))) or exit( mysql_error() );
            $u = mysql_fetch_assoc($uq);
        }

        if( $u["firstname"] || $u["lastname"] ) 
        {
            return $u["firstname"] . " " . $u["lastname"];
        }

        if( $u["email"] ) 
        {
            return $u["email"];
        }

        return $u["name"];
    }

    public function SetPassword($cid, $password, $sub = FALSE, $updateservers = FALSE)
    {
        global $Event;
        $safesql = new SafeSQL_MySQL();
        if( !$password ) 
        {
            return false;
        }

        if( $sub ) 
        {
            $tbl = "usersubaccounts";
        }
        else
        {
            $tbl = "users";
        }

        $password = $this->whitelist($password, "password");
        $ogpassword = $password;
        $cid = $this->whitelist($cid, "int");
        $key = $this->PassString();
        if( defined("encrypw") && encrypw == "1" ) 
        {
            $this->loadIncludes("crypt");
            $cv = new ConvertData(true);
            $password = $cv->encrypt($key, $password, strlen($key));
        }

        if( $password ) 
        {
            mysql_query($safesql->query("" . "UPDATE `" . $tbl . "` SET `password` = '%s', keystring='%s' WHERE `id` = '%i'", array( $password, $this->whitelist($key, "clean"), $cid )));
        }

        if( $updateservers == true ) 
        {
            $this->loadIncludes("linux");
            $Linux = new Linux();
            $Linux->Password($cid, $ogpassword);
            $this->loadIncludes("backend");
            $Backend = new Backend();
            $Backend->UpdateAllFTP($cid);
        }

        return true;
    }

    public function PassString()
    {
        $salt = "_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        srand((double) microtime() * 1000000);
        for( $i = 0; $i < 8; $i++ ) 
        {
            $num = rand() % 33;
            $tmp = substr($salt, $num, 1);
            $pass = $pass . $tmp;
        }
        return strip_tags($pass);
    }

    public function get_gravatar($email, $s = 80, $d = "mm", $r = "g", $img = false, $atts = array(  ))
    {
        $url = "http://www.gravatar.com/avatar/";
        $url .= md5(strtolower(trim($email)));
        $url .= "" . "?s=" . $s . "&d=" . $d . "&r=" . $r;
        if( $img ) 
        {
            $url = "<img src=\"" . $url . "\"";
            foreach( $atts as $key => $val ) 
            {
                $url .= " " . $key . "=\"" . $val . "\"";
            }
            $url .= " />";
        }

        return $url;
    }

    public function UserGameAccess($ugid, $page = false)
    {
        global $GameCP;
        global $safesql;
        global $smarty;
        $gamecid = sql_query($safesql->query("SELECT cid, gid FROM usergames WHERE id='%i'", array( $ugid ))) or exit( mysql_error() );
        $gamecid = mysql_fetch_row($gamecid);
        $_SESSION["gamecp"]["user"]["browseGameCID"] = $gamecid[0];
        if( $this->UserCanEdit($gamecid[0]) == false ) 
        {
            $this->loadIncludes("panel");
            $Panel = new Panel();
            $Panel->ErrorExit("You do not have permission to view this page.");
        }

        $disableconfigsQ = sql_query($safesql->query("SELECT disableconfigs, userupdate, mapdir, winmapdir, winusermapdir, usermapdir FROM game WHERE id='%i' LIMIT 1", array( $GameCP->whitelist($gamecid[1], "int") ))) or exit( mysql_error() );
        $tmpgameinfo = mysql_fetch_assoc($disableconfigsQ);
        $smarty->assign("menugame", $tmpgameinfo);
        if( $_SESSION["gamecp"]["userinfo"]["ulevel"] == "0" && $page == "configs" && $tmpgameinfo["disableconfigs"] == "1" ) 
        {
            $this->loadIncludes("panel");
            $Panel = new Panel();
            $Panel->ErrorExit("You do not have permission to view this page.");
        }

    }

    public function UserVoiceAccess($ugid)
    {
        global $GameCP;
        global $safesql;
        global $smarty;
        $gamecid = sql_query($safesql->query("SELECT cid FROM uservoice WHERE id='%i'", array( $ugid ))) or exit( mysql_error() );
        $gamecid = mysql_fetch_row($gamecid);
        $_SESSION["gamecp"]["user"]["browseGameCID"] = $gamecid[0];
        if( $this->UserCanEdit($gamecid[0]) == false ) 
        {
            $this->loadIncludes("panel");
            $Panel = new Panel();
            $Panel->ErrorExit("You do not have permission to view this page.");
        }

    }

    public function UserCanEdit($idd)
    {
        global $GameCP;
        global $safesql;
        if( $_SESSION["gamecp"]["userinfo"]["ulevel"] == "4" ) 
        {
            $rsid = sql_query($safesql->query("SELECT rsid FROM users WHERE id='%i' LIMIT 1;", array( $this->whitelist($idd, "int") ))) or exit( mysql_error() );
            $rsid = mysql_fetch_row($rsid);
            if( $rsid[0] == $_SESSION["gamecp"]["userinfo"]["id"] ) 
            {
                return true;
            }

            return false;
        }

        if( $_SESSION["gamecp"]["userinfo"]["ulevel"] == "0" ) 
        {
            if( $_SESSION["gamecp"]["userinfo"]["id"] == $idd ) 
            {
                return true;
            }

            return false;
        }

        return true;
    }

    public function MasterIP()
    {
        if( !isset($_SERVER["SERVER_ADDR"]) ) 
        {
            if( isset($_SERVER["LOCAL_ADDR"]) ) 
            {
                $_SERVER["SERVER_ADDR"] = $_SERVER["LOCAL_ADDR"];
            }
            else
            {
                $_SERVER["SERVER_ADDR"] = $_SERVER["HTTP_HOST"];
            }

        }

        if( $_SERVER["SERVER_ADDR"] == "" ) 
        {
            $_SERVER["SERVER_ADDR"] = "Unknown";
        }

        return $_SERVER["SERVER_ADDR"];
    }

    public function loadIncludes($inc)
    {
        global $Email;
        global $Backend;
        switch( $inc ) 
        {
            case "modules":
                require_once(path . "/includes/core/classes/gamecp/modules.inc.php");
                break;
            case "crypt":
                require_once(path . "/includes/core/classes/gamecp/crypt.inc.php");
                break;
            case "email":
                require_once(path . "/includes/core/classes/email/class.phpmailer.php");
                require_once(path . "/includes/core/classes/email/class.inc.php");
                $Email = new Email();
                break;
            case "backend":
                require_once(path . "/includes/core/classes/backend/class.inc.php");
                $Backend = new Backend();
                break;
            case "support":
                require_once(path . "/includes/core/classes/support/class.inc.php");
                break;
            case "voice":
                require_once(path . "/includes/core/classes/voice/class.inc.php");
                break;
            case "gameq":
                require_once(path . "/includes/core/classes/gameq2/GameQ.php");
                break;
            case "query":
                require_once(path . "/includes/core/classes/query/class.inc.php");
                break;
            case "user":
                require_once(path . "/includes/core/classes/user/class.inc.php");
                break;
            case "ftp":
                require_once(path . "/includes/core/classes/ftp/class.inc.php");
                break;
            case "linux":
                require_once(path . "/includes/core/classes/linux/class.inc.php");
                break;
            case "ports":
                require_once(path . "/includes/core/classes/ports/class.inc.php");
                break;
            case "display":
                require_once(path . "/includes/core/classes/display/class.inc.php");
                break;
            case "panel":
                require_once(path . "/includes/core/classes/gamecp/panel.inc.php");
                break;
            case "game":
                require_once(path . "/includes/core/classes/games/class.inc.php");
                break;
            case "bukkit":
                require_once(path . "/includes/core/classes/games/bukkit.inc.php");
                break;
            case "control":
                require_once(path . "/includes/core/classes/control/class.inc.php");
                break;
            case "cron":
                require_once(path . "/includes/core/classes/cron/class.inc.php");
                break;
            case "suspend":
                require_once(path . "/includes/core/classes/suspend/class.inc.php");
                break;
            case "ip":
                require_once(path . "/includes/core/classes/ip/class.inc.php");
                break;
            case "xml":
                require_once(path . "/includes/core/classes/xml/class.inc.php");
                break;
            case "rcon":
                require_once(path . "/includes/core/classes/games/rcon.inc.php");
                break;
            case "billing":
                require_once(path . "/includes/core/classes/billing/class.inc.php");
                break;
            case "order":
                require_once(path . "/includes/core/classes/billing/order.inc.php");
                break;
            case "darkstarllc":
                require_once(path . "/includes/core/classes/voice/darkstarllc/include.inc.php");
                break;
            case "files":
                require_once(path . "/includes/core/classes/files/class.inc.php");
        }
    }

    public function CleanAll($document, $substr = FALSE)
    {
        $search = array( "@<script[^>]*?>.*?</script>@si", "@<style[^>]*?>.*?</style>@siU", "@<[\\/\\!]*?[^<>]*?>@si", "@<![\\s\\S]*?--[ \\t\\n\\r]*>@" );
        $text = preg_replace($search, "", $document);
        $text = strip_tags($text);
        if( $substr ) 
        {
            $text = substr($text, 0, $substr);
        }

        return $text;
    }

    public function CleanJavascript($document)
    {
        $search = array( "@<script[^>]*?>.*?</script>@si" );
        $text = preg_replace($search, "", $document);
        return $text;
    }

    public function parseserialize($data, $flag)
    {
        if( !is_array($data) ) 
        {
            return $data;
        }

        foreach( $data as $un => $d ) 
        {
            if( is_array($d) ) 
            {
                $data[$un] = $this->parseserialize($d, $flag);
            }
            else
            {
                $data[$un] = $this->whitelist($d, $flag);
            }

        }
        return $data;
    }

    public function whitelist($data, $type = FALSE, $flag = FALSE)
    {
        if( !is_string($data) ) 
        {
            return $data;
        }

        switch( $type ) 
        {
            case "int":
                $string = "/[^0-9.-]/";
                break;
            case "text":
                $string = "/[^a-zA-Z]/";
                break;
            case "password":
                $string = "/[^a-zA-Z0-9_.\\-;{}!^*()\\=\\+\$]/";
                break;
            case "web":
                $data = $this->CleanJavascript($data);
                break;
            case "username":
                $string = "/[^a-zA-Z0-9_]/";
                break;
            case "string":
                $string = "/[^a-zA-Z0-9.-_]/";
                break;
            case "encode":
                $data = htmlspecialchars($data);
                break;
            case "clean":
                $data = $this->CleanAll($data);
                break;
            case "useredit":
                $data = str_replace("../", "", $data);
                $data = str_replace("%2F", "", $data);
                break;
            case "striptags":
                $data = strip_tags($data);
                break;
            case "wysiwyg":
                $search = array( "@<script[^>]*?>.*?</script>@si", "@<style[^>]*?>.*?</style>@siU", "@<![\\s\\S]*?--[ \\t\\n\\r]*>@" );
                $data = preg_replace($search, "", $data);
                $data = strip_tags($data, "<br><li><ul><b><strong><u><dd><a><i><div><em><span><ol><p><blockquote><hr>");
                break;
            case "shell":
                $data = escapeshellcmd($data);
                break;
            case "serialize":
                $data = serialize($this->parseserialize(unserialize($data), $flag));
                break;
            default:
                $string = "/[^a-zA-Z0-9_@.\\-:?;{}&!^*()\\=\\+\$\\/]/";
                $data = str_replace("../", "", $data);
                $data = str_replace("%2F", "", $data);
                break;
        }
        if( isset($string) && $string != "" ) 
        {
            $dirty_array = str_split($data);
            $clean_data = "";
            foreach( $dirty_array as $char ) 
            {
                $clean_char = preg_replace($string, "", $char);
                $clean_data = $clean_data . $clean_char;
            }
            $data = $clean_data;
        }

        return $data;
    }

    public function generateNavigationStats($alt = FALSE, $alt2 = FALSE, $force = false)
    {
        global $GameCP;
        global $safesql;
        if( $this->ranNavStats != true && isset($_SESSION["gamecp"]["userinfo"]["ulevel"]) || $alt2 ) 
        {
            if( $alt2 || $_SESSION["gamecp"]["userinfo"]["ulevel"] == "1" || $_SESSION["gamecp"]["userinfo"]["ulevel"] == "2" || $_SESSION["gamecp"]["userinfo"]["ulevel"] == "3" || $_SESSION["gamecp"]["userinfo"]["ulevel"] == "4" || $_SESSION["gamecp"]["userinfo"]["ulevel"] == "5" ) 
            {
                if( isset($_SESSION["gamecp"]["nav_control"]) && time() - $_SESSION["gamecp"]["nav_control"]["last_ran"] < "300" && $force == false ) 
                {
                    $this->totalClients = $_SESSION["gamecp"]["nav_control"]["totalClients"];
                    $this->totalMachinesLin = $_SESSION["gamecp"]["nav_control"]["totalMachinesLin"];
                    $this->totalMachinesWin = $_SESSION["gamecp"]["nav_control"]["totalMachinesWin"];
                    $this->totalMachines = $_SESSION["gamecp"]["nav_control"]["totalMachines"];
                    $this->voiceEnabled = $_SESSION["gamecp"]["nav_control"]["voiceEnabled"];
                    $this->totalGames = $_SESSION["gamecp"]["nav_control"]["totalGames"];
                    $this->activeVoice = $_SESSION["gamecp"]["nav_control"]["activeVoice"];
                    $this->billEnabled = $_SESSION["gamecp"]["nav_control"]["billEnabled"];
                    $this->userGames = $_SESSION["gamecp"]["nav_control"]["userGames"];
                }
                else
                {
                    $totalClients = sql_query("SELECT COUNT(*) FROM users WHERE userlevel = '0' OR userlevel = '10'", "global nav control") or exit( mysql_error() );
                    $totalClients = mysql_fetch_row($totalClients);
                    $this->totalClients = $totalClients[0];
                    $totalMachinesQ = sql_query("SELECT COUNT(*) FROM servers WHERE os!='1'  ORDER BY 'name'", "global nav control") or exit( mysql_error() );
                    $totalMachines = mysql_fetch_row($totalMachinesQ);
                    $this->totalMachinesLin = $totalMachines[0];
                    $totalMachinesQ = sql_query("SELECT COUNT(*) FROM servers WHERE os='1' ORDER BY 'name'", "global nav control") or exit( mysql_error() );
                    $totalMachines = mysql_fetch_row($totalMachinesQ);
                    $this->totalMachinesWin = $totalMachines[0];
                    $totalMachinesQ = sql_query("SELECT COUNT(*) FROM servers  ORDER BY 'name'", "global nav control") or exit( mysql_error() );
                    $totalMachines = mysql_fetch_row($totalMachinesQ);
                    $this->totalMachines = $totalMachines[0];
                    $voiceEnabled = sql_query("SELECT COUNT(*) FROM servers WHERE ts2='1' OR vent='1' OR ts3host='1'", "global nav control") or exit( mysql_error() );
                    $voiceEnabled = mysql_fetch_row($voiceEnabled);
                    $voiceEnabled = $voiceEnabled[0];
                    if( usedarkstarvent == "yes" ) 
                    {
                        $voiceEnabled++;
                    }

                    $this->voiceEnabled = $voiceEnabled;
                    $totalGamesQ = sql_query("SELECT COUNT(*) FROM game ORDER BY 'name'", "global nav control") or exit( mysql_error() );
                    $totalGames = mysql_fetch_row($totalGamesQ);
                    $this->totalGames = $totalGames[0];
                    $activeVoice = sql_query("SELECT COUNT(*) FROM uservoice", "global nav control");
                    $activeVoice = mysql_fetch_row($activeVoice);
                    $this->activeVoice = $activeVoice[0];
                    $billEnabled = sql_query("SELECT COUNT(*) FROM userbills;", "global nav control") or exit( mysql_error() );
                    $billEnabled = mysql_fetch_row($billEnabled);
                    $this->billEnabled = $billEnabled[0];
                    $userGames = sql_query("SELECT COUNT(*) FROM usergames;", "global nav control") or exit( mysql_error() );
                    $userGames = mysql_fetch_row($userGames);
                    $this->userGames = $userGames[0];
                    $_SESSION["gamecp"]["nav_control"] = array(  );
                    $_SESSION["gamecp"]["nav_control"]["last_ran"] = time();
                    $_SESSION["gamecp"]["nav_control"]["totalClients"] = $this->totalClients;
                    $_SESSION["gamecp"]["nav_control"]["totalMachinesLin"] = $this->totalMachinesLin;
                    $_SESSION["gamecp"]["nav_control"]["totalMachinesWin"] = $this->totalMachinesWin;
                    $_SESSION["gamecp"]["nav_control"]["totalMachines"] = $this->totalMachines;
                    $_SESSION["gamecp"]["nav_control"]["voiceEnabled"] = $this->voiceEnabled;
                    $_SESSION["gamecp"]["nav_control"]["totalGames"] = $this->totalGames;
                    $_SESSION["gamecp"]["nav_control"]["activeVoice"] = $this->activeVoice;
                    $_SESSION["gamecp"]["nav_control"]["billEnabled"] = $this->billEnabled;
                    $_SESSION["gamecp"]["nav_control"]["userGames"] = $this->userGames;
                }

            }
            else
            {
                if( isset($_SESSION["gamecp"]["nav_control"]) && time() - $_SESSION["gamecp"]["nav_control"]["last_ran"] < "300" ) 
                {
                    $this->totalMachines = $_SESSION["gamecp"]["nav_control"]["totalMachines"];
                    $this->voiceEnabled = $_SESSION["gamecp"]["nav_control"]["voiceEnabled"];
                    $this->totalGames = $_SESSION["gamecp"]["nav_control"]["totalGames"];
                    $this->activeVoice = $_SESSION["gamecp"]["nav_control"]["activeVoice"];
                    $this->billEnabled = $_SESSION["gamecp"]["nav_control"]["billEnabled"];
                }
                else
                {
                    $billEnabled = sql_query("SELECT COUNT(*) FROM userbills WHERE cid='" . $_SESSION["gamecp"]["userinfo"]["id"] . "'", "global nav control") or exit( mysql_error() );
                    $billEnabled = mysql_fetch_row($billEnabled);
                    $this->billEnabled = $billEnabled[0];
                    $voiceEnabled = sql_query("SELECT COUNT(*) FROM uservoice WHERE cid='" . $_SESSION["gamecp"]["userinfo"]["id"] . "'", "global nav control") or exit( mysql_error() );
                    $voiceEnabled = mysql_fetch_row($voiceEnabled);
                    $voiceEnabled = $voiceEnabled[0];
                    if( usedarkstarvent == "yes" ) 
                    {
                        $voiceEnabled++;
                    }

                    $this->voiceEnabled = $voiceEnabled;
                    $this->activeVoice = $voiceEnabled[0];
                    $totalGamesQ = sql_query("SELECT COUNT(*) FROM usergames WHERE cid='" . $_SESSION["gamecp"]["userinfo"]["id"] . "' ORDER BY 'name'", "global nav control") or exit( mysql_error() );
                    $totalGames = mysql_fetch_row($totalGamesQ);
                    $this->totalGames = $totalGames[0];
                    if( $alt == true ) 
                    {
                        $totalMachinesQ = sql_query("SELECT COUNT(*) FROM servers ORDER BY 'name'", "global nav control") or exit( mysql_error() );
                        $totalMachines = mysql_fetch_row($totalMachinesQ);
                        $this->totalMachines = $totalMachines[0];
                    }

                    $_SESSION["gamecp"]["nav_control"] = array(  );
                    $_SESSION["gamecp"]["nav_control"]["last_ran"] = time();
                    if( $_SESSION["gamecp"]["userinfo"]["ulevel"] != "0" ) 
                    {
                        $_SESSION["gamecp"]["nav_control"]["totalMachines"] = $this->totalMachines;
                    }

                    $_SESSION["gamecp"]["nav_control"]["voiceEnabled"] = $this->voiceEnabled;
                    $_SESSION["gamecp"]["nav_control"]["totalGames"] = $this->totalGames;
                    $_SESSION["gamecp"]["nav_control"]["activeVoice"] = $this->activeVoice;
                    $_SESSION["gamecp"]["nav_control"]["billEnabled"] = $this->billEnabled;
                }

            }

        }

        $this->ranNavStats = true;
    }

    public function generateUserList()
    {
        global $GameCP;
        global $safesql;
        if( $this->ranUserList != true ) 
        {
            $this->userList = array(  );
            $this->adminUserList = array(  );
            if( isset($_SESSION["gamecp"]["userinfo"]["ulevel"]) && ($_SESSION["gamecp"]["userinfo"]["ulevel"] == "1" || $_SESSION["gamecp"]["userinfo"]["ulevel"] == "2" || $_SESSION["gamecp"]["userinfo"]["ulevel"] == "3" || $_SESSION["gamecp"]["userinfo"]["ulevel"] == "4" || $_SESSION["gamecp"]["userinfo"]["ulevel"] == "4") ) 
            {
                if( isset($_SESSION["gamecp"]["cache_userlist"]) && time() - $_SESSION["gamecp"]["cache_userlist"]["time"] < "120" ) 
                {
                    $this->adminUserList = $_SESSION["gamecp"]["cache_userlist"]["adminUserList"];
                    $this->userList = $_SESSION["gamecp"]["cache_userlist"]["userList"];
                }
                else
                {
                    $resQ = "";
                    if( $_SESSION["gamecp"]["userinfo"]["ulevel"] == "4" ) 
                    {
                        $resQ = " WHERE rsid = '" . $_SESSION["gamecp"]["userinfo"]["id"] . "'";
                    }

                    $userListQ = sql_query("" . "SELECT name, active, userlevel, id, email, firstname, lastname FROM users " . $resQ . " ORDER BY `id` ASC", "global user list") or exit( mysql_error() );
                    while( $r = mysql_fetch_row($userListQ) ) 
                    {
                        $email = "";
                        if( $r[4] ) 
                        {
                            $email = " - (" . $r[4] . ")";
                        }

                        if( $r[5] || $r[6] ) 
                        {
                            $username = $r[5] . " " . $r[6];
                        }
                        else
                        {
                            $username = $r[0];
                        }

                        switch( userlistmode ) 
                        {
                            case "1":
                                $name = $username . " " . $email;
                                break;
                            case "2":
                                $name = $r[4] . " " . $username;
                                break;
                            case "3":
                                $name = "#" . $r[3] . " " . $username . " " . $email;
                                break;
                            default:
                                $name = "#" . $r[3] . " - " . $username . " " . $email;
                                break;
                        }
                        if( $r[2] == "0" || $r[2] == "10" ) 
                        {
                            if( !$r[1] ) 
                            {
                                $this->userList[] = array( "name" => "* " . $name, "id" => $r[3], "userlevel" => $r[2] );
                            }
                            else
                            {
                                $this->userList[] = array( "name" => $name, "id" => $r[3], "userlevel" => $r[2] );
                            }

                        }
                        else
                        {
                            if( !$r[1] ) 
                            {
                                $this->adminUserList[] = array( "name" => "* " . $r[4], "id" => $r[3], "userlevel" => $r[2] );
                            }
                            else
                            {
                                $this->adminUserList[] = array( "name" => $r[4], "id" => $r[3], "userlevel" => $r[2] );
                            }

                        }

                    }
                    $_SESSION["gamecp"]["cache_userlist"]["adminUserList"] = $this->adminUserList;
                    $_SESSION["gamecp"]["cache_userlist"]["userList"] = $this->userList;
                    $_SESSION["gamecp"]["cache_userlist"]["time"] = time();
                }

            }

        }

        $this->ranUserList = true;
    }

    /**
	 * @access private 
	 * @internal
	 */

    public function CheckKey()
    {
        if( !gcplickey ) 
        {
            return false;
        }

        return true;
    }

    /**
	 * @access private 
	 * @internal
	 */

    public function UsersOnline()
    {
        global $GameCP;
        global $safesql;
        if( !isset($_SESSION["gamecp"]["userinfo"]["ulevel"]) ) 
        {
            return false;
        }

        $REMOTE_ADDR = $_SERVER["REMOTE_ADDR"];
        $PHP_SELF = $_SERVER["PHP_SELF"];
        $FULL_PAGE = $PHP_SELF . "?" . $_SERVER["QUERY_STRING"];
        $bad_pages = array( "process.php", "gzip.php", "serverstatus.php", "quickcontrol.php", "graph.php", "cron.php" );
        foreach( $bad_pages as $bp ) 
        {
            if( preg_match("" . "/" . $bp . "/i", $PHP_SELF) ) 
            {
                return false;
            }

        }
        $userOnlineDelay = "30";
        if( isset($_SESSION["gamecp"]["userinfo"]["username"]) && (!isset($_SESSION["gamecp"]["usersonline"]["time"]) || $_SESSION["gamecp"]["usersonline"]["time"] + $userOnlineDelay < time()) ) 
        {
            $_SESSION["gamecp"]["usersonline"]["time"] = time();
            $REMOTE_ADDR = $this->whitelist($_SERVER["REMOTE_ADDR"], "clean");
            if( !$REMOTE_ADDR ) 
            {
                $REMOTE_ADDR = "Unknown";
            }

            $FULL_PAGE = $this->whitelist($_SERVER["PHP_SELF"] . "?" . $_SERVER["QUERY_STRING"], "clean");
            $PHP_SELF = $this->whitelist($_SERVER["PHP_SELF"], "clean");
            $timestamp = time();
            $timeoutseconds = "120";
            $timeout = $timestamp - $timeoutseconds;
            if( isset($_SESSION["gamecp"]["userinfo"]["username"]) ) 
            {
                $gcpusername = $_SESSION["gamecp"]["userinfo"]["username"];
            }
            else
            {
                $gcpusername = "Unknown User";
            }

            if( isset($_SESSION["gamecp"]["subaccount"]) && $_SESSION["gamecp"]["subaccount"] == "yes" ) 
            {
                $gcpusername = "<strong>" . $_SESSION["gamecp"]["userinfo"]["username"] . "</strong>/" . $_SESSION["gamecp"]["subuser"]["name"];
            }

            $isOnlineQ = sql_query("SELECT ip FROM usersonline WHERE ip = '" . $REMOTE_ADDR . "" . "' AND name='" . $gcpusername . "'", "user online scan") or exit( mysql_error() );
            $isOnline = mysql_num_rows($isOnlineQ);
            if( $isOnline == 0 ) 
            {
                if( $gcpusername ) 
                {
                    sql_query("" . "INSERT INTO usersonline (name, timestamp, ip, FILE, RFILE) VALUES ('" . $gcpusername . "', '" . $timestamp . "','" . $REMOTE_ADDR . "','" . $PHP_SELF . "', '" . addslashes($FULL_PAGE) . "')", "user online scan") or exit( mysql_error() );
                }

            }
            else
            {
                if( $gcpusername ) 
                {
                    sql_query("" . "UPDATE usersonline SET timestamp = '" . $timestamp . "', FILE = '" . $PHP_SELF . "', RFILE = '" . addslashes($FULL_PAGE) . "" . "'  WHERE ip = '" . $REMOTE_ADDR . "' AND name='" . $gcpusername . "'", "user online scan") or exit( mysql_error() );
                }

            }

            sql_query("" . "DELETE FROM usersonline WHERE timestamp < " . $timeout, "user online scan") or exit( mysql_error() );
        }

    }

    /**
	 * @access private 
	 * @internal
	 */

    public function Error($error)
    {
        global $smarty;
        if( !isset($smarty) ) 
        {
            require_once(path . "/includes/core/includes/gamecp/settings.inc.php");
        }

        $error .= " " . $this->MasterIP();
        $smarty->assign("error", $error);
        $smarty->display("portal/license.tpl");
        if( isset($_SESSION["gamecp"]) ) 
        {
            unset($_SESSION["gamecp"]);
        }

        exit();
    }

    public function Password($idd, $table = "users", $md5pass = FALSE)
    {
        global $GameCP;
        global $safesql;
        $idd = $this->whitelist($idd, "int");
        $passQ = sql_query($safesql->query("" . "SELECT password as pass, keystring FROM " . $table . " WHERE id='%i'", array( $this->whitelist($idd, "int") ))) or exit( mysql_error() );
        $pass = mysql_fetch_row($passQ);
        $_pass = "";
        if( encrypw == "1" ) 
        {
            $this->loadIncludes("crypt");
            $cv = new ConvertData(true);
            $_pass = $cv->decrypt($pass[1], $pass[0]);
        }
        else
        {
            $_pass = $pass[0];
        }

        if( $md5pass ) 
        {
            return md5($_pass);
        }

        return $_pass;
    }

    /**
	 * @access private 
	 * @internal
	 */

    public function Login($username, $password, $md5pass = false, $email = false, $getlogin = true)
    {
        global $conn;
        global $safesql;
        global $GameCP;
        sql_query("DELETE FROM logintrys WHERE time < '" . (time() - logindelay) . "';");
        $chectrys = sql_query($safesql->query("SELECT * FROM logintrys WHERE ip='%s';", array( getenv("REMOTE_ADDR") )));
        if( logintrys <= mysql_num_rows($chectrys) ) 
        {
            return 3;
        }

        $validuser = false;
        $err = false;
        if( $email ) 
        {
            $col = "email";
        }
        else
        {
            $col = "name";
        }

        run_hook("user_login", array( $username, $password ));
        $idQ = sql_query($safesql->query("" . "SELECT id FROM users WHERE " . $col . " = '%s' LIMIT 1;", array( $username )));
        if( mysql_num_rows($idQ) == 1 ) 
        {
            $subuser = false;
            $validuser = true;
            $tbl = "users";
            $userid = mysql_fetch_row($idQ);
        }
        else
        {
            $subidQ = sql_query($safesql->query("" . "SELECT id FROM usersubaccounts WHERE " . $col . " = '%s' LIMIT 1;", array( $username )));
            if( mysql_num_rows($subidQ) == 1 ) 
            {
                $subuser = true;
                $validuser = true;
                $tbl = "usersubaccounts";
                $this->subuser = true;
                $userid = mysql_fetch_row($subidQ);
            }
            else
            {
                $err = 1;
            }

        }

        if( $validuser == true && $this->Password($userid[0], $tbl, $md5pass) != $password ) 
        {
            $validuser = false;
            $err = 2;
        }

        if( $getlogin ) 
        {
            $this->GetLogin();
        }

        if( $validuser != true ) 
        {
            sql_query($safesql->query("INSERT INTO logintrys SET ip='%s', time='" . time() . "';", array( getenv("REMOTE_ADDR") ))) or exit( mysql_error() );
            return $err;
        }

        if( $subuser == true ) 
        {
            $_SESSION["gamecp"]["subaccount"] = "yes";
        }

        sql_query($safesql->query("UPDATE users SET lastlogin = '" . time() . "', userip='" . getenv("REMOTE_ADDR") . "" . "' WHERE " . $col . " = '%s'", array( $username )));
        sql_query($safesql->query("DELETE FROM logintrys WHERE ip='%s';", array( getenv("REMOTE_ADDR") ))) or exit( mysql_error() );
        return 0;
    }

    public function FullURL()
    {
        global $_SERVER;
        $ssl = !empty($s["HTTPS"]) && $s["HTTPS"] == "on" ? true : false;
        $sp = strtolower($s["SERVER_PROTOCOL"]);
        $protocol = substr($sp, 0, strpos($sp, "/")) . ($ssl ? "s" : "");
        $port = $s["SERVER_PORT"];
        $port = !$ssl && $port == "80" || $ssl && $port == "443" ? "" : ":" . $port;
        $host = isset($s["HTTP_X_FORWARDED_HOST"]) ? $s["HTTP_X_FORWARDED_HOST"] : isset($s["HTTP_HOST"]) ? $s["HTTP_HOST"] : $s["SERVER_NAME"];
        return $this->whitelist($protocol . "://" . $host . $port . $s["REQUEST_URI"]);
    }

    public function SetURLCookie()
    {
    }

    /**
	 * @access private 
	 * @internal
	 */

    private function GetStats()
    {
        $this->generateNavigationStats(true, true);
        return array( $this->totalClients, $this->totalMachinesLin, $this->totalMachinesWin, $this->voiceEnabled, $this->userGames, $this->activeVoice, $this->billEnabled );
    }

    /**
	 * @access private 
	 * @internal
	 */

    private function GetTrial($expiry)
    {
        global $LNG_TRIALEXPIRED;
        if( $expiry < time() ) 
        {
            $this->Error($LNG_TRIALEXPIRED);
        }

        $_SESSION["gamecp"]["license"]["trial"] = "true";
        $_SESSION["gamecp"]["license"]["expiry"] = date("l jS \\of F Y h:i:s A", $expiry);
        unset($expiry);
    }

    /**
	 * @access private 
	 * @internal
	 */

    public function GetLogin()
    {
        if( gcplickey ) 
        {
            global $LNG_UNABLETOCONNECT;
            if( !($results = $this->CheckLogin()) ) 
            {
                $this->Error($LNG_UNABLETOCONNECT);
            }

            if( $results["gcpact"] != "1" && $results["gcpact"] != "gcpok" ) 
            {
                $this->Error($results["message"]);
            }
            else
            {
                if( preg_match("/" . "31 Day Trial" . "/s", $results["gcpprod"]) ) 
                {
                    $this->GetTrial(strtotime($results["gcpreg"]) + 2678400);
                }

                if( $results["gcpopt"] ) 
                {
                    $lic = explode("|", $results["gcpopt"]);
                    $res = array(  );
                    foreach( $lic as $lica ) 
                    {
                        $licdetail = explode("=", $lica);
                        $licb = explode(" ", $licdetail[1]);
                        $str = str_replace(" ", "", $licdetail[0]);
                        if( isset($res[$str]) ) 
                        {
                            $res[$str] = $res[$str] + strtolower($licb[0]);
                        }
                        else
                        {
                            $res[$str] = strtolower($licb[0]);
                        }

                        unset($str);
                    }
                    $basicType = explode("GameCP", $results["gcpprod"]);
                    if( isset($basicType[1]) && trim(strtolower($basicType[1])) == "basic" ) 
                    {
                        $_SESSION["gamecp"]["basic"] = "1";
                    }

                    if( isset($results["gcpadd"]) ) 
                    {
                        $addons = explode("|", $results["gcpadd"]);
                        $i = 0;
                        $addonres = array(  );
                        foreach( $addons as $lica ) 
                        {
                            $addons2 = explode(";", $lica);
                            foreach( $addons2 as $licb ) 
                            {
                                $addons3 = explode("=", $licb);
                                $addonres[$i][str_replace(" ", "", $addons3[0])] = strtolower(str_replace(" ", "", $addons3[1]));
                            }
                            $i++;
                        }
                        $_SESSION["gamecp"]["upgrades"] = $addonres;
                        foreach( $addonres as $add ) 
                        {
                            if( $add["name"] == "removecopyright" && $add["status"] == "active" ) 
                            {
                                $_SESSION["gamecp"]["copyright"] = "1";
                            }

                        }
                        unset($add);
                        unset($i);
                        unset($addons);
                        unset($addons3);
                        unset($addons2);
                        unset($addons);
                        unset($lica);
                        unset($licb);
                        unset($addonres);
                    }

                    $this->CheckMachines($res);
                    return $res;
                }

                $this->Error("Invalid Key Options");
                unset($lic);
                unset($res);
                unset($lica);
                unset($licdetail);
                unset($licb);
                unset($basicType);
            }

            unset($datakey);
            unset($personalkey);
        }

    }

    /**
	 * @access private 
	 * @internal
	 */

    private function CheckMachines($res)
    {
        $machineTotal = sql_query("SELECT * FROM `servers` WHERE os = '1'") or exit( mysql_error() );
        $winMachineTotal = mysql_num_rows($machineTotal);
        $machineTotal = sql_query("SELECT * FROM `servers` WHERE os != '1'") or exit( mysql_error() );
        $machineTotal = mysql_num_rows($machineTotal);
        $stop = false;
        if( $res["WindowsServers"] < $winMachineTotal ) 
        {
            $stop = true;
        }

        if( $res["LinuxServers"] < $machineTotal ) 
        {
            $stop = true;
        }

        if( $stop == true ) 
        {
            $this->Error("" . "Your machine limit has been reached (w: " . $winMachineTotal . "/" . $res["WindowsServers"] . "" . ", l: " . $machineTotal . "/" . $res["LinuxServers"] . "). Upgrade your license key.");
        }

        unset($totalMachines);
        unset($stop);
        $_SESSION["gamecp"]["count"] = array( $res["WindowsServers"], $res["LinuxServers"] );
    }

    /**
	 * @access private 
	 * @internal
	 */

    private function CL()
	{
		$results = array(
			'h1'=>'TEAM_ECHO_ROCKS',
			'gcpact'=>'1',
			'gcpprod'=>'GameCP Full',
			'gcpreg'=>'2015-01-01',
			'gcpopt'=> 'Windows Servers=9999|Linux Servers=9999',
			'gcpadd'=> 'name=removecopyright;status=active',
			'validdomain'=>$_SERVER['SERVER_NAME'],
			'validip'=>$_SERVER['SERVER_ADDR'],
			'checkdate'=>date('Ymd')); 
		return $results;
	}


    /**
	 * @access private 
	 * @internal
	 */

    private function GetURLVars()
    {
        $this->loadIncludes("crypt");
        $crypt = new ConvertData();
        $p = array(  );
        $p["gcpk"] = urlencode($crypt->encrypt($this->sentKey, gcplickey));
        $p["domain"] = urlencode($crypt->encrypt($this->sentKey, url));
        $p["ip"] = urlencode($crypt->encrypt($this->sentKey, $this->MasterIP()));
        $p["dir"] = path;
        $p["stats"] = urlencode($crypt->encrypt($this->sentKey, serialize($this->GetStats())));
        return $p;
    }

    /**
	 * @access private 
	 * @internal
	 */

    private function GetMatches($data)
    {
        preg_match_all("/<(.*?)>([^<]+)<\\/\\1>/i", $data, $matches);
        $resultsa = array(  );
        foreach( $matches[1] as $k => $v ) 
        {
            $resultsa[$v] = $matches[2][$k];
        }
        return array( $resultsa, $matches );
    }

    /**
	 * @access private 
	 * @internal
	 */

    private function CheckLogin()
	{
		$this->loadIncludes("crypt");
		$crypt = new ConvertData();
		$results = $this->CL();
		if( $results["gcpact"] == "1" ) 
		{
			$results["checkdate"] = date("Ymd");
			$de = strrev(md5(date("Ymd") . $this->key) . base64_encode(serialize($results)));
			sql_query("UPDATE settings SET value='" . $crypt->encrypt( "8aal1o72bb7c3a4l5k66kevv7yl8a59u0t1h2dd", urlencode(wordwrap($de . md5($de . $this->key), 80, "\n", true))) . "' WHERE name='gcplocalkey';");
			unset($de);
		}
			
		unset($p);
		unset($data);
		unset($matches);
		return $results;
	}

    /**
	 * @access private 
	 * @internal
	 */

    public function SendCurl($url, $PostData, $direction = "POST")
    {
        global $Event;
        $ch = curl_init();
        $PostData = http_build_query($PostData);
        $PostData = str_replace("&amp;", "&", $PostData);
        @set_time_limit(120);
        if( $direction == "GET" ) 
        {
            $url = $url . "?" . $PostData;
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        if( $direction == "POST" ) 
        {
            curl_setopt($ch, CURLOPT_POST, 1);
        }

        if( $direction == "GET" ) 
        {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        }

        curl_setopt($ch, CURLOPT_POSTFIELDS, $PostData);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        if( isset($PostData["test_suite"]) ) 
        {
            $useragent = $_SERVER["HTTP_USER_AGENT"];
            $strCookie = "PHPSESSID=" . $_COOKIE["PHPSESSID"] . "; path=/";
            session_write_close();
            curl_setopt($ch, CURLOPT_COOKIE, $strCookie);
            @session_start();
        }

        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.159 9.101 Safari/537.36");
        $output = curl_exec($ch);
        curl_close($ch);
        unset($ch);
        unset($PostData);
        return strtr($output, array_flip(get_html_translation_table(HTML_SPECIALCHARS)));
    }

    /**
	 * @access private 
	 * @internal
	 */

    public function Send($url, $data, $direction = "POST")
    {
        if( extension_loaded("curl") ) 
        {
            return $this->SendCurl($url, $data, $direction);
        }

        $postdata = http_build_query($data);
        $postdata = str_replace("&amp;", "&", $postdata);
        $opts = array( "http" => array( "method" => $direction, "user_agent" => "GameCP Panel", "header" => "Content-type: application/x-www-form-urlencoded", "content" => $postdata ) );
        $context = stream_context_create($opts);
        $result = file_get_contents($url, false, $context);
        return strtr($result, array_flip(get_html_translation_table(HTML_SPECIALCHARS)));
    }

}


