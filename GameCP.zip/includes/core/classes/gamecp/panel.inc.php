<?php 

class Panel
{
    public $machineInfoStore = array(  );

    public function GetThemes($thm = THEME, $styl = styleadmin)
    {
        global $GameCP;
        global $smarty;
        $badtheme = array( "hooks" );
        $themelist = "";
        $stylelist = "";
        $usrthemelist = "";
        $usrstylelist = "";
        $themeRows = $this->GetDirContents("../includes/template");
        $arrayLength = count($themeRows);
        for( $i = 0; $i < $arrayLength; $i++ ) 
        {
            if( $themeRows[$i] ) 
            {
                $theme = explode("/", $themeRows[$i]);
                $theme = $theme[0];
                if( !in_array($theme, $badtheme) ) 
                {
                    $themelist .= "" . "<option value=\"" . $theme . "\"";
                    if( $theme == $thm ) 
                    {
                        $themelist .= " SELECTED";
                    }

                    $themelist .= "" . ">" . $theme . "</option>";
                    $usrthemelist .= "" . "<option value=\"" . $theme . "\"";
                    if( $theme == USERTHEME ) 
                    {
                        $usrthemelist .= " SELECTED";
                    }

                    $usrthemelist .= "" . ">" . $theme . "</option>";
                }

            }

        }
        $themeRows = $this->GetDirContents("../includes/template/" . $thm . "/css/");
        $arrayLength = count($themeRows);
        for( $i = 0; $i < $arrayLength; $i++ ) 
        {
            if( $themeRows[$i] ) 
            {
                $theme = explode("/", $themeRows[$i]);
                $theme = $theme[0];
                $stylelist .= "" . "<option value=\"" . $theme . "\"";
                if( $theme == $styl ) 
                {
                    $stylelist .= " SELECTED";
                }

                $stylelist .= "" . ">" . $theme . "</option>";
            }

        }
        $themeRows = $this->GetDirContents("../includes/template/" . USERTHEME . "/css/");
        $arrayLength = count($themeRows);
        for( $i = 0; $i < $arrayLength; $i++ ) 
        {
            if( $themeRows[$i] ) 
            {
                $theme = explode("/", $themeRows[$i]);
                $theme = $theme[0];
                if( $theme != "hooks" ) 
                {
                    $usrstylelist .= "" . "<option value=\"" . $theme . "\"";
                    if( $theme == styleclient ) 
                    {
                        $usrstylelist .= " SELECTED";
                    }

                    $usrstylelist .= "" . ">" . $theme . "</option>";
                }

            }

        }
        $smarty->assign("themelist", $themelist);
        $smarty->assign("stylelist", $stylelist);
        $smarty->assign("usrthemelist", $usrthemelist);
        $smarty->assign("usrstylelist", $usrstylelist);
    }

    public function SetUserSession($usrnfo)
    {
        global $GameCP;
        $_SESSION["gamecp"]["userinfo"]["id"] = $usrnfo["id"];
        $_SESSION["gamecp"]["userinfo"]["ulevel"] = $usrnfo["userlevel"];
        $_SESSION["gamecp"]["userinfo"]["email"] = $usrnfo["email"];
        $_SESSION["gamecp"]["userinfo"]["username"] = $usrnfo["username"];
        $_SESSION["gamecp"]["userinfo"]["name"] = $usrnfo["name"];
        $_SESSION["gamecp"]["userinfo"]["phone"] = $usrnfo["phone"];
        $_SESSION["gamecp"]["userinfo"]["address"] = $usrnfo["address"];
        $_SESSION["gamecp"]["userinfo"]["address2"] = $usrnfo["address2"];
        $_SESSION["gamecp"]["userinfo"]["city"] = $usrnfo["city"];
        $_SESSION["gamecp"]["userinfo"]["state"] = $usrnfo["state"];
        $_SESSION["gamecp"]["userinfo"]["country"] = $usrnfo["country"];
        $_SESSION["gamecp"]["userinfo"]["zip"] = $usrnfo["zip"];
        $_SESSION["gamecp"]["userinfo"]["website"] = $usrnfo["website"];
        $_SESSION["gamecp"]["userinfo"]["firstname"] = $usrnfo["firstname"];
        $_SESSION["gamecp"]["userinfo"]["lastname"] = $usrnfo["lastname"];
        $_SESSION["gamecp"]["userinfo"]["payment"] = $usrnfo["payment"];
        if( isset($usrnfo["joindate"]) && $usrnfo["joindate"] ) 
        {
            $_SESSION["gamecp"]["userinfo"]["joindate"] = date(dateformat, $usrnfo["joindate"]);
        }

        $_SESSION["gamecp"]["userinfo"]["lastlogin"] = $usrnfo["lastlogin"];
        $_SESSION["gamecp"]["userinfo"]["signature"] = $usrnfo["signature"];
        $_SESSION["gamecp"]["userinfo"]["smsaddress"] = $usrnfo["smsaddress"];
        $_SESSION["gamecp"]["userinfo"]["slotlimit"] = $usrnfo["slotlimit"];
        $_SESSION["gamecp"]["userinfo"]["reseller"] = $usrnfo["rsid"];
        $_SESSION["gamecp"]["userinfo"]["active"] = $usrnfo["active"];
        $_SESSION["gamecp"]["userinfo"]["theme"] = $usrnfo["theme"];
        $_SESSION["gamecp"]["userinfo"]["style"] = $usrnfo["style"];
        $_SESSION["gamecp"]["userinfo"]["filemanager"] = $usrnfo["filemanager"];
        $_SESSION["gamecp"]["userinfo"]["permissions"] = unserialize($usrnfo["permissions"]);
        $_SESSION["gamecp"]["security"]["path"] = path;
        $_SESSION["gamecp"]["security"]["url"] = url;
        $_SESSION["gamecp"]["security"]["key"] = $GameCP->GetSessionKey();
        $_SESSION["gamecp"]["security"]["checkme"]["usertime"] = time();
    }

    public function CheckInteralIP($ip)
    {
        $ip = gethostbyname($ip);
        $long = ip2long($ip);
        if( 167772160 <= $long && $long <= 184549375 || 0 - 1408237568 <= $long && $long <= 0 - 1407188993 || 0 - 1062731776 <= $long && $long <= 0 - 1062666241 || 2130706432 <= $long && $long <= 2147483647 || $long == 0 - 1 ) 
        {
            return true;
        }

        return false;
    }

    public function CheckMySQL2($db, $user, $pass, $host)
    {
        $a = true;
        $conncheck = @mysql_connect($host, $user, $pass) or @mysql_select_db($db, $conncheck) or mysql_close($conncheck);
        return $a;
    }

    public function CheckMySQLRow($table, $col, $col2, $val, $val2)
    {
        global $safesql;
        $checkQ = sql_query($safesql->query("" . "SELECT * FROM " . $table . " WHERE " . $col2 . "='%s'", array( $val2 )));
        $chk = mysql_num_rows($checkQ);
        if( "1" <= $chk ) 
        {
            return false;
        }

        return true;
    }

    public function checkRow($table, $col, $val)
    {
        global $safesql;
        $checkQ = mysql_query($safesql->query("" . "SELECT * FROM " . $table . " WHERE " . $col . "='%s' LIMIT 1;", array( $val )));
        $chk = mysql_num_rows($checkQ);
        if( "1" <= $chk ) 
        {
            return "0";
        }

    }

    public function checkTable($table)
    {
        $checkQ = mysql_query("SHOW TABLES");
        while( $chk = mysql_fetch_array($checkQ) ) 
        {
            if( $chk[0] == $table ) 
            {
                return "0";
            }

        }
    }

    public function FetchMultiArray($sql)
    {
        $array = array(  );
        $mysqlQuery = sql_query($sql) or exit( mysql_error() );
        while( $mysqlResult = mysql_fetch_assoc($mysqlQuery) ) 
        {
            $array[] = $mysqlResult;
        }
        return $array;
    }

    public function FolderSize($path)
    {
        if( !file_exists($path) ) 
        {
            return 0;
        }

        if( is_file($path) ) 
        {
            return filesize($path);
        }

        $ret = 0;
        $ar = glob($path . "/*");
        if( is_array($ar) ) 
        {
            foreach( $ar as $fn ) 
            {
                $ret += $this->FolderSize($fn);
            }
            return $ret;
        }

        return 0;
    }

    public function Export($evenlogs = FALSE)
    {
        require(path . "/includes/core/classes/mysql/export.class.php");
        $tables = array(  );
        $result = sql_query("SHOW TABLES");
        while( $row = mysql_fetch_row($result) ) 
        {
            if( $row[0] != "eventlogs" || $evenlogs == true ) 
            {
                $tables[] = $row[0];
            }

        }
        $e = new SQL_Export($tables);
        return $e->export();
    }

    public function Backup($mailmode = FALSE, $xtra = FALSE)
    {
        global $GameCP;
        $userExport = "";
        $GameCP->loadIncludes("user");
        $User = new User();
        $result = sql_query("SELECT id FROM users WHERE active='1';") or exit( mysql_error() );
        while( $serverDetails = mysql_fetch_array($result) ) 
        {
            $userExport .= $User->Export($serverDetails["id"]) . "\r\n";
        }
        $mySQLExport = $this->Export();
        if( $xtra == true ) 
        {
            return array( $userExport, $mySQLExport );
        }

        if( extension_loaded("zip") === true ) 
        {
            $bkupname = "GameCP-Backup." . time() . rand() . ".zip";
            $backupFile = path . DIRECTORY_SEPARATOR . $bkupname;
            if( !$this->Zip($backupFile, $userExport, $mySQLExport) ) 
            {
                return "Zip functions are not available. Backup files are not available.";
            }

            if( $mailmode == true && backupemail ) 
            {
                $GameCP->loadIncludes("email");
                $Email = new Email();
                $Email->emailto = backupemail;
                $Email->emailsubject = "GameCP Daily Backup";
                $Email->emailbody = "Your GameCP backup is attached.";
                $Email->AddAttachment($backupFile, $backupFile);
                $Email->ReplaceStuff();
                $Email->send();
                unlink($backupFile);
            }
            else
            {
                set_time_limit("1200");
                ini_set("max_execution_time", "1200");
                ini_set("memory_limit", "200M");
                $fc = file_get_contents($backupFile);
                unlink($backupFile);
                header("Content-type: application/gz");
                header("Content-Disposition: attachment; filename=\"" . $bkupname . "\"");
                echo $fc;
            }

        }
        else
        {
            return "Zip functions are not available. Backup files are not available.";
        }

    }

    public function GetWebFileCurl($url)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($c, CURLOPT_URL, $url);
        $contents = curl_exec($c);
        curl_close($c);
        if( $contents ) 
        {
            return $contents;
        }

        return false;
    }

    public function GetWebFile($url)
    {
        $opts = array( "http" => array( "method" => "GET" ) );
        $context = stream_context_create($opts);
        return file_get_contents($url, false, $context);
    }

    public function Download($filea, $url)
    {
        set_time_limit("1200");
        ini_set("max_execution_time", "1200");
        ini_set("memory_limit", "200M");
        if( extension_loaded("curl") ) 
        {
            $data = $this->GetWebFileCurl($url);
        }
        else
        {
            $data = $this->GetWebFile($url);
        }

        if( !$data ) 
        {
            return false;
        }

        $file = fopen($filea, "wb");
        if( $file == FALSE ) 
        {
            return false;
        }

        fwrite($file, $data);
        fclose($file);
    }

    public function UnZip($file, $dir, $exclude = false)
    {
        set_time_limit("1200");
        ini_set("max_execution_time", "1200");
        ini_set("memory_limit", filesize($file) * 2 . "bytes");
        if( !is_file($file) || !is_dir($dir) || !is_writeable($dir) ) 
        {
            return false;
        }

        if( extension_loaded("zip") === true ) 
        {
            $zip = new ZipArchive();
            $res = $zip->open($file);
            if( $res === TRUE ) 
            {
                if( is_array($exclude) ) 
                {
                    foreach( $exclude as $exc ) 
                    {
                        $zip->deleteName($exc);
                    }
                }

                $zip->extractTo($dir);
                $zip->close();
                return true;
            }

            return false;
        }

        return "Zip functions are not available. Upgrade is not available.";
    }

    public function Zip($destination, $userExport, $mySQLExport)
    {
        global $hosted_panel;
        if( extension_loaded("zip") === true ) 
        {
            set_time_limit("1200");
            ini_set("max_execution_time", "1200");
            ini_set("memory_limit", $this->FolderSize(path) * 2 . "bytes");
            if( !isset($hosted_panel) ) 
            {
                $i = "0";
                $iterator = $this->DirectoryToArray(path);
                foreach( $iterator as $id => $key ) 
                {
                    if( $i == "0" || $i == "40" ) 
                    {
                        if( $i == "40" ) 
                        {
                            $zip->close();
                        }

                        $i = "0";
                        $zip = new ZipArchive();
                        if( $zip->open($destination, ZIPARCHIVE::CREATE) !== TRUE ) 
                        {
                            return false;
                        }

                    }

                    $key = str_replace("\\\\", "\\", $key);
                    $key = str_replace("/", "\\", $key);
                    if( is_file($key) && !is_dir($key) ) 
                    {
                        $zip->addFile(realpath($key), str_replace(path . DIRECTORY_SEPARATOR, "", $key));
                    }

                    $i++;
                }
            }
            else
            {
                $zip = new ZipArchive();
                if( $zip->open($destination, ZIPARCHIVE::CREATE) !== TRUE ) 
                {
                    return false;
                }

            }

            if( $userExport ) 
            {
                $zip->addFromString("userExport.txt", $userExport) or exit( "ERROR: Could not add file" );
            }

            if( $mySQLExport ) 
            {
                $zip->addFromString("mySQLbackup.sql", $mySQLExport) or exit( "ERROR: Could not add file" );
            }

            $zip->close();
            if( is_file($destination) ) 
            {
                return true;
            }

        }

        return false;
    }

    public function RemoveRecursiveDir($directory, $empty = FALSE)
    {
        if( substr($directory, 0 - 1) == "/" ) 
        {
            $directory = substr($directory, 0, 0 - 1);
        }

        if( !file_exists($directory) || !is_dir($directory) ) 
        {
            return FALSE;
        }

        if( is_readable($directory) ) 
        {
            $handle = opendir($directory);
            while( FALSE !== ($item = readdir($handle)) ) 
            {
                if( $item != "." && $item != ".." ) 
                {
                    $path = $directory . "/" . $item;
                    if( is_dir($path) ) 
                    {
                        $this->RemoveRecursiveDir($path);
                    }
                    else
                    {
                        unlink($path);
                    }

                }

            }
            closedir($handle);
            if( $empty == FALSE && !rmdir($directory) ) 
            {
                return FALSE;
            }

        }

        return true;
    }

		public function Upgrade($ignoreerror = false)
		{
			global $gcpVersion;
			if( extension_loaded("zip") === true ) 
			{
				$backupArchive = "GameCP-Backup." . time() . rand() . ".zip";
				$backupFinal = path . DIRECTORY_SEPARATOR . $backupArchive;
				$_SESSION["gamecp"]["backup"] = $backupFinal;
				$updateArchive = "GameCPX.zip";
				$updateURL = $_SERVER['DOCUMENT_ROOT'] . '/assets' . "/" . $updateArchive; 

            if( $Backup = $this->Backup("", true) ) 
            {
                if( is_file(path . DIRECTORY_SEPARATOR . $updateArchive) ) 
                {
                    unlink(path . DIRECTORY_SEPARATOR . $updateArchive);
                }

                if( !$this->Zip($backupFinal, $Backup[0], $Backup[1]) && $ignoreerror == false ) 
                {
                    return "Update failed, unable to create backup zip.";
                }

                if( $gcpVersion == "Beta" ) 
                {
                    return "upgraded";
                }

                $this->Download(path . DIRECTORY_SEPARATOR . $updateArchive, $updateURL);
                if( is_file(path . DIRECTORY_SEPARATOR . "includes" . DIRECTORY_SEPARATOR . "extract_exclude.txt") ) 
                {
                    $exclude = explode("\n", file_get_contents(path . DIRECTORY_SEPARATOR . "includes" . DIRECTORY_SEPARATOR . "extract_exclude.txt"));
                    $exclude["includes" . DIRECTORY_SEPARATOR . "extract_exclude.txt"] = "";
                }
                else
                {
                    $exclude = "";
                }

                if( is_file(path . DIRECTORY_SEPARATOR . $updateArchive) && $this->UnZip(path . DIRECTORY_SEPARATOR . $updateArchive, path, $exclude) ) 
                {
                    unlink(path . DIRECTORY_SEPARATOR . $updateArchive);
                }

                if( is_dir(path . DIRECTORY_SEPARATOR . "installer") && is_file(path . DIRECTORY_SEPARATOR . "installer" . DIRECTORY_SEPARATOR . "include.inc.php") ) 
                {
                    require_once(path . DIRECTORY_SEPARATOR . "installer" . DIRECTORY_SEPARATOR . "include.inc.php");
                    $Installer = new Installer();
                    require_once(path . DIRECTORY_SEPARATOR . "installer" . DIRECTORY_SEPARATOR . "resources" . DIRECTORY_SEPARATOR . "update.php");
                    $Installer->ImportMySQL(path . DIRECTORY_SEPARATOR . "installer" . DIRECTORY_SEPARATOR . "resources" . DIRECTORY_SEPARATOR . "update.sql", true);
                    $Installer->ClearCache(path);
                    $this->RemoveRecursiveDir(path . DIRECTORY_SEPARATOR . "installer");
                }

                return "upgraded";
            }

            return "Update failed, unable to generate backup data.";
        }

        return "PHP-Zip functions are not available. Upgrade is not available.";
    }

    public function DownloadBackup()
    {
        if( is_file($_SESSION["gamecp"]["backup"]) ) 
        {
            set_time_limit("1200");
            ini_set("max_execution_time", "1200");
            ini_set("memory_limit", filesize($_SESSION["gamecp"]["backup"]) * 2 . "bytes");
            $fc = file_get_contents($_SESSION["gamecp"]["backup"]);
            unlink($_SESSION["gamecp"]["backup"]);
            header("Content-type: application/gz");
            header("Content-Disposition: attachment; filename=\"" . $_SESSION["gamecp"]["backup"] . "\"");
            echo $fc;
            unset($_SESSION["gamecp"]["backup"]);
        }
        else
        {
            return false;
        }

    }

    public function DirectoryToArray($directory, $recursive = true)
    {
        $array_items = array(  );
        if( $handle = opendir($directory) ) 
        {
            while( false !== ($file = readdir($handle)) ) 
            {
                if( $file != ".svn" && $file != "." && $file != ".." ) 
                {
                    if( is_dir($directory . "/" . $file) ) 
                    {
                        if( $recursive ) 
                        {
                            $array_items = array_merge($array_items, $this->DirectoryToArray($directory . "/" . $file, $recursive));
                        }

                        $file = $directory . "/" . $file;
                        $array_items[] = preg_replace("/\\/\\//si", "/", $file);
                    }
                    else
                    {
                        $file = $directory . "/" . $file;
                        $array_items[] = preg_replace("/\\/\\//si", "/", $file);
                    }

                }

            }
            closedir($handle);
        }

        return $array_items;
    }

    public function FormatSize($size)
    {
        if( !is_numeric($size) ) 
        {
            return $size;
        }

        if( $size ) 
        {
            $s = array( "K", "M", "G", "T", "P" );
            $e = floor(log($size) / log(1024));
            if( $e == 0 && round($size / pow(1024, floor($e))) < 1024 ) 
            {
                return "0M";
            }

            if( $e == 1 || $e == 0 ) 
            {
                return sprintf("%.0f" . $s[$e], $size / pow(1024, floor($e)));
            }

            return sprintf("%.2f" . $s[$e], $size / pow(1024, floor($e)));
        }

    }

    public function ErrorExit($error)
    {
        $this->Error($error);
        echo "</body></html>";
        exit();
    }

    public function Error($error = "Unknown", $queue = FALSE, $status = FALSE, $return = TRUE)
    {
        global $GameCP;
        global $fname;
        global $fip;
        global $fport;
        global $gross;
        global $fusername;
        global $sid;
        global $Email;
        global $Event;
        global $smarty;
        $Event->EventLogAdd(isset($_SESSION["gamecp"]["userinfo"]) ? $_SESSION["gamecp"]["userinfo"]["name"] : "System", "Error Triggered:" . $error);
        if( is_array($error) ) 
        {
            if( 0 < count($error) ) 
            {
                $err = "";
                foreach( $error as $er ) 
                {
                    $err .= $er . "<br>";
                }
                $this->ErrorHeader($err);
            }

        }
        else
        {
            $this->ErrorHeader($error);
        }

        if( isset($_SESSION["gamecp"]["orderapi"]) && $_SESSION["gamecp"]["orderapi"] == true ) 
        {
            $subject = "" . "There was an error while processing order #" . $queue;
            $email = "" . "Order #" . $queue . " had the following error while the server was being installed:\n";
            $email .= "" . " " . $error . " \n";
            $email .= "  \n";
            $email .= "" . "Please manaully correct any errors and process order #" . $queue . ".\n";
            $email .= "\n";
            $email .= "Thank you.";
            $GameCP->loadIncludes("email");
            $Email->emailto = emailNotify;
            $Email->emailsubject = $subject;
            $Email->emailbody = $email;
            $Email->ReplaceStuff();
            $Email->send();
        }

        if( $queue ) 
        {
            $this->QueueFlush($queue, $status, $error);
        }

        if( isset($smarty) ) 
        {
            $smarty->assign("error", $error);
        }

        if( $return ) 
        {
            return $error;
        }

        return false;
    }

    public function QueueFlush($queue, $status, $contents)
    {
        global $GameCP;
        global $safesql;
        if( $queue != "0" && $contents && $contents != "" ) 
        {
            if( is_array($contents) ) 
            {
                $contents = serialize($contents);
            }

            if( $contents ) 
            {
                $contents = addslashes($contents);
            }

            sql_query($safesql->query("UPDATE `queue` SET `result`='%s', `status`='%s' WHERE `id` = '%i'", array( $GameCP->whitelist($contents, "useredit"), $GameCP->whitelist($status, "clean"), $GameCP->whitelist($queue, "int") ))) or exit( mysql_error() );
        }

    }

    public function ErrorHeader($error)
    {
        global $API;
        global $smarty;
        if( isset($API) ) 
        {
            $API->Error($error);
        }
        else
        {
            if( isset($_SESSION["gamecp"]["orderapi"]) && $_SESSION["gamecp"]["orderapi"] == true ) 
            {
                $smarty->assign("errorCode", $error);
                $smarty->display("order/error.tpl");
            }
            else
            {
                echo "" . "<div class=\"alert alert-error alert-custom  nomail notification error\">" . $error . "</div>";
            }

        }

    }

    public function FormatNumber($num, $cid = false, $chars = false, $exchange = false)
    {
        global $GameCP;
        $format = currencyFormat;
        $currencyChar = currencyChar;
        $currencyChar2 = currencyChar2;
        $_exchange = false;
        $GameCP->loadIncludes("billing");
        $Billing = new Billing();
        if( $cid && $_SESSION["gamecp"]["userinfo"]["ulevel"] == "0" ) 
        {
            $_user = $this->GetUser($cid);
            $_currency = $_user["currency"];
            $_exchange = $Billing->ExchangeRate($_currency);
        }

        if( $exchange ) 
        {
            $_exchange = $Billing->ExchangeRate($exchange);
        }

        if( is_array($_exchange) && $_exchange["format"] && $_exchange["rate"] ) 
        {
            $format = $_exchange["format"];
            $currencyChar = $_exchange["prefix"];
            $currencyChar2 = $_exchange["suffix"];
            $num = $num * $_exchange["rate"];
        }

        if( $num == "0" || !$num ) 
        {
            $num = "0.00";
        }

        if( is_numeric($num) && function_exists("number_format") ) 
        {
            switch( $format ) 
            {
                case "1":
                    $num = number_format($num, 2, ".", ",");
                    break;
                case "2":
                    $num = number_format($num, 2, ".", "");
                    break;
                case "3":
                    $num = number_format($num, 2, ",", ".");
                    break;
                case "4":
                    $num = number_format($num, 0, "", ",");
            }
        }

        if( $chars ) 
        {
            $num = $currencyChar . $num . $currencyChar2;
        }

        return $num;
    }

    public function RemFormatNumber($num)
    {
        switch( currencyFormat ) 
        {
            case "1":
                return str_replace(",", "", $num);
            case "2":
                return $num;
            case "3":
                $num = str_replace(".", "", $num);
                return str_replace(",", ".", $num);
            case "4":
                return str_replace(",", "", $num);
        }
    }

    public function GetServer($sid, $ip = FALSE, $id = FALSE)
    {
        global $GameCP;
        global $safesql;
        if( $id ) 
        {
            if( isset($this->machineInfoStore) && array_key_exists($id, $this->machineInfoStore) ) 
            {
                return $this->machineInfoStore[$id];
            }

            $infoQ = sql_query($safesql->query("SELECT * FROM servers WHERE id ='%s'", array( $GameCP->whitelist($id, "int") ))) or exit( mysql_error() );
        }
        else
        {
            if( $ip ) 
            {
                if( isset($this->machineInfoStore) && array_key_exists($ip, $this->machineInfoStore) ) 
                {
                    return $this->machineInfoStore[$ip];
                }

                $sid = $ip;
                $infoQ = sql_query($safesql->query("SELECT S.* FROM servers S, iptable I WHERE I.sid = S.sid AND I.ip ='%s'", array( $GameCP->whitelist($ip, "clean") ))) or exit( mysql_error() );
            }
            else
            {
                if( isset($this->machineInfoStore) && array_key_exists($sid, $this->machineInfoStore) ) 
                {
                    return $this->machineInfoStore[$sid];
                }

                $infoQ = sql_query($safesql->query("SELECT * FROM servers WHERE sid ='%s'", array( $GameCP->whitelist($sid, "clean") ))) or exit( mysql_error() );
            }

        }

        $info = mysql_fetch_assoc($infoQ);
        $this->machineInfoStore[$sid] = $info;
        return $info;
    }

    public function GetServerIPs($sid)
    {
        global $GameCP;
        global $safesql;
        $return = array(  );
        $result = sql_query($safesql->query("SELECT * FROM iptable WHERE sid ='%s';", array( $GameCP->whitelist($sid, "clean") ))) or exit( mysql_error() );
        while( $row = mysql_fetch_array($result) ) 
        {
            $return[] = $row;
        }
        return $return;
    }

    public function GetIP($ip)
    {
        global $GameCP;
        global $safesql;
        $return = array(  );
        $result = sql_query($safesql->query("SELECT * FROM iptable WHERE ip ='%s' LIMIT 1;", array( $GameCP->whitelist($ip, "clean") ))) or exit( mysql_error() );
        return mysql_fetch_array($result);
    }

    public function GetServiceFolder($ugid, $root = true)
    {
        $gameInfo = $this->GetUserGame($ugid);
        $folder = "";
        if( $root ) 
        {
            $folder = "/home/" . $gameInfo["username"] . "/";
        }

        if( $gameInfo["subdirectory"] == "yes" ) 
        {
            if( ipsubdir == "true" ) 
            {
                $folder = $folder . $gameInfo["ip"] . "-" . $gameInfo["port"] . "/";
            }
            else
            {
                $folder = $folder . "service" . $ugid . "/";
            }

        }

        return $folder;
    }

    public function GetUserGame($ugid)
    {
        global $safesql;
        global $GameCP;
        $gameInfoQ = sql_query($safesql->query("SELECT UG.*, U.name as 'username', U.id as 'userid'\r\n\t\t\t\t\t\t\t\tFROM usergames UG, users U WHERE U.id = UG.cid AND UG.id = '%i' LIMIT 1;", array( $GameCP->whitelist($ugid, "int") ))) or exit( mysql_error() );
        return mysql_fetch_assoc($gameInfoQ);
    }

    public function GetUserVoice($ugid)
    {
        global $safesql;
        global $GameCP;
        $gameInfoQ = sql_query($safesql->query("SELECT UG.*, U.name as 'username', U.id as 'userid'\r\n\t\t\t\t\t\t\t\tFROM uservoice UG, users U WHERE U.id = UG.cid AND UG.id = '%i' LIMIT 1;", array( $GameCP->whitelist($ugid, "int") ))) or exit( mysql_error() );
        return mysql_fetch_assoc($gameInfoQ);
    }

    public function GetUserGames($uid, $uname = FALSE)
    {
        global $safesql;
        global $GameCP;
        $return = array(  );
        if( $uname ) 
        {
            $result = sql_query($safesql->query("SELECT UG.*, U.name as 'username', U.id as 'userid', UG.id as 'ugid'\r\n\t\t\t\t\t\t\t\tFROM usergames UG, users U WHERE U.id = UG.cid AND U.name = '%s';", array( $GameCP->whitelist($uname, "useredit") ))) or exit( mysql_error() );
        }
        else
        {
            $result = sql_query($safesql->query("SELECT UG.*, U.name as 'username', U.id as 'userid', UG.id as 'ugid'\r\n\t\t\t\t\t\t\t\tFROM usergames UG, users U WHERE U.id = UG.cid AND U.id = '%i';", array( $GameCP->whitelist($uid, "int") ))) or exit( mysql_error() );
        }

        while( $row = mysql_fetch_array($result) ) 
        {
            $return[] = $row;
        }
        return $return;
    }

    public function GetUser($cid, $name = FALSE, $sub = FALSE, $email = FALSE)
    {
        global $safesql;
        global $GameCP;
        if( $name ) 
        {
            $wherea = "name";
            $where = $name;
        }
        else
        {
            if( $email ) 
            {
                $wherea = "email";
                $where = $email;
            }
            else
            {
                $wherea = "id";
                $where = $cid;
            }

        }

        if( $sub ) 
        {
            $table = "usersubaccounts";
        }
        else
        {
            $table = "users";
        }

        $userInfoQ = sql_query($safesql->query("" . "SELECT * FROM " . $table . " WHERE " . $wherea . "='%s'", array( $GameCP->whitelist($where, "clean") ))) or exit( mysql_error() );
        if( mysql_num_rows($userInfoQ) != "1" ) 
        {
            return false;
        }

        $userInfo = mysql_fetch_assoc($userInfoQ);
        if( $name ) 
        {
            $cid = $userInfo["id"];
        }

        $GameCP->loadIncludes("user");
        $User = new User();
        $userInfo["password"] = $User->Password($cid);
        return $userInfo;
    }

    public function GetGame($gid)
    {
        global $safesql;
        global $GameCP;
        $gameInfoQ = sql_query($safesql->query("SELECT * FROM game WHERE id = '%i' LIMIT 1;", array( $GameCP->whitelist($gid, "int") ))) or exit( mysql_error() );
        return mysql_fetch_array($gameInfoQ);
    }

    public function GetUserConfig($gid)
    {
        global $safesql;
        global $GameCP;
        $gameInfoQ = sql_query($safesql->query("SELECT * FROM userconfigs WHERE id = '%i' LIMIT 1;", array( $GameCP->whitelist($gid, "int") ))) or exit( mysql_error() );
        return mysql_fetch_assoc($gameInfoQ);
    }

    public function GetBill($gid)
    {
        global $safesql;
        global $GameCP;
        $gameInfoQ = sql_query($safesql->query("SELECT * FROM billing WHERE id = '%i' LIMIT 1;", array( $GameCP->whitelist($gid, "int") ))) or exit( mysql_error() );
        return mysql_fetch_array($gameInfoQ);
    }

    public function GetTicket($gid)
    {
        global $safesql;
        global $GameCP;
        $gameInfoQ = sql_query($safesql->query("SELECT * FROM ttsystem WHERE id = '%i' LIMIT 1;", array( $GameCP->whitelist($gid, "int") ))) or exit( mysql_error() );
        return mysql_fetch_assoc($gameInfoQ);
    }

    public function GetServerUsers($sid)
    {
        global $safesql;
        global $GameCP;
        $result = sql_query($safesql->query("SELECT distinct(UG.cid), U.* FROM usergames UG, iptable I, users U WHERE I.sid='%s' AND UG.ip = I.ip AND U.id = UG.cid", array( $GameCP->whitelist($sid, "clean") ))) or exit( mysql_error() );
        $return = array(  );
        while( $row = mysql_fetch_array($result) ) 
        {
            $return[] = $row;
        }
        return $return;
    }

    public function QueueList($level, $limit = false)
    {
        global $GameCP;
        global $safesql;
        if( $limit ) 
        {
            $limit = "" . "LIMIT " . $limit;
            $status = "status='0' OR status='3' OR status='4'";
            $ar = "";
        }
        else
        {
            $status = "status='%s'";
            $ar = array( $GameCP->whitelist($level, "clean") );
        }

        $result = sql_query($safesql->query("" . "SELECT * FROM queue WHERE " . $status . " ORDER BY id DESC " . $limit . ";", $ar)) or exit( mysql_error() );
        $smartdata = array(  );
        while( $row = mysql_fetch_array($result) ) 
        {
            $status = $row["status"];
            $qid = $row["id"];
            $modq = unserialize($row["mod"]);
            if( is_array($modq) ) 
            {
                $row = array_merge($row, $modq);
                $row["orderdate"] = $modq["date"];
                $row["orderpayment"] = $modq["payment"];
                $row["orderemail"] = $modq["femail"];
                $row["ordergross"] = $modq["gross"];
                if( $status == "0" ) 
                {
                    $status = "" . "<a href=?mode=run&qid=" . $qid . ">Install Pending</a>";
                }

                if( $status == "1" ) 
                {
                    $status = "" . "<a href=?mode=run&qid=" . $qid . ">Install Error</a>";
                }

                if( $status == "2" ) 
                {
                    $status = "Install Completed.";
                }

                if( $status == "3" ) 
                {
                    $status = "" . "<a href=?mode=run&qid=" . $qid . "><b>Awaiting Payment</b></a>";
                }

                $smartdata[] = $row;
            }

        }
        return $smartdata;
    }

    public function ExecQueue($qid = FALSE, $dontsuspend = FALSE, $admin = false)
    {
        global $Event;
        if( auto_setup == "0" && $admin == false ) 
        {
            $this->ErrorHeader("Automtic creation disabled");
            $Event->EventLogAdd("", "" . "Queue #" . $qid . " failed to execute, Automtic creation disabled- " . date("l jS \\of F Y h:i:s A"));
            return false;
        }

        $results = $this->ExecQueueInternal($qid, $dontsuspend);
        if( $results == false ) 
        {
            $this->ErrorHeader("There was a problem while executing the queue.");
            $Event->EventLogAdd("", "" . "Queue #" . $qid . " failed to execute - " . date("l jS \\of F Y h:i:s A"));
        }
        else
        {
            return $results;
        }

    }

    public function ExecQueueInternal($qid = FALSE, $dontsuspend = FALSE)
    {
        global $Event;
        global $GameCP;
        global $safesql;
        global $smarty;
        global $LNG_HOURS;
        $GameCP->loadIncludes("user");
        $User = new User();
        $orderpage = true;
        $result = sql_query($safesql->query("SELECT * FROM queue WHERE id='%i' LIMIT 1", array( $GameCP->whitelist($qid, "int") ))) or exit( mysql_error() );
        if( mysql_num_rows($result) == "0" ) 
        {
            return false;
        }

        while( $row = mysql_fetch_array($result) ) 
        {
            $mod = $row["mod"];
            $queue = $row[1];
            if( $row["status"] == "0" || $qid ) 
            {
                sql_query("UPDATE queue SET status='2', result='' WHERE id='" . $row["id"] . "';");
                $mod = unserialize($mod);
                extract($mod);
                if( !isset($extrainfo) ) 
                {
                    $extrainfo = "";
                }

                if( !isset($demo) ) 
                {
                    $demo = "";
                }

                if( !isset($billingid) ) 
                {
                    $billingid = "";
                }

                if( !isset($clan) ) 
                {
                    $clan = "";
                }

                if( $dontsuspend == true ) 
                {
                    $suspend_notpaid = false;
                }

                if( isset($vars) && $vars != "" ) 
                {
                    $_REQUEST["cvars"] = unserialize($vars);
                }

                if( $existingsignup ) 
                {
                    if( is_numeric($fname) ) 
                    {
                        $user_data = $this->GetUser($fname);
                    }
                    else
                    {
                        $user_data = $this->GetUser(false, $fname);
                    }

                    $gcp_cid = $user_data["id"];
                    $fname = $user_data["name"];
                    $mod["femail"] = $user_data["email"];
                    $Event->EventLogAdd($fname, "Order #" . $row["id"] . " for user " . $fname . "" . " is being installed by the queue (existing user, " . $gcp_cid . ") " . json_encode($mod));
                }
                else
                {
                    if( !$fname ) 
                    {
                        $fname = "order" . time();
                    }

                    $user_data = array( "fmanager" => $fmanager, "today" => date(dateformat, time()), "loginpath" => $loginpath, "payment" => $payment, "lastname" => $lastname, "firstname" => $firstname, "extrainfo" => $extrainfo, "clienturl" => $clienturl, "zip" => $zip, "country" => $country, "state" => $state, "city" => $city, "address" => $address, "address2" => $address2, "phone" => $phone, "fuserlevel" => $fuserlevel, "femail" => $femail, "fname" => $fname, "freseller" => $freseller, "queue" => $queue, "fpassword" => $fpassword, "demo" => $demo, "billingid" => $billingid, "clan" => $clan, "currency" => $currency );
                    $gcp_cid = $User->AddUser($user_data);
                    sql_query("UPDATE users SET name='" . userprefix . "" . $gcp_cid . "', username='" . userprefix . "" . $gcp_cid . "' WHERE id='" . $gcp_cid . "'");
                    $Event->EventLogAdd($fname, "Order #" . $row["id"] . " for " . $femail . "" . " is being installed by the queue (new user, " . $gcp_cid . ", username gamecp" . $gcp_cid . ") " . $mod);
                }

                if( !$gcp_cid ) 
                {
                    return false;
                }

                $addons = array(  );
                $game_addons = array(  );
                if( $paddons ) 
                {
                    $addonsArray = unserialize($paddons);
                    if( is_array($addonsArray) ) 
                    {
                        foreach( $addonsArray as $adnvar => $adnval ) 
                        {
                            if( preg_match("/addon_/i", $adnvar) ) 
                            {
                                if( $adnvar != "sv_slots" && $adnvar != "sv_location" ) 
                                {
                                    $addons[$adnvar] = $adnval;
                                }

                            }
                            else
                            {
                                if( preg_match("/game_/i", $adnvar) ) 
                                {
                                    $game_addons[] = array( "cvar" => strtoupper($adnvar), "value" => $adnval );
                                }

                            }

                        }
                    }

                }

                if( isset($pid) && 0 < $pid && $pid != "nogame" ) 
                {
                    $ugid = $User->AddGame($fname, $gcp_cid, $pid, $fip, $fport, "", "", "yes", $fmaxclients, $fpubpriv, "0", $flimit, $subdirectory, $fstartmap, $RCONPASSWORD, $SPECPASSWORD, $PRIVPASSWORD, $HOSTNAME, $MOTD, $WEBSITE, $fconfig, $installtype, $startserver, $addons, $game_addons, FALSE, FALSE, $start_time, $end_time, $row["id"], $servicebillingid, "no", "", $location, "", $fmip);
                }

                $packageQ = sql_query($safesql->query("SELECT pid, module FROM prices P, packages PP WHERE P.id = '%i' AND P.pid = PP.id LIMIT 1", array( $ordergame["id"] ))) or exit( mysql_error() );
                if( mysql_num_rows($packageQ) == "1" ) 
                {
                    $package = mysql_fetch_array($packageQ);
                    if( $package["module"] ) 
                    {
                        $GameCP->loadIncludes("modules");
                        $Modules = new Modules($package["module"]);
                        $params = $mod;
                        $params["cid"] = $gcp_cid;
                        $params["qid"] = $qid;
                        $params["pid"] = $package["pid"];
                        $params["user_data"] = $user_data;
                        $upid = $Modules->CreateModuleRecord($params);
                    }

                }

                if( $voiceInstall == "yes" ) 
                {
                    $GameCP->loadIncludes("voice");
                    $Voice = new Voice();
                    if( $voiceType == "1000" ) 
                    {
                        $vid = $Voice->AddTeamSpeak2($gcp_cid, $voiceIP, $voicePort, $voiceName, $voiceMaxClients, $fpassword, false, false, false, $voicebillingid);
                    }

                    if( $voiceType == "1001" ) 
                    {
                        $vid = $Voice->AddVentrilo($gcp_cid, $voiceIP, $voicePort, $fname, $voiceName, $fpassword, $fpassword, "", $voiceMaxClients, $fpassword, false, false, false, $voicebillingid);
                    }

                    if( $voiceType == "1002" ) 
                    {
                        $vid = $Voice->AddTeamSpeak3($gcp_cid, $voiceIP, $voicePort, $voiceName, $voiceMaxClients, $fpassword, false, false, false, $voicebillingid);
                    }

                    if( $voiceType == "1003" ) 
                    {
                        $vid = $User->AddGame($fname, $gcp_cid, "1003", "", $voicePort, "", "", "yes", $voiceMaxClients, "", "0", "+1", $subdirectory, $fstartmap, $RCONPASSWORD, $SPECPASSWORD, $PRIVPASSWORD, $voiceName, $MOTD, $WEBSITE, $fconfig, $installtype, $startserver, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, "no");
                    }

                    if( $voiceType == "1004" ) 
                    {
                        $vid = $User->AddGame($fname, $gcp_cid, "1004", "", $voicePort, "", "", "yes", $voiceMaxClients, "", "0", "+1", $subdirectory, $fstartmap, $RCONPASSWORD, $SPECPASSWORD, $PRIVPASSWORD, $voiceName, $MOTD, $WEBSITE, $fconfig, $installtype, $startserver, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, "no");
                    }

                    if( !$vid ) 
                    {
                        $smarty->assign("error", "Voice service not created.");
                    }

                    if( !is_integer($vid) ) 
                    {
                        $smarty->assign("error", $vid);
                    }

                }
                else
                {
                    $vid = "";
                }

                if( $addbill == "yes" || $addbill == "1" ) 
                {
                    if( $daystill == "1" ) 
                    {
                        $description = $hours . " " . $LNG_HOURS;
                    }
                    else
                    {
                        $description = "";
                    }

                    $GameCP->loadIncludes("billing");
                    $Billing = new Billing();
                    $bid = $Billing->AddBill($daystill, $gcp_cid, date(dateformat), $status, $gross, $fee, $subscr_id, $promo);
                    $Billing->CreateSubBill($addbill, $bid, $ugid, $vid, $ordergame, $ordervoice, $gcp_cid, unserialize($promo), unserialize($paddons), array( $taxproduct, $taxvoice, $taxaddon ), $description, $upid);
                    $Billing->updateBillTotals($bid);
                    if( isset($paidPrice) && $paidPrice ) 
                    {
                        $Billing->AddPayment($bid, $paidPrice, $subscr_id, $transactionid, $payment, $fee);
                    }

                    if( $suspend_notpaid != false && ($status == "Completed" && isset($paidPrice) && $paidPrice < $gross || $status != "Completed") ) 
                    {
                        $GameCP->loadIncludes("suspend");
                        $Suspend = new Suspend();
                        if( isset($ugid) && $ugid != "" && (is_int($ugid) || is_integer($ugid)) ) 
                        {
                            $Suspend->Game($ugid);
                        }

                        if( $vid && ($ordervoice["type"] == "1003" || $ordervoice["type"] == "1004") && (is_int($vid) || is_integer($vid)) ) 
                        {
                            $Suspend->Game($vid);
                        }
                        else
                        {
                            if( $vid && (is_int($vid) || is_integer($vid)) ) 
                            {
                                $Suspend->Voice($vid);
                            }

                        }

                    }

                }

                if( $fsendinfo == "yes" ) 
                {
                    $GameCP->loadIncludes("email");
                    $Email = new Email();
                    $Email->SendDetails($gcp_cid);
                    $packageQ = sql_query($safesql->query("SELECT * FROM packages WHERE id = '%i' LIMIT 1", array( $pid ))) or exit( mysql_error() );
                    $package = mysql_fetch_array($packageQ);
                    if( $package["eid"] ) 
                    {
                        $convert = array(  );
                        $convert[] = array( "var" => "\$ORDERID", "value" => $row["id"] );
                        $convert[] = array( "var" => "\$USERNAME", "value" => $fname );
                        $Email = new Email();
                        $Email->SendPackageDetails($gcp_cid, $package["eid"], $convert);
                    }

                }

                $promo = unserialize($promo);
                if( is_array($promo) && 0 < count($promo) ) 
                {
                    $userInfo = $this->GetUser("", $fname);
                    $gcp_cid = $userInfo["id"];
                    foreach( $promo as $p => $mo ) 
                    {
                        sql_query("INSERT INTO promotionsuse SET pmid='" . $mo["id"] . "', cid='" . $userInfo["id"] . "';");
                    }
                }

                $return = array(  );
                if( isset($ugid) && (is_int($ugid) || is_integer($ugid)) ) 
                {
                    $smarty->assign("ugid", $ugid);
                    $mod["ugid"] = $ugid;
                    $return["ugid"] = $ugid;
                }

                if( isset($vid) && (is_int($vid) || is_integer($vid)) ) 
                {
                    $smarty->assign("vid", $vid);
                    $mod["vid"] = $vid;
                    $return["vid"] = $vid;
                }

                if( isset($bid) && (is_int($bid) || is_integer($bid)) ) 
                {
                    $smarty->assign("bid", $bid);
                    $mod["bid"] = $bid;
                    $return["bid"] = $bid;
                }

                if( isset($upid) && (is_int($upid) || is_integer($upid)) ) 
                {
                    $smarty->assign("upid", $upid);
                    $mod["upid"] = $upid;
                    $return["upid"] = $upid;
                }

                $smarty->assign("cid", $gcp_cid);
                $mod["cid"] = $gcp_cid;
                $return["cid"] = $gcp_cid;
                $smarty->assign("fname", $fname);
                sql_query($safesql->query("UPDATE queue SET `mod`='%s' WHERE id='%i' LIMIT 1", array( serialize($mod), $GameCP->whitelist($qid, "int") ))) or exit( mysql_error() );
                $Event->EventLogAdd($fname, "Order #" . $row["id"] . " for " . $fname . " is has been installed by the queue. " . json_encode($mod));
                return $return;
            }

        }
        return false;
    }

    public function GetDirContents($dir, $alt = FALSE)
    {
        $exclusions = array( ".", "..", ".svn", "order", "default", "hooks" );
        $files = array(  );
        if( $root = @opendir($dir) ) 
        {
            while( $file = readdir($root) ) 
            {
                if( in_array($file, $exclusions) ) 
                {
                    continue;
                }

                if( $alt ) 
                {
                    if( !is_dir($dir . "/" . $file) ) 
                    {
                        $files[] = $file;
                    }

                }
                else
                {
                    if( is_dir($dir . "/" . $file) ) 
                    {
                        $files[] = $file;
                    }

                }

            }
        }

        return $files;
    }

    public function RemoveCache()
    {
        global $path;
        $smartypath = path . DIRECTORY_SEPARATOR . "includes" . DIRECTORY_SEPARATOR . "cache" . DIRECTORY_SEPARATOR . THEME;
        if( is_dir($smartypath) ) 
        {
            $dir = opendir($smartypath);
            while( $entry = readdir($dir) ) 
            {
                if( is_file("" . $smartypath . "/" . $entry) ) 
                {
                    unlink("" . $smartypath . "/" . $entry);
                }

            }
            closedir($dir);
        }

    }

    public function Optimize()
    {
        sql_query("OPTIMIZE TABLE `addons`");
        sql_query("OPTIMIZE TABLE `billing`");
        sql_query("OPTIMIZE TABLE `charges`");
        sql_query("OPTIMIZE TABLE `cmdcenter`");
        sql_query("OPTIMIZE TABLE `emails`");
        sql_query("OPTIMIZE TABLE `game`");
        sql_query("OPTIMIZE TABLE `gameconfigs`");
        sql_query("OPTIMIZE TABLE `gameupdates`");
        sql_query("OPTIMIZE TABLE `gateways`");
        sql_query("OPTIMIZE TABLE `iptable`");
        sql_query("OPTIMIZE TABLE `navigation`");
        sql_query("OPTIMIZE TABLE `news`");
        sql_query("OPTIMIZE TABLE `packages`");
        sql_query("OPTIMIZE TABLE `prices`");
        sql_query("OPTIMIZE TABLE `queue`");
        sql_query("OPTIMIZE TABLE `rcon-hl`");
        sql_query("OPTIMIZE TABLE `rcon-q3`");
        sql_query("OPTIMIZE TABLE `resellers`");
        sql_query("OPTIMIZE TABLE `servers`");
        sql_query("OPTIMIZE TABLE `settings`");
        sql_query("OPTIMIZE TABLE `ttcategorys`");
        sql_query("OPTIMIZE TABLE `ttsystem`");
        sql_query("OPTIMIZE TABLE `userbills`");
        sql_query("OPTIMIZE TABLE `usergames`");
        sql_query("OPTIMIZE TABLE `userlevels`");
        sql_query("OPTIMIZE TABLE `userpermissions`");
        sql_query("OPTIMIZE TABLE `users`");
        sql_query("OPTIMIZE TABLE `usersonline`");
        sql_query("OPTIMIZE TABLE `uservoice`");
    }

    public function TempDir()
    {
        $tmpfile = tempnam("", "");
        $autodir = dirname($tmpfile);
        if( is_dir($autodir) ) 
        {
            if( $autodir == "." ) 
            {
                if( is_dir("/tmp") && is_writeable("/tmp") ) 
                {
                    return "/tmp";
                }

                echo "Unable to determing a temporary folder, defailting to /tmp";
                return "/tmp";
            }

            return $autodir;
        }

        if( is_dir(tmppath) ) 
        {
            return tmppath;
        }

    }

    public function Kill()
    {
        if( isset($_SESSION["gamecp"]) ) 
        {
            unset($_SESSION["gamecp"]);
        }

        @session_regenerate_id();
        $_SESSION["gamecp"] = array(  );
        exit();
    }

    public function RandomPassword()
    {
        $salt = "_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        srand((double) microtime() * 1000000);
        for( $i = 0; $i < 10; $i++ ) 
        {
            $num = rand() % 33;
            $tmp = substr($salt, $num, 1);
            $pass = $pass . $tmp;
        }
        return strip_tags($pass);
    }

    public function TimeDistance($start_timestamp, $end_timestamp)
    {
        $days_seconds_star = 23 * 56 * 60 + 4.091;
        $days_seconds_sun = 24 * 60 * 60;
        $difference_seconds = $end_timestamp - $start_timestamp;
        $difference_days = round($difference_seconds / $days_seconds_sun, 2);
        $difference_hours = round($difference_seconds / 3600, 2);
        $difference_minutes = round($difference_seconds / 60, 2);
        if( 24 < $difference_hours ) 
        {
            return $difference_days . " Days";
        }

        if( 60 < $difference_minutes ) 
        {
            return $difference_hours . " Hours";
        }

        if( 60 < $difference_seconds ) 
        {
            return $difference_minutes . " Minutes";
        }

        if( $difference_seconds == 1 ) 
        {
            return $difference_seconds . " Second";
        }

        return $difference_seconds . " Seconds";
    }

    public function InvalidNames()
    {
        $invalidnames = array(  );
        $invalidnamesQ = sql_query("SELECT deny FROM denyusers;");
        while( $inv = mysql_fetch_array($invalidnamesQ) ) 
        {
            $invalidnames[] = $inv["deny"];
        }
        return $invalidnames;
    }

    public function InvalidFiles()
    {
        $invalidnames = array(  );
        $invalidnamesQ = sql_query("SELECT deny FROM denyfiles;");
        while( $inv = mysql_fetch_array($invalidnamesQ) ) 
        {
            $invalidnames[] = $inv["deny"];
        }
        return $invalidnames;
    }

    public function InvalidUploads()
    {
        $invalidnames = array(  );
        $invalidnamesQ = sql_query("SELECT deny FROM denyupload;");
        while( $inv = mysql_fetch_array($invalidnamesQ) ) 
        {
            $invalidnames[] = $inv["deny"];
        }
        return $invalidnames;
    }

    public function InvalidExtensions()
    {
        $invalidnames = array(  );
        $invalidnamesQ = sql_query("SELECT deny FROM denyextensions;");
        while( $inv = mysql_fetch_array($invalidnamesQ) ) 
        {
            $invalidnames[] = $inv["deny"];
        }
        return $invalidnames;
    }

    public function GetMasterID()
    {
        $master = sql_query("SELECT sid FROM servers WHERE master = 'yes'");
        $masterQ = mysql_fetch_row($master);
        return $masterQ[0];
    }

    public function GetLatestGCPDevBuild()
    {
        global $GameCP;
        $postfields = array(  );
        $contents = $_SERVER['DOCUMENT_ROOT'] .'/assets/version.txt'; 
        if( $contents ) 
        {
            $contents_exp = explode(" ", $contents);
            $output["Version"] = $contents_exp[0];
            $output["BuildTimestamp"] = $this->GetLatestGCPDevDate();
            return $output;
        }

    }

    public function GetLatestGCPDevDate()
    {
        global $GameCP;
        $postfields = array(  );
        return file_get_contents($_SERVER['DOCUMENT_ROOT'] .'/assets/versiondate'); 
    }

    public function GetLatestGCPRemoteV()
    {
        global $GameCP;
        $postfields = array(  );
        return file_get_contents($_SERVER['DOCUMENT_ROOT'] .'/assets/api.php');
    }

    public function GetLatestGCPDevBuildComments($versionDiff)
    {
        global $GameCP;
        $postfields = array(  );
        $postfields["view"] = $versionDiff;
        return file_get_contents($_SERVER['DOCUMENT_ROOT'] .'/assets/comments.php'); 
    }

}


