<?php 

/**
 * @access private 
 * @internal
 */

class ConvertData
{
    public $scramble1 = NULL;
    public $scramble2 = NULL;
    public $errors = NULL;
    public $adj = NULL;
    public $mod = NULL;
    public $usermode = NULL;

    public function ConvertData($usermode = FALSE)
    {
        $this->errors = array(  );
        if( $usermode ) 
        {
            $this->scramble1 = "! #\$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~";
            $this->scramble2 = "f^jAE]okIOzU[2&q1{3`h5w_794p@6s8?BgP>dFV=m D<TcS%Ze|r:lGK/uCy.Jx)HiQ!#\$~(;Lt-R}Ma,NvW+Ynb*0X";
        }
        else
        {
            $this->scramble1 = "! #\$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~";
            $this->scramble2 = "f^jAE]okIOzU[2&q1{3`h5w_794p@6s8?BgP>dFV=m D<TcS%Ze|r:lGK/uCy.Jx)HiQ!#\$~(;Lt-R}Ma,NvW+Ynb*0X";
        }

        if( strlen($this->scramble1) != strlen($this->scramble2) ) 
        {
            trigger_error("** SCRAMBLE1 is not same length as SCRAMBLE2 **", E_USER_ERROR);
        }

        $this->adj = 1.75;
        $this->mod = 3;
    }

    public function decrypt($key, $source)
    {
        $this->errors = array(  );
        $fudgefactor = $this->_convertKey($key);
        if( $this->errors ) 
        {
            return NULL;
        }

        if( empty($source) ) 
        {
            $this->errors[] = "No value has been supplied for decryption";
        }
        else
        {
            $target = null;
            $factor2 = 0;
            for( $i = 0; $i < strlen($source); $i++ ) 
            {
                if( function_exists("mb_substr") ) 
                {
                    $char2 = mb_substr($source, $i, 1);
                }
                else
                {
                    $char2 = substr($source, $i, 1);
                }

                $num2 = strpos($this->scramble2, $char2);
                if( $num2 === false ) 
                {
                    $this->errors[] = "" . "Source string contains an invalid character (" . $char2 . ")";
                    return NULL;
                }

                $adj = $this->_applyFudgeFactor($fudgefactor);
                $factor1 = $factor2 + $adj;
                $num1 = $num2 - round($factor1);
                $num1 = $this->_checkRange($num1);
                $factor2 = $factor1 + $num2;
                if( function_exists("mb_substr") ) 
                {
                    $char1 = mb_substr($this->scramble1, $num1, 1);
                }
                else
                {
                    $char1 = substr($this->scramble1, $num1, 1);
                }

                $target .= $char1;
            }
            return rtrim($target);
        }

    }

    public function encrypt($key, $source, $sourcelen = 0)
    {
        $this->errors = array(  );
        $fudgefactor = $this->_convertKey($key);
        if( $this->errors ) 
        {
            return NULL;
        }

        if( empty($source) ) 
        {
            $this->errors[] = "No value has been supplied for encryption";
        }
        else
        {
            $source = str_pad($source, $sourcelen);
            $target = null;
            $factor2 = 0;
            for( $i = 0; $i < strlen($source); $i++ ) 
            {
                if( function_exists("mb_substr") ) 
                {
                    $char1 = mb_substr($source, $i, 1);
                }
                else
                {
                    $char1 = substr($source, $i, 1);
                }

                $num1 = strpos($this->scramble1, $char1);
                if( $num1 === false ) 
                {
                    $this->errors[] = "" . "Source string contains an invalid character (" . $char1 . ")";
                    return NULL;
                }

                $adj = $this->_applyFudgeFactor($fudgefactor);
                $factor1 = $factor2 + $adj;
                $num2 = round($factor1) + $num1;
                $num2 = $this->_checkRange($num2);
                $factor2 = $factor1 + $num2;
                if( function_exists("mb_substr") ) 
                {
                    $char2 = mb_substr($this->scramble2, $num2, 1);
                }
                else
                {
                    $char2 = substr($this->scramble2, $num2, 1);
                }

                $target .= $char2;
            }
            return $target;
        }

    }

    public function getAdjustment()
    {
        return $this->adj;
    }

    public function getModulus()
    {
        return $this->mod;
    }

    public function setAdjustment($adj)
    {
        $this->adj = (double) $adj;
    }

    public function setModulus($mod)
    {
        $this->mod = (int) abs($mod);
    }

    public function _applyFudgeFactor(&$fudgefactor)
    {
        $fudge = array_shift($fudgefactor);
        $fudge = $fudge + $this->adj;
        $fudgefactor[] = $fudge;
        if( !empty($this->mod) && $fudge % $this->mod == 0 ) 
        {
            $fudge = $fudge * (0 - 1);
        }

        return $fudge;
    }

    public function _checkRange($num)
    {
        $num = round($num);
        $limit = strlen($this->scramble1);
        while( $limit <= $num ) 
        {
            $num = $num - $limit;
        }
        while( $num < 0 ) 
        {
            $num = $num + $limit;
        }
        return $num;
    }

    public function _convertKey($key)
    {
        if( empty($key) ) 
        {
            $this->errors[] = "No value has been supplied for the encryption key";
        }
        else
        {
            $array[] = strlen($key);
            $tot = 0;
            for( $i = 0; $i < strlen($key); $i++ ) 
            {
                if( function_exists("mb_substr") ) 
                {
                    $char = mb_substr($key, $i, 1);
                }
                else
                {
                    $char = substr($key, $i, 1);
                }

                $num = strpos($this->scramble1, $char);
                if( $num === false ) 
                {
                    $this->errors[] = "" . "Key contains an invalid character (" . $char . ")";
                    return NULL;
                }

                $array[] = $num;
                $tot = $tot + $num;
            }
            $array[] = $tot;
            return $array;
        }

    }

}


