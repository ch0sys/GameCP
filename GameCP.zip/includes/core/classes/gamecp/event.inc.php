<?php 

class Event
{
    public function EventLogAdd($affecteduser, $comment)
    {
        global $safesql;
        global $GameCP;
        if( disableevents != "0" ) 
        {
            return false;
        }

        if( isset($_SESSION["gamecp"]["subaccount"]) && isset($_SESSION["gamecp"]["subuser"]["name"]) ) 
        {
            $username = $_SESSION["gamecp"]["subuser"]["name"];
        }
        else
        {
            if( isset($_SESSION["gamecp"]["userinfo"]["name"]) ) 
            {
                $username = $_SESSION["gamecp"]["userinfo"]["name"];
            }
            else
            {
                $username = "System";
            }

        }

        $datetime = time();
        if( isset($_SERVER["REMOTE_ADDR"]) ) 
        {
            $remoteaddr = $_SERVER["REMOTE_ADDR"];
        }
        else
        {
            $remoteaddr = "localhost";
        }

        if( isset($_SERVER["REQUEST_URI"]) ) 
        {
            $requesturl = $_SERVER["REQUEST_URI"];
        }
        else
        {
            $requesturl = $_SERVER["PHP_SELF"];
        }

        if( empty($username) ) 
        {
            $username = "Automated System";
        }

        $query = sql_query($safesql->query("INSERT INTO `eventlogs` SET \r\n\t\t\tuser='%s',\r\n\t\t\ttime='%s',\r\n\t\t\taffecteduser='%s',\r\n\t\t\tcomment='%s',\r\n\t\t\tip='%s',\r\n\t\t\tpage='%s',\r\n\t\t\tpost='%s';", array( $GameCP->whitelist($username, "clean"), $GameCP->whitelist($datetime, "clean"), $GameCP->whitelist($affecteduser, "clean"), $GameCP->whitelist($comment, "encode"), $GameCP->whitelist($remoteaddr, "clean"), $GameCP->whitelist($requesturl, "clean"), $GameCP->whitelist(serialize($_REQUEST) . "---" . serialize($_SESSION["gamecp"]), "clean") )));
    }

    public function EventLogView($username, $affected = FALSE)
    {
        global $safesql;
        if( !empty($username) ) 
        {
            if( $affected == TRUE ) 
            {
                $query = sql_query($safesql->query("SELECT * FROM `eventlogs` WHERE affecteduser='%s' ORDER BY `time` DESC", array( $username )));
            }
            else
            {
                $query = sql_query($safesql->query("SELECT * FROM `eventlogs` WHERE user='%s' ORDER BY `time` DESC", array( $username )));
            }

        }
        else
        {
            $query = sql_query("SELECT * FROM `eventlogs` ORDER BY `time` DESC");
        }

        if( $query && 0 < mysql_num_rows($query) ) 
        {
            $data = mysql_fetch_array($query);
            return $data;
        }

        return "No Events logged";
    }

}


