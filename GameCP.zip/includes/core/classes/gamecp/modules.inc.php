<?php 

class Modules
{
    public $module = NULL;
    public $configoptions = array(  );
    public $loaded = false;
    public $mod_type = "servers";
    public $product = NULL;
    public $params = array(  );
    public $record = false;
    public $safesql = NULL;
    public $GameCP = NULL;

    public function __construct($module = "", $mod_type = "servers")
    {
        global $safesql;
        global $GameCP;
        $this->GameCP = $GameCP;
        $this->safesql = $safesql;
        $this->module = $module;
        $this->mod_type = $mod_type;
        if( $module ) 
        {
            $this->LoadModule();
        }

        $this->ConfigOptions();
    }

    public function ExecUserCommand($cid, $function)
    {
        $info = sql_query($this->safesql->query("SELECT * FROM `module_services` WHERE cid = '%i'", array( $this->GameCP->whitelist($cid, "int") ))) or exit( mysql_error() );
        while( $pinfo = mysql_fetch_assoc($info) ) 
        {
            $this->SetRecord($pinfo["id"]);
            $this->SetModuleData();
            if( $this->module ) 
            {
                call_user_func($function);
            }

        }
    }

    public function GetModules()
    {
        $this->GameCP->loadIncludes("panel");
        $Panel = new Panel();
        return $Panel->GetDirContents(path . "/includes/modules/" . $this->mod_type);
    }

    public function LoadModule()
    {
        if( is_file(path . "/includes/modules/" . $this->mod_type . "/" . $this->module . "/" . $this->module . ".php") ) 
        {
            require_once(path . "/includes/modules/" . $this->mod_type . "/" . $this->module . "/" . $this->module . ".php");
            $this->loaded = true;
        }

    }

    public function SetProduct($product)
    {
        $this->product = $product;
    }

    public function CreateModuleRecord($params)
    {
        sql_query($this->safesql->query("INSERT INTO `module_services` SET\r\n\t\t\t\t\t\t\t\t\t\t`date` ='%s',\r\n\t\t\t\t\t\t\t\t\t\t`customfields` ='%s',\r\n\t\t\t\t\t\t\t\t\t\t`customfieldsog` ='%s',\r\n\t\t\t\t\t\t\t\t\t\t`pid` ='%i',\r\n\t\t\t\t\t\t\t\t\t\t`cid` ='%i',\r\n\t\t\t\t\t\t\t\t\t\t`qid` ='%i',\r\n\t\t\t\t\t\t\t\t\t\t`status` ='Pending'", array( time(), $params["paddons"], $params["paddonsOriginal"], $params["pid"], $params["cid"], $params["qid"] ))) or exit( mysql_error() );
        $this->record = mysql_insert_id();
        if( $params["status"] == "Completed" ) 
        {
            $this->CreateAccount();
        }

        return $this->record;
    }

    public function UpdateModule($params)
    {
        sql_query($this->safesql->query("UPDATE `module_services` SET\r\n\t\t\t\t\t\t\t\t\t\t`customfieldsog` ='%s',\r\n\t\t\t\t\t\t\t\t\t\t`notes`='%s',\r\n\t\t\t\t\t\t\t\t\t\t`status` ='%s'  WHERE id='%i'", array( serialize($params["paddon"]), $params["notes"], $params["status"], $this->record ))) or exit( mysql_error() );
    }

    public function UpdateModuleStatus($_status)
    {
        sql_query($this->safesql->query("UPDATE `module_services` SET status='%s' WHERE id='%i' LIMIT 1", array( $_status, $this->record )));
        return true;
    }

    public function DeleteModuleRecord()
    {
        sql_query($this->safesql->query("DELETE FROM `module_services` WHERE id='%i' LIMIT 1", array( $this->record )));
    }

    public function GetModuleRecord()
    {
        $cs = sql_query($this->safesql->query("SELECT * FROM `module_services` WHERE id='%i' LIMIT 1", array( $this->record )));
        $result = mysql_fetch_assoc($cs);
        $result["customfields"] = unserialize($result["customfields"]);
        $ps = sql_query($this->safesql->query("SELECT * FROM `packages` WHERE id='%i' LIMIT 1", array( $result["pid"] )));
        $packageinfo = mysql_fetch_assoc($ps);
        $result["producttype"] = $packageinfo["module"];
        $result["product"] = $packageinfo;
        return $result;
    }

    public function SetRecord($_id)
    {
        $this->record = $_id;
    }

    public function SetModuleData()
    {
        if( !$this->record ) 
        {
            return false;
        }

        $this->GameCP->loadIncludes("panel");
        $Panel = new Panel();
        $_configoptions = $this->GetConfigOptions();
        $result = $this->GetModuleRecord();
        $i = 1;
        $final = array(  );
        foreach( $_configoptions as $c => $o ) 
        {
            $result["configoption" . $i] = $o["value"];
            $final[$c] = $o["value"];
            $i++;
        }
        $result["configoptions"] = $final;
        $result["clientsdetails"] = $Panel->GetUser($result["cid"]);
        $result["serviceid"] = $this->record;
        $result["username"] = $result["clientsdetails"]["username"];
        $result["password"] = $result["clientsdetails"]["password"];
        $this->params = $result;
    }

    public function Error($error)
    {
        return "" . "<h3>" . $error . "</h3>";
    }

    public function GetConfigOptions()
    {
        $saved = array(  );
        $cs = sql_query($this->safesql->query("SELECT * FROM `module_settings` WHERE module = '%s' AND pid='%i'", array( $this->module, $this->product )));
        while( $c = mysql_fetch_assoc($cs) ) 
        {
            $saved[$c["setting"]] = $c["value"];
        }
        $result = array(  );
        if( is_array($this->configoptions) && 0 < count($this->configoptions) ) 
        {
            foreach( $this->configoptions as $cc => $o ) 
            {
                if( array_key_exists($cc, $saved) ) 
                {
                    $val = $saved[$cc];
                }
                else
                {
                    if( isset($o["Default"]) ) 
                    {
                        $val = $o["Default"];
                    }
                    else
                    {
                        $val = "";
                    }

                }

                $o["value"] = $val;
                if( isset($o["Options"]) && preg_match("/,/s", $o["Options"]) ) 
                {
                    $o["Options"] = explode(",", $o["Options"]);
                }

                $result[$cc] = $o;
            }
        }

        return $result;
    }

    public function SetConfigOptions($data)
    {
        if( is_array($data) && 0 < count($data) ) 
        {
            sql_query($this->safesql->query("DELETE FROM `module_settings` WHERE module = '%s' AND pid='%i'", array( $this->module, $this->product )));
            foreach( $data as $name => $value ) 
            {
                sql_query($this->safesql->query("INSERT INTO `module_settings` SET setting='%s', value='%s', module = '%s', pid='%i'", array( $name, $value, $this->module, $this->product )));
            }
        }

    }

    public function RunFunction($function)
    {
        $this->SetModuleData();
        return $this->RunCommand($this->module, $function, $this->params);
    }

    public function RunCommand($prefix, $function, $data = "")
    {
        if( $this->loaded && function_exists($prefix . "_" . $function) ) 
        {
            return call_user_func($prefix . "_" . $function, $data);
        }

        return false;
    }

    public function ConfigOptions()
    {
        $this->configoptions = $this->RunFunction("ConfigOptions");
    }

    public function CreateAccount()
    {
        $_result = $this->RunFunction("CreateAccount");
        if( $_result == "success" ) 
        {
            return $this->UpdateModuleStatus("Active");
        }

        return $this->Error($_result);
    }

    public function TerminateAccount()
    {
        $_result = $this->RunFunction("TerminateAccount");
        if( $_result == "success" ) 
        {
            return $this->UpdateModuleStatus("Terminated");
        }

        return $this->Error($_result);
    }

    public function SuspendAccount()
    {
        $_result = $this->RunFunction("SuspendAccount");
        if( $_result == "success" ) 
        {
            return $this->UpdateModuleStatus("Suspended");
        }

        return $this->Error($_result);
    }

    public function UnsuspendAccount()
    {
        $_result = $this->RunFunction("UnsuspendAccount");
        if( $_result == "success" ) 
        {
            return $this->UpdateModuleStatus("Pending");
        }

        return $this->Error($_result);
    }

    public function ChangePackage()
    {
        $_result = $this->RunFunction("ChangePackage");
        if( $_result == "success" ) 
        {
            return true;
        }

        return $this->Error($_result);
    }

    public function AdminLink()
    {
        return $this->RunFunction("AdminLink");
    }

    public function LoginLink()
    {
        return $this->RunFunction("LoginLink");
    }

    public function AdminCustomButtonArray()
    {
        return $this->RunFunction("AdminCustomButtonArray");
    }

    public function ClientArea()
    {
        return $this->RunFunction("ClientArea");
    }

    public function ChangePassword()
    {
        return $this->RunFunction("ChangePassword");
    }

    public function UsageUpdate()
    {
        return $this->RunFunction("UsageUpdate");
    }

    public function ExecButton($_function)
    {
        return $this->RunCommand($_function, "button", $this->params);
    }

}

function logModuleCall($module, $mode, $req, $result)
{
    global $Event;
    $Event->EventLogAdd("module_" . $module, "" . "Module: " . $module . " triggered mode: " . $mode . " with result of " . json_encode($result) . " and variables (encoded) as : " . json_encode($req));
}

function convert_data($array)
{
    $output = "";
    if( is_array($array) ) 
    {
        foreach( $array as $id => $val ) 
        {
            $output .= "" . $id . "='" . $val . "', ";
        }
        return substr($output, 0, 0 - 2);
    }

}

function select_query($table, $data, $where)
{
    $data = convert_data($data);
    if( !$data ) 
    {
        $data = "*";
    }

    $where = convert_data($where);
    return mysql_query("" . "SELECT " . $data . " FROM " . $table . " WHERE " . $where);
}

function update_query($table, $data, $where)
{
    $data = convert_data($data);
    $where = convert_data($where);
    return mysql_query("" . "UPDATE " . $table . " SET " . $data . " WHERE " . $where);
}

function insert_query($table, $data)
{
    $data = convert_data($data);
    return mysql_query("" . "INSERT INTO " . $table . " SET " . $data);
}

function full_query($data)
{
    return mysql_query("" . $data);
}


