<?php 

class Command
{
    public function Run($fname, $sid, $command, $winport, $os, $primary, $thesubdir, $ugid)
    {
        global $GameCP;
        $GameCP->loadIncludes("backend");
        $Backend = new Backend();
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $ugid ) 
        {
            $command = $Game->ReplaceAllVars($ugid, $command);
        }

        if( !$fname ) 
        {
            $fname = "root";
        }

        $time = time();
        set_time_limit(9999999);
        if( $os == "1" ) 
        {
            $homepath = "\$MAINDIR\\home\\" . $fname;
            if( $thesubdir ) 
            {
                $homepath .= "" . "\\" . $thesubdir;
            }

            $script = "" . "gamecp-cmdcontrol" . $fname . $time . ".bat";
            $command = "" . "cd /d \$MAINDIR\\home\\" . $fname . "\\" . $thesubdir . " \n" . $command;
            $command = str_replace("\r", "", $command);
            $command = str_replace("\n", "\r\n", $command);
            $Backend->QueryResponse($sid, $winport, "" . "writefile:_:" . $homepath . "\\" . $script . ":_:" . $command);
            $reply = $Backend->QueryResponse($sid, $winport, "" . $homepath . "\\" . $script . ":_:");
            $Backend->Query($sid, $winport, "" . "deletefile:_:" . $homepath . "\\" . $script);
        }
        else
        {
            if( $primary == "1" ) 
            {
                $script = "" . ".gamecp-cmdcontrol" . $time . ".sh";
            }
            else
            {
                $script = "" . "gamecp-cmdcontrol" . $fname . $time . ".sh";
            }

            if( $thesubdir ) 
            {
                $thesubdir = rtrim($thesubdir, "/");
            }

            $command = str_replace("\r", "", $command);
            if( $fname == "root" ) 
            {
                $homepath = "/root";
            }
            else
            {
                $homepath = "" . "/home/" . $fname;
            }

            $Backend->QueryResponse($sid, $winport, "" . "writefile:_:" . $homepath . "/" . $thesubdir . "/" . $script . ":_:" . $command, $fname);
            if( $primary == "1" ) 
            {
                $reply = $Backend->QueryResponse($sid, $winport, "" . "command:_:cd " . $homepath . "/" . $thesubdir . " ; bash ./" . $script . " ; rm -f " . $script);
            }
            else
            {
                $reply = $Backend->QueryResponse($sid, $winport, "" . "command:_:cd " . $homepath . "/" . $thesubdir . " ; bash ./" . $script . " ; rm -f " . $script, $fname);
            }

        }

    }

    public function GameCP($cmdid)
    {
        global $GameCP;
        global $safesql;
        $GameCP->loadIncludes("panel");
        $Panel = new Panel();
        switch( $cmdid ) 
        {
            case "gcpupdate":
                $Panel->Upgrade(true);
                break;
            case "gcpbackup":
                $Panel->Backup(true);
                break;
            case "gcpoptimize":
                $Panel->Optimize();
        }
    }

    public function UserGame($cmdid)
    {
        global $GameCP;
        global $safesql;
        global $Event;
        if( !$cmdid ) 
        {
            return false;
        }

        $cmdInfoQ = sql_query($safesql->query("SELECT * FROM userschedule WHERE id = '%i' LIMIT 1;", array( $GameCP->whitelist($cmdid, "int") ))) or exit( mysql_error() );
        $cmdInfo = mysql_fetch_array($cmdInfoQ);
        if( !$cmdInfo["cmd"] ) 
        {
            return false;
        }

        if( $cmdInfo["cmd"] == "rcon" ) 
        {
            $GameCP->loadIncludes("game");
            $Game = new Game();
            $ugInfo = $Game->GetService($cmdInfo["ugid"]);
            $GameCP->loadIncludes("rcon");
            $Rcon = new Rcon();
            $Rcon->Send($ugInfo["ip"], $ugInfo["port"], $ugInfo["protocol"], $cmdInfo["settings"], "", $ugInfo["rconpass"]);
        }
        else
        {
            if( $cmdInfo["cmd"] == "backup" ) 
            {
                $GameCP->loadIncludes("game");
                $Game = new Game();
                $Game->ArchiveService($cmdInfo["ugid"]);
                unset($_SESSION["gamecp"]["backup"]);
            }
            else
            {
                if( $cmdInfo["cmd"] == "update" ) 
                {
                    $GameCP->loadIncludes("game");
                    $Game = new Game();
                    $Game->Update($cmdInfo["ugid"]);
                }
                else
                {
                    $GameCP->loadIncludes("control");
                    $Control = new Control();
                    $Control->Usergame($cmdInfo["ugid"], $cmdInfo["cmd"]);
                }

            }

        }

    }

    public function Game($cmdid)
    {
        global $GameCP;
        global $safesql;
        if( !$cmdid ) 
        {
            return false;
        }

        $GameCP->loadIncludes("control");
        $Control = new Control();
        $cmdInfoQ = sql_query($safesql->query("SELECT games, servers, mode FROM schedule WHERE id = '%i' LIMIT 1;", array( $GameCP->whitelist($cmdid, "int") ))) or exit( mysql_error() );
        $cmdInfo = mysql_fetch_array($cmdInfoQ);
        $machines = unserialize($cmdInfo["servers"]);
        $games = unserialize($cmdInfo["games"]);
        foreach( $machines as $mach ) 
        {
            foreach( $games as $gme ) 
            {
                if( $cmdInfo["mode"] == "restart" || $cmdInfo["mode"] == "stop" ) 
                {
                    $restart = "AND UG.active='1'";
                }
                else
                {
                    $restart = "";
                }

                if( $gme != "all" ) 
                {
                    $gid = "" . " AND UG.gid = '" . $gme . "'";
                }

                if( $mach != "all" ) 
                {
                    $mac = "" . " AND I.sid = '" . $mach . "'";
                }

                $userGameQ = sql_query($safesql->query("" . "SELECT UG.id FROM usergames UG, iptable I WHERE I.ip = UG.ip " . $mac . " " . $gid . " " . $restart, array(  ))) or exit( mysql_error() );
                while( $userGame = mysql_fetch_array($userGameQ) ) 
                {
                    if( $cmdInfo["mode"] == "update" ) 
                    {
                        $GameCP->loadIncludes("game");
                        $Game = new Game($userGame["id"]);
                        $Game->Update();
                    }
                    else
                    {
                        $Control->Usergame($userGame["id"], $cmdInfo["mode"]);
                    }

                }
            }
        }
    }

    public function Shell($cmdid, $taskid)
    {
        global $GameCP;
        global $safesql;
        if( !$cmdid ) 
        {
            return false;
        }

        $preInfoQ = sql_query($safesql->query("SELECT id, name, cmd, ulevel, os FROM cmdcenter WHERE id = '%i' LIMIT 1;", array( $GameCP->whitelist($cmdid, "int") ))) or exit( mysql_error() );
        $preInfo = mysql_fetch_array($preInfoQ);
        $cmdid = $preInfo[0];
        $cmdname = $preInfo[1];
        $cmd = $preInfo[2];
        $pulevel = $preInfo[3];
        $pos = $preInfo[4];
        if( $pos == "1" ) 
        {
            $pq = " S.os='1'";
        }
        else
        {
            $pq = " S.os !='1'";
        }

        $schedInfoQ = sql_query($safesql->query("SELECT games, servers, users FROM schedule WHERE id = '%i' LIMIT 1;", array( $GameCP->whitelist($taskid, "int") ))) or exit( mysql_error() );
        $schedInfo = mysql_fetch_array($schedInfoQ);
        $games = unserialize($schedInfo["games"]);
        $userlist = unserialize($schedInfo["users"]);
        $serverlist = unserialize($schedInfo["servers"]);
        if( is_array($userlist) && 0 < count($userlist) ) 
        {
            foreach( $userlist as $u => $uid ) 
            {
                if( $uid ) 
                {
                    $result = sql_query($safesql->query("" . "SELECT U.name, U.username, S.sid, UG.ip as 'ugip', UG.port, UG.subdirectory, UG.id as 'ugid' FROM users U, usergames UG, iptable I, servers S WHERE U.id = UG.cid AND U.id = '%i' AND U.userlevel = '0' AND I.ip = UG.ip AND S.sid = I.sid AND " . $pq, array( $GameCP->whitelist($uid, "int") ))) or exit( mysql_error() );
                    $uinfo = mysql_fetch_array($result);
                    $fname = $uinfo[0];
                    $sid = $uinfo[2];
                    if( $fname ) 
                    {
                        $this->Run($fname, $sid, $cmd, "", $pos, $pulevel, "", "");
                    }

                }

            }
        }
        else
        {
            if( is_array($games) && 0 < count($games) ) 
            {
                foreach( $games as $g => $gid ) 
                {
                    if( $gid ) 
                    {
                        $result = sql_query($safesql->query("" . "SELECT U.name, U.username, S.sid, UG.ip as 'ugip', UG.port, UG.subdirectory, UG.id as 'ugid' FROM users U, usergames UG, iptable I, servers S WHERE U.id = UG.cid AND UG.gid = '%i' AND U.userlevel = '0' AND I.ip = UG.ip AND S.sid = I.sid AND " . $pq, array( $GameCP->whitelist($gid, "int") ))) or exit( mysql_error() );
                        while( $row = mysql_fetch_array($result) ) 
                        {
                            $fname = $row[0];
                            $sid = $row["sid"];
                            $fip = $row["ugip"];
                            $fport = $row["port"];
                            $ugid = $row["ugid"];
                            $subdirectory = $row["subdirectory"];
                            if( $subdirectory == "yes" ) 
                            {
                                if( ipsubdir == "true" ) 
                                {
                                    $thesubdir = $fip . "-" . $fport;
                                }
                                else
                                {
                                    $thesubdir = "service" . $ugid;
                                }

                            }

                            $runcmd = $cmd;
                            if( $fname ) 
                            {
                                $this->Run($fname, $sid, $runcmd, "", $pos, $pulevel, $thesubdir, $ugid);
                            }

                        }
                    }

                }
            }
            else
            {
                if( is_array($serverlist) && 0 < count($serverlist) ) 
                {
                    foreach( $serverlist as $g => $gid ) 
                    {
                        if( $gid ) 
                        {
                            $result = sql_query($safesql->query("" . "SELECT U.name, U.username, S.sid, UG.ip as 'ugip', UG.port, UG.subdirectory, UG.id as 'ugid' FROM users U, usergames UG, iptable I, servers S WHERE U.id = UG.cid AND S.sid = '%s' AND U.userlevel = '0' AND I.ip = UG.ip AND S.sid = I.sid AND " . $pq, array( $GameCP->whitelist($gid, "clean") ))) or exit( mysql_error() );
                            while( $row = mysql_fetch_array($result) ) 
                            {
                                $fname = $row[0];
                                $sid = $row["sid"];
                                $fip = $row["ugip"];
                                $fport = $row["port"];
                                $ugid = $row["ugid"];
                                $subdirectory = $row["subdirectory"];
                                if( $subdirectory == "yes" ) 
                                {
                                    if( ipsubdir == "true" ) 
                                    {
                                        $thesubdir = $fip . "-" . $fport;
                                    }
                                    else
                                    {
                                        $thesubdir = "service" . $ugid;
                                    }

                                }

                                $runcmd = $cmd;
                                if( $fname ) 
                                {
                                    $this->Run($fname, $sid, $runcmd, "", $pos, $pulevel, $thesubdir, $ugid);
                                }

                            }
                        }

                    }
                }

            }

        }

    }

}


