<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class IP{

	function UpdateIPUse($sid){
		global $GameCP, $safesql;

		$ipt=sql_query($safesql->query("SELECT id FROM iptable WHERE sid='%s' AND assigned='0';", array($sid))) or die(mysql_error());
		sql_query($safesql->query("UPDATE servers SET ipuse='%i' WHERE sid='%s';", array(mysql_num_rows($ipt), $sid))) or die(mysql_error());
	}

	function ListAll($sid, $mode){
		global $GameCP, $safesql;
		if($mode == "sid"){ $query = "WHERE sid = '$sid'"; } else if($mode == "active"){ $query = "WHERE quota != '0'"; } else { $query = ""; }

		$serverNameQ = sql_query("SELECT ip, name, sid FROM servers $query ORDER BY quota - used  DESC") or die(mysql_error());
		while ($serverName = mysql_fetch_array($serverNameQ)){

		$ipResultArray[]=array('ip'=>$serverName['ip'],'value'=>$serverName['name']);
			$nsid = $serverName['sid'];
			$serverIPQ = sql_query($safesql->query("SELECT ip FROM iptable WHERE assigned = 0 AND sid = '%s'", array($sid))) or die(mysql_error());
			while ($serverIP = mysql_fetch_array($serverIPQ)){
				$ipResultArray[]=array('ip'=>$serverIP['ip'], 'value'=>$serverIP['ip']);
			}
			$ipResultArray[]=array('ip'=>'','value'=> '-----------------------');
		}

		return $ipResultArray;
	}

	function GetVoice($type, $slots){
		global $GameCP, $safesql;
		if($type == "ts2"){
			$typeQ="ts2='1'";
		} elseif($type == "ts3"){
			$typeQ="ts3host='1'";
		} else $typeQ="vent='1'";

		 $sql_bestServer = $safesql->query("SELECT quota-used as 'available', slotquota-slotused as 'slotsavail', sid FROM `servers`
											WHERE                                            
											 $typeQ
											 AND (slotquota-slotused >= '%i' OR slotquota = '0')
											 AND quota-used >= '1' AND active='1' ORDER BY available DESC LIMIT 1;", array($GameCP->whitelist($slots, "int")));

		$bestServer = sql_query($sql_bestServer);
		if (mysql_num_rows($bestServer) == 1)
		{
			$results = mysql_fetch_array($bestServer);
			$sid = $results["sid"];
			return $sid;
		}
	}

	function GetIP($gmid=FALSE, $slots=FALSE, $location=FALSE) {
		global $GameCP, $Event, $safesql;
		

			$machines=array();
			$iplist=array();
			$game_machines=array();
			$reseller_machines=array();
			$gquery="";
			$ip='';

			$GameCP->loadIncludes("game");
			$Game=new Game();
			$Game->UpdateUsage();

			$location=$GameCP->whitelist($location, "clean");
	 
			if($location && $location != "Auto Location" && strtolower($location) != "any"){
					$location=$GameCP->whitelist($location, "clean");
					$localQ=" AND location ='$location'";
			} else $localQ="";
	 
			/* games have their own list of allowed ip addresses */
			$installed='';
			if($gmid){
				$gameInfoQ = sql_query($safesql->query("SELECT installedon FROM game WHERE id='%i'", array($GameCP->whitelist($gmid, "int")))) or die(mysql_error()); 
				$gameInfo=mysql_fetch_array($gameInfoQ);
				$d=unserialize($gameInfo['installedon']);
				$installed=array();
				if(is_array($d) && count($d) > 0 ){
					foreach($d as $a => $b){
						if(trim($b)) $installed[]=$b;
					}
				}
				if(is_array($installed) && count($installed) > 0){
					$machineInfoQ = sql_query("SELECT distinct(sid) FROM iptable WHERE ip IN ('" . implode("','", $installed) . "');") or die(mysql_error()); 
					while($machineInfo=mysql_fetch_array($machineInfoQ)) $game_machines[]=$machineInfo['sid'];
				} else $installed=array();
			}

			$machines=$game_machines;
			$iplist=$installed;
			/* if an ip list exist make sure the machine we pick a machine that belings to it */
			$gquery="";

			if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "4"){ 
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$userInfo=$Panel->GetUser($_SESSION['gamecp']['userinfo']['id']);
				$servers=unserialize($userInfo['servers']);

				if(is_array($machines) && count($machines) > 0){
					foreach($machines as $m => $i){
						if(!in_array($i, $servers)) unset($machines[$m]);
					}
				} else $machines=$servers;

			}

			if(is_array($machines) && count($machines) > 0) $gquery.="AND sid IN ('" . implode("','", $machines) . "')";

	 

			/* 
					select a machine that has atleast 1 game slot available,
					with a total player slots available greater or equal to what we need
					limit to 1 so we only receive the best possible server
					check make sure the server is in a list of sid's by ip if defined
			*/

			$sval="1";
			$voiceip=false;
			switch($gmid){
				case "1000":
					$service="ts2";
					$voiceip=true;
				break;
				case "1002":
					$service="ts3host";
					$voiceip=true;
				break;
				case "1001":
					$service="vent";
					$voiceip=true;
				break;
				case "1003":
					$service="mohawk";
				break;
				case "1004":
					$service="mumble";
				break;
				default: 
					$service="gamehost";
					$sval="yes";
				break;
			}

			if($voiceip == true){
				$quotacheck=" AND (slotquota-slotused >= '$slots' OR slotquota = '0') AND quota-used >= '1' ";
				$quotasort="quota-used as 'available', slotquota-slotused as 'slotsavail',";
				$quotasortq='available';
			} else {
				$quotacheck=" AND (slotquota-slotused >= '$slots' OR slotquota = '0') AND quota-used >= '1' ";
				$quotasort="quota-used as 'available', slotquota-slotused as 'slotsavail',";
				$quotasortq='available';
			}

			$sql_bestServer = "SELECT $quotasort sid FROM `servers`
									WHERE                                            
									$service = '$sval'
									$quotacheck
									AND active='1'
									AND ipuse > '0'
									$gquery
									$localQ
	 
									ORDER BY $quotasortq DESC LIMIT 1;";
			if(debugging == "1") echo "<div class='debuggingwindow'><b>Automatic IP Scan: get_ip_auto $gmid $slots $location<br></b>".$sql_bestServer."";
	 
			$Event->EventLogAdd('', "- Automatic IP Scan: get_ip_auto $gmid $slots $location ".urlencode($sql_bestServer));

		$bestServer = sql_query($sql_bestServer);
		if (mysql_num_rows($bestServer) == 1){
			$results = mysql_fetch_array($bestServer);
			$sid = $results["sid"];
			
			if(debugging == "1") echo "<br><b>Automatic IP Scan SID:</b> $sid<br><br>";
 
			if(is_array($iplist) && count($iplist) > 0 && $iplist[0] != ""){
				$ipquery="AND ip IN ('" . implode("','", $iplist) . "')";
			} else $ipquery="";
	 
			$usedips = array();
			$usedipscount = array();

			if(debugging == "1") echo "SELECT ip FROM `iptable` WHERE sid='$sid' AND assigned='0' $ipquery;";
			$ipq="SELECT ip FROM `iptable` WHERE sid='$sid' AND assigned='0' $ipquery;";
			$Event->EventLogAdd('', "- Automatic IP Scan Step 2:".urlencode($ipq));
			$query = sql_query($ipq);

			if($voiceip){
				$tbl="uservoice";
			} else $tbl="usergames";

			while($row = mysql_fetch_array($query)){
				$ipq = $row[0];
				$query2 = sql_query("SELECT ip FROM `$tbl` WHERE `ip`='$ipq'") or die(mysql_error());
				$usedipscount[] = mysql_num_rows($query2);
				$usedips[] = $ipq;
			}

			if(!empty($usedipscount)){
				$min = min($usedipscount);

				$x = 0;
				while($x < count($usedipscount)){
					if($usedipscount[$x] == $min){
						$ip = $usedips[$x];
						break;
					}
					$x++;
				}
			}
			if(debugging == "1") echo "</div>";

		}

		return preg_replace('/[\r\n\t]+/', '', $ip);    
	}

	function GetLocation($location_name = "any") {
		// This method gets a random IP based on the location name.
		global $GameCP, $safesql;
		// Determine if any was selected
		if ($location_name == "Any" || $location_name == "any" ) {
			return $this->GetIP();
		}
		
		$location_name=$GameCP->whitelist($location_name, "clean");
		
		$sql_auto_not_used = "SELECT S.id, S.sid, S.name, I.ip FROM `servers` S, `iptable` I 
							WHERE S.location = '$location_name'
							AND S.quota > S.used 
							AND I.assigned = '0' 
							AND I.sid = S.sid 
							AND S.gamehost = 'yes'
							AND S.active='1'
							ORDER BY rand() 
							LIMIT 1";
							
		$sql_auto_inc_used = "SELECT S.id, S.sid, S.name, I.ip FROM `servers` S, `iptable` I
							WHERE S.location = '$location_name'
							AND I.sid = S.sid 
							AND S.gamehost = 'yes'
							AND S.active='1'
							ORDER BY rand() 
							LIMIT 1";
							
		$results_not_used = sql_query($sql_auto_not_used);
		$results_used = sql_query($sql_auto_inc_used);

		if (mysql_num_rows($results_not_used) == 1) {
			$results = mysql_fetch_array($results_not_used);
			$ip = $results["ip"];
		} else if (mysql_num_rows($results_used) == 1) {
			$results = mysql_fetch_array($results_used);
			$ip = $results["ip"];
		} else {
			// Get an AUTO IP Address
			$ip = $this->GetIP(@$_REQUEST['game_id']);
		}

		return $ip;	
	}

	function GetServer($sid) {
		// This method gets a random IP based on the sid
		global $GameCP, $safesql;
		
		// Determine if any was selected
		if ($sid == "Any" OR $sid == "any" ) {
			return $this->GetIP();
		}
		
		$sid=$GameCP->whitelist($sid, "clean");
	
		$sql_auto_not_used = "SELECT S.id, S.sid, S.name, I.ip FROM `servers` S, `iptable` I 
							WHERE S.sid = '$sid'
							AND S.quota > S.used 
							AND I.assigned = '0' 
							AND I.sid = S.sid 
							AND S.active='1'
							ORDER BY rand() 
							LIMIT 1";
							
		$sql_auto_inc_used = "SELECT S.id, S.sid, S.name, I.ip FROM `servers` S, `iptable` I
							WHERE S.sid = '$sid'
							AND I.sid = S.sid 
							AND S.active='1'
							ORDER BY rand() 
							LIMIT 1";
							
		$results_not_used = $GameCP->query($sql_auto_not_used);
		$results_used = $GameCP->query($sql_auto_inc_used);

		if (mysql_num_rows($results_not_used) == 1) {
			$results = mysql_fetch_array($results_not_used);
			$ip = $results["ip"];
			
		} else if (mysql_num_rows($results_used) == 1) {
			$results = mysql_fetch_array($results_used);
			$ip = $results["ip"];
			
		} else {
			// Get an AUTO IP Address
			$ip = $this->GetIP();
		}

		return $ip;	
	}

}
?>