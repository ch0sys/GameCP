<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Rcon{

	function ChangeMap($items){
		$items['action']="map ";
		return $this->SendV2($items);
	}

	function SendV2($items){
		global $GameCP;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$gameInfo = $Panel->GetUserGame($items['item_id']);
		$mainGameInfo = $Panel->GetGame($gameInfo['gid']);

		return $this->Send ($gameInfo['ip'], $gameInfo['port'], $mainGameInfo['protocol'], $items['action'], $items['value'], $gameInfo['rconpass']);

	}

	function Send ($ip, $port, $packet, $rconcmd, $rconvalue, $rconpass) { // halflife quake3 quake2 gamespy bf1942
		global $GameCP;

		if(!$rconcmd || !$rconpass){
			echo "No password or command";
			return false;
		}

		run_hook("run_rcon");

		if (!$packet) {
			$packet1 = chr(255) . chr(255) . chr(255) . chr(255) . "rcon" . chr(0). "\"$rconpass\" $rconcmd";
			$delim = "\n"; 
			$resp  = "����print\n";
		}

		if ($packet =="samp") {
			require_once("SampRconAPI.php");

			$rcon = new SampRconAPI($ip, $port, $rconpass);
			$res=$rcon->Call($rconcmd .' ' . $rconvalue);
			if(is_array($res) && count($res) > 0){
				foreach ($res as $r)echo $r."<br>";
			}
			return '';
	
		}
		if ($packet == "minecraft") {
			require_once(path."/includes/core/classes/query/minecraft/MinecraftRcon.class.php");
			$Rcon = new MinecraftRcon();
			$Rcon->Connect( $ip, $port+10, $rconpass, '10' );
			$Data = $Rcon->Command($rconcmd .' ' . $rconvalue);
			echo nl2br($Data['String']);
			$Rcon->Disconnect( );
			return '';
		}

		if ($packet =="bfbc2") {
			require_once(path.'/includes/core/classes/games/bc2rcon.inc.php'); 
			if($rconcmd == "kick") $rconcmd="admin.kickPlayer";
			if($rconcmd == "ban") $rconcmd="banList.add";
			if($rconcmd == "map") $rconcmd="admin.runNextLevel";

			$BFBC2=new BFBC2();
			$BFBC2->Connect($ip, $port, $rconpass);
			$res=$BFBC2->Command($rconcmd .' ' . $rconvalue);
			//print_r($res);
			if($res[0] == "UnknownCommand"){
				echo "Unknown Command";
			} else {
				foreach($res as $r => $s) if($s != "OK") echo $GameCP->whitelist($s)."<br>";	
			}

			$BFBC2->Disconnect();
			
			if($BFBC2->stopError) echo $GameCP->whitelist($BFBC2->stopError);
			return true;
		}


		if($packet == "csgo") $packet="cssource";
		if ($packet =="cssource") {
			if($rconcmd == "map") $rconcmd="changelevel";
			require_once(path.'/includes/core/classes/games/csrcon.inc.php'); 
			$r = new CSRCon($ip, $port, $rconpass);
			$r->Auth();
			$result=$r->rconCommand($rconcmd .' ' . $rconvalue);
			if(isset($result['2']['Response'])){
				if($result['2']['Response'] == "0"){
					echo "Completed";
				} else echo $result['2']['Response'];
				$result['2']['Response'];
			} else echo "Completed";
			return true;
		}

		if($packet == "bf2"){
			$port=$port-9856;
			$socket = fsockopen($ip, $port);
			if (!$socket) {
				echo "Failed to connect to server."; 
			  return false;
			} else $bf_serverstr = $this->GetWelcomeResponse($socket);


			$prefix = '### Digest seed: ';
			$challpos=strpos($bf_serverstr,$prefix);
			if ($challpos != -1) {
			   $len=strlen($prefix);
			   $seed=substr($bf_serverstr,$challpos+$len,strlen($bf_serverstr));
			   $seed=trim($seed);
			}

			# Concats a seed string with the password and returns a ASCII-hex MD5 digest.
			$encrypted = md5($seed.$rconpass);
			$cmd = "login ".$encrypted;
			$result = $this->Invoke($socket,$cmd);
			if (!preg_match("/Authentication success/", $result))  {
				   echo "Invalid Password.";
				   return false;
			}

			$cmd=$rconcmd .' ' . $rconvalue;
			$result= $this->Invoke($socket,$cmd);

			//echo "Rcon command executed.<br>";
			if($result) echo $GameCP->whitelist($result);

			fclose($socket);

			return true;
		}


		if ($packet =="halflife") {
			$fp = fsockopen("udp://$ip", $port, $errno, $errstr,2); 
			if (!$fp) { 
				echo "Failed to connect to server."; 
				return false;
			} else {
				fwrite($fp,"����challenge rcon"."\x00"); 
				$chal = fgets($fp,50); 
				$chal = substr($chal, 19); 
				$chal = trim ($chal);	
				if(!$chal){
					echo "Failed to receive challenge.";
					return false;
				}
				$rconvalue=stripslashes($rconvalue);
				$packet1 = chr(255) . chr(255) . chr(255) . chr(255) . "rcon ". $chal. " \"$rconpass\" $rconcmd $rconvalue". chr(0); 
				$delim = "\n"; 
				$resp   = "����challenge rcon "; 
			}
		}

		if ($packet =="cod"||$packet =="cod4") { 
			$packet1 = "\xff\xff\xff\xff" . "rcon ". "$rconpass $rconcmd $rconvalue"; 
			$delim = "\n"; 
			$resp  = "����print\n";
		}

		if ($packet =="quake3" || $packet =="quake2") { 
			$packet1 = chr(255) . chr(255) . chr(255) . chr(255) . "rcon". "\"$rconpass\" $rconcmd $rconvalue". chr(0); 
			$delim = "\n"; 
			$resp  = "����print\n";
		}

		if ($packet =="quake4") { 
			$packet1 = "\xFF\xFFgetInfo\x00\x00\x00\x00\x00net_serverRemoteConsolePassword". "\"$rconpass\" $rconcmd $rconvalue". chr(0); 
			$delim = "\n"; 
			$resp  = "����print\n";
		}


		if ($packet =="gamespy") {
			$packet1 = "\\status\\";
			$delim = null; 
			$resp   = "";
		}

		if ($packet =="bf1942") { 
			$packet1 = "\\info\\";  
			$delim = null;
			$resp = "";
		}

		$fp = fsockopen("udp://$ip", $port, $errno, $errstr, 2); 

		if (!$fp) { 
			echo "Failed to connect to server."; 
			return false;
		} else {
			fwrite($fp,$packet1); 
			stream_set_timeout($fp, 1);
			$output = fread($fp, 1);

			if (! empty ($output)) {
			  do {
				$status_pre  = socket_get_status($fp);
				$output      = $output . fread($fp, 1);
				$status_post = socket_get_status($fp);
			  } while ($status_pre['unread_bytes'] != $status_post['unread_bytes']);
			};

			fclose ($fp);

		if ($packet =="halflife") {
			$output = explode("l", $output);
			$output = $output[1];
		} else if ($packet =="quake3") {
			$output = explode("print", $output);
			$output = $output[1];
		}
			if($output && $output != $resp) echo $GameCP->whitelist($output, 'web');
			return true;
		}
	}

	function Invoke ($sock,$cmd) {
		   // print "<br>Command sent : $cmd<br>";
		   $sock_result = fputs($sock,"\x02".$cmd."\n");
		   $result=$this->GetResponse($sock);
		   return $result;
	}

	function GetWelcomeResponse ($sock) {
	  $bfstr='';
	  $data='';
	  while(1) {
		   $data = fgets($sock,1024);
		   $bfstr.=$data;
		   if (preg_match("/\\n\\n/", $bfstr)) {
				   break;
		   }
	  }
		   return $bfstr;
	}

	function GetResponse($sock) {
	  $bfstr='';
	  $data='';
	  $done=0;
	  while ($done == 0) {
	   $data = fgets($sock, 2);
	   if (preg_match("/\\x04/", $data)){
			   $done=1;
			   break;
	   }
	   $bfstr.=$data;
	  }
		return $bfstr;
	}

}

?>