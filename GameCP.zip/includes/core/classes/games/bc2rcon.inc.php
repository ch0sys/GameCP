<?php
// found on pastebin - had no license = legal code
/**
 * @access private 
 * @internal
 */

class BFBC2{
    var $stopError = "";

	function BFBC2(){
		$this->seqNum = 0;
		$this->stopError = false;
	}

	function unpack($data){
		$decode = unpack('I', $data);
		return $decode[1];
	}

	//Send Request to Server
	function Request($sequence, $words){
		$words = explode(' ', $words);
		$header = pack('I', $sequence & 0x3fffffff);
		$numWords = pack('I', count($words));

		//Encode Words
		$size = 0;
		$encodedWords = '';
		foreach($words as $word){
			$encodedWords .= pack('I', strlen($word));
			$encodedWords .= $word;
			$encodedWords .= "\x00";
			$size += strlen($word) + 5;
		}
		$words = array($size, $encodedWords);

		list($wordsSize, $eWords) = $words;
		$eSize = pack('I', ($wordsSize + 12));
		return $header . $eSize . $numWords . $eWords;
	}

	//Response from Server
	function Response($data){
		$header = unpack('I', $data);
		list($fromServer, $isResponse, $sequence) = array($header & 0x80000000, $header & 0x40000000, $header & 0x3fffffff);
		$wordSize = $this->unpack(substr($data, 4, 4)) - 12;

		//Decode Words
		$data2 = substr($data, 12);
		$numWords = $this->unpack($data2);
		$offset = 0;
		while($offset < $wordSize){
			$wordLen = $this->unpack(substr($data2, $offset, 4));
			$word = substr($data2, $offset+4, $wordLen);
			$words[] = $word;
			$offset += $wordLen + 5;
		}

		return array($fromServer, $isResponse, $sequence, $words);
	}

	//Connect to Server
	function Connect($host, $port, $pw=''){
		$this->host = $host;
		$this->socket = fsockopen('tcp://'.$host, $port, $errno, $errstr, 1);
		if($this->socket != false){
			socket_set_timeout($this->socket, 0, 500000);
			//Connect Admin
			if($pw){

				$response = $this->Command('login.plainText '.$pw);

				if($response[0] == 'InvalidPassword'){$this->stopError = 'Invalid Password Specified';}
				elseif($response[0] == 'OK'){}
			}
		}else{
			$this->stopError = 'Unable to Connect to Server';
		}
	}

	//Disconnect from Server
	function Disconnect(){
		$this->Command('quit');
		@fclose($this->socket);
	}

	// Send Command
	function Command($cmd){
		if($this->stopError){return false;}

		fwrite($this->socket, $this->Request($this->seqNum, $cmd));
		$this->seqNum++;
		//list($fromServer, $isResponse, $seq, $words) = $this->Response(fread($this->socket, 4096));
		$response = $this->Response(fread($this->socket, 4096));

		if($response[3] == 'LogInRequired'){return 'RCON Password Required';}
		else{return $response[3];}
	}

}
/*
$BFBC2=new BFBC2();
$BFBC2->Connect($host, $port, $pw='');
$BFBC2->Command($cmd);
*/

?>