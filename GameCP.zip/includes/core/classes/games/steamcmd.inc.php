<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class SteamCMD{
	var $backend;
	var $login;
	var $game;
	var $steamid;
	var $steammod;
	var $run_file="steamcmd";
	var $url_windows=$_SERVER['DOCUMENT_ROOT'] .'/assets/steamcmd.zip';
	var $url_linux= $_SERVER['DOCUMENT_ROOT'] .'/assets/steamcmd_linux.tar.gz';
	var $binary_windows="steamcmd.exe";
	var $binary_linux="steamcmd.sh";

	function __construct($steamid=false, $steammod=false){
		global $GameCP;
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$this->backend=new Backend();
		$GameCP->loadIncludes("game");
		$this->game=new Game();

		if($steammod) $this->steammod=$steammod;
		if($steamid){
			$this->steamid=$steamid;
			$this->run_file=$steamid."-steamcmd";
		}

		if(steam_user != '' && steam_pass != ''){
			$this->login=steam_user.' '.steam_pass;
		} else $this->login='anonymous';
	}

	function Exec($name, $os, $sid, $winport, $command, $detach, $screenname=false, $logfile=false){
		return $this->game->Exec($name, $os, $sid, $winport, $this->run_file.'.sh', $this->run_file.'.bat', $command, $detach, $screenname, $logfile);
	}

	function Install($os, $sid, $winport){
		$command="";
		if($os =="1"){
			$this->backend->QueryResponse($sid, $winport, "mkdir:_:\$MAINDIR\\steamcmd");
			$command.="cd /d \$MAINDIRsteamcmd\r\n";
			$command.="\$MAINDIRbin\wget.exe ". $this->url_windows."\r\n";
			$command.="\$MAINDIRbin\gcpextract.exe steamcmd.zip .\r\n";
			$command.="del /f steamcmd.zip\r\n";
			$command.="\$MAINDIR\\steamcmd\\".$this->binary_windows." +quit\r\n";
			$log="steamcmd\\steamcmd.log";
		} else {
			$this->backend->QueryResponse($sid, $winport, "mkdir:_:\$MAINDIR/steamcmd");
			$command.="cd  \$MAINDIR/steamcmd\r\n";
			$command.="wget ". $this->url_linux."\r\n";
			$command.="tar zxvf steamcmd_linux.tar.gz\r\n";
			$command.="rm -f steamcmd_linux.tar.gz\r\n";
			$command.="\$MAINDIR/steamcmd/".$this->binary_linux." +quit\r\n";
			$log="steamcmd/steamcmd.log";
		}

		return $this->Exec('', $os, $sid, $winport, $command, true, "steamcmd", $log);
	}

	function Update($os, $sid, $winport){
		if($os =="1"){
			$command="\$MAINDIR\\steamcmd\\".$this->binary_windows." +quit\r\n";
			$log="steamcmd\\steamcmd.log";
		} else {
			$command="\$MAINDIR/steamcmd/".$this->binary_linux." +quit";
			$log="steamcmd/steamcmd.log";
		}

		return $this->Exec('', $os, $sid, $winport, $command, true, "steamcmd", $log);
	}


	function CheckSteamCMD($os, $sid, $winport){
		if($os =="1"){
			if($this->game->CheckInstallExists($sid, "\$MAINDIR\\steamcmd\\".$this->binary_windows) != true) return false;
		} else if(!trim($this->backend->QueryResponse($sid, $winport, "isfile:_:\$MAINDIR/steamcmd/".$this->binary_linux))) return false;
		return true;
	}

	function CheckBackgroundTask($rows, $checktype=false){
		global $GameCP;
		$status=array();
		if(!is_array($rows) || (is_array($rows) && count($rows) == 0)) return $status;
		foreach($rows as $rid => $r){
			$status[$r['id']]=array();

			if($r['os'] == "1"){
				$log="\$MAINDIRsteamcmd\\steamcmd.log";
				$status[$r['id']]['log']=$this->backend->QueryResponse($r['sid'], '', "readfile:_:$log");

				if(!$this->game->CheckInstallExists($r['sid'], "\$MAINDIR".$this->run_file.'.bat', true)){
					$this->backend->Query($r['sid'], '', "deletefile:_:$log");
					$status[$r['id']]['status']='completed';
				} else {
					$status[$r['id']]['status']='working';
				}
			} else {
				$GameCP->loadIncludes("linux");
				$Linux=new Linux();
				$updateStatus=$Linux->Watch($r['sid'], "steamcmd", false, false, true, false);

				if(!$updateStatus[0]){
					$status[$r['id']]['status']='completed';
					$this->backend->Query($r['sid'], '', "command:_:rm -f screenwatchupdate.steamcmd.log .screenrc.watchupdate.steamcmd");
				} else {
					$status[$r['id']]['status']='working';
					$status[$r['id']]['log']=$updateStatus[1];
				}
			}
		}
		return $status;
	}

	function RunMachine($id=false, $mode=''){
		if($id)$id="AND id='$id'";

		$resultsQ  =  sql_query("SELECT * FROM servers WHERE active='1' $id;") or die(mysql_error());
		$rows=array();
		while( $row   =  mysql_fetch_array($resultsQ)){
			$rows[]=$row;
		}

		switch($mode){
			case 'auth':
				return $this->ManageSteamAuth($rows);
			break;

			case 'check':
				return $this->CheckBackgroundTask($rows);
			break;

			default:
				return $this->ManageSteamCMD($rows);
			break;
		}
	}

	function ManageSteamCMD($rows){
		$status=array();
		if(!is_array($rows) || (is_array($rows) && count($rows) == 0)) return $status;
		foreach($rows as $rid => $r){
			if($this->CheckSteamCMD($r['os'], $r['sid'], $r['winport'])){
				if($this->Update($r['os'], $r['sid'], $r['winport'])){
					$status[$r['id']]=array("id" => $r['id'], "result" => "updating");
				} else $status[$r['id']]=array("id" => $r['id'], "result" => "failed to update");
			} else {
				if($this->Install($r['os'], $r['sid'], $r['winport'])){
					$status[$r['id']]=array("id" => $r['id'], "result" => "installing");
				} else $status[$r['id']]=array("id" => $r['id'], "result" => "failed to install");
			}
		}
		return $status;
	}

	function GetCommand($os, $homepath, $script){
		if($os == "1"){
			$exec=$this->binary_windows;
		} else $exec=$this->binary_linux;

		$command= "@ShutdownOnFailedCommand 1\r\n";
		$command.= "@NoPromptForPassword 1\r\n";
		$command.= "login ".$this->login."\r\n";
		$command.= "force_install_dir ".$homepath."\r\n";
		$command.= "app_update ".$this->steamid." validate\r\n";
		if($this->steammod) $command.="app_set_config ".$this->steamid." mod ".$this->steammod;
		$command.= "quit\r\n";
		
		if($os == "1"){
			$exec= "\$MAINDIRsteamcmd\\".$exec." +runscript " . $homepath.$script ." +quit ";
		} else $exec= "\$MAINDIR/steamcmd/".$exec." +runscript " . $homepath.$script ." +quit ";
		return array($command, $exec);
	}

	function ManageSteamAuth($rows){
		$status=array();
		if(!is_array($rows) || (is_array($rows) && count($rows) == 0)) return $status;
		foreach($rows as $rid => $r){
			if($this->SteamAuth($r['os'], $r['sid'], $r['winport'])){
				$status[$r['id']]=array("id" => $r['id'], "result" => "authed");
			} else $status[$r['id']]=array("id" => $r['id'], "result" => "failed to auth");
		}
		return $status;
	}

	function SteamAuth($os, $sid, $winport){
		if($os =="1"){
			$homepath="\$MAINDIR\\steamcmd\\";
		} else $homepath="\$MAINDIR/steamcmd/";

		$script=$homepath."steamcmd".time().".txt";
		$this->backend->QueryResponse($sid, $winport, "writefile:_:$script:_:".$this->GetCommandAuth());

		if($os =="1"){
			$command=$homepath.$this->binary_windows." +runscript " . $script ." +quit";
		} else $command=$homepath.$this->binary_linux." +runscript " . $script ." +quit";

		$result=$this->Exec('', $os, $sid, $winport, "$command:_:", false);
		return $this->CheckSteamAuth($result);
	}

	function CheckSteamAuth($result){
		if(preg_match("/Logging in user '".steam_user."' to Steam Public...Success./s", $result)){
			return true;
		} else return false;
	}

	function GetCommandAuth(){
		$command= "@ShutdownOnFailedCommand 1\r\n";
		$command.= "@NoPromptForPassword 1\r\n";
		$command.= "login ".$this->login."\r\n";
		if(steam_code) $command.= "set_steam_guard_code ".steam_code."\r\n";
		$command.= "quit\r\n";		
		return $command;
	}	
}

?>