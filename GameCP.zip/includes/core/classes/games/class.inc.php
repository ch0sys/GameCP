<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Game{
	var $ugstore;
	var $ugstore2;

	function ChangeServiceUser($ugid, $cid){
		global $safesql, $GameCP, $Event;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$GameCP->loadIncludes("control");
		$Control=new Control();

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$GameCP->loadIncludes("user");
		$User=new User();

		$gameDetails=$Panel->GetUserGame($ugid);
		$homefolder=$Panel->GetServiceFolder($ugid, false);
		$serverInfo=$Panel->GetServer('', $gameDetails['ip']);
		$userInfo=$Panel->GetUser($cid);
		$sid=$serverInfo['sid'];
		$os=$serverInfo['os'];

		$fname=$userInfo['name'];
		$fpassword=$userInfo['password'];
		$ubash=$userInfo['bash'];

		$olduser=$gameDetails['username'];
		$olduserInfo=$Panel->GetUser('', $olduser);


		if($homefolder == '') return false;

		$Control->Usergame($ugid, "stop");

		if($os != '1'){

			$User->CheckThenAdd($sid, $fname, $fpassword, $User->GetShell($ubash, false));
			$Backend->QueryResponse($sid, '', "addserver:_:$ugid", $fname);

			$Backend->QueryResponse($sid, '', "command:_:mv /home/$olduser/$homefolder /home/$fname/");
			$Backend->QueryResponse($sid, '', "command:_:chown -R $fname /home/$fname");
			$Backend->QueryResponse($sid, '', "removeserver:_:$ugid", $olduser);


		} else {
			$homefolder=str_replace('/', '\\', $homefolder);

			$Backend->QueryResponse($sid, '', "mkdir:_:\$MAINDIRhome\\$fname\\");
			$Backend->QueryResponse($sid, '', "movedir:_:\$MAINDIRhome\\$olduser\\$homefolder:_:\$MAINDIRhome\\$fname\\$homefolder");

			$Backend->QueryResponse($sid, '', "removeserver:_:gcp-$fname-$ugid");
		}

		$isLastGameQ=sql_query($safesql->query("SELECT UG.id FROM iptable I, usergames UG WHERE UG.ip = I.ip AND I.sid='%s' AND UG.cid='%i'", array($sid, $olduserInfo['id'])));
		$isLastGame=mysql_num_rows($isLastGameQ);

		if($isLastGame == "1") $User->RemoveUserAccount($sid, '', $os, $Backend, $olduser);

		sql_query($safesql->query("UPDATE usergames SET cid='%i' WHERE id = '%i' LIMIT 1", array($GameCP->whitelist($cid, "int"), $GameCP->whitelist($ugid, "int")))) or die(mysql_error()); 
		
		if($os == '1'){
			$Control->Build($ugid, "add");
			$Backend->UpdateFTP($sid);

		}

		$Control->Usergame($ugid, "start");

	}

	function MapList($ugid, $items){
		global $GameCP;

		if(isset($items['search_local'])) $searchuser=$items['search_local'];
		if(isset($items['search_remote'])) $searchshared=$items['search_local'];

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
	
		$gameDetails=$Panel->GetUserGame($ugid);
		$homefolder=$Panel->GetServiceFolder($ugid);
		$serverInfo=$Panel->GetServer('', $gameDetails['ip']);
		$gameInfo=$Panel->GetGame($gameDetails['gid']);


		$mapextension=$GameCP->whitelist(ltrim($gameInfo['mapextension'], "."), "clean");

		$os=$serverInfo['os'];
		$winport=$serverInfo['winport'];
		$sid=$serverInfo['sid'];

		if($os == "1"){
			$sharedmapdir=$gameInfo['winmapdir']; 
			$usermapdir=$gameInfo['winusermapdir']; 
		} else {
			$sharedmapdir=$gameInfo['mapdir'];
			$usermapdir=$gameInfo['usermapdir'];
		}
		$homemapdir=$homefolder.$usermapdir;

		if($sharedmapdir && $usermapdir){
			if($os == "1"){ 
				$homemapdir="\$MAINDIR".str_replace("/", "\\", $homemapdir);
				$usermaplist=$Backend->QueryResponse($sid, $winport, "filelist2:_:$homemapdir");

				$usermaplist = explode("::", $usermaplist);
				foreach($usermaplist as $r => $v){
					if($mapextension != ""){
						if(preg_match("/.$mapextension/i",$v)) $usermaplistA[]=$v;
					} else $usermaplistA[]=$v;
				}

				$GameCP->loadIncludes("ftp");
				$FTP=new FTP();

				$sharedmaplistA=$FTP->ListURL($sharedmapdir);

				/* ftp sharedmapdir says no result, check socket based */
				if(!$sharedmaplistA){
					if(!preg_match("/:/i", $sharedmapdir)){
						$sharedmapdir="/games/".$sharedmapdir;
						$sharedmapdir=str_replace("/", "\\", $sharedmapdir);
						$sharedmapdir="\$MAINDIR".$sharedmapdir;
					}
					$sharedmaplist=$Backend->QueryResponse($sid, $winport, "filelist2:_:$sharedmapdir");
					$sharedmaplist = explode("::", $sharedmaplist);

					foreach($sharedmaplist as $r => $v){
						if($mapextension != ""){
							if(preg_match("/.$mapextension/i",$v)
								|| preg_match("/.tar.gz/i",$v)
								|| preg_match("/.rar/i",$v)
								|| preg_match("/.zip/i",$v)
								|| preg_match("/.tar/i",$v)
								|| preg_match("/.bz2/i",$v)						
							) $sharedmaplistA[]=$v;
						} else $sharedmaplistA[]=$v;
					}
				}
				
				$sharedmaplistA =array_diff($sharedmaplistA, $usermaplistA);
			} else {
				$usermaplist=$Backend->QueryResponse($sid, $winport, "filelist:_:$homemapdir");
				$usermaplistA=explode("\n", $usermaplist);
				if($mapextension != ""){
					$uml=$usermaplistA;
					$usermaplistA="";
					foreach($uml as $r => $v){
						if(preg_match("/.$mapextension/s",$v)) $usermaplistA[]=$v;
					}
				}

				$GameCP->loadIncludes("ftp");
				$FTP=new FTP();
				$sharedmaplistA=$FTP->ListURL($sharedmapdir);

				if(!$sharedmaplistA){
					if(substr($sharedmapdir, 0, 1) != "/") $sharedmapdir = "/usr/local/games/". $sharedmapdir;
					$sharedmaplist=$Backend->QueryResponse($sid, $winport, "filelist:_:$sharedmapdir");
					$sharedmaplist=explode("\n", $sharedmaplist);
					$sharedmaplistA=array();
					foreach($sharedmaplist as $r => $v){
						if($mapextension != ""){
							if(preg_match("/.$mapextension/i",$v)
								|| preg_match("/.tar.gz/i",$v)
								|| preg_match("/.rar/i",$v)
								|| preg_match("/.zip/i",$v)
								|| preg_match("/.tar/i",$v)
								|| preg_match("/.bz2/i",$v)						
							) $sharedmaplistA[]=$v;
						} else $sharedmaplistA[]=$v;
					}
				}
				$sharedmaplistA=array_diff($sharedmaplistA, $usermaplistA);
			}

			// Only build if there are results
			if(count($usermaplistA) > 0){
				if(isset($searchuser) && $searchuser){
					$usermaplist=array();
					// Split the arrays to do searches
					for($i = 0; $i < count($usermaplistA); $i++){
						if (eregi($searchuser, $usermaplistA[$i])) $usermaplist[]=$usermaplistA[$i];
					}
				} else $usermaplist = $usermaplistA; 

				if(isset($searchshared) && $searchshared){
					$sharedmaplist=array();
					// Split the arrays to do searches
					for($i = 0; $i < count($sharedmaplistA); $i++){
						if (eregi($searchshared, $sharedmaplistA[$i])) $sharedmaplist[]=$sharedmaplistA[$i];
					}
				} else $sharedmaplist = $sharedmaplistA; 

				// Assign the maplist to the user array
				$userMapArray[]=$usermaplist;
				$sharedMapArray[]=$sharedmaplist;
			}
		}

		if(is_array($usermaplist)){
			foreach($usermaplist as $i => $s){
				if(trim($s) == "") unset($usermaplist[$i]);
			}
		}
		if(is_array($sharedmaplist)){
			foreach($sharedmaplist as $i => $s){
				if(trim($s) == "") unset($sharedmaplist[$i]);
			}
		}


		return array('remote_list' =>$sharedmaplist, 'local_list'=>$usermaplist);

	}

	function MapControl($ugid, $map=array(), $direction){
		global $GameCP, $hook_vars;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$gameDetails=$Panel->GetUserGame($ugid);
		$homefolder=$Panel->GetServiceFolder($ugid);
		$serverInfo=$Panel->GetServer('', $gameDetails['ip']);
		$gameInfo=$Panel->GetGame($gameDetails['gid']);

		$mapextension=$GameCP->whitelist(ltrim($gameInfo['mapextension'], "."), "clean");

		$os=$serverInfo['os'];
		$winport=$serverInfo['winport'];
		$sid=$serverInfo['sid'];

		$usr=$gameDetails['username'];

		if($os == "1"){
			$sharedmapdir=$gameInfo['winmapdir']; 
			$usermapdir=$gameInfo['winusermapdir']; 
		} else {
			$sharedmapdir=$gameInfo['mapdir'];
			$usermapdir=$gameInfo['usermapdir'];
		}
		$homemapdir=$homefolder.$usermapdir."/";


		$checkScheme=parse_url($sharedmapdir);
		if(isset($checkScheme['scheme']) && ($checkScheme['scheme'] == "ftp" || $checkScheme['scheme'] == "ftps")){
			$downloadurl=$sharedmapdir;
		} else $downloadurl="";

		foreach($map as $newmap) { 	
			if($newmap){
				$newmap=$GameCP->whitelist($newmap, "clean");
				$hook_vars=array("map"=>$newmap, "ugid"=>$ugid, "details"=>$gameDetails, "homemapdir" => $homemapdir, "usermapdir"=>$usermapdir);

				if($direction == 'add'){
					$pathinfo = pathinfo($newmap);
					$ext=$pathinfo['extension'];
					$extractMode=$this->Extract($ext, $os);
					$extract=$extractMode[0];

					if($os != "1" && $os !="3"){
						if(substr($sharedmapdir, -1) != "/")	$sharedmapdir=$sharedmapdir."/";
						$maplocation=$sharedmapdir.$newmap;
						if(substr($homemapdir, -1) != "/")	$homemapdir=$homemapdir."/";

						if($downloadurl) {
							$Backend->QueryResponse($sid, $winport, "command:_:cd $homemapdir; wget $downloadurl/$newmap ; chown $usr:$usr $homemapdir/$newmap ; chmod 644 $homemapdir/$newmap;", $usr);
						} else $Backend->Query($sid, $winport, "copyfile:_:$maplocation:_:$homemapdir", $usr);
						if($extract) $Backend->Query($sid, $winport, "command:_:cd $homemapdir; $extract $maplocation", $usr);
					} else { 
						
						$afile="$mapdir\\$newmap";
						$bfile="\$MAINDIRhome$homemapdir\\$newmap";

						if($downloadurl) {
							$Backend->Query($sid, $winport, "downloadfile:_:$downloadurl/$newmap:_:$bfile");
						} else $Backend->Query($sid, $winport, "copyfile:_:$afile:_:$bfile");
						if($extract) $Backend->Query($sid, $winport, "bin\gcpextract:_:$bfile");
					}

					run_hook("map_install");
				} else {

					if($os == "1"){
						$Backend->Query($sid, $winport, "deletefile:_:\$MAINDIR$homemapdir$newmap");
					} else $Backend->Query($sid, $winport, "deletefile:_:$homemapdir$newmap", $usr);
					run_hook("map_uninstall");
				}
			}
		}
		return true;
	}



	function ConfigExecute($item_id){
		global $GameCP;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$cfg=$Panel->GetUserConfig($item_id);
		return $this->ConfigCreate($cfg['ugid'], $item_id);
	}

	function ConfigRestore($ugid){
		global $GameCP, $hook_vars;
		$this->ConfigCreate($ugid, false, 'clear');

		$hook_vars=$ugid;
		run_hook("config_restore");
		return true;
	}

	function ConfigFetch($item_id){
		global $GameCP;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$cfg=$Panel->GetUserConfig($item_id);
		$path=$Panel->GetServiceFolder($cfg['ugid']);

		$userGameDetails=$Panel->GetUserGame($cfg['ugid']);
		$serverDetails=$Panel->GetServer('', $userGameDetails['ip']);

		if($cfg['edittype'] != "database"){
			$file='';
			$file=$cfg['configdir'];
			$file.=$cfg['config'];

			if($serverDetails['os'] == "1"){
				$file=str_replace("/","\\", $file);
				$return= $Backend->QueryResponse($serverDetails['sid'], $serverDetails['winport'], "readfile:_:\$MAINDIR$file");
			} else $return= $Backend->QueryResponse($serverDetails['sid'], $serverDetails['winport'], "readfile:_:$file");
			if(trim($return)){
				return $return;
			} else return $cfg['contents'];
		} else return $cfg['contents'];

	}


	function ConfigCreateV2($items){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$path=$Panel->GetServiceFolder($items['item_id']);

		sql_query($safesql->query("INSERT INTO userconfigs SET 
			name='%s',
			config='%s',
			contents='%s',
			ugid='%i',
			autoexec='%i',
			hidecfg='%i',
			configdir='%s'", 
			array($GameCP->whitelist($items['title'], "useredit"),
				$GameCP->whitelist($items['file_name'], "useredit"),
				$GameCP->whitelist($items['contents'], "web"),
				$GameCP->whitelist($items['item_id'], "int"),
				$GameCP->whitelist($items['execute_onstart'], "useredit"),
				$GameCP->whitelist($items['hide'], "useredit"),
				$GameCP->whitelist($path.$items['folder'], "web")))) or die(mysql_error());

		
		return mysql_insert_id();

	}

	function ConfigRemove($items){
		global $GameCP, $safesql;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$cfg=$Panel->GetUserConfig($items['item_id']);

		if(isset($items['delete_file']) && $items['delete_file']=="yes"){
			$userGameDetails=$Panel->GetUserGame($cfg['ugid']);
			$serverDetails=$Panel->GetServer('', $userGameDetails['ip']);

			$os=$serverDetails['os'];
			$sid=$serverDetails['sid'];
			$fname=$userGameDetails['username'];

			if($userGameDetails['subdirectory'] == "yes"){ 
				if(ipsubdir == "true"){
					$thesubdir=$userGameDetails['ip']."-".$userGameDetails['port']."/";
				} else $thesubdir="service".$cfg['ugid']."/";
			}


			$GameCP->loadIncludes("backend");
			$Backend=new Backend();
			$fullpath="/home/$fname/$thesubdir".$cfg['configdir']."/".$cfg['config'];
			if($os == "1"){
				$fullpath=str_replace("/", "\\", $fullpath);
				$fullpath=str_replace(":_:", " ", $fullpath);
				$Backend->QueryResponse($sid, $winport, "deletefile:_:\$MAINDIR$fullpath");
			} else $Backend->QueryResponse($sid, $winport, "deletefile:_:$fullpath", $userGameDetails['username']);
		}

		sql_query($safesql->query("DELETE FROM userconfigs WHERE id = '%i' LIMIT 1", array($GameCP->whitelist($items['item_id'], "int")))) or die(mysql_error()); 


		return true;

	}

	function QuickMod($gid, $quickmod){
		global $GameCP, $hook_vars,$safesql;
		sql_query($safesql->query("UPDATE usergames SET gametype='%s' WHERE id = '%i';", array($quickmod,$gid ))) or die(mysql_error());
		$GameCP->loadIncludes("control");
		$Control=new Control();
		$Control->Usergame($gid, "restart");

		$hook_vars=$gid;
		run_hook("quick_mod");
		return true;
	}

	function RunAddon($gmid, $aid, $mode){
		global $GameCP;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$gameInfo=$Panel->GetUserGame($gmid);
		return $this->AddonV2($gameInfo['cid'], $gmid, $aid, $mode);
	}

	function AddonV2($cid, $gmid, $aid, $mode){
		global $GameCP, $smarty, $safesql, $hook_vars;

		$cid=$GameCP->whitelist($cid, "int");
		$gmid=$GameCP->whitelist($gmid, "int");
		$aid=$GameCP->whitelist($aid, "int");

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if(!$cid || !$gmid || !$aid) return false;
		

		$GameCP->loadIncludes("control");
		$Control=new Control();

		$cuserInfo=$Panel->GetUser($cid);
		$fusername=$cuserInfo['username'];

		$addonInfoQ  =  sql_query($safesql->query("SELECT * FROM addons  WHERE id='%i'", array($aid))) or die(mysql_error());
		$addonInfo   =  mysql_fetch_array($addonInfoQ);

		if($mode == "add" && $addonInfo['doinstall'] != "1") return false; 
		if($mode == "update" && $addonInfo['doupdate'] != "1") return false; 
		if($mode == "remove" && $addonInfo['douninstall'] != "1") return false; 
		if($mode == "enable" && $addonInfo['doenable'] != "1") return false; 
		if($mode == "disable" && $addonInfo['dodisable'] != "1") return false; 
		if($mode == "execute" && $addonInfo['doexecute'] != "1") return false; 

		$notes=$addonInfo['notes'];

		$cuserGInfoQ =  sql_query($safesql->query("SELECT * FROM usergames WHERE cid='%i' AND id='%i' LIMIT 1;", array($cid, $gmid))) or die(mysql_error());
		$cuserGInfo   =  mysql_fetch_array($cuserGInfoQ);
		$cuserGInfoR  =  mysql_num_rows($cuserGInfoQ);

		$fip = $cuserGInfo['ip'];
		$fport = $cuserGInfo['port'];
		$gid = $cuserGInfo['gid'];
		$ugid = $cuserGInfo['id'];
		$subdirectory = $cuserGInfo['subdirectory'];

		$gameInfoQ =  sql_query($safesql->query("SELECT * FROM game WHERE id='%i' LIMIT 1;", array($gid))) or die(mysql_error());
		$gameInfo   =  mysql_fetch_array($gameInfoQ);

		$sidQ  =  sql_query($safesql->query("SELECT S.sid, S.os, S.winport FROM iptable I, servers S WHERE I.ip='%s' AND I.sid = S.sid LIMIT 1;", array($fip))) or die(mysql_error());
		$sid   =  mysql_fetch_array($sidQ);

		$os = $sid[1];
		$winport = $sid[2];
		$sid = $sid[0];

		if($os != "1"){ 
			if($mode == "add") $command=$addonInfo['command'];   
			if($mode == "update") $command=$addonInfo['updatecommandline'];   
			if($mode == "remove") $command=$addonInfo['uninstallcommandline'];   
			if($mode == "enable") $command=$addonInfo['enablecmdline'];   
			if($mode == "disable") $command=$addonInfo['disablecmdline'];   
			if($mode == "execute") $command=$addonInfo['execcmd'];   
		} else {
			if($mode == "add") $command=$addonInfo['wincommand'];  
			if($mode == "update") $command=$addonInfo['winupdatecommandline'];   
			if($mode == "remove") $command=$addonInfo['winuninstallcommandline'];   
			if($mode == "enable") $command=$addonInfo['winenablecmdline'];   
			if($mode == "disable") $command=$addonInfo['windisablecmdline'];   
			if($mode == "execute") $command=$addonInfo['winexeccmd'];   
		}

		if(!$command) return false;
		if($cuserGInfoR == "0") return false;

		$command = str_replace("\$InstallFile", $addonInfo['installfile'], $command);
		$command = $this->ReplaceAllVars($ugid, $command);

		if($subdirectory == "yes"){ 
			if(ipsubdir == "true"){
				$subdir = "cd ".$fip."-".$fport.";"; 
				$thesubdir=$fip."-".$fport;
			} else {
				$subdir = "cd service$ugid ;"; 
				$thesubdir="service".$ugid;
			}
		} else {
			$subdir='';
			$thesubdir="";
		}


		if($addonInfo['restart'] == "1"){
			$reply.= "Stopping server.";
			$Control->Usergame($ugid, "stop");
		}

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$hook_vars=$command;
		run_hook("add_addon");

		if($os == "1"){
			$script="\$MAINDIRhome\\$fusername\\$gmid-addon.bat";
			$script2="\$MAINDIRhome\\$fusername\\$gmid-addon-2.bat";
			$scriptlog="\$MAINDIRhome\\$fusername\\$gmid-addon.log";
			
			$command ="@ECHO off\r\ncd /d \$MAINDIRhome\\$fusername\\$thesubdir\r\n".$command;
			$command=str_replace("\r", "", $command);
			$command=str_replace("\n", "\r\n", $command);
			$Backend->QueryResponse($sid, $winport, "writefile:_:$script:_:$command\r\necho > \$MAINDIRhome\\$fusername\\$ugid-addon.gcp\r\nexit\r\n");
			$Backend->QueryResponse($sid, $winport, "writefile:_:$script2:_:$script > $scriptlog");
			$Backend->Query($sid, $winport, "$script2:_:");
		} else {
			$GameCP->loadIncludes("linux");
			$Linux=new Linux();
			$script="/home/$fusername/.$gmid-addon.sh";
			$command ="cd /home/$fusername/$thesubdir\n".$command;
			$command=str_replace("\r", "", $command);

			if(debugging != "1") $command.="\n rm -f $script";
			$Backend->QueryResponse($sid,'', "writefile:_:$script:_:$command", $fusername);
			$Linux->Screen($sid, "bash $script", $gmid, $fusername, true);
		}

		if($mode == "add" || $mode == "remove"){
			$addonstatus = $this->DoUnserialize($cuserGInfo['addonstatus']);
			if(!is_array($addonstatus))$addonstatus=array();
			$addonstatus[$aid]=$mode;
			sql_query($safesql->query("UPDATE usergames SET addonstatus='%s' WHERE id='%i';", array(serialize($addonstatus), $gmid)));
		}

		return true;
	}




	function GetAddons($ggid){
		global $GameCP, $safesql, $LNG_DEFAULT;
		$addonList=array();

		$catQ = sql_query("SELECT * FROM addoncategorys ORDER BY 'title'") or die(mysql_error());
		while($cats = mysql_fetch_assoc($catQ)){
			$addonCatList=array();
			$resultClient = sql_query($safesql->query("SELECT A.*, UG.addonstatus FROM  addongames AG, addons A, usergames UG, game G  WHERE  UG.gid = G.id AND UG.id='%i' AND A.id = AG.aid AND AG.gid = G.id AND A.category='".$cats['id']."' ORDER BY `name` ASC", array($GameCP->whitelist($ggid, "int")))) or die(mysql_error());
			while($al=mysql_fetch_array($resultClient)) $addonCatList[]=$al;
			$addonList[]=array('category' => $cats, 'addons' => $addonCatList);
		}

		$addonCatList=array();
		$resultClient = sql_query($safesql->query("SELECT A.*, UG.addonstatus FROM  addongames AG, addons A, usergames UG, game G  WHERE  UG.gid = G.id AND UG.id='%i' AND A.id = AG.aid AND AG.gid = G.id AND A.category = '0' ORDER BY `name` ASC", array($GameCP->whitelist($ggid, "int")))) or die(mysql_error());
		while($al=mysql_fetch_array($resultClient)) $addonCatList[]=$al;
		$addonList[]=array('category' => array('title' => $LNG_DEFAULT), 'addons' => $addonCatList);

		return $addonList;

	}

	function Update($ggid){
		global $GameCP, $safesql, $Event, $hook_vars;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$ugDetails=$Panel->GetUserGame($ggid);
		$username=$ugDetails['username'];
		$fcid=$ugDetails['userid'];
		
		$userGameArray=sql_query($safesql->query("SELECT 
			U.id as 'uid',
			UG.id,
			UG.maxplayers,
			UG.startmap,
			UG.config,
			UG.ip,
			UG.port,
			G.gcode,
			G.protocol,
			G.name as 'gamename',
			U.name,
			UG.active as 'gstats',
			S.sid,
			G.updateLine,
			UG.subdirectory,
			G.vars,
			G.customvars,
			UG.vars as 'ugvars',
			S.os,
			UG.rconpass,
			G.winupdateline,
			S.winport,
			G.install,
			G.winappdir,
			UG.status
		FROM game G, usergames UG, users U, iptable I, servers S
		WHERE 
			G.id = UG.gid
			AND U.id = UG.cid AND U.userlevel ='0'
			AND I.ip = UG.ip AND I.sid=S.sid AND UG.id = '%i' LIMIT 1;", array($GameCP->whitelist($ggid, "int"))));
		$ugInfo=mysql_fetch_array($userGameArray);

		$install = $ugInfo['install'];
		$winappdir = $ugInfo['winappdir'];
		$os = $ugInfo['os'];

		if($os == "1"){
			if(preg_match("/:/i", $winappdir) || preg_match("/MAINDIR/i", $winappdir)){ 
				$winappdir=str_replace("/", "\\", $winappdir);
				$wap=explode("\\", $winappdir);
				$install=$wap[count($wap)-1];
			} else $install=$winappdir;
		}

		if($ugInfo['subdirectory'] == "yes"){ 
			if(ipsubdir == "true"){
				if($install){
					$thesubdir=$ugInfo['ip']."-".$ugInfo['port']."/$install";
				} else $thesubdir=$ugInfo['ip']."-".$ugInfo['port'];
			} else {
				if($install){
					$thesubdir="service".$ggid."/$install";
				} else $thesubdir="service".$ggid;
			}
		}else if($install)$thesubdir=$install;

		if($ugInfo['os'] == "1"){
			$updateLine=$ugInfo['winupdateline'];
		} else $updateLine=$ugInfo['updateLine'];

		if(trim($updateLine) != ""){
			$GameCP->loadIncludes("control");
			$Control=new Control();


			$Control->Usergame($ggid, "stop");
			$updateLine = $this->ReplaceAllVars($GameCP->whitelist($ggid, "int"), $updateLine);
			
			$GameCP->loadIncludes("backend");
			$Backend=new Backend();

			if($ugInfo['os'] == "1"){
				$updateLine=str_replace("\r", "", $updateLine);
				$updateLine=str_replace("\n", "\r\n", $updateLine);

				$homepath=str_replace("/", "\\", "\$MAINDIRhome\\$username\\$thesubdir");
				if(debugging != "yes") $updateLine = "@ECHO off\r\n".$updateLine;
				if($thesubdir) $updateLine = "cd $homepath \r\n".$updateLine;
				$updateLine.="\r\necho > \$MAINDIRhome\\$username\\$ggid-updated.gcp\r\n"; 

				$script="\$MAINDIRhome\\$username\\$ggid-update.bat";
				$script2="\$MAINDIRhome\\$username\\$ggid-update-2.bat";
				$scriptlog="\$MAINDIRhome\\$username\\$ggid-update.log";

				$Backend->QueryResponse($ugInfo['sid'], '', "writefile:_:$script:_:$updateLine\r\nexit\r\n");
				$Backend->QueryResponse($ugInfo['sid'], '', "writefile:_:$script2:_:$script > $scriptlog");
				$Backend->Query($ugInfo['sid'], '', "$script2:_:");

			} else {
				$script="/home/$username/.gcp-update-$ggid.sh";
				if(isset($thesubdir) && $thesubdir) $updateLine = "cd /home/$username/". $thesubdir. " ; ".$updateLine;
				$updateLine=str_replace("\r", "", $updateLine);
				$Backend->Query($ugInfo['sid'], '', "writefile:_:$script:_:$updateLine", $username);
				$GameCP->loadIncludes("linux");
				$Linux=new Linux();
				$Linux->Screen($ugInfo['sid'], "chmod u+x $script ; $script ; rm -f $script", "update.".$ggid, $username, true);
			}
			
			sql_query($safesql->query("UPDATE usergames SET `status`='2', `updatestatus`='%i' WHERE id='%i'", array($ugInfo['gstats'], $ggid)))or die (mysql_error());
		}

		$hook_vars=$ugInfo;
		run_hook("update_game");
		return true;

	}

	function Reinstall($ggid, $removeconfigs=FALSE,$removegame=FALSE){
		global $GameCP, $safesql, $Event, $hook_vars;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$ugDetails=$Panel->GetUserGame($ggid);
		$fname=$ugDetails['username'];
		$ugid=$ggid;
		$dome="0";
		$smartyResult="";

		$sidQ = sql_query($safesql->query("SELECT 
												S.sid,
												G.installfile,
												S.os,
												G.id as 'gid',
												S.winport,
												UG.ip,
												UG.port,
												UG.maxplayers,
												UG.rconpass,
												U.id as 'cid',
												I.internal,
												I.useinternal,
												G.install,
												UG.subdirectory,
												UG.premode, G.wininstall, G.wininstall, G.altinstall, G.altinstallwin, G.winappdir, G.vars
		
										FROM servers S, game G, usergames UG, iptable I, users U 
										WHERE 
											U.id = UG.cid
											AND UG.ip = I.ip 
											AND I.sid = S.sid
											AND UG.gid = G.id
											AND UG.id='%i' LIMIT 1;", array($GameCP->whitelist($ggid, "int")))) or die(mysql_error());
		
		$query = mysql_fetch_assoc($sidQ);

		$hook_vars=$query;
		run_hook("reinstall_game_pre");

		$sid=$query['sid'];
		$installFile=$query['installfile'];
		$os=$query['os'];
		$gid=$query['gid'];
		$winport=$query['winport'];
		$fip=$query['ip'];
		$fport=$query['port'];
		$fmaxclients=$query['maxplayers'];
		$RCONPASSWORD=$query['rconpass'];
		$cid=$query['cid'];
		$serverip = $fip;
		$install=$query['install'];
		$subdirectory=$query['subdirectory'];
		$premode=$query['premode'];
		$DefaultArchive=$query['wininstall'];
		$DefaultInstall=$query['installfile'];
		$installdir=$query['install'];
		$wininstall=$query['wininstall'];
		$defaultvars=$query['vars'];

		if($os == "1"){
			$altinstall=$query['altinstallwin'];
			$installdir=$query['winappdir'];
		} else $altinstall=$query['altinstall'];

		$GameCP->loadIncludes("control");
		$Control=new Control();

		sql_query($safesql->query("UPDATE usergames SET `status`='6', startserver='yes', addonstatus='%s', vars='%s' WHERE id='%i'", array(serialize(array()), $defaultvars, $GameCP->whitelist($ugid, "int")))) or die(mysql_error());

		$GameCP->loadIncludes("control");
		$Control=new Control();
		$Control->Usergame($ugid, "stop");

		if($removeconfigs == "1") sql_query($safesql->query("DELETE FROM userconfigs WHERE ugid='%i'", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error());


		$Control->Build($ugid, "add");
			
		if(isset($_SESSION['gamecp']['install'][$ugid]['start'])) unset($_SESSION['gamecp']['install'][$ugid]['start']);

		$this->InstallFiles($fname, $ugid, $fip, $fport, $sid, $os, $winport, $DefaultInstall, $subdirectory, $premode,$wininstall,$installdir,$DefaultArchive, '', $removegame, $altinstall);

		$this->ConfigCreate($ugid, false, "clear");

		$hook_vars=$query;
		run_hook("reinstall_game");

		$Event->EventLogAdd($fname, "User ". $fname. " had game $ugid reinstalled on $sid by ".$_SESSION['gamecp']['userinfo']['name']." ". time());
		return true;

	}

	function DoUnserialize($item){
		if($item != ""){
			$a=unserialize($item);
			if(is_array($a)){
				return $a;
			} else return array();
		}else return array();
	}

	function GameCommand($type, $ugid, $reinstall=FALSE, $wincmd=FALSE, $lincmd=FALSE, $detach=FALSE){
		global $GameCP;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$userInfo=$Panel->GetUserGame($ugid);
		$gameInfo=$Panel->GetGame($userInfo['gid']);
		$serverInfo=$Panel->GetServer('', $userInfo['ip']);
		$os=$serverInfo['os'];

		switch($type){
			case "install":
				if($os == "1"){
					$command=$gameInfo['wininstallLine'];
				} else $command=$gameInfo['installLine'];
			break;

			case "remove":
				if($os == "1"){
					$command=$gameInfo['winremove'];
				} else $command=$gameInfo['remove'];
			break;

			case "update":
				if($os == "1"){
					$command=$gameInfo['winupdateline'];
				} else $command=$gameInfo['updateLine'];
			break;
			default:
				$type="default";
				if($os == "1"){
					$command=$wincmd;
				} else $command=$lincmd;
			break;
		}

		if($os == "1"){
			$installdir2=$gameInfo['winappdir'];
		} else $installdir2=$gameInfo['install'];
		
		$premode=$userInfo['premode'];
		$serverip=$userInfo['ip'];
		$fport=$userInfo['port'];
		$subdirectory=$userInfo['subdirectory'];

		$fmaxclients=$userInfo['maxplayers'];
		$RCONPASSWORD=$userInfo['rconpass'];
		$fname=$userInfo['username'];
		$addons=unserialize($userInfo['addons']);

		$sid=$serverInfo['sid'];
		$os=$serverInfo['os'];
		$winport=$serverInfo['winport'];

		$GameCP->loadIncludes("user");
		$User=new User();
		$fpassword=$User->Password($userInfo['userid']);

		if($command){
			$installdira="";
			if($installdir2) $installdira="/$installdir2";

			if($subdirectory == "yes"){ 
				if(ipsubdir == "true"){
					$command="cd ".$serverip."-".$fport . "$installdira; ".$command;
				} else $command="cd service".$ugid ."$installdira; ".$command;
			} else if($installdir2) $command="cd $installdir2 ; ".$command;
			
			$command = $this->ReplaceAllVars($ugid, $command);

			if($reinstall == true) 	$command = str_replace("\$REINSTALL", "true", $command);

			/* execute by writing a bash/bat script */
			$winscript="gcp-".$type."cmd".$ugid.".bat";
			$script=".gcp-".$type."cmd".$ugid.".sh";
			
			run_hook("game_command");

			return $this->Exec($fname, $os, $sid, $winport, $script, $winscript, $command, $detach);
		} return false;
	}


	function MapImage($mapdir, $map){
		if(is_file(path."/includes/maps/$mapdir/$map.jpg")){
			return "includes/maps/$mapdir/$map.jpg";
		}elseif(is_file(path."/includes/maps/$mapdir/$map.gif")){
			return "includes/maps/$mapdir/$map.gif";
		}elseif(is_file(path."/includes/maps/$mapdir/$map.png")) return "includes/maps/$mapdir/$map.png";
	}

	function UpdateService($ggid){
		global $GameCP, $safesql;

		if($_SESSION['gamecp']['userinfo']['ulevel'] == "0") {
			$username=$_SESSION['gamecp']['userinfo']['name'];
			$fcid=$_SESSION['gamecp']['userinfo']['id'];
		} else {
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$ugDetails=$Panel->GetUserGame($ggid);
			$username=$ugDetails['username'];
			$fcid=$ugDetails['userid'];
		}
		$userGameArray=sql_query($safesql->query("SELECT 
			U.id as 'uid',
			UG.id,
			UG.maxplayers,
			UG.startmap,
			UG.config,
			UG.ip,
			UG.port,
			G.gcode,
			G.protocol,
			G.name as 'gamename',
			U.name,
			UG.active as 'gstats',
			S.sid,
			G.updateLine,
			UG.subdirectory,
			G.vars,
			G.customvars,
			UG.vars as 'ugvars',
			S.os,
			UG.rconpass,
			G.winupdateline,
			S.winport,
			G.install,
			G.winappdir,
			UG.status,
			G.steamid,
			G.steammod
		FROM game G, usergames UG, users U, iptable I, servers S
		WHERE 
			G.id = UG.gid AND UG.cid = '%i'
			AND U.id = UG.cid AND U.userlevel ='0'
			AND I.ip = UG.ip AND I.sid=S.sid AND UG.id = '%i' LIMIT 1;", array($GameCP->whitelist($fcid, "int"),$GameCP->whitelist($_REQUEST['ggid'], "int"))));
		$ugInfo=mysql_fetch_array($userGameArray);

		$install = $ugInfo['install'];
		$winappdir = $ugInfo['winappdir'];
		$os = $ugInfo['os'];

		if($os == "1"){
			if(preg_match("/:/i", $winappdir) || preg_match("/MAINDIR/i", $winappdir)){ 
				$winappdir=str_replace("/", "\\", $winappdir);
				$wap=explode("\\", $winappdir);
				$install=$wap[count($wap)-1];
			} else $install=$winappdir;
		}

		if($ugInfo['subdirectory'] == "yes"){ 
			if(ipsubdir == "true"){
				if($install){
					$thesubdir=$ugInfo['ip']."-".$ugInfo['port']."/$install";
				} else $thesubdir=$ugInfo['ip']."-".$ugInfo['port'];
			} else {
				if($install){
					$thesubdir="service".$ggid."/$install";
				} else $thesubdir="service".$ggid;
			}
		}else if($install)$thesubdir=$install;

		if($ugInfo['os'] == "1"){
			$homepath=str_replace("/", "\\", "\$MAINDIRhome\\$username\\$thesubdir\\");
			$updateLine=$ugInfo['winupdateline'];
		} else {
			$updateLine=$ugInfo['updateLine'];
			$homepath=str_replace("\\", "/", "\\home\\$username\\$thesubdir\\");
		}

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		if($ugInfo['steamid'] > "0"){
			require_once(path."/includes/core/classes/games/steamcmd.inc.php");
			$SteamCMD=new SteamCMD($ugInfo['steamid'], $ugInfo['steammod']);
			$cmdscript='steamcmd'.time().'.txt';
			$cmdline=$SteamCMD->GetCommand($os, $homepath, $cmdscript);
			$Backend->QueryResponse($ugInfo['sid'], '', "writefile:_:$homepath".$cmdscript.":_:".$cmdline[0], $username);
			if($ugInfo['os'] == "1"){
				$cmdel="del /f $cmdscript\r\n";
			} else $cmdel="rm -f f $cmdscript\r\n";
			$updateLine=$cmdline[1]."\r\n".$cmdel.$updateLine;
		}

		if(trim($updateLine) != ""){
			$GameCP->loadIncludes("control");
			$Control=new Control();

			$GameCP->loadIncludes("game");
			$Game=new Game();

			$Control->Usergame($ggid, "stop");
			$updateLine = $Game->ReplaceAllVars($GameCP->whitelist($_REQUEST['ggid'], "int"), $updateLine);
			

			if($ugInfo['os'] == "1"){
				$updateLine=str_replace("\r", "", $updateLine);
				$updateLine=str_replace("\n", "\r\n", $updateLine);

				if($thesubdir) $updateLine = "cd $homepath \r\n".$updateLine;
				$updateLine.="\r\necho > \$MAINDIRhome\\$username\\$ggid-updated.gcp\r\n"; 
				if(debugging != "0") $updateLine = "@ECHO off\r\n".$updateLine;

				$script="\$MAINDIRhome\\$username\\$ggid-update.bat";
				$script2="\$MAINDIRhome\\$username\\$ggid-update-2.bat";
				$scriptlog="\$MAINDIRhome\\$username\\$ggid-update.log";

				$Backend->QueryResponse($ugInfo['sid'], '', "writefile:_:$script:_:$updateLine\r\nexit\r\n");
				$Backend->QueryResponse($ugInfo['sid'], '', "writefile:_:$script2:_:$script > $scriptlog");
				$Backend->Query($ugInfo['sid'], '', "$script2:_:");

			} else {
				$script="/home/$username/.gcp-update-$ggid.sh";
				if(isset($thesubdir) && $thesubdir) $updateLine = "cd /home/$username/". $thesubdir. " ; ".$updateLine;
				$updateLine=str_replace("\r", "", $updateLine);
				$Backend->Query($ugInfo['sid'], '', "writefile:_:$script:_:$updateLine", $username);
				$GameCP->loadIncludes("linux");
				$Linux=new Linux();
				$Linux->Screen($ugInfo['sid'], "chmod u+x $script ; $script ; rm -f $script", "update.".$ggid, $username, true);
			}
			
			sql_query($safesql->query("UPDATE usergames SET `status`='2', `updatestatus`='%i' WHERE id='%i'", array($ugInfo['gstats'], $ggid)))or die (mysql_error());
		}

		$hook_vars=$ugInfo;
		run_hook("update_game");


	}

	function ConsoleLog($ugid, $mode){
		global $GameCP, $safesql;


		if ($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
			$sql=" AND U.id = '". $_SESSION['gamecp']['userinfo']['id']."'";
		} else $sql="";

		$result = sql_query($safesql->query("SELECT UG.ip, UG.port,
								G.scontrolname, U.name, G.name as 'gname',G.protocol,
								UG.id as 'gid',I.sid, G.gcode,S.os, UG.maxplayers as 'mplayers',
								UG.logfile, G.id as 'rgid', S.winport,
								S.sid, U.id as 'cid',
								UG.subdirectory, G.gcode, G.logfile as 'defaultlog', UG.gametype
								
								FROM users U, usergames UG, game G, iptable I, servers S WHERE U.id = UG.cid AND  UG.gid = G.id AND I.ip = UG.ip AND U.id=UG.cid AND UG.id='%i' AND I.sid=S.sid $sql LIMIT 1;", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error());
		$row = mysql_fetch_array($result);

		$rgid=$row['rgid'];
		$ugid=$row['gid'];
		$os=$row['os'];
		$winport=$row['winport'];
		$ucid=$row['cid'];
		$logfile=$row['logfile'];
		if(!$logfile && $row['defaultlog'] && $os == "1") $logfile=$row['defaultlog'];

		$subdirectory=$row['subdirectory'];
		$ip=$row['ip'];
		$port=$row['port'];
		$gcodea=$row['gcode'];
		$fname=$row[3];
		$sid=$row['sid'];
		$protocol=$row['protocol'];
		$gname=$row['gname'];
		$mplayers=$row['mplayers'];
		$gametype=$row['gametype'];

		if(!$logfile){
			$log = "screenlog.$ugid"; 
		} else $log=$logfile;




		if($mode == "downloadlog"){
			$linelimit="1000";
		} else $linelimit="150";

		$log=$GameCP->whitelist($log, 'web');

		if($subdirectory == "yes"){ 
			if(ipsubdir == "true"){
				$log=$ip."-".$port . "/".$log;
			} else {
				$log="service".$ugid ."/".$log;
			}
		}

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$GameCP->loadIncludes("game");
		$Games=new Game();


		$log=str_replace("\$D", date("d"), $log);
		$log=str_replace("\$M", date("m"), $log);
		$log=str_replace("\$YEAR", date("Y"), $log);
		$log=str_replace("\$Y", date("y"), $log);







		if($os != "1"){ 
			/* get the log */
			if($logfile){
				$readlog="/home/$fname/$log";
			} else $readlog="/home/$fname/screenlog.$ugid";
			$readlog=$Games->ReplaceAllVars($ugid,$readlog);
			$screenLog=$Backend->QueryResponse($sid, $winport, "command:_:tail -n $linelimit $readlog", $fname);
			$screenLog=@htmlspecialchars($GameCP->whitelist($screenLog, "web"), ENT_COMPAT | ENT_HTML401 | ENT_NOQUOTES | ENT_IGNORE);
			$screenLog=nl2br(trim(str_replace("\r", "",$screenLog)));
			
			$df=explode("\t",$Backend->QueryResponse($sid, '', "command:_:du -bs $readlog", $fname));
			if(is_array($df) && isset($df[0]) && $df[0] >= consoleDump) $Backend->Query($sid, '', "writefile:_:$readlog:_:", $fname);
			

		} else {
			if($logfile){
				$logfile=$Games->ReplaceAllVars($ugid, "\$MAINDIR\home\\$fname\\$log");
				$logfile=str_replace("/", "\\", $logfile);

				$screenLog=$Backend->QueryResponse($sid, $winport, "bin\\tail.exe:_:-n $linelimit \"$logfile\"");
				$screenLog=@htmlspecialchars($GameCP->whitelist($screenLog, "web"), ENT_COMPAT | ENT_HTML401 | ENT_NOQUOTES);
				$screenLog=trim(str_replace("\r", "",$screenLog));

				if(preg_match("/No such file or directory/s", $screenLog)){
					if ($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
						$screenLog = "<br><br><div style='font-size: 14px;'>&nbsp;&nbsp;No console log.</div>";
					} else $screenLog = "<br><br><div style='font-size: 14px;'>&nbsp;&nbsp;Unable to read log file.<br>&nbsp;&nbsp;<a target='_parent' href='userservices.php?fname=$fname&fcid=$ucid&ggid=$ugid&sid=$sid&mode=edit2&opt=edit'>Edit this game</a> and set a <strong>log file</strong> to be loaded from this page.</div>";
				} else {
					$screenLog=explode("\n", trim($screenLog));

					$arrayLength = count($screenLog);
					$screenLogQ="";
					for ($i = 0; $i < $arrayLength; $i++){
						$screenLogQ.= $screenLog[$i]."<br>";
					}
					$screenLog=$screenLogQ;


					$df=explode("\t",$Backend->QueryResponse($sid, '', "bin\du.exe:_:-bs $logfile", $fname));
					if(is_array($df) && isset($df[0]) && $df[0] >= consoleDump) $Backend->Query($sid, '', "writefile:_:$logfile:_:", $fname);

				}
			} else {
				if ($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
					$screenLog = "<br><br><div style='font-size: 14px;'>&nbsp;&nbsp;No console log.</div>";
				} else $screenLog = "<br><br><div style='font-size: 14px;'>&nbsp;&nbsp;No console log.<br>&nbsp;&nbsp;<a target='_parent' href='userservices.php?fname=$fname&fcid=$ucid&ggid=$ugid&sid=$sid&mode=edit2&opt=edit'>Edit this game</a> and set a <strong>log file</strong> to be loaded from this page.</div>";
			}
		}

		
		/* Clean up the logs */
		$screenLog=str_replace("^H", " ", $screenLog);
		$screenLog=str_replace("^M", " ", $screenLog);
		$screenLog=str_replace("^r", " ", $screenLog);
		$screenLog=str_replace("^", " ", $screenLog);
		$screenLog=str_replace("24;3", " ", $screenLog);
		$screenLog=str_replace("7;23", " ", $screenLog);
		$screenLog=str_replace("23;1H", " ", $screenLog);
		$screenLog=str_replace("1;24", " ", $screenLog);
		$screenLog=str_replace("22;1", " ", $screenLog);
		$screenLog=str_replace("1B", " ", $screenLog);
		$screenLog=str_replace("", " ", $screenLog);
		$screenLog=str_replace("L ", " ", $screenLog);
		$screenLog=str_replace("   ", "", $screenLog);

		return $screenLog;

	}

	function CheckUpdateStatus($ggid, $showlog=false){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$ugDetails=$this->GetService($ggid);

		$fname=$ugDetails['username'];
		$sid=$ugDetails['sid'];
		$updatecompleted = false;

		if($ugDetails['status'] == "2"){
			/* windows */
			if($ugDetails['os'] == "1"){
				$script ="\$MAINDIRhome\\$fname\\$ggid-update.bat";
				$script1="\$MAINDIRhome\\$fname\\$ggid-updated.gcp";
				$script2="\$MAINDIRhome\\$fname\\$ggid-update-2.bat";
				$scriptlog="\$MAINDIRhome\\$fname\\$ggid-update.log";

				$updatelog=$Backend->QueryResponse($sid, '', "readfile:_:".str_replace("/", "\\", $scriptlog));
				if($showlog == "true" && trim($updatelog) && strtolower(trim($updatelog)) != "error: reading file") echo "<div id='logarea' class='updatelog'>".nl2br($GameCP->whitelist(trim($updatelog), "wysiwyg"))."</div>";

				if($this->CheckInstallExists($sid, $script1, true) == true){
					
					$Backend->Query($sid, '', "deletefile:_:$script");
					$Backend->Query($sid, '', "deletefile:_:$script1");
					$Backend->Query($sid, '', "deletefile:_:$script2");
					$Backend->Query($sid, '', "deletefile:_:$scriptlog");

					$updatecompleted = true;
				} 
			} else {
			/* linux */
				$script="/home/$fname/.gcp-update-$ggid.sh";

				$GameCP->loadIncludes("linux");
				$Linux=new Linux();
				$updateStatus=$Linux->Watch($sid, "update.".$ggid, $fname, true, true, false);

				if($showlog == "true" && trim($updateStatus[1])) echo "<div id='logarea' class='updatelog'>".nl2br($GameCP->whitelist(trim($updateStatus[1]), "wysiwyg"))."</div>";

				if(!$updateStatus[0]){
					if(debugging == "1"){
						$Backend->Query($sid, '', "command:_:rm -f screenwatchupdate.$ggid.log .screenrc.watchupdate.$ggid", $fname);
					} else $Backend->Query($sid, '', "command:_:rm -f screenwatchupdate.$ggid.log .screenrc.watchupdate.$ggid $script", $fname);

					$updatecompleted = true;
				} 
			}
		} else echo "Update completed.";

		if($updatecompleted == true){
			sql_query($safesql->query("UPDATE usergames SET `status`='0', `updatestatus`='' WHERE id='%i'", array($ggid)));

			if($ugDetails['updatestatus'] == "1"){
				$GameCP->loadIncludes("control");
				$Control=new Control();
				$Control->Usergame($ggid, "start");
			}

			$hook_vars=$ggid;
			run_hook("update_game_completed");
		}
	}

	function CheckStatus($sid, $ugid, $fname, $startserver, $alt=false, $updater=false, $tag="", $reinstall=FALSE){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$serverInfo=$Panel->GetServer($sid);
		$GameCP->loadIncludes("control");
		$Control=new Control();

		if($serverInfo['os']== "1"){
			$status=array();
			$status[0]="installing";
			if($this->CheckInstallExists($sid, "\$MAINDIRhome\\$fname\\$tag$ugid-complete.gcp") == true) $status[0]="";
		} else {
			$GameCP->loadIncludes("linux");
			$Linux=new Linux();
			$status=$Linux->Watch($sid, $ugid, $fname, true);
		}

		if($status[0] != ""){
			if($alt==false) echo "<b>Service files are being installed.</b><br>You do not need to stay on this page.<br><br>";
		} else {
			if($alt==false) echo "<b>Service files are installed.</b><br><br>";
			if(!isset($_SESSION['gamecp']['install'][$ugid]['start'])){

				$GameCP->loadIncludes("backend");
				$Backend=new Backend();

				if($updater == false){
					if($alt==false) echo "Creating configurations<br><br>";
					$this->ConfigCreate($ugid, false, true);
					$updatecmd="";
				} else $updatecmd="updatecmd$ugid.sh";
				
				if($serverInfo['os'] == "1"){
					$script="\$MAINDIRhome\\$fname\\$tag$ugid-extract.bat";
					$script2="\$MAINDIRhome\\$fname\\$tag$ugid-extract-2.bat";
					$Backend->Query($sid, '', "deletefile:_:$script", $fname);
					$Backend->Query($sid, '', "deletefile:_:$script2", $fname);
					$Backend->Query($sid, '', "deletefile:_:\$MAINDIRhome\\$fname\\$tag$ugid-complete.gcp", $fname);
				} else $Backend->Query($sid, '', "command:_:rm -f screenwatch$tag$ugid.log .screenrc.watch$tag$ugid $updatecmd", $fname);

				$this->GameCommand("install", $ugid, $reinstall);

				if($startserver == "yes"){
					if($alt==false) echo "Starting service.<br><br>";
					$Control->Usergame($ugid, "start");
				}
				$_SESSION['gamecp']['install'][$ugid]['start']=true;
			}
			sql_query($safesql->query("UPDATE usergames SET `status`='0' WHERE id='%i'", array($ugid)));
			return true;
		}
	}

	function CheckInstallExists($sid, $file, $ignoredown=FALSE){
		global $GameCP;
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$script="\$MAINDIRcheckinstall".rand(1,4).".bat";
		$batch="@echo OFF\r\nIF NOT EXIST $file ECHO failed\r\nexit\r\n";
		$Backend->QueryResponse($sid, '', "writefile:_:$script:_:$batch");
		$reply=$Backend->QueryResponse($sid, '', "$script:_:");
		$Backend->Query($sid, '', "deletefile:_:$script");
		
		run_hook("check_install_exists");

		if($ignoredown == true){
		if(preg_match("/Remote Down/s",trim($reply))) return true;
		}
		if(trim($reply) == "failed") return false;
		return true;
	}

	function FinalInstall($os, $DefaultInstall){
		if($os !="1"){
			if(preg_match("/\//i", $DefaultInstall)){
				$final_install=$DefaultInstall;
			} else $final_install="\$MAINDIR/installs/$DefaultInstall";
		} else {
			if(preg_match("/:/i", $DefaultInstall)){
				$final_install=$DefaultInstall;
			} else $final_install="\$MAINDIRinstalls\\".$DefaultInstall;
		
		}
		return $final_install;
	}

	function CheckInstallFiles($sid, $winport, $os, $final_install){
		global $Backend;

		if($os !="1"){
			if(!trim($Backend->QueryResponse($sid, $winport, "isfile:_:$final_install")) && !trim($Backend->QueryResponse($sid, $winport, "isdir:_:$final_install"))) return false;
		} else {
			if($this->CheckInstallExists($sid, $final_install) != true) return false;
		}
		return true;
	}

	function GetExtension($file){
		$ext = pathinfo($file);
		if(!isset($ext["extension"])) return false;
		$extention =  $ext["extension"];
		if(preg_match("/.tar.bz2/i", $file)) $extention="tar.bz2";
		return $extention;
	}

	function IsDownload($DefaultInstall){
		$checkScheme=parse_url($DefaultInstall);
		if(isset($checkScheme['scheme']) && ($checkScheme['scheme'] == "ftp" || $checkScheme['scheme'] == "http" || $checkScheme['scheme'] == "https" || $checkScheme['scheme'] == "ftps")) return true;
		return false;
	}

	function InstallFiles($fname, $ugid, $fip, $fport, $sid, $os, $winport, $DefaultInstall, $subdirectory, $premode, $wininstall,$installdir,$DefaultArchive, $deleteinstall=FALSE, $deletefiles=FALSE, $altinstall=FALSE){
		global $GameCP, $hook_vars;

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$batch="";
		$removefiles="";
		$webdl=false;
		if($os == "1") $DefaultInstall=$DefaultArchive;
		if(!$DefaultInstall) return false;

		if($subdirectory == "yes"){ 
			if(ipsubdir == "true"){
				$subdir = "cd ".$fip."-".$fport.";"; 
				$thesubdir=$fip."-".$fport;
			} else {
				$subdir = "cd service$ugid ;"; 
				$thesubdir="service".$ugid;
			}
			$wininstall=$thesubdir;
		} else {
			$subdir='';
			$thesubdir="";
			$wininstall="";
		}



		/* check if this is a folder or supported archive */
		$extention=$this->GetExtension($DefaultInstall);
		$determinExtract=$this->Extract($extention, $os);

		if($determinExtract != false){
			$EXTRACT=$determinExtract[0];
			$EXTRACTMODE=$determinExtract[1];
		}

		/* check if this is a download */
		if($this->IsDownload($DefaultInstall)){
			$parts = explode("/", $DefaultInstall);
			$last_seg = ($parts[count($parts)-1] == "") ? $parts[count($parts)-2] : $parts[count($parts)-1];
			
			$fileurl=$DefaultInstall;
			$DefaultInstall = $last_seg;
			$webdl=true;
		}

		/* set timelimit higher so games can take their time */
		set_time_limit(99999);

		/* validate the files exists */
		$final_install=$this->FinalInstall($os, $DefaultInstall);
		if(!$altinstall && $webdl == false && $this->CheckInstallFiles($sid, $winport, $os, $final_install) == false){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->Error("Missing: ".str_replace("\$MAINDIR", "", $final_install)."");
			return false;
		}

		if($thesubdir && $installdir){
			if($os =="1"){
				$filesdir = $thesubdir."\\".$installdir;
			} else $filesdir = $thesubdir."/".$installdir;
		}elseif($thesubdir){
			$filesdir = $thesubdir;
		}elseif($installdir){
			$filesdir = $installdir;
		} else $filesdir="";


		/* Linux Servers */
		if($os !="1"){
			/* priority */
			if(installPriority){
				$nice="nice -n ".installPriority." ";
			} else $nice="";

			if($deletefiles) $removefiles="rm -rf /home/$fname/$filesdir/ ; ";

			/* Download */
			if(isset($fileurl) && $fileurl != ""){
				$final_install="/home/$fname/$DefaultInstall";
				$dl="wget $fileurl -O $final_install ; ";
				$del="; rm -f $final_install ;";
			} else {
				$del="";
				$dl="";
			}

			if($thesubdir){
				$subcmd="cd /home/$fname ; mkdir -p $thesubdir ; cd $thesubdir ;";
			} else $subcmd="cd /home/$fname ; ";

			if($altinstall){
				$altinstall = $this->ReplaceAllVars($ugid, $altinstall);
				$cmd="$subcmd$altinstall";
			}elseif(isset($EXTRACT)){
			/* Extract */
				$cmd="$dl$subcmd$nice$EXTRACT $final_install $del";
			/* Copy */
			} else $cmd="$dl mkdir -p /home/$fname/$filesdir/ ; $nice cp -R $final_install/* /home/$fname/$filesdir/";

			$hook_vars=$cmd;
			run_hook("install_game_files");

			$script="/home/". $fname . "/install$ugid.sh";
			$cmd=str_replace("\r", "", $cmd);
			$cmd=str_replace(";", "\n", $cmd);
			$Backend->QueryResponse($sid, $winport, "writefile:_:$script:_:$removefiles$cmd\nrm -f $script", $fname);

			$GameCP->loadIncludes("linux");
			$Linux=new Linux();
			$Linux->Screen($sid, "bash $script", $ugid, $fname, true);

		/* Windows Servers */
		} else { 

			$finallocation=$fname."\\".$thesubdir;

			if($deletefiles) $Backend->QueryResponse($sid, $winport, "deldir:_:\$MAINDIRhome\\$finallocation"); 

			$Backend->QueryResponse($sid, $winport, "mkdir:_:\$MAINDIR\home\\".$finallocation);
			if($installdir) $Backend->QueryResponse($sid, $winport, "mkdir:_:\$MAINDIR\home\\".$finallocation."\\".$installdir);

			/* Download */
			if(isset($fileurl) && $fileurl) $batch.="\$MAINDIRbin\wget.exe $fileurl -O \"$final_install\"\r\n";

			if($altinstall){
				$altinstall = $this->ReplaceAllVars($ugid, $altinstall);
				$altinstall=str_replace("\r", "", $altinstall);
				$altinstall=str_replace("\n", "\r\n", $altinstall);
				$batch="cd /d \$MAINDIRhome\\".$finallocation."\\".$installdir." \r\n\r\n$altinstall\r\necho > \$MAINDIRhome\\$fname\\$ugid-complete.gcp\r\n";
			}elseif(isset($EXTRACT)){
			/* Extract */
				$batch.="\$MAINDIRbin\\$EXTRACT $final_install $EXTRACTMODE \$MAINDIRhome\\$finallocation\r\necho > \$MAINDIRhome\\$fname\\$ugid-complete.gcp\r\n"; 
			/* Copy */
			} else {
				if($installdir){
					$install_folder="\$MAINDIRhome\\".$finallocation."\\".$installdir."\\";
				} else $install_folder="\$MAINDIRhome\\".$finallocation."\\";
				$batch.="xcopy $final_install $install_folder /E /R /H /Y /C\r\necho > \$MAINDIRhome\\$fname\\$ugid-complete.gcp\r\n";
			}

			if(!$altinstall && ((isset($fileurl) && $fileurl) || $deleteinstall)) $batch.="del /F $final_install\r\n";		

			$hook_vars=$batch;
			run_hook("install_game_files");

			/* Run */
			if($batch){
				$script="\$MAINDIRhome\\$fname\\$ugid-extract.bat";
				$script2="\$MAINDIRhome\\$fname\\$ugid-extract-2.bat";
				$Backend->QueryResponse($sid, $winport, "writefile:_:$script:_:$batch\r\nexit\r\n");
				$Backend->QueryResponse($sid, $winport, "writefile:_:$script2:_:call \"cmd /c start $script\"");
				$Backend->Query($sid, $winport, "$script2:_:");
			}

		}

		if(isset($fileurl) && $fileurl != ""){	
			return "fileurl";
		} else return true;
	}

	function SubGame($gmid, $sgid, $hostname, $maxplayers, $autoinstall, $cfgid, $remove, $pubpriv, $flimit, $subdir){	
		global $GameCP,$safesql;
		$sgid=$GameCP->whitelist($sgid, 'int');
		if($cfgid){
			if($remove == "yes"){
				echo "Removing sub game install $sgid<br>";
				sql_query($safesql->query("DELETE FROM gamesubinstalls WHERE id='%i' LIMIT 1", array($cfgid))) or die(mysql_error());
			} else {
				echo "Updating sub game install $sgid<br>";
				sql_query($safesql->query("UPDATE gamesubinstalls SET 
								sgid='%s', 
								hostname='%s', 
								maxplayers='%s', 
								install='%s', 
								pubpriv='%s', 
								`limit`='%s', 
								subdir='%s' 
							WHERE 
								id='%i' LIMIT 1", array($sgid,$hostname,$maxplayers,$autoinstall,$pubpriv,$flimit,$subdir,$cfgid))) or die(mysql_error());
			}
		} else {
			echo "Inserting sub game install..<br>";
			sql_query($safesql->query("INSERT INTO gamesubinstalls SET 
								sgid='%s', 
								hostname='%s', 
								maxplayers='%s', 
								install='%s',
								gid='%s', 
								pubpriv='%s',
								`limit`='%s', 
								subdir='%s'", array($sgid,$hostname,$maxplayers,$autoinstall,$gmid,$pubpriv,$flimit,$subdir))) or die(mysql_error());
		}
	}

	function Extract($uextension, $os){
		$EXTRACTMODE="";
		if($os !="1"){

			if ($uextension == "zip"){
				$EXTRACT="unzip -o"; 
			} else if ($uextension == "rar"){
				$EXTRACT="rar x "; 
			} else if ($uextension == "tar"){
				$EXTRACT="tar xvf"; 
			} else if($uextension == "gz"){
				$EXTRACT="tar zxvf"; 
			} else if($uextension == "bz2"){
				$EXTRACT="tar xvjf";
			} else if($uextension == "tar.bz2"){
				$EXTRACT="tar xvjf";
			} else return false;
		} else {
			if ($uextension == "zip" || $uextension == "rar" || $uextension == "tar" || $uextension == "gz" || $uextension == "bz2"|| $uextension == "7z"){
				$EXTRACT="gcpextract"; $EXTRACTMODE="";
			} else return false;

		}

		return array($EXTRACT, $EXTRACTMODE);
	}

	function URLSize($url) {
		$sch = parse_url($url);
		if (($sch != "http") && ($sch != "https") && ($sch != "ftp") && ($sch != "ftps")) {
			return false;
		}
		if (($sch == "http") || ($sch == "https")) {
			$headers = get_headers($url, 1);
			if ((!array_key_exists("Content-Length", $headers))) { return false; }
			return $headers["Content-Length"];
		}
		if (($sch == "ftp") || ($sch == "ftps")) {
			$server = $sch['host'];
			$port = $sch['port'];
			$path = $sch['path'];
			$user = $sch['user'];
			$pass = $sch['pass'];
			if ((!$server) || (!$path)) { return false; }
			if (!$port) { $port = 21; }
			if (!$user) { $user = "anonymous"; }
			if (!$pass) { $pass = "phpos@"; }
			switch ($sch) {
				case "ftp":
					$ftpid = ftp_connect($server, $port);
					break;
				case "ftps":
					$ftpid = ftp_ssl_connect($server, $port);
					break;
			}
			if (!$ftpid) { return false; }
			$login = ftp_login($ftpid, $user, $pass);
			if (!$login) { return false; }
			$ftpsize = ftp_size($ftpid, $path);
			ftp_close($ftpid);
			if ($ftpsize == -1) { return false; }
			return $ftpsize;
		}
	}

	function Addon($cid, $gmid, $aid, $mode){
		global $GameCP, $smarty, $safesql, $hook_vars;

		$cid=$GameCP->whitelist($cid, "int");
		$gmid=$GameCP->whitelist($gmid, "int");
		$aid=$GameCP->whitelist($aid, "int");

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if(!$cid || !$gmid || !$aid){
			$Panel->Error("Error: Missing fields.");
			return false;
		}

		$GameCP->loadIncludes("control");
		$Control=new Control();

		$cuserInfo=$Panel->GetUser($cid);
		$fusername=$cuserInfo['username'];

		$addonInfoQ  =  sql_query($safesql->query("SELECT * FROM addons  WHERE id='%i'", array($aid))) or die(mysql_error());
		$addonInfo   =  mysql_fetch_array($addonInfoQ);

		if(
			($mode == "add" && $addonInfo['doinstall'] != "1") || 
			($mode == "update" && $addonInfo['doupdate'] != "1") ||
			($mode == "remove" && $addonInfo['douninstall'] != "1") ||
			($mode == "enable" && $addonInfo['doenable'] != "1") ||
			($mode == "disable" && $addonInfo['dodisable'] != "1") ||
			($mode == "execute" && $addonInfo['doexecute'] != "1")
		){ $Panel->ErrorExit("Operation not allowed."); } 

		$notes=$addonInfo['notes'];

		if(!$gmid){ $gmid=$addonInfo['gmid']; }

		//echo "SELECT id, startmap, maxplayers, rconpass, queryport, pubpriv, ip, port FROM usergames WHERE cid='$cid' AND gid='$gmid'";
		$cuserGInfoQ =  sql_query($safesql->query("SELECT * FROM usergames WHERE cid='%i' AND id='%i' LIMIT 1;", array($cid, $gmid))) or die(mysql_error());
		$cuserGInfo   =  mysql_fetch_array($cuserGInfoQ);
		$cuserGInfoR  =  mysql_num_rows($cuserGInfoQ);

		$fip = $cuserGInfo['ip'];
		$fport = $cuserGInfo['port'];
		$gid = $cuserGInfo['gid'];
		$ugid = $cuserGInfo['id'];
		$subdirectory = $cuserGInfo['subdirectory'];

		$gameInfoQ =  sql_query($safesql->query("SELECT * FROM game WHERE id='%i' LIMIT 1;", array($gid))) or die(mysql_error());
		$gameInfo   =  mysql_fetch_array($gameInfoQ);

		$sidQ  =  sql_query($safesql->query("SELECT S.sid, S.os, S.winport FROM iptable I, servers S WHERE I.ip='%s' AND I.sid = S.sid LIMIT 1;", array($fip))) or die(mysql_error());
		$sid   =  mysql_fetch_array($sidQ);

		$os = $sid[1];
		$winport = $sid[2];
		$sid = $sid[0];

		if($os != "1"){ 
			if($mode == "add"){ $command=$addonInfo['command'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "update"){ $command=$addonInfo['updatecommandline'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "remove"){ $command=$addonInfo['uninstallcommandline'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "enable"){ $command=$addonInfo['enablecmdline'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "disable"){ $command=$addonInfo['disablecmdline'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "execute"){ $command=$addonInfo['execcmd'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
		} else {
			if($mode == "add"){ $command=$addonInfo['wincommand']; if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "update"){ $command=$addonInfo['winupdatecommandline'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "remove"){ $command=$addonInfo['winuninstallcommandline'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "enable"){ $command=$addonInfo['winenablecmdline'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "disable"){ $command=$addonInfo['windisablecmdline'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
			if($mode == "execute"){ $command=$addonInfo['winexeccmd'];  if(!$command){ $Panel->Error("Execution command was not found"); } }
		}

		if($cuserGInfoR == "0") $Panel->ErrorExit("Game must be installed first.<br><br><a href=\"javascript:history.go(-1)\"><b>Click here</b></a> to go back.");

		$command = str_replace("\$InstallFile", $addonInfo['installfile'], $command);
		$command = $this->ReplaceAllVars($ugid, $command);

		if($subdirectory == "yes"){ 
			if(ipsubdir == "true"){
				$subdir = "cd ".$fip."-".$fport.";"; 
				$thesubdir=$fip."-".$fport;
			} else {
				$subdir = "cd service$ugid ;"; 
				$thesubdir="service".$ugid;
			}
		} else {
			$subdir='';
			$thesubdir="";
		}


		if($addonInfo['restart'] == "1"){
			$reply.= "Stopping server.";
			$Control->Usergame($ugid, "stop");
		}

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$hook_vars=$command;
		run_hook("add_addon");

		if($os == "1"){
			$script="\$MAINDIRhome\\$fusername\\$gmid-addon.bat";
			$script2="\$MAINDIRhome\\$fusername\\$gmid-addon-2.bat";
			$scriptlog="\$MAINDIRhome\\$fusername\\$gmid-addon.log";
			
			$command ="@ECHO off\r\ncd /d \$MAINDIRhome\\$fusername\\$thesubdir\r\n".$command;
			$command=str_replace("\r", "", $command);
			$command=str_replace("\n", "\r\n", $command);
			$Backend->QueryResponse($sid, $winport, "writefile:_:$script:_:$command\r\necho > \$MAINDIRhome\\$fusername\\$ugid-addon.gcp\r\nexit\r\n");
			$Backend->QueryResponse($sid, $winport, "writefile:_:$script2:_:$script > $scriptlog");
			$Backend->Query($sid, $winport, "$script2:_:");
		} else {
			$GameCP->loadIncludes("linux");
			$Linux=new Linux();
			$script="/home/$fusername/.$gmid-addon.sh";
			$command ="cd /home/$fusername/$thesubdir\n$command";
			$command=str_replace("\r", "", $command);

			if(debugging != "1") $command.="\n rm -f $script";
			$Backend->QueryResponse($sid,'', "writefile:_:$script:_:$command", $fusername);
			$Linux->Screen($sid, "bash $script", $gmid, $fusername, true);
		}

		$_SESSION['gamecp']['addon'][$aid]['start']=$addonInfo['restart'];

		if($mode == "add" || $mode == "remove"){
			$addonstatus = $this->DoUnserialize($cuserGInfo['addonstatus']);
			if(!is_array($addonstatus))$addonstatus=array();
			$addonstatus[$aid]=$mode;
			sql_query($safesql->query("UPDATE usergames SET addonstatus='%s' WHERE id='%i';", array(serialize($addonstatus), $gmid)));
		}

		if(isset($smarty)){
			$smarty->assign("idd", $cid);  
			$smarty->assign("ggid", $ugid);  
			$smarty->assign("thesubdir", $thesubdir); 
			if(isset($startserver)) $smarty->assign("startserver", $startserver); 
			
			$smarty->display("manageusergames/addon-complete.tpl");
		}
	}

	function Exec($fusername, $os, $sid, $winport, $script, $winscript, $command, $detach=FALSE, $screenname=false, $logfile=false){
		global $GameCP, $hook_vars;
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		if(!$screenname) $screenname="execmd-$fusername";

		$hook_vars=array($fusername, $os, $sid, $winport, $script, $winscript, $command);
		run_hook("exec_cmd");

		if($os == "1"){ 
			if($fusername){
				$homepath="\$MAINDIRhome".$fusername."\\";
			}else $homepath="\$MAINDIR";
			
			$command = "@ECHO off\r\ncd $homepath ;".$command;
			$command=str_replace(";", "\n", $command);
			$command=str_replace("\r\n", "\n", $command);
			$command=str_replace("\n", "\r\n", $command);
			if($detach == true){
				if($logfile){
					$winscript2="run_".$winscript;
					$command.="\r\ndel -f $homepath$winscript2";
				}

				$command.="\r\ndel -f $homepath$winscript";
				$Backend->QueryResponse($sid, $winport, "writefile:_:$homepath$winscript:_:$command\r\nexit\r\n");

				if($logfile){
					$Backend->QueryResponse($sid, '', "writefile:_:$homepath$winscript2:_:$homepath$winscript > $homepath$logfile");
					$reply=$Backend->Query($sid, '', "$homepath\\$winscript2:_:");
				} else $reply=$Backend->Query($sid, $winport, "$homepath$winscript:_:");

			} else {
				$Backend->QueryResponse($sid, $winport, "writefile:_:$homepath$winscript:_:$command\r\nexit\r\n");
				$reply=$Backend->QueryResponse($sid, $winport, "$homepath$winscript:_:");
				$Backend->Query($sid, $winport, "deletefile:_:$homepath$winscript");
			}
		} else {

			if($fusername){
				$homepath="/home/".$fusername."/";
			}else $homepath=rtrim("\$MAINDIR", "/")."/";

			$command=str_replace("\r", "", $command);

			if($detach == true){
				$GameCP->loadIncludes("linux");
				$Linux=new Linux();
				if($fusername){
					$runuser=true;
				} else $runuser=false;
				$command.="\nrm -f ".$homepath."screenwatch".$screenname.".log";
				$Backend->QueryResponse($sid, $winport, "writefile:_:$homepath$script:_:$command", $fusername);
				$Linux->Screen($sid, "chmod u+x $homepath$script ; cd $homepath ; bash $script", $screenname, $fusername, $runuser);

			} else {
				$Backend->QueryResponse($sid, $winport, "writefile:_:$homepath$script:_:$command", $fusername);
				$reply=$Backend->QueryResponse($sid, $winport, "command:_:cd $homepath ; bash $script:_:", $fusername);
				$Backend->Query($sid, $winport, "deletefile:_:$homepath$script", $fusername);
			}

		}

		if($detach == true) {
			return true;
		} else return $reply;
	}

	function UpdateUsage(){
		$serverUpdateQ = sql_query("SELECT sid FROM servers ORDER BY used") or die(mysql_error());
		while ($serverUpdate = mysql_fetch_array($serverUpdateQ)){
			$tsid = $serverUpdate[0];

			$usedQ = sql_query("SELECT UG.maxplayers FROM usergames UG, iptable I, users U WHERE UG.ip = I.ip AND I.sid = '$tsid' AND U.id = UG.cid AND U.active='1'");
			$usedNum = mysql_num_rows($usedQ);

			$usedSlots="0";
			while($maxUsed=mysql_fetch_array($usedQ)){
				$usedSlots=$usedSlots+$maxUsed['maxplayers'];
			}

			sql_query("UPDATE servers SET used='$usedNum', slotused='$usedSlots' WHERE sid='$tsid'");
		}
	}

	function MergeVars($vars, $ugvars, $force=FALSE){
		global $GameCP;
		$userGameCvars=array();
		$ugcvarArray=array();
		$ugcvar=array();

		if(is_array($vars)){
			foreach($vars as $vid => $var){
				$cv=$var['cvar'];
				if(isset($var['user']) && $var['user'] == "1" || isset($_SESSION['gamecp']['userinfo']['ulevel']) && ($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4") || $force ){
					$ugcvarArray[]=$var['cvar'];
					$ugcvar[$cv]=$GameCP->whitelist($var['value'], "clean");
				}
			}
		}

		if(is_array($ugvars)){
			foreach($ugvars as $uvid => $uvar){
				$var=$uvar['cvar'];
				if(in_array($var, $ugcvarArray)){
					$ugcvar[$var]=$GameCP->whitelist($uvar['value'], "clean");
				}
			}
		}


		if(is_array($ugcvar)){
			foreach($ugcvar as $v => $i){
				$userGameCvars[]=array("cvar" => $v, "value" => $GameCP->whitelist($i, "clean"));
			}
		}

		return $userGameCvars;
	}

	function ReplaceVars($cvars, $customvars, $addons, $standard, $LinuxInstallCommand){
		if(is_array($addons)){
			foreach($addons as $ad => $av) $LinuxInstallCommand = str_replace("\$".strtoupper($ad), $av, $LinuxInstallCommand);
			
		}

		if(is_array($cvars)){
			foreach($cvars as $cid => $cvar){
				if($cvar['cvar'] && $cvar['value']) $LinuxInstallCommand = str_replace("\$".$cvar['cvar'], $cvar['value'], $LinuxInstallCommand);				
			}
		}
		if(is_array($customvars)){
			foreach($customvars as $cid => $cvar){
				if($cvar['cvar'] && $cvar['value']) $LinuxInstallCommand = str_replace("\$".$cvar['cvar'], $cvar['value'], $LinuxInstallCommand);
				
			}
		}

		if(is_array($standard)){
			foreach($standard as $cid => $cvar){
				if($cvar['cvar'] && $cvar['value']) $LinuxInstallCommand = str_replace("\$".$cvar['cvar'], $cvar['value'], $LinuxInstallCommand);
			}
		}

		return $LinuxInstallCommand;
	}

	function BanIP($banip, $fip, $fport, $drop){
		global $GameCP, $hook_vars;
		if($drop == "REMOVE"){
			$mode="";

		}elseif($drop == "true"){
			$mode="DROP";
		}else $mode="ACCEPT";

		$drop=$GameCP->whitelist($drop, "bash");

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$serverDetails=$Panel->GetServer('', $fip);
		$sid=$serverDetails['sid'];
		$iptablesconfig=$serverDetails['iptablesconf'];
		
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$hook_vars=array($banip, $fip, $fport, $drop);
		run_hook("ban_ip");

		$Backend->Query($sid, '', "command:_:iptables -D INPUT -s $banip -p tcp --destination $fip --dport $fport -j DROP ; iptables -D OUTPUT -s $fip -p tcp --destination $banip --dport $fport -j DROP ; iptables -D INPUT -s $banip -p udp --destination $fip --dport $fport -j DROP ; iptables -D OUTPUT -s $fip -p udp --destination $banip --dport $fport -j DROP ; iptables -D INPUT -s $banip -p tcp --destination $fip --dport $fport -j ACCEPT ; iptables -D OUTPUT -s $fip -p tcp --destination $banip --dport $fport -j ACCEPT ; iptables -D INPUT -s $banip -p udp --destination $fip --dport $fport -j ACCEPT ; iptables -D OUTPUT -s $fip -p udp --destination $banip --dport $fport -j ACCEPT; iptables-save > $iptablesconfig;");
		if($mode) $Backend->Query($sid, '', "command:_:iptables -I INPUT -s $banip -p tcp --destination $fip --dport $fport -j $mode ; iptables -I OUTPUT -s $fip -p tcp --destination $banip --dport $fport -j $mode ; iptables -I INPUT -s $banip -p udp --destination $fip --dport $fport -j $mode ; iptables -I OUTPUT -s $fip -p udp --destination $banip --dport $fport -j $mode; iptables-save > $iptablesconfig;");
	}

	function Import($data, $updateid=false){
		global $GameCP,$safesql;

			$importdata=json_decode($data);
			if($importdata->game_data){
				if($updateid){ 
					$q="UPDATE `game` SET ";
				} else $q="INSERT INTO `game` SET ";
				foreach($importdata->game_data as $i => $g){
					if($i != "id"){
					if($i == "disablefirewall" && !$g) $g="0";
					$q.=$safesql->query("`%s`='%s',", array($i, $g));
					}
				}
				$gameq=rtrim($q, ",");

				if($updateid) $gameq.= $safesql->query("WHERE id='%i'", array($updateid));

				sql_query($gameq)or die(mysql_error());
				
				if($updateid){
					$gmid=$updateid;
				} else $gmid=mysql_insert_id();

				/* these ids are reserved for voice only - do not allow games on them! */
				if($gmid == "1000" || $gmid == "1001" || $gmid == "1002" || $gmid == "1003" || $gmid == "1004"){
					sql_query($safesql->query("UPDATE game SET id='1010' WHERE id='%i'", array($gmid))) or die(mysql_error());
					$gmid="1010";
				}
		

				if(isset($importdata->config_data) && is_array($importdata->config_data) && count($importdata->config_data) > 0){
					foreach($importdata->config_data as $c => $d){
						$cq="INSERT INTO `gameconfigs` SET ";
						foreach($d as $a => $b){
							if($a != "id"){
								if($a == "gid") $b=$gmid;
								$cq.=$safesql->query("`%s`='%s',", array($a, $b));
							}
						}
						$configq=rtrim($cq, ",");
						sql_query($configq)or die(mysql_error());
					}
				}
			}

		return $gmid;
	}

	function Export($gmid){
		global $safesql;
		$gInfo = sql_query($safesql->query("SELECT * FROM game WHERE id ='%i' LIMIT 1;", array($gmid))) or die(mysql_error());
		$row = mysql_fetch_array($gInfo);

		$dom=array();
		$fieldsQ = sql_query("SHOW COLUMNS FROM `game`") or die(mysql_error());
		while($fields = mysql_fetch_assoc($fieldsQ)){
			if($fields['Field'] != "id") $dom['game_data'][$fields['Field']]=$row[$fields['Field']];
		}


		$configInfoQ = sql_query($safesql->query("SELECT * FROM gameconfigs WHERE gid='%i';", array($gmid))) or die(mysql_error());
		$i=0;
		while($configInfo = mysql_fetch_assoc($configInfoQ)){
			$dom['config_data'][$i]=$configInfo;
			$i++;
	
		}
		return json_encode($dom);
	}

	function ConfigSQL($gmid, $configdir, $winconfigdir, $configfile, $gconfig, $configInstall, $installfile, $cfgid, $remove, $cfgname, $hideconfig="no", $defaultconfig="no", $edittype="file", $autoexec="no", $fencoding="utf8", $editable='0', $configbuilder='0'){	
		global $GameCP, $safesql;
		if($cfgid){
			if($remove == "yes"){
				sql_query($safesql->query("DELETE FROM gameconfigs WHERE id='%i' LIMIT 1", array($cfgid))) or die(mysql_error());
				sql_query($safesql->query("DELETE FROM config_builderitems WHERE builderid='%i' LIMIT 1", array($cfgid))) or die(mysql_error());
			} else sql_query($safesql->query("UPDATE gameconfigs SET 
													winconfigdir='%s',
													configdir='%s', 
													configfile='%s',
													config='%s', 
													install='%s',
													name='%s',
													hideconfig='%s',
													defaultconfig='%s', 
													edittype='%s',
													autoexec='%s',
													fencoding='%s',
													editable='%i',
													configbuilder='%i'
													WHERE id='%i'
													LIMIT 1", array($winconfigdir, $configdir, $configfile, $gconfig, $configInstall, $cfgname, $hideconfig, 
														$defaultconfig, $edittype,$autoexec, $fencoding, $editable, $configbuilder, $cfgid ))) or die(mysql_error());
		} else sql_query($safesql->query("INSERT INTO gameconfigs SET 
													gid='%i',
													winconfigdir='%s',
													configdir='%s', 
													configfile='%s',
													config='%s', 
													install='%s',
													name='%s',
													hideconfig='%s',
													defaultconfig='%s', 
													edittype='%s',
													autoexec='%s',
													fencoding='%s',
													editable='%i',
													configbuilder='%i'", array($gmid, $winconfigdir, $configdir, $configfile, $gconfig, $configInstall, $cfgname, $hideconfig, 
														$defaultconfig, $edittype,$autoexec, $fencoding, $editable, $configbuilder ))) or die(mysql_error());
	}

	function ConfigCreate($ugid, $configID=FALSE, $alwaysinsert=FALSE, $file=FALSE, $dir=FALSE, $inputcontent=FALSE, $configName=FALSE){
		global $Event, $GameCP, $safesql, $hook_vars;

		$configID=$GameCP->whitelist($configID);
		$ugid=$GameCP->whitelist($ugid);

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();


		if(!$ugid) return $Panel->Error("Service id is missing $ugid"); 
		
		if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
			$sqlA=" AND UG.cid=".$_SESSION['gamecp']['userinfo']['id'];
		} else $sqlA="";

		$ugameInfoQ = sql_query($safesql->query("SELECT * FROM usergames WHERE id = '%i' LIMIT 1;", array($ugid))) or die(mysql_error());
		$ugameInfo = mysql_fetch_array($ugameInfoQ);
		if(!is_array($ugameInfo)) return $Panel->Error("There was a problem while trying to reinstall $ugid");

		$subdirectory=$ugameInfo['subdirectory'];
		$RCONPASSWORD=$ugameInfo['rconpass'];
		$fmaxclients=$ugameInfo['maxplayers'];
		$fip=$ugameInfo['ip'];
		$fport=$ugameInfo['port'];
		$fpubpriv=$ugameInfo['pubpriv'];
		$gid=$ugameInfo['gid'];
		$MAXPLAYERS=$fmaxclients;
		$IP = $fip;
		$PORT = $fport;


		$userInfo=$Panel->GetUser($ugameInfo['cid']);
		$fname=$userInfo['name'];
		$USERNAME = $fname;
		$fpassword=$userInfo['password'];
		$cuserInfo=$userInfo;
		$USEREMAIL=$cuserInfo['email'];

		$serverDetails=$Panel->GetServer('', $fip);
		$sid=$serverDetails['sid'];
		$os=$serverDetails['os'];

		$gameNumbersQ = sql_query($safesql->query("SELECT * FROM users U, usergames UG, iptable I, servers S WHERE UG.gid ='%i' AND UG.ip = I.ip AND I.sid = S.sid AND U.name = '%s' AND UG.cid = U.id", array($gid, $fname))) or die(mysql_error());
		$gameNum=mysql_num_rows($gameNumbersQ);

		/* select only the config defined otherwise this function will copy all configs for this game */
		if($configID){ 
			$configDetailsQ=sql_query($safesql->query("SELECT 
				UC.configdir,
				UC.config as 'configfile',
				UC.contents as 'config',
				'1' as 'install',
				UC.configdir as 'winconfigdir',
				UC.name,
				UC.hidecfg as 'hideconfig',
				'0' as 'defaultconfig',
				UC.edittype,
				UG.vars,
				UC.autoexec, UC.fencoding, 
				UC.editable, 
				UC.configbuilder, UC.id
			FROM userconfigs UC, usergames UG, game G WHERE UC.id='%i' AND G.id=UG.gid AND UG.id=UC.ugid $sqlA LIMIT 1", array($configID))) or die(mysql_error());
		} else $configDetailsQ = sql_query($safesql->query("SELECT
				configdir,
				configfile,
				config,
				install,
				winconfigdir,
				`name`,
				hideconfig,
				defaultconfig,
				edittype,
				autoexec, 
				fencoding,
				id, 
				editable, 
				configbuilder
			FROM gameconfigs WHERE gid ='%i'", array($gid))) or die(mysql_error());
		while($configDetails = mysql_fetch_array($configDetailsQ)){

			$gameConfigDir	 = $configDetails[0];
			$gameConfigFile	 = $configDetails[1];
			$gameConfig		 = $configDetails[2];
			$installConfig	 = $configDetails[3];

			$winconfigdir	 = $configDetails[4];
			$cfgname		 = $configDetails[5];
			$namehideconfig	 = $configDetails[6];
			$defaultconfig	 = $configDetails[7];
			$edittype		 = $configDetails['edittype'];
			$autoexec		 = $configDetails['autoexec'];
			$fencoding		 = $configDetails['fencoding'];
			$cfgid			 = $configDetails['id'];
			$editable		 = $configDetails['editable'];
			$configbuilder	 = $configDetails['configbuilder'];
			$configfile		 = $gameConfigFile;
			
			if(!isset($configDetails['vars']) || (isset($configDetails['vars']) && !$configDetails['vars'])) $configDetails['vars']=serialize(array());
			if(!$winconfigdir)	$winconfigdir=$gameConfigDir; 
			if($inputcontent)	$gameConfig = $inputcontent; 
			if($dir)			$gameConfigDir = $dir; 
			if($file)			$gameConfigFile = $file; 

			// if there is no config - get out!
			if(!$gameConfigFile) break;

			if(isset($gameConfig)){
				$ogcfg=$gameConfig;
				
				$gameConfig = $this->ReplaceAllVars($ugid, $gameConfig);
				$gameConfig = str_replace("\$CONFIGNUM", $gameNum+1, $gameConfig);

				// Create the config file.
				if($configName && $gameConfigFile == $configfile) $gameConfigFile=$configName;

				if(!$gameConfigFile) return $Panel->Error("Unable to create config, missing file name"); 

				$GameCP->loadIncludes("backend");
				$Backend=new Backend();

				$hook_vars=array($gameConfig);
				run_hook("create_config");

				if($subdirectory == "yes"){ 
					if(ipsubdir == "true"){
						$subdir = "cd ".$fip."-".$fport.";"; 
						$thesubdir=$fip."-".$fport;
					} else {
						$subdir = "cd service$ugid ;"; 
						$thesubdir="service".$ugid;
					}
				} else {
					$subdir='';
					$thesubdir="";
				}


				if((!$configID && $installConfig == "1" || $configID)){
					if($os != "1" && $os != "3"){ 
						$afile = $gameConfigDir.$gameConfigFile;
						if($gameConfigDir){
							$adest = $gameConfigDir."/".$gameConfigFile;
						} else $adest = $gameConfigFile;

						if($gameConfig){
							if($thesubdir){
								$finalLocalPath="/home/". $fname."/".$thesubdir;
							} else $finalLocalPath="/home/". $fname;
							
							$gameConfig=str_replace("\r\n", "\n", $gameConfig);

							$finalLocal=$finalLocalPath."/".$adest;
							if($fname){
								$Backend->QueryResponse($sid, '', "mkdir:_:$finalLocalPath/$gameConfigDir", $fname);
								$Backend->Query($sid, '', "writefile:_:$finalLocal:_:$gameConfig", $fname);
							} else echo "Error: missing user name.";
						}
					} else {
						$afile = $winconfigdir.$gameConfigFile;
						if($winconfigdir){
							$adest = $winconfigdir."/".$gameConfigFile;
						} else $adest = $gameConfigFile;

						if($thesubdir){
							$finalLocalPath="/home/". $fname."/".$thesubdir;
						} else $finalLocalPath="/home/". $fname;

						$finalLocal=$finalLocalPath."/".$adest;

						$finalLocal=str_replace("/", "\\", $finalLocal);
						$finalLocalPath=str_replace("/", "\\", $finalLocalPath);
						$winconfigdir=str_replace("/", "\\", $winconfigdir);

						$gameConfig=str_replace("\r\n", "\n", $gameConfig);
						$gameConfig=str_replace("\n", "\r\n", $gameConfig);

						$Backend->QueryResponse($sid, '', "mkdir:_:\$MAINDIR$finalLocalPath\\$winconfigdir");

						if($fencoding == "default"){
							$Backend->Query($sid, '', "writefile:_:\$MAINDIR$finalLocal:_:$gameConfig");
						} else $Backend->Query($sid, '', "writefileutf8:_:\$MAINDIR$finalLocal:_:$gameConfig");
						
						$afile=str_replace("\\", "/", $afile);
					}
				}
				if($os == "1"){
					$gcFile=$winconfigdir;
				} else $gcFile=$gameConfigDir;
				$q="";
				if(!$cfgname) $cfgname=$fname;
				if($edittype == "database" && !$configID) $gameConfig=$ogcfg;
				if($alwaysinsert == "clear"){
					sql_query($safesql->query("DELETE FROM `userconfigs` WHERE `name`='%s' AND `config`='%s' AND ugid='%i' AND configdir='%s' AND edittype='%s'", array($cfgname, $configfile,$ugid,$gcFile,$edittype)));
					$alwaysinsert=true;
				}

				$q=$safesql->query("INSERT INTO `userconfigs` SET
										`name`='%s',
										`config`='%s', 
										contents='%s', 
										ugid='%i',
										configdir='%s',
										edittype='%s',
										autoexec='%s', 
										hidecfg='%s', 
										fencoding='%s',
										editable='%i',
										configbuilder='%i',
										cfgid='%s'
									", array($cfgname, 
											$configfile, 
											$gameConfig, 
											$ugid,
											$gcFile,
											$edittype, 
											$autoexec,
											$namehideconfig,
											$fencoding,
											$editable,
											$configbuilder,
											$cfgid
									));
				if($alwaysinsert != false && (($ugid && !$configID) || ($ugid && $alwaysinsert == true))) sql_query($q) or die(mysql_error());
				
			} else if(debugging =="1") echo "No default config provided.<br>"; 


		 } // end while
		return true;
	}

	function Backup($ugid, $timestamp){
		global $GameCP;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$GameCP->loadIncludes("linux");
		$Linux=new Linux();

		$gameInfo=$Panel->GetGame($userInfo['gid']);
		if($gameInfo['subdirectory'] == "yes"){ 
			if(ipsubdir == "true"){
				$thesubdir=$gameInfo['ip']."-".$gameInfo['port'];
			} else $thesubdir="service".$ugid;
		}

		$cmd="cd /home/$fname/$thesubdir ; if [ -f Backup-$ugid-$timestamp.tar.gz ] ; then rm -f Backup-$ugid-$timestamp.tar.gz; fi ; tar -pczf backup$ugid.tar.gz *";
		$Linux->Screen($gameInfo['sid'], $cmd, $ugid, $gameInfo['username']);
	}

	function WindowsFileSize($sid, $folder, $filename){
		global $Backend;

		$filelist=$Backend->QueryResponse($sid, '', "filelist:_:$folder");
		$file=str_replace(":_:", "GC_PC", $filelist);
		$file=explode("::" , $file);
		if(is_array($file)){
			for ($i = 0; $i < count($file); $i++){
				$filesub = explode("GC_PC", $file[$i]);
				if($filesub[0] == $filename) return $filesub[1];
			}
		}
	}

	function WindowsFileExists($sid, $folder, $filename){
		global $Backend;

		$filelist=$Backend->QueryResponse($sid, '', "filelist:_:$folder");

		$file=str_replace(":_:", "GC_PC", $filelist);
		$file=explode("::" , $file);
		if(is_array($file)){
			for ($i = 0; $i < count($file); $i++){
				$filesub = explode("GC_PC", $file[$i]);
				if($filesub[0] == $filename) return true;
			}
		}
		return false;
	}


	function Move($ggid, $fip, $port){
		global  $Event, $smarty, $GameCP, $safesql;
		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2") return false;
		$GameCP->loadIncludes("control");
		$Control=new Control();

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$GameCP->loadIncludes("user");
		$User=new User();

		$gameInfoQ = sql_query($safesql->query("SELECT UG.ip, UG.port, UG.cid, G.scontrolname, UG.id, UG.cid, G.install, UG.subdirectory, UG.premode, U.name FROM usergames UG, game G, users U WHERE UG.cid = U.id AND UG.id='%i' AND G.id=UG.gid LIMIT 1;", array($ggid))) or die(mysql_error());
		$gameInfo = mysql_fetch_array($gameInfoQ);
		$oldip=$gameInfo[0];
		$oldport=$gameInfo[1];
		$cid=$gameInfo[2];
		$ugid=$gameInfo[4];
		$scontrolName=$gameInfo[3].".".$ugid;
		$ucid = $gameInfo["cid"];
		$install = $gameInfo["install"];
		$premode = $gameInfo["premode"];
		$subdirectory = $gameInfo["subdirectory"];
		$fname = $gameInfo["name"];

		$serverInfoQ = sql_query("SELECT S.os, S.sid, S.ftpport FROM servers S, iptable I WHERE I.sid=S.sid AND I.ip='$oldip'") or die(mysql_error());
		$serverInfo = mysql_fetch_row($serverInfoQ);
		$sosA=$serverInfo[0];
		$sidA=$serverInfo[1];
		$sidAport=$serverInfo[2];

		$serverInfoQB = sql_query($safesql->query("SELECT S.os, S.sid, S.sshport FROM servers S, iptable I WHERE I.sid=S.sid AND I.ip='%s' LIMIT 1;", array($fip))) or die(mysql_error());
		$serverInfoB = mysql_fetch_row($serverInfoQB);
		$sosB=$serverInfoB[0];
		$sidB=$serverInfoB[1];
		$sshport=$serverInfoB[2];

		$isLastGameQ=sql_query("SELECT UG.id FROM iptable I, usergames UG WHERE UG.ip = I.ip AND I.sid='$sidA' AND UG.cid='$cid'");
		$isLastGame=mysql_num_rows($isLastGameQ);

		$isAUserQ=sql_query("SELECT UG.id FROM iptable I, usergames UG WHERE UG.ip = I.ip AND I.sid='$sidB' AND UG.cid='$cid' LIMIT 1;");
		$isAUser=mysql_num_rows($isAUserQ);

		$reply="";

		if(($sosA == "1" || $sosB == "1") && $sosA != $sosB) { 
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->Error("You can only move servers to the same type of machine, Linux to Linux, Windows to Windows");
			$smarty->assign("error", true);
			return false;
		}

		
		$reply.= "Stopping server<br>";
		$Control->Usergame($ugid, "stop");
		$reply.= "<br><hr>";

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$userInfo=$Panel->GetUser($cid);
		$fpassword=$userInfo['password'];
		$loginpath=$userInfo['bash'];
		$demo=$userInfo['demo'];

		if($loginpath == "noftp"){
			$loginpath="no";
			sql_query($safesql->query("UPDATE users SET bash ='%s' WHERE id='%i' LIMIT 1;", array($loginpath, $cid))) or die(mysql_error());
		}
		
		$ubash = $User->GetShell($loginpath, $demo);

		if($subdirectory == "yes"){ 
			if(ipsubdir == "true"){
				$thesubdir=$oldip."-".$oldport;
				$newsubdir=$fip."-".$port;
				$premode=str_replace($thesubdir, $newsubdir, $premode);
			} else {
				$thesubdir="service".$ugid;
				$newsubdir="service".$ugid;
			}
		}

		$GameCP->loadIncludes("query");
		$Query=new Query();

		if($sidA != $sidB) {
			if(!$Query->Status($sidA) || !$Query->Status($sidB)){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->Error("One of the remote servers is offline");
				return false;
			}

			$_SESSION['gamecp']['move'][$ggid]=array();
			$_SESSION['gamecp']['move'][$ggid]['step']="1";

		
			if($sosB != "1"){
			/* linux */

				if(!$User->CheckThenAdd($sidB, $fname, $fpassword, $ubash)) return $Panel->Error("<b>USER DOES NOT EXIST.</b><br>The user should be installed onto the server first. Setup exited.<br><b>User not added.</b>");
				$foldersize=preg_split("/\s+/",$Backend->QueryResponse($sidA, $winport, "command:_:du -hbs /home/$fname/$thesubdir"));
				$_SESSION['gamecp']['move'][$ggid]['foldersize']=$foldersize[0];
				$_SESSION['gamecp']['move'][$ggid]['file']="backup$ugid.tar.gz";

				$GameCP->loadIncludes("linux");
				$Linux=new Linux();
				$Linux->SSHAccess($cid, $loginpath);


			} else {
			/* windows */

				$Backend->QueryResponse($sidB, '', "mkdir:_:\$MAINDIRhome\\$fname\\");
				$Backend->UpdateFTP($sidA);

				$df=explode("\t",$Backend->QueryResponse($sidA, '', "bin\du.exe:_:-s \$MAINDIRhome\\$fname\\$thesubdir"));
				$foldersize=$df[0];
				$_SESSION['gamecp']['move'][$ggid]['foldersize']=$foldersize;
				$_SESSION['gamecp']['move'][$ggid]['file']="backup$ugid.tar";

			}

		
			$GameCP->loadIncludes("ftp");
			$FTP=new FTP();
			if(!$FTP->Status($sidA, $fname, $fpassword)){
				$GameCP->loadIncludes("panel");	
				$Panel=new Panel();
				$Panel->Error("User was added to server but was unable to access FTP");
				$smarty->assign("error", true);
				return false;
			}

			$_SESSION['gamecp']['move'][$ggid]['user']=$fname;
			$_SESSION['gamecp']['move'][$ggid]['password']=$fpassword;
			$_SESSION['gamecp']['move'][$ggid]['game']=$ggid;

			$_SESSION['gamecp']['move'][$ggid]['ip']=$fip;
			$_SESSION['gamecp']['move'][$ggid]['port']=$port;
			$_SESSION['gamecp']['move'][$ggid]['premode']=$premode;

			$_SESSION['gamecp']['move'][$ggid]['sidA']=$sidA;
			$_SESSION['gamecp']['move'][$ggid]['os']=$sosA;
			$_SESSION['gamecp']['move'][$ggid]['sidAport']=$sidAport;
			$_SESSION['gamecp']['move'][$ggid]['sidB']=$sidB;
			$_SESSION['gamecp']['move'][$ggid]['oldhfolder']="/home/$fname/";
			$_SESSION['gamecp']['move'][$ggid]['newhfolder']="/home/$fname/";
			$_SESSION['gamecp']['move'][$ggid]['oldfolder']="/home/$fname/$thesubdir";
			$_SESSION['gamecp']['move'][$ggid]['newfolder']="/home/$fname/$newsubdir";
			$_SESSION['gamecp']['move'][$ggid]['subdir']="$newsubdir";
			$_SESSION['gamecp']['move'][$ggid]['mstatcount']=0;

			/* zip it up */
			$this->ArchiveService($ggid);
		}

		$Event->EventLogAdd($fname, "User ". $fname. " server $ugid move from $sidA to $sidB started");			

		$smarty->assign("reply", $reply);
	}

	function MoveCheck($ggid, $machine=FALSE){
		global  $Event, $smarty, $GameCP;
		
		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2") return false;

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$GameCP->loadIncludes("linux");
		$Linux=new Linux();
		$fi=$_SESSION['gamecp']['move'][$ggid]['file'];
		$fname=$_SESSION['gamecp']['move'][$ggid]['user'];

		$moveStatus="";


		if($_SESSION['gamecp']['move'][$ggid]['os'] == "1"){ 
			if($_SESSION['gamecp']['move'][$ggid]['step'] =="1"){
				$folder=str_replace('/', '\\', "\$MAINDIR".$_SESSION['gamecp']['move'][$ggid]['oldhfolder']);
				$folderf=str_replace('/', '\\', "\$MAINDIR".$_SESSION['gamecp']['move'][$ggid]['oldfolder']);
				
				if($this->WindowsFileExists($_SESSION['gamecp']['move'][$ggid]['sidA'], $folder, "completebackup$ggid.tmp") == true){
					$archivesize=$this->WindowsFileSize($_SESSION['gamecp']['move'][$ggid]['sidA'], $folderf, $_SESSION['gamecp']['move'][$ggid]['file']);
					$_SESSION['gamecp']['move'][$ggid]['archivesize']=$archivesize;
					$Backend->Query($_SESSION['gamecp']['move'][$ggid]['sidA'], '', "deletefile:_:$folder\\completebackup$ggid.tmp");

					echo "<b>Copying service to new location...</b><br><br>";
					if($machine == false) echo "<img src='".url."/includes/core/javascript/jquery/ajax-loader2.gif' alt='Loading...' title='Loading...' >";
					
					$command="cd $folder\r\n";
					$command.="\$MAINDIRbin\wget.exe ftp://".$_SESSION['gamecp']['move'][$ggid]['user'].":".$_SESSION['gamecp']['move'][$ggid]['password']."@".$_SESSION['gamecp']['move'][$ggid]['sidA'].":".$_SESSION['gamecp']['move'][$ggid]['sidAport'].str_replace("/home/".$_SESSION['gamecp']['move'][$ggid]['user'] , "",$_SESSION['gamecp']['move'][$ggid]['oldfolder'])."/$fi\r\n";
					$command.="echo completed > completewget$ggid.tmp\r\n";
					$this->Exec($_SESSION['gamecp']['move'][$ggid]['user'], $_SESSION['gamecp']['move'][$ggid]['os'], $_SESSION['gamecp']['move'][$ggid]['sidB'], '', '', "wgetmove$ggid.bat", $command, true);

					$_SESSION['gamecp']['move'][$ggid]['step']="2";
					exit;
					

				} else {
					$archivesize=$this->WindowsFileSize($_SESSION['gamecp']['move'][$ggid]['sidA'], $folder, $_SESSION['gamecp']['move'][$ggid]['file']);
					$dlsize=$_SESSION['gamecp']['move'][$ggid]['foldersize'];
					$percent=round(($archivesize/1024)/($dlsize/1024)*100, 0);
					exit;

					echo "<b>Compressing ".$archivesize." out of ". $_SESSION['gamecp']['move'][$ggid]['foldersize']."</b><br>";
					if($percent <= "100") echo "<table><tr><td><div class='dlbg' style='text-align: left;'><div class='dlfg' style='width: ".$percent."%;'></div></div></td><td>%$percent</td></tr></table>";


					exit;

				}
			}
			if($_SESSION['gamecp']['move'][$ggid]['step'] =="2"){
				$folder=str_replace('/', '\\', "\$MAINDIR".$_SESSION['gamecp']['move'][$ggid]['newhfolder']);
				$folderf=str_replace('/', '\\', "\$MAINDIR".$_SESSION['gamecp']['move'][$ggid]['newfolder']);
				$folderfa=str_replace('/', '\\', "\$MAINDIR".$_SESSION['gamecp']['move'][$ggid]['oldfolder']);
				$_SESSION['gamecp']['move'][$ggid]['uploadsize']=$this->WindowsFileSize($_SESSION['gamecp']['move'][$ggid]['sidB'], $folder, $_SESSION['gamecp']['move'][$ggid]['file']);

				if($this->WindowsFileExists($_SESSION['gamecp']['move'][$ggid]['sidB'], $folder, "completewget$ggid.tmp") == true){
					$Backend->Query($_SESSION['gamecp']['move'][$ggid]['sidB'], '', "deletefile:_:$folder\\completewget$ggid.tmp");
					//$Backend->Query($_SESSION['gamecp']['move'][$ggid]['sidA'], '', "deletefile:_:$folderfa\\".$_SESSION['gamecp']['move'][$ggid]['file']);
					if($_SESSION['gamecp']['move'][$ggid]['uploadsize'] >= $_SESSION['gamecp']['move'][$ggid]['archivesize']){
						echo "<h3>Transfer complete, extracting...</h3>";
						if($machine == false) echo "<img src='".url."/includes/core/javascript/jquery/ajax-loader2.gif' alt='Loading...' title='Loading...' >";

						$command="cd $folder\r\n";
						$command.="mkdir $folderf\r\n";
						$command.="move ".$_SESSION['gamecp']['move'][$ggid]['file']." $folderf\r\n";
						$command.="cd $folderf\r\n";
						$command.="\$MAINDIRbin\gcpextract.exe ".$_SESSION['gamecp']['move'][$ggid]['file']." . \r\n";
						$command.="del /f ".$_SESSION['gamecp']['move'][$ggid]['file']."\r\n";
						$command.="echo completed > ../completextract$ggid.tmp\r\n";
						$_SESSION['gamecp']['move'][$ggid]['step'] ="3";
						$this->Exec($_SESSION['gamecp']['move'][$ggid]['user'], $_SESSION['gamecp']['move'][$ggid]['os'], $_SESSION['gamecp']['move'][$ggid]['sidB'], '', '', "wgetextract$ggid.bat", $command, true);
						exit;
					} else {
						echo "<h3>File download failed</h3>";
						$_SESSION['gamecp']['move'][$ggid]['failed']=true;
						exit;
					}

				} else {
					if(isset($_SESSION['gamecp']['move'][$ggid]['failed'])){
						echo "<h3>Move failed</h3>";
					} else {
						echo "<b>Transfering ". $_SESSION['gamecp']['move'][$ggid]['uploadsize']." out of ". $_SESSION['gamecp']['move'][$ggid]['archivesize']."</b><br>";
						$percent=round(($_SESSION['gamecp']['move'][$ggid]['uploadsize']/1024)/($_SESSION['gamecp']['move'][$ggid]['archivesize']/1024)*100, 0);
						if($percent <= "100") echo "<table><tr><td><div  class='dlbg' style='text-align: left;'><div class='dlfg' style='width: ".$percent."%;'></div></div></td><td>%$percent</td></tr></table>";
					}
					exit;
				}
			}
			if($_SESSION['gamecp']['move'][$ggid]['step'] =="3"){
				$folder=str_replace('/', '\\', "\$MAINDIR".$_SESSION['gamecp']['move'][$ggid]['newhfolder']);
				$folderf=str_replace('/', '\\', "\$MAINDIR".$_SESSION['gamecp']['move'][$ggid]['newfolder']);

				if(isset($_SESSION['gamecp']['move'][$ggid]['completed']) || $this->WindowsFileExists($_SESSION['gamecp']['move'][$ggid]['sidB'], $folder, "completextract$ggid.tmp") == true){
					
					$Backend->Query($_SESSION['gamecp']['move'][$ggid]['sidB'], '', "deletefile:_:$folder\\completextract$ggid.tmp");

					$df=explode("\t",$Backend->QueryResponse($_SESSION['gamecp']['move'][$ggid]['sidB'], '', "bin\du.exe:_:-s $folderf"));
					if($df[0] == $_SESSION['gamecp']['move'][$ggid]['foldersize']){

						if(!isset($_SESSION['gamecp']['move'][$ggid]['completed'])){
							$_SESSION['gamecp']['move'][$ggid]['completed']=true;

							$this->MoveFinish($ggid, $fname);

							echo "<h3>Finishing move, please wait...</h3>";
							if($machine == false) echo "<img src='".url."/includes/core/javascript/jquery/ajax-loader2.gif' alt='Loading...' title='Loading...' >";
						} else {
							if(!isset($_SESSION['gamecp']['move'][$ggid]['started'])){
								
								$GameCP->loadIncludes("control");
								$Control=new Control();
								$this->ConfigCreate($ggid);

								if(!$Control->Build($_SESSION['gamecp']['move'][$ggid]['game'], "add")) echo "Did not create service.";
								$Control->Usergame($_SESSION['gamecp']['move'][$ggid]['game'], "start");
								$_SESSION['gamecp']['move'][$ggid]['started']=true;
								$Event->EventLogAdd($fname, "User ". $fname. " server $ggid moved from ".$_SESSION['gamecp']['move'][$ggid]['sidA']." to ".$_SESSION['gamecp']['move'][$ggid]['sidB']);
							}
							echo "<h3>Completed</h3>";
							if($machine == false) echo "<script type='text/javascript'>window.location=\"". url . "/system/userservices.php?showsaved=true&mode=edit2&opt=edit&ggid=".$_SESSION['gamecp']['move'][$ggid]['game']."\";</script>"; 
						}

					} else {
						echo "<h3>Completed but folder sizes are not the same (".$df[0]." != ".$_SESSION['gamecp']['move'][$ggid]['foldersize'].") </h3>";
						$_SESSION['gamecp']['move'][$ggid]['failed']=true;
					}

					exit;
				} else {
					if(isset($_SESSION['gamecp']['move'][$ggid]['failed'])){
						echo "<h3>Move failed</h3>";
					} else {
						echo "<b>Extracting archive...</b><br>";
						if($machine == false) echo "<img src='".url."/includes/core/javascript/jquery/ajax-loader2.gif' alt='Loading...' title='Loading...' >";
					}
					exit;
				}
			}


		} else { 
			if($_SESSION['gamecp']['move'][$ggid]['step'] =="1"){
				$moveStatus=$Linux->Watch($_SESSION['gamecp']['move'][$ggid]['sidA'], $_SESSION['gamecp']['move'][$ggid]['game'], $_SESSION['gamecp']['move'][$ggid]['user']);
				if($moveStatus[0]){
					$currentsize=preg_split("/\s+/",$Backend->QueryResponse($_SESSION['gamecp']['move'][$ggid]['sidA'], '', "command:_:du -hbs ".$_SESSION['gamecp']['move'][$ggid]['oldfolder']."/$fi"));
					$_SESSION['gamecp']['move'][$ggid]['currentarchivesize']=$currentsize[0];
					$dlsize=$_SESSION['gamecp']['move'][$ggid]['foldersize'];
					$currentSize=$currentsize[0];
					$percent=round(($currentSize/1024)/($dlsize/1024)*100, 0);

					echo "<b>Compressing ".$_SESSION['gamecp']['move'][$ggid]['currentarchivesize']." out of ". $_SESSION['gamecp']['move'][$ggid]['foldersize']."</b><br>";
					if($percent <= "100") echo "<table><tr><td><div title='$title' class='dlbg' style='text-align: left;'><div title='$title' class='dlfg' style='width: ".$percent."%;'></div></div></td><td>%$percent</td></tr></table>";

				} else {
					$_SESSION['gamecp']['move'][$ggid]['step']="2";	

					$archivesize=preg_split("/\s+/", $Backend->QueryResponse($_SESSION['gamecp']['move'][$ggid]['sidA'], '', "command:_:du -hbs ".$_SESSION['gamecp']['move'][$ggid]['oldfolder']."/$fi"));
					$_SESSION['gamecp']['move'][$ggid]['archivesize']=$archivesize[0];

					echo "<b>Copying service to new location...</b><br><br>";
					if($machine == false) echo "<img src='".url."/includes/core/javascript/jquery/ajax-loader2.gif' alt='Loading...' title='Loading...' >";

					$GameCP->loadIncludes("linux");
					$Linux=new Linux();
					$cmd="mkdir -p ".$_SESSION['gamecp']['move'][$ggid]['newfolder']." ; cd ".$_SESSION['gamecp']['move'][$ggid]['newfolder']." ; if [ -f $fi ] ; then rm -f $fi; fi; wget ftp://".$_SESSION['gamecp']['move'][$ggid]['user'].":".$_SESSION['gamecp']['move'][$ggid]['password']."@".$_SESSION['gamecp']['move'][$ggid]['sidA'].":".$_SESSION['gamecp']['move'][$ggid]['sidAport'].str_replace("/home/".$_SESSION['gamecp']['move'][$ggid]['user'] , "",$_SESSION['gamecp']['move'][$ggid]['oldfolder'])."/$fi";
					$Linux->Screen($_SESSION['gamecp']['move'][$ggid]['sidB'], $cmd, $_SESSION['gamecp']['move'][$ggid]['game'], $_SESSION['gamecp']['move'][$ggid]['user'], true);

					exit;
				}
			}
			if($_SESSION['gamecp']['move'][$ggid]['step'] =="2"){
				$moveStatus=$Linux->Watch($_SESSION['gamecp']['move'][$ggid]['sidB'], $_SESSION['gamecp']['move'][$ggid]['game'], $_SESSION['gamecp']['move'][$ggid]['user']);
				$uploadsize=preg_split("/\s+/",$Backend->QueryResponse($_SESSION['gamecp']['move'][$ggid]['sidB'], '', "command:_:du -hbs ".$_SESSION['gamecp']['move'][$ggid]['newfolder']."/$fi"));
				$_SESSION['gamecp']['move'][$ggid]['lastuploadsize']=$_SESSION['gamecp']['move'][$ggid]['uploadsize'];
				$_SESSION['gamecp']['move'][$ggid]['uploadsize']=$uploadsize[0];


				if(!$moveStatus[0]){

					if($_SESSION['gamecp']['move'][$ggid]['lastuploadsize'] == $_SESSION['gamecp']['move'][$ggid]['uploadsize']) $_SESSION['gamecp']['move'][$ggid]['mstatcount']++;
					if($_SESSION['gamecp']['move'][$ggid]['mstatcount'] >= 10){
						echo "<h3>Transfer incomplete, uploaded ".$_SESSION['gamecp']['move'][$ggid]['uploadsize']." out of ".$_SESSION['gamecp']['move'][$ggid]['archivesize']."</h3>";
					} else {

						echo "<h3>Archive complete, transfering to new location...</h3>";
						if($machine == false) echo "<img src='".url."/includes/core/javascript/jquery/ajax-loader2.gif' alt='Loading...' title='Loading...' >";

						if($_SESSION['gamecp']['move'][$ggid]['uploadsize'] >= $_SESSION['gamecp']['move'][$ggid]['archivesize']){
							$_SESSION['gamecp']['move'][$ggid]['step']="3";	

							$extract="cd ".$_SESSION['gamecp']['move'][$ggid]['newfolder']." ; tar zxvf $fi  ; rm -f $fi ; chown -R ".$_SESSION['gamecp']['move'][$ggid]['user']." *";

							$GameCP->loadIncludes("linux");
							$Linux=new Linux();
							$Linux->Screen($_SESSION['gamecp']['move'][$ggid]['sidB'], $extract, $_SESSION['gamecp']['move'][$ggid]['game'], $_SESSION['gamecp']['move'][$ggid]['user']);
							exit;
						} 
					}

				}else{
					echo "<b>Transfering ". $_SESSION['gamecp']['move'][$ggid]['uploadsize']." out of ". $_SESSION['gamecp']['move'][$ggid]['archivesize']."</b><br>";
					$percent=round(($_SESSION['gamecp']['move'][$ggid]['uploadsize']/1024)/($_SESSION['gamecp']['move'][$ggid]['archivesize']/1024)*100, 0);
					if($percent <= "100") echo "<table><tr><td><div title='$title' class='dlbg' style='text-align: left;'><div title='$title' class='dlfg' style='width: ".$percent."%;'></div></div></td><td>%$percent</td></tr></table>";

				}
			}
			if($_SESSION['gamecp']['move'][$ggid]['step'] =="3"){
				$moveStatus=$Linux->Watch($_SESSION['gamecp']['move'][$ggid]['sidB'], $_SESSION['gamecp']['move'][$ggid]['game'], $_SESSION['gamecp']['move'][$ggid]['user']);
				if($moveStatus[0] && !isset($_SESSION['gamecp']['move'][$ggid]['failed'])){

					$oldsize=$_SESSION['gamecp']['move'][$ggid]['newfoldersize'];
					$_SESSION['gamecp']['move'][$ggid]['newfoldersize']=$Backend->QueryResponse($_SESSION['gamecp']['move'][$ggid]['sidB'], '', "command:_:du -hbs ".$_SESSION['gamecp']['move'][$ggid]['newfolder']."");
					$fs= preg_split("/\s+/", $_SESSION['gamecp']['move'][$ggid]['newfoldersize']);
					$fs2= preg_split("/\s+/", $_SESSION['gamecp']['move'][$ggid]['foldersize']);
					echo "<b>Extracting archive ($fs2[0])</b><br>";

					$target=$fs2[0]+$_SESSION['gamecp']['move'][$ggid]['foldersize'];
					$percent=round(($fs[0])/($target)*100, 0);
					if($percent <= "100") echo "<table><tr><td><div title='$title' class='dlbg' style='text-align: left;'><div title='$title' class='dlfg' style='width: ".$percent."%;'></div></div></td><td>%$percent</td></tr></table>";
				}


				if(!$moveStatus[0] || $_SESSION['gamecp']['move'][$ggid]['completed'] == true){

					if(!isset($_SESSION['gamecp']['move'][$ggid]['completed'])){
						$_SESSION['gamecp']['move'][$ggid]['completed']=true;

						$this->MoveFinish($ggid, $fname);

						echo "<h3>Finishing move, please wait...</h3>";
						if($machine == false) echo "<img src='".url."/includes/core/javascript/jquery/ajax-loader2.gif' alt='Loading...' title='Loading...' >";
					} else {
						if(!isset($_SESSION['gamecp']['move'][$ggid]['started'])){
							
							$GameCP->loadIncludes("control");
							$Control=new Control();
							$this->ConfigCreate($ggid);

							if(!$Control->Build($_SESSION['gamecp']['move'][$ggid]['game'], "add")) echo "Did not create service.";
							$Control->Usergame($_SESSION['gamecp']['move'][$ggid]['game'], "start");
							$_SESSION['gamecp']['move'][$ggid]['started']=true;
							$Event->EventLogAdd($fname, "User ". $fname. " server $ugid moved from $sidA to $sidB ");
							$Backend->Query($_SESSION['gamecp']['move'][$ggid]['sidB'], $winport, "command:_:rm -f /home/$fname/screenwatch".$_SESSION['gamecp']['move'][$ggid]['game'].".log /home/$fname/.screenrc.watch".$_SESSION['gamecp']['move'][$ggid]['game']."");
						}
						echo "<h3>Completed</h3>";
						if($machine == false) echo "<script type='text/javascript'>window.location=\"". url . "/system/userservices.php?showsaved=true&mode=edit2&opt=edit&ggid=".$_SESSION['gamecp']['move'][$ggid]['game']."\";</script>"; 
					}

				} else {


						$oldsize= preg_split("/\s+/", $oldsize);
					if($fs[0] == $oldsize[0] || $_SESSION['gamecp']['move'][$ggid]['failed'] == true){
						// done here not goin back
						echo "File extraction failed<br>";
						//$Backend->Query($_SESSION['gamecp']['move'][$ggid]['sidA'], '', "command:_:rm -f ".$_SESSION['gamecp']['move'][$ggid]['oldfolder']."/$fi /home/$fname/screenwatch".$_SESSION['gamecp']['move'][$ggid]['game'].".log /home/$fname/.screenrc.move".$_SESSION['gamecp']['move'][$ggid]['game']."");
						if(!isset($_SESSION['gamecp']['move'][$ggid]['failed'])) $Backend->Query($_SESSION['gamecp']['move'][$ggid]['sidA'], $winport, "command:_:rm -f /home/$fname/screenwatch".$_SESSION['gamecp']['move'][$ggid]['game'].".log /home/$fname/.screenrc.watch".$_SESSION['gamecp']['move'][$ggid]['game']."");
						$_SESSION['gamecp']['move'][$ggid]['failed']=true;

					} else {
						//echo "Files are still extracting, please wait... ".$_SESSION['gamecp']['move'][$ggid]['newfoldersize']." $fs[0] != $oldsize[0]<br>";
						//echo "Files are still extracting, please wait... ".$_SESSION['gamecp']['move'][$ggid]['newfoldersize']." $fs[0] != $oldsize[0]<br>";
					}
					// [00:11] <William|GCP> could likely stop, ask user what to do, option to roll back or leave or continue

				}
			}
		}	

		return $moveStatus;
	}

	function MoveFinish($ggid, $fname){
		global $GameCP, $Backend, $safesql;

		$serveruserA = $Backend->QueryResponse($_SESSION['gamecp']['move'][$ggid]['sidA'], '', "checkuser:_:$fname");
		if ($serveruserA){
			$GameCP->loadIncludes("user");
			$User=new User();
			$User->RemoveGame($_SESSION['gamecp']['move'][$ggid]['game'], "no", "no", "no", false, true, false);
		}

		$gameInfo=$this->GetService($ggid);
		$serverip=$_SESSION['gamecp']['move'][$ggid]['ip'];

		$GameCP->loadIncludes("ports");
		$Ports=new Ports();

		/* firewall */
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$GameCP->loadIncludes("user");
		$User=new User();

		$serverInfo=$Panel->GetServer($_SESSION['gamecp']['move'][$ggid]['sidA']);
		$sida = $serverInfo['sid'];
		$osa = $serverInfo['os'];
		$iptablesconfiga=$serverInfo['iptablesconf'];

		// close all old ports on the old machine
		$firewall_ports=unserialize($gameInfo['firewallports']);
		if(!is_array($firewall_ports)) $firewall_ports=array();
		$User->ExecFirewall($sida, $osa, $serverip, $firewall_ports, "delete", $iptablesconfiga);


		$portdiff=$_SESSION['gamecp']['move'][$ggid]['port']-$gameInfo['port'];
		$default_port=$gameInfo['port'];


		$serverInfo=$Panel->GetServer($_SESSION['gamecp']['move'][$ggid]['sidB']);
		$sidb = $serverInfo['sid'];
		$osb = $serverInfo['os'];
		$iptablesconfigb=$serverInfo['iptablesconf'];

		$queryport=$Ports->GetPort($queryport, $serverip, $default_port, $portdiff);
		
		foreach($ports as $p=>$t) $ports[$p]['port']=$Ports->GetPort($t['port'], $serverip, $default_port, $portdiff);
		$regular_ports=array(array("cvar" =>"PORT", "port"=>$_SESSION['gamecp']['move'][$ggid]['port']),array("cvar"=>"QUERYPORT","port"=>$queryport)); 
		$all_ports=array_merge($regular_ports, $ports);

		$open_ports=array();
		foreach($all_ports as $o->$p)$open_port[]=$p['port'];
		$User->ExecFirewall($sidb, $osb, $_SESSION['gamecp']['move'][$ggid]['ip'], $open_ports, "open", $iptablesconfigb);


		sql_query("UPDATE `usergames` SET 
						ip = '".$_SESSION['gamecp']['move'][$ggid]['ip']."',
						port='".$_SESSION['gamecp']['move'][$ggid]['port']."',
						premode='".$_SESSION['gamecp']['move'][$ggid]['premode']."',
						queryport='$queryport', firewallports='".serialize($all_ports)."'
					WHERE `id` = '".$_SESSION['gamecp']['move'][$ggid]['game']."' LIMIT 1 ;") or die(mysql_error());
	}

	function ArchiveService($ggid){
		global $GameCP;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$userGame=$this->GetService($ggid);
		$serverInfo=$Panel->GetServer($userGame['sid']);
		$folder=$Panel->GetServiceFolder($ggid, true);

		$fname=$userGame['username'];
		$sid=$serverInfo['sid'];
		$os=$serverInfo['os'];

		if($os != "1"){
			$file=explode("\n",$Backend->QueryResponse($sid, '', "command:_:ls -shx1la --time-style iso $folder", $fname));
			$addto="";
			for ($i = 0; $i < count($file); $i++){
				$file[$i] = trim($file[$i]);
				$infoArray = preg_split("/\s+/", $file[$i]);	
				if(isset($infoArray[1])){
					$dir=substr($infoArray[1], 0, 1);
					if($dir == "d" && $infoArray[8] != "." && $infoArray[8] != ".." && substr($infoArray[8], 0, 1) == ".") $addto.=$infoArray[8]." ";
				}
			}
			$movecmd="cd $folder ; if [ -f backup$ggid.tar.gz ] ; then rm -f backup$ggid.tar.gz; fi ; tar -pczf backup$ggid.tar.gz * $addto";
			$GameCP->loadIncludes("linux");
			$Linux=new Linux();
			$Linux->Screen($sid, $movecmd, $ggid, $fname, true);
		} else {
			$fold=str_replace("/","\\", "\$MAINDIR$folder");
			$folda=str_replace("/","\\", "\$MAINDIR/home/$fname");
			$thesubdir=$Panel->GetServiceFolder($ggid, false);

			$command="cd $folda\r\n";
			$command.="\$MAINDIRbin\gcpcompress.exe $fold backup$ggid.tar\r\n";
			$command.="move backup$ggid.tar $thesubdir\r\n";
			$command.="echo completed > completebackup$ggid.tmp\r\n";
			$this->Exec($fname, $os, $sid, '', '', "move$ggid.bat", $command, true);
		}
	}

	function ArchiveServiceComplete($ggid){
		global $GameCP;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$userGame=$this->GetService($ggid);
		$serverInfo=$Panel->GetServer($userGame['sid']);
		$folder=$Panel->GetServiceFolder($ggid, true);
		$servicefolder=$Panel->GetServiceFolder($ggid, false);

		$fname=$userGame['username'];
		$sid=$serverInfo['sid'];
		$os=$serverInfo['os'];

		$userInfo=$Panel->GetUser('', $fname);

		if($os == "1"){
			$fi="backup$ggid.tar";
			$folder="\$MAINDIRhome\\$fname";
			if($this->WindowsFileExists($sid, $folder, "completebackup$ggid.tmp") == true){
				$Backend->Query($sid, '', "deletefile:_:$folder\\completebackup$ggid.tmp");
				return "ftp://".$fname.":".$userInfo['password']."@".$sid.":".$serverInfo['ftpport']."/$servicefolder$fi\r\n";
			}
		} else {
			$fi="backup$ggid.tar.gz";
			$folder="/home/$fname";
			$GameCP->loadIncludes("linux");
			$Linux=new Linux();
			$moveStatus=$Linux->Watch($sid, $ggid, $fname);
			if(!$moveStatus[0]) return "ftp://".$fname.":".$userInfo['password']."@".$sid.":".$serverInfo['ftpport']."/$servicefolder$fi";
		}
		return false;
	}

	function ExecAllGames($idd, $command){
		global  $GameCP, $safesql;
		$row = sql_query($safesql->query("SELECT distinct(I.sid), U.name, S.os FROM users U, iptable I, usergames UG, servers S WHERE U.id= '%i' AND I.ip = UG.ip AND UG.cid=U.id AND I.sid = S.sid", array($idd))) or die(mysql_error());
		while($srv=mysql_fetch_array($row)) $this->Exec($srv[1], $srv[2], $srv[0], '', $srv[1].".sh", $srv[1].".bat", $command);
	}

	function GetService($ugid){
		global $safesql;
		if(isset($this->ugstore) && is_array($this->ugstore2) && array_key_exists($ugid, $this->ugstore2)){
			return $this->ugstore2[$ugid];
		} else {

			/* Verfiy the game is owned by the user */
			if(isset($_SESSION['gamecp']['userinfo']['username'])) $sesname=$_SESSION['gamecp']['userinfo']['username']; 

			$cQuery = "";
			if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes"){
				$cQuery  = "AND U.id = '".$_SESSION['gamecp']['userinfo']['id']."'";
			}elseif (isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "0") $cQuery  = "AND U.name = '$sesname'";
			
			$gameInfoQ = sql_query($safesql->query("SELECT I.sid, U.username,
				UG.sci, UG.ip, UG.port, UG.startmap, UG.maxplayers, UG.config, UG.subdirectory, UG.addons,
				UG.scontrol,
				UG.premode,
				UG.gametype,
				UG.rconpass,
				G.queryport,
				UG.vars as 'ugvars',
				UG.customvars,

				G.game, G.fsgame, G.gcode, G.install, G.id as 'gameid',


				G.winappdir, G.winexec, G.startmode as 'gamestartmode', G.winparams as 'winstartmode', G.vars,
				G.port as 'defaultport', G.basepath,

				I.useinternal, I.internal,
				S.winuser, S.winadminpass, S.winport, S.os, S.sid,
				
				UG.queryport as 'ugqueryport',

				G.scontrolname, UG.affinity, UG.active as 'gactive', U.active, UG.status,
				UG.start_time,
				UG.use_sched,
				UG.end_time,
				UG.priority, U.id as 'cid', U.limit as 'flimit', G.postmode, G.winpostmode,G.winpremode, UG.pubpriv,
				UG.files,
				G.files AS 'gamefiles',
				G.pidstop,
				G.exestop,
				G.exedir, UG.rconpass, G.mapimgdir, G.wininstall, UG.servername, G.hostname, UG.branding, UG.brandingon, UG.defaultinfo, UG.lastplayers, UG.lastplytime, G.gameQcode, G.name as 'gamename',
				G.stopmode, UG.gid,
				G.lsofcheck, UG.updatestatus,
				G.winstopmode,
				G.stopconsole,
				G.winstopconsole, 
				UG.eac,
				UG.eactype,
				G.premode as 'gamepremode',
				G.winpremode as 'gamewinpremode', G.protocol, UG.firewallports


				FROM 
					game G, usergames UG, users U, iptable I, servers S

				WHERE UG.id='%i'
					AND UG.gid=G.id 
					AND U.id = UG.cid
					AND I.ip=UG.ip 
					AND I.sid = S.sid $cQuery", array($ugid)), "stored user game info") or die(mysql_error());
			$gameInfo = mysql_fetch_array($gameInfoQ); 
			$this->ugstore2[$ugid]=$gameInfo;
			return $gameInfo;
		}
	}
	
	function GetUserGame($ugid){
		global $safesql;
		if(isset($this->ugstore) && array_key_exists($ugid, $this->ugstore)){
			return $this->ugstore[$ugid];
		} else {

			/* Verfiy the game is owned by the user */
			if(isset($_SESSION['gamecp']['userinfo']['username'])) $sesname=$_SESSION['gamecp']['userinfo']['username']; 

			$cQuery = "";
			if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes"){
				$cQuery  = "AND U.id = '".$_SESSION['gamecp']['userinfo']['id']."'";
			}elseif (isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "0") $cQuery  = "AND U.name = '$sesname'";
			
			$gameInfoQ = sql_query($safesql->query("SELECT * FROM usergames WHERE id = '%i' LIMIT 1;", array($ugid))) or die(mysql_error());
			$gameInfo = mysql_fetch_assoc($gameInfoQ); 
			$this->ugstore[$ugid]=$gameInfo;
			return $gameInfo;
		}
	}

	/**
	 * replaces paramaters in {if}{/if}
	 * This is primarly used in the startmodes
	 * @param string $winparams this is the string to replace variables in
	 * @param array $paramList the array of variables and values to replace
	 */
	function ReplaceParams($winparams, $paramList){
		/* this is a lame attempt to do this
			if anyone has a better way please help me out! 
			(SMARTYS AS WE NOW DO< MWAUAHAHASDFASDF)
		*/

			preg_match_all("|{if[^}]+}(.*){/[^}]+}|U",
				$winparams,
				$out, PREG_PATTERN_ORDER);

			foreach($out[0] as $var => $val){
				$variableA=explode("}", $val);
				$variable=str_replace("{if $", "", $variableA[0]);
				$fulline=$out[0][$var];
				$replaceline=$out[1][$var];

				$variable=trim($variable);


				if(preg_match("/==/i", $variable)){
					$values=explode("==", $variable);
					if(array_key_exists(trim($values[0]), $paramList)){
						if(trim($values[1]) == $paramList[trim($values[0])]) $winparams = str_replace($fulline, $replaceline, $winparams);
					}
				}elseif(preg_match("/!=/i", $variable)){
					$values=explode("!=", $variable);
					if(array_key_exists(trim($values[0]), $paramList)){
						if(trim($values[1]) != $paramList[trim($values[0])]) $winparams = str_replace($fulline, $replaceline, $winparams);
					}
				}elseif(preg_match("/>/i", $variable)){
					$values=explode(">", $variable);
					if(array_key_exists(trim($values[0]), $paramList)){
						if(trim($values[1]) > $paramList[trim($values[0])]) $winparams = str_replace($fulline, $replaceline, $winparams);
					}
				}elseif(preg_match("/</i", $variable)){
					$values=explode("<", $variable);
					if(array_key_exists(trim($values[0]), $paramList)){
						if(trim($values[1]) < $paramList[trim($values[0])]) $winparams = str_replace($fulline, $replaceline, $winparams);
					}
				}
				
				if(!array_key_exists($variable, $paramList) || $paramList[$variable] == ""){
					$winparams = str_replace($fulline, "", $winparams);
				} else $winparams = str_replace($fulline, $replaceline, $winparams);

			}

		return $winparams;
	}

	function ReplaceAllVars($ugid, $data){
		global $GameCP, $safesql, $smarty;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if(!$ugid) return $Panel->Error("Service id is missing $ugid"); 
		
		$ugameInfo=$this->GetUserGame($ugid);
		$dataq=$this->GetService($ugid);

		if(!is_array($ugameInfo)) return $Panel->Error("Unable to locate service #$ugid");

		$subdirectory=$ugameInfo['subdirectory'];
		$RCONPASSWORD=$ugameInfo['rconpass'];
		$fmaxclients=$ugameInfo['maxplayers'];
		$fip=$ugameInfo['ip'];
		$fport=$ugameInfo['port'];
		$fpubpriv=$ugameInfo['pubpriv'];
		$gid=$ugameInfo['gid'];
		$all_ports=unserialize($ugameInfo['firewallports']);
		if(!is_array($all_ports)) $all_ports=array();

		$MAXPLAYERS=$fmaxclients;
		$IP = $fip;
		$PORT = $fport;

		$userInfo=$Panel->GetUser($ugameInfo['cid']);
		$fname=$userInfo['name'];
		$cuserInfo=$userInfo;

		$serverDetails=$Panel->GetServer('', $fip);
		$sid=$serverDetails['sid'];
		$os=$serverDetails['os'];
		$machineVars=unserialize($serverDetails['cvars']);
		if($os == "1"){ 
			if($dataq['winpremode']){
				$premode = $dataq['winpremode'];
			}elseif($dataq['gamewinpremode']){
				$premode = $dataq['gamewinpremode'];
			} else $premode="";

			if($dataq['sci']){
				$startmode = $dataq['sci'];
			}elseif($dataq['winstartmode']){
				$startmode = $dataq['winstartmode'];
			} else $startmode="";
		} else {
			if($dataq['premode']){
				$premode = $dataq['premode'];
			}elseif($dataq['gamepremode']){
				$premode = $dataq['gamepremode'];
			} else $premode="";

			if($dataq['sci']){
				$startmode = $dataq['sci'];
			}elseif($dataq['gamestartmode']){
				$startmode = $dataq['gamestartmode'];
			} else $startmode="";
		}

		if(is_array($machineVars)){
			foreach($machineVars as $ma => $va) $data = str_replace("\$MachineVar".strtoupper($ma), $va, $data);
		}

		$ipInfo=$Panel->GetIP($fip);
		$useinternal=$ipInfo['useinternal'];
		if($useinternal == "1" && $ipInfo['internal'] !=""){
			$gameip=$ipInfo['internal'];
		} else $gameip=$fip;

		$gameInfoQ = sql_query($safesql->query("SELECT fsgame, install, map, hostname, website, motd, protocol, config, vars, customvars, port, maxplayers, basepath, hostname, wininstall, game, installfile, winappdir, ports FROM game WHERE id = '%i' LIMIT 1;", array($gid))) or die(mysql_error());
		$gameInfo = mysql_fetch_array($gameInfoQ);

		$installdir=$gameInfo['install'];
		$wininstalldir=$gameInfo['winappdir'];

		$BASEPATH="";

		if($os == "1"){
			if($wininstalldir){
				$BASEPATH = "\$MAINDIRgames/". $wininstalldir."/";
				$BASEPATH=str_replace("/", "\\", $BASEPATH);
			}
		} else {
			if($gameInfo['basepath']){
				$BASEPATH=$gameInfo['basepath'];
			} elseif($installdir) $BASEPATH = "/usr/local/games/". $installdir."/";
		}
		
		if($subdirectory == "yes"){ 
			if(ipsubdir == "true"){
				$thesubdir=$fip."-".$fport;
			} else $thesubdir="service".$ugid;
		} else $thesubdir="";

		if($thesubdir){
			$HOMEPATH="/home/".$fname."/".$thesubdir;
		} else $HOMEPATH= "/home/" . $fname;

		if($os == "1"){ 
			$HOMEPATH=ltrim($HOMEPATH, "/");
			$appdir=$gameInfo['winappdir'];
			$insdir=$gameInfo['wininstall'];
			if($wininstalldir) $HOMEPATH=$HOMEPATH."/$wininstalldir";
			$HOMEPATH="\$MAINDIR".$HOMEPATH;
			$HOMEPATH=str_replace("/", "\\", $HOMEPATH);
			$ServerPath=str_replace("/", "\\", "\$MAINDIRhome/$fname/$thesubdir/".$gameInfo['winappdir']);	
		} else {
			$appdir=$gameInfo['install'];
			$insdir=$gameInfo['installfile'];
			if($installdir) $HOMEPATH=$HOMEPATH."/$installdir";
			$ServerPath=str_replace("//", "/", "/home/$fname/$thesubdir/".$gameInfo['install']);
		}

		if(strtolower($fpubpriv) == "private"){
			$game_pubpriv_bool_value="1";
		} else $game_pubpriv_bool_value="0";

		$vars			= $this->DoUnserialize($gameInfo['vars']);
		$ugvars			= $this->DoUnserialize($ugameInfo['vars']);
		$cvars			= $this->MergeVars($vars, $ugvars, true);

		$ugcvars		= $this->DoUnserialize($ugameInfo['customvars']);
		$defaultinfo	= $this->DoUnserialize($ugameInfo['defaultinfo']);
		$addons			= $this->DoUnserialize($ugameInfo['addons']);


		if($ugameInfo['brandingon'] == "1" && !preg_match("/".str_replace("[", "\[", $ugameInfo['branding'])."/i", $defaultinfo['HOSTNAME'])) $defaultinfo['HOSTNAME'] = $ugameInfo['branding'] ." ". $defaultinfo['HOSTNAME'];

		$all_vars=array(
			"ServerPath" => $ServerPath,
			"GAMETYPE" => $ugameInfo['gametype'],
			"EXTERNALIP" => $ugameInfo['ip'],
			"INTERNALIP" => $ipInfo['internal'],
			"IP" => $gameip,
			"PORT" => $ugameInfo['port'],
			"MAXPLAYERS" => $ugameInfo['maxplayers'],
			"HUNKMEGS" => "54",
			"STARTMAP" => $ugameInfo['startmap'],
			"USERNAME" => $userInfo['name'],
			"PASSWORD" => $userInfo['password'],
			"USERBILLINGID" => $userInfo['billingid'],
			"HOMEPATH" => $HOMEPATH,
			"BASEPATH" => $BASEPATH,
			"APPDIR" => $appdir,
			"BOOLPUBPRIV" => $game_pubpriv_bool_value,
			"PUBPRIV" => $game_pubpriv_bool_value,
			"GAMEID" => $gid,
			"SERVICEID" => $ugid,
			"USEREMAIL" => $cuserInfo['email'],
			"RCONPASSWORD" => $ugameInfo['rconpass'],
			"SERVERCONFIG" => $ugameInfo['config'],
			"PreMode" => $premode,
			"PREMODE" => $premode,
			"INSTALLREPO" => $insdir,
			"SCONTROL" => "service$ugid",
			"LOGFILE" => $ugameInfo['logfile'],
			"STARTMODE" => $startmode,
			"CID" => $ugameInfo['cid'],
			'QUERYPORT' => $ugameInfo['queryport'],
			'SERVICEBILLINGID' => $ugameInfo['billingid'],
			'EAC' => $ugameInfo['eac']
		);
		

		// extract the variables 
		$ugtmpcvars=array();
		foreach($ugcvars as $ug => $cv) $ugtmpcvars[$cv['cvar']]=$cv['value'];
		
		
		$cv=array();
		foreach($cvars as $cid => $cvar){
			if($cvar['cvar']) $cv[$cvar['cvar']]=$cvar['value'];
		}
	
		$ports=array();
		if(count($all_ports) > 0){
			foreach($all_ports as $a=>$p) $ports[$p['cvar']]=$p['port'];
		}

		$data_values=array_merge($all_vars, $defaultinfo, $cv, $addons, $ugtmpcvars,$ports);
		$smarty->assign('Game', $dataq);
		$smarty->assign('Service', $ugameInfo);
		$smarty->assign('User', $userInfo);
		$smarty->assign('Machine', $serverDetails);
		$smarty->assign('Ports', $ports);

		foreach($data_values as $cid => $cvar) $smarty->assign($cid, $cvar);
		$data=$smarty->fetch('string:'.$data);
		
		// do after to preserve vars
		foreach($data_values as $cid => $cvar) $data = str_replace("\$".$cid, $cvar, $data);
		


		return $data;
	}
}

?>