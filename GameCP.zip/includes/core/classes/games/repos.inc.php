<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Repos{
	var $backend;
	var $game;
	var $repo_id;
	var $run_file="repository_";

	function __construct(){
		global $GameCP;
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$this->backend=new Backend();
		$GameCP->loadIncludes("game");
		$this->game=new Game();

	}

	function HealthCheck($row, $repolist, $fix=false, $action=false){
		global $GameCP, $safesql;

		$this->repo_id=$row['id'];
		$masterinfo=array();
		

		$dosync=false;

		$row['health']=array();
		foreach($repolist as $r=>$rsid){
			$row['health'][$rsid['sid']]=array();

			if($rsid['os'] == "1"){
				$repofolder=$row['winrepo'];
				$lastsize=$row['winsize'];
				$master=masterrepowin;
				$syncmaster=$row['syncmasterwin'];
			} else {
				$repofolder=$row['linuxrepo'];
				$lastsize=$row['linuxsize'];
				$master=masterrepolinux;
				$syncmaster=$row['syncmasterlinux'];
			}
			if($master == $rsid['id'] && $syncmaster == '0'){
				$dosync=false;
			} else $dosync=true;

			$repofolder=$this->game->FinalInstall($rsid['os'], $repofolder);

			if($action == 'reinstall' && $dosync) $this->backend->QueryResponse($rsid['sid'], $rsid['winport'], "deldir:_:$repofolder");

			if($this->game->CheckInstallFiles($rsid['sid'], $rsid['winport'], $rsid['os'], $repofolder)){
				if($rsid['os'] == "1"){
					$df=explode("\t",$this->backend->QueryResponse($rsid['sid'], $rsid['winport'], "bin\du.exe:_:-bs $repofolder"));
				} else $df=explode("\t",$this->backend->QueryResponse($rsid['sid'], $rsid['winport'], "command:_:du -bs $repofolder"));

				if(preg_match("/Remote down/s", $df[0])){
					$row['health'][$rsid['sid']]['repocheck']="Remote offline";
					sql_query($safesql->query("UPDATE gameupdates SET status='2', lastran='".time()."', `log`='' WHERE id='%i'", array($row['id'])));

				} elseif($df[0] == "0" || $df[0] == "4096"){
					$row['health'][$rsid['sid']]['repocheck']="Repository is empty";
				} else if(!$df[0]){
					$row['health'][$rsid['sid']]['repocheck']="Unable to determin repository size";
				} else if(!$lastsize){
					$row['health'][$rsid['sid']]['repocheck']="No last known repository size";
				} else if($df[0] != $lastsize){
					$row['health'][$rsid['sid']]['repocheck']="Repository size does not match last known size";
				} else {
					$md5sums=json_decode($row['md5sums'], true);
					$md5res=array();
					if(is_array($md5sums) && count($md5sums) >0){
						if(isset($md5sums[$master])){
							$mymaster=$md5sums[$master];
							if(isset($md5sums[$rsid['sid']])){
								$mymd5=$md5sums[$rsid['sid']];
								foreach($mymd5 as $file => $md5){
									if(isset($mymaster[$file])){
										if($mymaster[$file] != $md5) $md5res[$rsid['sid']][$file]['status']='Invalid md5';
									} else $md5res[$rsid['sid']][$file]['status']='Missing from master repository';
								}
								foreach($mymaster as $file => $md5){
									if(!isset($mymd5[$file])) $md5res[$rsid['sid']][$file]['status']='Missing from repository';
								}
							}
						}						
					} else $row['health'][$rsid['sid']]['repocheck']="MD5 check not completed";
					if(count($md5res) == '0') $md5res='OK';
					$row['health'][$rsid['sid']]['md5check']=$md5res;

					$row['health'][$rsid['sid']]['repocheck']="OK";
				}
			} else {
				$row['health'][$rsid['sid']]['repocheck']="Missing repository folder";
			}
			if($fix != false && $dosync) $row['health'][$rsid['sid']]['result']=$this->RunFix($row['health'][$rsid['sid']]['repocheck'], $rsid['sid'], $rsid['winport'], $rsid['os'], $repofolder, $row, $fix);
		}

		if($fix == 'start'){
			sql_query($safesql->query("UPDATE gameupdates SET status='1', lastran='".time()."', `log`='' WHERE id='%i'", array($row['id'])));
		}else if($fix =='check'){
			sql_query($safesql->query("UPDATE gameupdates SET lastran='".time()."', `log`='%s' WHERE id='%i'", array(json_encode($row['health']),$row['id'])));
			$completed=true;
			foreach($row['health'] as $h => $r){
				echo "<div class='ajaxlog'><h3>".$h. "</h3>" . nl2br(substr($GameCP->whitelist($r['result']['log'], 'web'), strlen($r['result']['log'])-348))."</div>";
				if($r['result']['status'] != 'completed') $completed=false;
			}
			if($completed){
				sql_query($safesql->query("UPDATE gameupdates SET status='2' WHERE id='%i'", array($row['id'])));
				echo "Update completed, checking files.";
			}
		}else if($fix =='md5check'){
			sql_query($safesql->query("UPDATE gameupdates SET status='0', lastran='".time()."' WHERE id='%i'", array($row['id'])));

			$md5result=array();
			foreach($repolist as $r=>$rsid){
				if($rsid['os'] == "1"){
					$repofolder=$row['winrepo'];
				} else $repofolder=$row['linuxrepo'];
				$repofolder=$this->game->FinalInstall($rsid['os'], $repofolder);

				$md5result[$rsid['sid']]=$this->RunMD5Checks($rsid, $repofolder);

				if(masterrepolinux == $rsid['sid']) $this->RunSizechecks($rsid, $repofolder,$row['id']);
				if(masterrepowin == $rsid['sid']) $this->RunSizechecks($rsid, $repofolder,$row['id']);
			}

			sql_query($safesql->query("UPDATE gameupdates SET `md5sums`='%s' WHERE id='%i'", array(json_encode($md5result),$row['id'])));
		
			echo "Update completed.";
		}

		return $row;
	}

	function GetMD5DirectoryList($sid, $winport, $os, $folder){
		$wheremai=$this->backend->QueryResponse($sid, $winport, "command:_:echo \$MAINDIR");
		$res=$this->backend->QueryResponse($sid, $winport, "directorymd5:_:".$folder);
		if($os=="1"){
			$n=array();
			$r=explode("\n", $res);
			foreach($r as $i=>$a){
				if($a){
					$b=explode("::", $a);
					if($b[0] && $b[1]) $n[trim(str_replace($wheremai, '', $b[0]))]=trim($b[1]);
				}
			}
			return $n;
		} else { 
			$res=json_decode($res, true);
			$res1=array();
			foreach($res as $i=>$d) $res1[str_replace($wheremai, '', $d)]=$i;
			return $res1;
		}
	}

	function RunSizechecks($rsid, $repofolder, $id){
		global $safesql;

		if($rsid['os'] == "1"){
			$df=explode("\t",$this->backend->QueryResponse($rsid['sid'], $rsid['winport'], "bin\du.exe:_:-bs $repofolder"));
			sql_query($safesql->query("UPDATE gameupdates SET `winsize`='%i' WHERE id='%i'", array($df[0],$id)));
		} else {
			$df=explode("\t",$this->backend->QueryResponse($rsid['sid'], $rsid['winport'], "command:_:du -bs $repofolder"));
			sql_query($safesql->query("UPDATE gameupdates SET `linuxsize`='%i' WHERE id='%i'", array($df[0],$id)));
		}
	}

	function RunMD5Checks($rsid, $repofolder){
		return $this->GetMD5DirectoryList($rsid['sid'], $rsid['winport'], $rsid['os'], $repofolder);
	}

	function RunFix($fix, $sid, $winport, $os, $repofolder, $row, $mode){
		if($mode == 'start'){
			switch($fix){
				case "Missing repository folder":
					$result=$this->backend->QueryResponse($sid, $winport, "mkdir:_:$repofolder");
				break;
			}

			if($os == "1"){
				$command=$row['wincommand'];
			} else $command=$row['command'];

			if($row['steamid'] > "0"){
				require_once(path."/includes/core/classes/games/steamcmd.inc.php");
				$SteamCMD=new SteamCMD($row['steamid'], $row['steammod']);
				$cmdscript='steamcmd'.time().'.txt';
				if($os =="1"){
					$homepath=$repofolder."\\";
				} else $homepath=$repofolder."/";

				$cmdline=$SteamCMD->GetCommand($os, $homepath, $cmdscript);
				if($cmdline[0] && $cmdline[1]){
					$this->backend->QueryResponse($sid, '', "writefile:_:$homepath".$cmdscript.":_:".$cmdline[0], '');
					if($os == "1"){
						$cmdel="del /f $cmdscript\r\n";
					} else $cmdel="rm -f f $cmdscript\r\n";
					$command=$cmdline[1]."\r\n".$cmdel.$command;
				}
			}



			return $this->Exec('', $os, $sid, $winport, $command, true, $this->run_file.$this->repo_id, $this->run_file.$this->repo_id.".log");
		} else if($mode == 'check') return $this->CheckFix($fix, $sid, $winport, $os, $repofolder, $row, $mode);
	}

	function CheckFix($fix, $sid, $winport, $os, $repofolder, $row, $fix){
		if($row['status'] == "1"){
			$this->repo_id=$row['id'];
			return $this->CheckBackgroundTask($sid, $os);
		} 
	}


	function Exec($name, $os, $sid, $winport, $command, $detach, $screenname=false, $logfile=false){
		return $this->game->Exec($name, $os, $sid, $winport, $this->run_file.$this->repo_id.'.sh', $this->run_file.$this->repo_id.'.bat', $command, $detach, $screenname, $logfile);
	}


	function CheckBackgroundTask($sid, $os){
		global $GameCP;
		$status=array();
			$status=array();

			if($os == "1"){
				$log="\$MAINDIR".$this->run_file.$this->repo_id.".log";
				$status['log']=$this->backend->QueryResponse($sid, '', "readfile:_:$log");

				if(!$this->game->CheckInstallExists($sid, "\$MAINDIR".$this->run_file.$this->repo_id.'.bat', true)){
					$this->backend->Query($sid, '', "deletefile:_:$log");
					$status['status']='completed';
				} else {
					$status['status']='working';
				}
			} else {
				$GameCP->loadIncludes("linux");
				$Linux=new Linux();
				$updateStatus=$Linux->Watch($sid, $this->run_file.$this->repo_id, false, false, true, false);

				if(!$updateStatus[0]){
					$Linux->RemoveScreenLog($sid, $this->run_file.$this->repo_id);
					$this->backend->Query($sid, '', "command:_:rm -f \$MAINDIR/".$this->run_file.$this->repo_id.".sh screenwatchupdate.".$this->run_file.$this->repo_id.".log .screenrc.watchupdate.".$this->run_file.$this->repo_id);
					$status['status']='completed';
					$status['log']=$updateStatus[1];

				} else {
					$status['status']='working';
					$status['log']=$updateStatus[1];
				}
			}

		return $status;
	}


	function ManageRepo($id=false, $mode=false){
		if($id) $id="AND id='$id'";
		$result=array();

		$sql=sql_query("SELECT * FROM gameupdates WHERE type='2' $id");
		while($row = mysql_fetch_assoc($sql)){
			$result[]=$this->HealthCheck($row, $repolist, $mode);
		}

		return $result;
	}

}

?>