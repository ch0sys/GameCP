<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Bukkit{
	var $backend;
	var $game;
	var $api_url="http://api.bukget.org/3/plugins/";
	var $uggame, $ugfolder, $ugserver;

	function __construct($steamid=false, $steammod=false){
		global $GameCP;
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$this->backend=new Backend();
		$GameCP->loadIncludes("game");
		$this->game=new Game();
	}

	function SetUserDetails($ugid){
		global $GameCP;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$this->uggame=$Panel->GetUserGame($ugid);
		$this->ugfolder=$Panel->GetServiceFolder($ugid);
		$this->ugserver=$Panel->GetServer('', $this->uggame['ip']);
	}

	function GetList(){
		global $GameCP;

		$list=$GameCP->Send($this->api_url.'?fields=versions.filename,slug,plugin_name,description' ,array(), 'GET');
		if($data=json_decode($list, true)){
			return $data;8:06 AM
		} else return false;
	}

	function GetExistingList($ugid){
		$this->SetUserDetails($ugid);
		if($this->ugserver['os'] =="1"){
			//$this->backend->QueryResponse($sid, $winport, "mkdir:_:\$MAINDIR\\steamcmd", $user);
		} else {
			echo "get".$this->ugfolder;
			$list=$this->backend->QueryResponse($this->ugserver['sid'], $this->ugserver['winport'], "command:_:ls -x1 ".$this->ugfolder."plugins", $this->uggame['username']);
			echo $list;
		}
	}


	function Install($os, $sid, $winport, $user){
		$command="";
		if($os =="1"){
			$this->backend->QueryResponse($sid, $winport, "mkdir:_:\$MAINDIR\\steamcmd", $user);
		} else {
			$this->backend->QueryResponse($sid, $winport, "mkdir:_:\$MAINDIR//steamcmd", $user);
		}
	}

	function Update($os, $sid, $winport){
		if($os =="1"){
			$this->backend->QueryResponse($sid, $winport, "mkdir:_:\$MAINDIR\\steamcmd", $user);
		} else {
			$this->backend->QueryResponse($sid, $winport, "mkdir:_:\$MAINDIR//steamcmd", $user);
		}
	}


	function CheckPlugin($os, $sid, $winport){
		if($os =="1"){
			if($this->game->CheckInstallExists($sid, "\$MAINDIR\\steamcmd\\".$this->binary_windows) != true) return false;
		} else if(!trim($this->backend->QueryResponse($sid, $winport, "isfile:_:\$MAINDIR/steamcmd/".$this->binary_linux))) return false;
		return true;
	}

}



?>