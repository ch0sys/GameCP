<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class RSync{
	var $cid;
	var $sid;
	var $source;
	var $destination;
	var $ugid;
	var $remoteid;
	var $sync_data;
	var $compression;
	var $includes;
	var $excludes;
	var $weblist;
	var $os;
	var $ftpport='21';
	var $base;

	function Query($sid, $folder){
		global $GameCP;

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$serverInfo=$Panel->GetServer($sid);
		
		$infoArray=array();

		if($serverInfo['os'] == '1'){
			if(preg_match("/home/s", $folder)){
				$folder=str_replace("/", "\\", $folder);
				$pre='$MAINDIR';
			} else $pre='';

			$fl=$Backend->QueryResponse($sid, '', "filelist:_:$pre$folder");

			$file=str_replace(":_:", "GC_PC", $fl);
			$filelist=explode("::" , $file);
			foreach($filelist as $fi){
					$f=explode("GC_PC", $fi);
				if(isset($f[1])){
					if($f[3] == "d"){
						$infoArray[$f[0]]=$this->Query($sid, rtrim($folder,'\\').'\\'.$f[0]);
					} else $infoArray[$f[0]]=$f[1];
				}
			}

		} else {
			$filelist=explode("\n", trim($Backend->QueryResponse($sid, '', "command:_:ls -sx1 $folder")));
			foreach($filelist as $fl){
				$d=preg_split("/\s+/", trim($fl));
				if($d[0] && $d[0] != "." && $d[0] != ".." && $d[0] != "total") $infoArray[$d[1]]=$d[0];
			}
		}
		return $infoArray;
	}

	function Compare($a, $b){
		$result=array();



function test($a, $b)
{
echo "$a $b <br>";
    if ($a === $b) {
        return 0;
    }
    return ($a > $b)? 1:-1;
}
return array_uintersect_uassoc  ($a, $b, "test", "test");

//exit;


		return $result;
		if(is_array($b)){
			foreach($a as $name => $size){
				if(is_array($size) && !isset($size['file'])){
					 $result[$name]=$this->Compare($size, $b);
				} else {
					if(!search_in_array($name, $b) )
						 $result[$name]=$size;
				}
			}
		}
	}




	function Parse($a, $b, $base=false){
		$final=array();

echo "<h3>a</h3>";
//print_r($a);
echo "<h3>b</h3>";
//print_r($b);

		$list=$this->Compare($a, $b);
echo "<h3>result</h3>";

		print_r($list);exit;
		if(!is_array($list)) return false;
		foreach($list as $name => $size){
			if(is_array($size)){
				 $final[$name]=$this->Parse($size, $b, $base."/".$name);
			} else {
				if($base){
					$path=str_replace("/home/$this->user/", "", str_replace("\\", "/",rtrim($this->source, "/")."/".$base."/".$name));
				} else $path=str_replace("/home/$this->user/", "", str_replace("\\", "/",rtrim($this->source, "/")."/".$name));
				$final[$name]=array('file'=>$name,'path' => $base, 'link'=>"ftp://$this->user:$this->pass@$this->sid:$this->ftpport/$path");
				$this->final[$base."/".$name]=array('file'=>$name,'path' => $base, 'link'=>"ftp://$this->user:$this->pass@$this->sid:$this->ftpport/$path");
			}
		}
		return $final;
	}

	function SetInfo(){
		global $Panel;
		
		$ugDetails=$Panel->GetUserGame($this->ugid);
		$userInfo=$Panel->GetUser($ugDetails['cid']);
		$serverInfo=$Panel->GetServer('', $ugDetails['ip']);

		$this->sid=$serverInfo['sid'];
		$this->ftpport=$serverInfo['ftpport'];
		$this->os=$serverInfo['os'];
		$this->user=$userInfo['name'];
		$this->pass=$userInfo['password'];
	}

	function Generate(){
		$a=$this->Query($this->sid, $this->source);
		$b=$this->Query($this->remoteid, $this->destination);
		
		echo "<pre><h3>a</h3>";
		//print_r($a);
		//echo "<h3>b</h3>";
		//print_r($b);




		$this->weblist=$b;
		$this->sync_data=$this->Parse($a, $b);
		$this->ProcessCludes();

	}

	function ProcessCludeDetails($name){
		$inc=explode("\n", $this->includes );
		if(is_array($inc) && count($inc) > 0){
			foreach($inc as $n){
				if($n && !preg_match("/".trim($n)."/s", $name)) return false; 
			}
		}

		$exc=explode("\n", $this->excludes );
		if(is_array($exc) && count($exc) > 0){
			foreach($exc as $n){
				if($n && preg_match("/".trim($n)."/s", $name)) return false; 
			}
		}

		return true;

	}

	function ProcessCludes(){

		$result=array();
		foreach($this->sync_data as $name=>$size){
			if($this->ProcessCludeDetails($name)) $result[$name]=$size;
		}
		$this->sync_data=$result;
	}

	function DeleteList(){
		$result=array();
		foreach($this->weblist as $name => $size){
			$name=$name;
			if(!isset($this->sync_data[$name])) $result[]=$name;
		}
		return $result;
	}

	function SyncPro($sync_data, $wget){


		foreach($sync_data as $file => $link){
			if(is_array($link) && !isset($link['file'])){
				
				$script.=$this->SyncPro($link, $wget);
			} else {
				if($this->compression){
					if($serverInfo['os'] == '1'){
						$script.="$wget $link -o $file\n$compress $file $file.".$this->compression."\ndel /f $file";
					} else $script.="$wget $link  -o $file; $compress $file.".$this->compression." $file ; rm -f $file\n";
				} else $script.="$wget $link -o $file\n";
			}
		}
		return $script;
	}

	function Sync(){
		global $GameCP;


		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$serverInfo=$Panel->GetServer($this->remoteid);
		$sid=$serverInfo['sid'];
		
		if($serverInfo['os'] == '1'){
			$wget="\$MAINDIRbin\wget.exe";
			$compress="\$MAINDIRbin\gcpcompress.exe";
		} else {
			$wget="wget";
			$compress="";
			switch($this->compression){
				case "zip";
					$compress="zip";
				break;
				case "gz";
					$compress="gzip";
				break;
			}
		}
	

		$script='';

		$dl=$this->DeleteList();
		foreach($dl as $id => $file){
			if($serverInfo['os'] == '1'){
				$script.="del /f $file\n";
			} else $script.="rm -f $file\n";
		} 

echo "<h3>sync</h3>";
print_r($this->sync_data);

$script.=$this->SyncPro($this->sync_data, '', $wget);

		echo $script;exit;

		$scriptbase="rsync-".$this->ugid;

		if($serverInfo['os'] == '1'){
			$scriptfile="\$MAINDIR$scriptbase.bat";
			$this->destination=str_replace("/", "\\", $this->destination);
			$command ="@ECHO off\r\nmkdir ".$this->destination."\r\ncd ".$this->destination."\r\n".$script."\r\ndel /f $scriptfile\r\nexit";
			$command=str_replace("\r", "", $command);
			$command=str_replace("\n", "\r\n", $command);
			$Backend->QueryResponse($sid, '', "writefile:_:$scriptfile:_:$command");
			$Backend->Query($sid, '', "$scriptfile:_:");
		} else {
			$GameCP->loadIncludes("linux");
			$Linux=new Linux();
			$scriptfile="/root/$scriptbase.sh";
			$command ="mkdir -p ".$this->destination."\ncd ".$this->destination."\n".$script;
			$command=str_replace("\r", "", $command);

			if(debugging != "1") $command.="\n rm -f $scriptfile";
			$Backend->QueryResponse($sid,'', "writefile:_:$scriptfile:_:$command", $fusername);
			$Linux->Screen($sid, "bash $scriptfile", $this->ugid, 'root', false);
		}
	
	}
}
?>