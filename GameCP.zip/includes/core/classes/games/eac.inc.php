<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


class EAC{

	var $protocols=array("csgo", "cssource","halflife", "cod4");

	function Check($gid, $exclude=false){
		global $GameCP, $safesql;

		$q=sql_query($safesql->query("SELECT id, protocol FROM game WHERE id='%i' LIMIT 1", array($gid))) or die(mysql_error());
		$dq=mysql_fetch_assoc($q);
		if($dq['protocol'] == $exclude) return false;
		if(in_array($dq['protocol'], $this->protocols)){
			return true;
		} else return false;
	}

	function Build(){
		global $GameCP, $safesql;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$gamelist=array();
		$gameids=array();
		$protos = join("','", $this->protocols);

		$hl1="";
		$hl2="";
		$cod4="";
		$csgo="";

		$glistQ = sql_query("SELECT id, protocol FROM game WHERE active='1' AND protocol IN('$protos')") or die(mysql_error());
		while ($gl = mysql_fetch_array($glistQ)){
			$gamelist[$gl['id']]=$gl['protocol'];
			$gameids[]=$gl['id'];
		}

		$uglistQ = sql_query("SELECT ip, port, rconpass, gid, eactype FROM usergames WHERE active='1' AND eac='1'") or die(mysql_error());
		while ($uglist = mysql_fetch_assoc($uglistQ)){
			$ipDetails=$Panel->GetIP($uglist['ip']);
			if($ipDetails['useinternal'] == "1"){
				$ip = $ipDetails['internal'];
			} else $ip = $ipDetails['ip'];

			$type="";
			if($uglist['eactype'] > "0") $type="-".$uglist['eactype'];
			$line=$ip.":".$uglist['port']."-".$uglist['rconpass'].$type."\n";
			
			switch($gamelist[$uglist['gid']]){
				case "halflife":
					$hl1.=$line;
				break;

				case "cssource":
					$hl2.=$line;
				break;

				case "csgo":
					$csgo.=$line;
				break;

				case "cod4":
					$cod4.=$line;
				break;
			}
		}

		$return=true;
		if(!$this->Write("/servers/hl1/gamecp_list.ini", $hl1)) $return=false;
		if(!$this->Write("/servers/hl2/gamecp_list.ini", $hl2)) $return=false;
		if(!$this->Write("/servers/csgo/gamecp_list.ini", $csgo)) $return=false;
		if(!$this->Write("/servers/cod4/gamecp_list.ini", $cod4)) $return=false;

		return $return;

	}

	function Write($file, $contents){
		global $GameCP;
		
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$uglistQ = sql_query("SELECT sid, winport, eacdir, os FROM servers WHERE active='1' AND eacdir != ''") or die(mysql_error());
		while ($mif = mysql_fetch_assoc($uglistQ)){
			$final=rtrim($mif['eacdir'], "/").$file;
			if($mif['os'] == "1") $final=str_replace("/", "\\", $final);
			$Backend->Query($mif['sid'],  $mif['winport'], "writefile:_:$final:_:$contents");
		}

		return true;
	}
}

?>