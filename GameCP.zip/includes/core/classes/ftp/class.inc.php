<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


/**
 * FTP class manages all ftp related items for GameCP
 *
 */
class FTP{

	/**
	 * copy
	 */
	function Copy($sid, $ftp_user_name, $ftp_user_pass, $file, $remote_file, $remote_dir=FALSE) {
		global $GameCP, $safesql;

		$sinfoQ = sql_query($safesql->query("SELECT ftpport, ip FROM servers WHERE sid='%s'", array($GameCP->whitelist($sid, "clean")))) or die(mysql_error());
		$sinfo = mysql_fetch_array($sinfoQ);
		$ftp_port = $sinfo[0];
		$ftp_server = $sinfo[1]; 

		$conn_id = ftp_connect($ftp_server, $ftp_port, 5);
		if(!$conn_id) return "FATAL: no connection to ftp server.";
		if(!$ftp_user_pass){ return "Missing password.";}

		$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
		if($remote_dir){ ftp_chdir($remote_dir); }

		if (ftp_put($conn_id, $remote_file, $file, FTP_ASCII)) {
			 return "File copy completed.<br>";
		} else {
			 return "File copy failed.<br>";
		}
		ftp_close($conn_id);   
	}

	/**
	 * list a folder
	 */
	function ListDIR($sid, $ftp_user_name, $ftp_user_pass, $directory, $remote_dir=FALSE) {
		global $GameCP, $safesql;

		$sinfoQ = sql_query($safesql->query("SELECT ftpport, ip FROM servers WHERE sid='%s'", array($GameCP->whitelist($sid, "clean")))) or die(mysql_error());
		$sinfo = mysql_fetch_array($sinfoQ);
		$ftp_port = $sinfo[0];
		$ftp_server = $sinfo[1];

		$conn_id = ftp_connect($ftp_server, $ftp_port, 5);
		if(!$conn_id) return "1";
		if(!$ftp_user_pass) return "2";

		$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
		if($remote_dir){ ftp_chdir($remote_dir); }

		$ftp_rawlist = ftp_rawlist($conn_id, $directory);

		$i="0";
		foreach ($ftp_rawlist as $v) {
			$info = array();
			$vinfo = preg_split("/[\s]+/", $v, 9);
			if ($vinfo[0] !== "total") {

				if($vinfo[0] && !$vinfo[4] && !$vinfo[5] && !$vinfo[6]){
					echo "Unix file listing not enabled on the servers FTPD, please enable.";
					return false;
				}
			  $info['chmod'] = $vinfo[0];
			  $info['dir'] = $vinfo[0][0];
			  $info['num'] = $vinfo[1];
			  $info['owner'] = $vinfo[2];
			  $info['group'] = $vinfo[3];
			  $info['size'] = $vinfo[4];
			  $info['month'] = $vinfo[5];
			  $info['day'] = $vinfo[6];
			  $info['time'] = $vinfo[7];
			  $info['name'] = $vinfo[8];
			  $rawlist[$i] = $info;
			  $i++;
			}
		  }

		ftp_close($conn_id);
		return $rawlist;
	}

	/**
	 * transfer files
	 */
	function Transfer($sid, $ftp_user_name, $ftp_user_pass, $remote_file, $local_file, $transfer_type, $remote_dir=FALSE) {
		global $GameCP, $safesql;

		$sinfoQ = sql_query($safesql->query("SELECT ftpport, ip FROM servers WHERE sid='%s'", array($GameCP->whitelist($sid, "clean")))) or die(mysql_error());
		$sinfo = mysql_fetch_array($sinfoQ);
		$ftp_port = $sinfo[0];
		$ftp_server = $sinfo[1];

		if(!$ftp_port) $ftp_port="21";

		if(!$ftp_user_pass){
			$_SESSION['gamecp']['ftp_error']="Unable to determine password";
			return false;
		}
		if(!$ftp_user_name){
			$_SESSION['gamecp']['ftp_error']="Unable to determine user";
			return false;
		}

		if(!$ftp_server){
			$_SESSION['gamecp']['ftp_error']="Unable to determine server";
			return false;
		}


		$conn_id = ftp_connect($ftp_server, $ftp_port, 5);

		if(!$conn_id){
			$_SESSION['gamecp']['ftp_error']="Unable to connect to FTP server";
			return false;
		}

		if(!ftp_login($conn_id, $ftp_user_name, $ftp_user_pass)){
			$_SESSION['gamecp']['ftp_error']="Unable to login as $ftp_user_name to FTP server";
			return false;
		}

		if($transfer_type == "list"){ 
			$contents = ftp_nlist($conn_id, $remote_dir);
			var_dump($contents);
		} else if($transfer_type == "get"){ 
			if($remote_dir) $remote_file= $remote_dir."/".$remote_file;
			$handle = fopen($local_file, 'w');
			if(!$handle) return "FTP handle failed.";
			if (ftp_fget($conn_id, $handle, $remote_file, FTP_ASCII, 0)) {
				fclose($handle);
				return true;
			} else {
				$_SESSION['gamecp']['ftp_error']="Unable to receive file from FTP server";
				return false;
			}
			
		} else { 
			/* put files */
			$tmpdira='';
			if($remote_dir) $remote_file=$remote_file;
			if($remote_dir){
				$makdir=explode("/", $remote_dir);
				foreach($makdir as $tmpdir){
					$tmpdira .=$tmpdir."/";
					@ftp_mkdir($conn_id, $tmpdira); 
				}
				@ftp_chdir($conn_id, $remote_dir); 
			}
			@ftp_delete($conn_id, $remote_file);
			ftp_pasv($conn_id, true);
			if (!ftp_put($conn_id, $remote_file, $local_file, FTP_BINARY)){
				$_SESSION['gamecp']['ftp_error']="Unable to send file to FTP server";
				return false;
			} else return true;
		}
		
		ftp_close($conn_id);

		return true;
	}

	/**
	 * check the status of a connection to ftp
	 */
	function Status($sid, $login, $fpassword){
		global $GameCP;
		if(!$fpassword) return false;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$serverDetails=$Panel->GetServer($sid);
		$host=$serverDetails['ip'];
		$port=$serverDetails['ftpport'];

		set_time_limit(10);
		$conn_id = ftp_connect($host, $port, 5);
		if($conn_id) $login_result = ftp_login($conn_id, $login, $fpassword);
		if ((!$conn_id) || (!$login_result)) return false;
		return true;
	}

	/**
	 * check if the url is ftp or http/https
	 */
	function CheckFTP($url, $http=FALSE){
		$checkScheme=parse_url($url);
		$schemes=array("ftp", "ftps");
		if($http){
			$schemes[]="http";
			$schemes[]="https";
		}
		if(!isset($checkScheme['scheme'])) return false;
		if(in_array($checkScheme['scheme'], $schemes)){
			return $checkScheme;
		} else return false;
	}

	/**
	 * list a url, ftp or http/https
	 */
	function ListURL($url){
		$checkScheme=parse_url($url);
		if(isset($checkScheme['scheme']) && ($checkScheme['scheme'] == "ftp" || $checkScheme['scheme'] == "ftps")){

			$port="21";
			$server = $checkScheme['host'];
			if(isset($checkScheme['port'])) $port = $checkScheme['port'];
			$path = $checkScheme['path'];
			$user = $checkScheme['user'];
			$pass = $checkScheme['pass'];

			if(substr($path, 0, 1) == "/") $path=substr($path, 1);

			if ((!$server) || (!$path)) return false; 
			if (!$port) $port = 21;

			if($checkScheme['scheme'] == "ftp"){
				$ftpid = ftp_connect($server, $port, 5);
			} else $ftpid = ftp_ssl_connect($server, $port);

			if ($ftpid) {  
				$login = ftp_login($ftpid, $user, $pass);
				ftp_pasv( $ftpid, true );
				if ($login) { 
					ftp_chdir($ftpid, $path); 

					return ftp_nlist($ftpid, "."); 
				}
				ftp_close($ftpid);
			}

			
			return false;
		}
	}


}
?>