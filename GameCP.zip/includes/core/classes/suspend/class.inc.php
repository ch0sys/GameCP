<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Suspend{

	function Module($id){
		global $GameCP;

		$GameCP->loadIncludes("modules");
		$Modules=new Modules();

		$Modules->SetRecord($id);
		$Modules->SetModuleData();

		$params=$Modules->params;
		$module=$params['product']['module'];

		$Modules=new Modules($module);
		$Modules->SetRecord($id);

		$Modules->SetProduct($params['pid']);
		return $Modules->SuspendAccount();
	}

	function Notify($tpl, $user, $extravars=array()){
		global $GameCP, $bid;
		$GameCP->loadIncludes("email");
		$Email = new Email();
		$Email->userid = $user;
		$Email->templatename = $tpl;
		$Email->GetTemplateStuff();
		$Email->usegamedata = true;
		$Email->usevoicedata = true;
		$Email->usebilldata = true;
		if($bid) $extravars[]=array("var" => "\$BillId", "value" => "$bid");
		$Email->ReplaceStuff($extravars);
		$Email->send();

	}

	function Voice($vid, $idd=false, $direction=FALSE){
		global $Event,$GameCP, $safesql, $hook_vars;

		if($direction == "unsuspend"){
			$method="start";
		} else $method="stop";


		if($vid == "" || $vid == NULL){ 
			$sql = $safesql->query("SELECT UV.ip, UV.id as uvid, UV.port, UV.tssid, S.sid, UV.billingId, UV.voicetype, UV.cid, UV.active
						FROM uservoice UV, servers S, iptable I
						WHERE UV.ip = I.ip
						AND S.sid = I.sid
						AND UV.cid = '%i'", array($GameCP->whitelist($idd, "int")));
		} else $sql = $safesql->query("SELECT UV.ip, UV.id as uvid, UV.port, UV.tssid, S.sid, UV.billingId, UV.voicetype, UV.cid, UV.active
						FROM uservoice UV, servers S, iptable I
						WHERE UV.ip = I.ip
						AND S.sid = I.sid
						AND UV.id = '%i'", array($GameCP->whitelist($vid, "int")));
		
		$voiceResult = sql_query($sql) or die(mysql_error());
		if(mysql_num_rows($voiceResult) == "0" && usedarkstarvent == "yes"){
			if($vid){
				$sql = $safesql->query("SELECT id, billingId, ip, port, tssid, id as 'uvid', cid voicetype, active FROM uservoice WHERE id = '%i'", array($GameCP->whitelist($vid, "int")));
			} else $sql = $safesql->query("SELECT id, billingId, ip, port, tssid, id as 'uvid', cid voicetype, active FROM uservoice WHERE cid = '%i'", array($GameCP->whitelist($idd, "int")));
			$voiceResult = sql_query($sql) or die(mysql_error());
		}

		while ($voiceResults = mysql_fetch_array($voiceResult)) {
			$vip = $voiceResults["ip"];
			$vport = $voiceResults["port"];
			$tssid = $voiceResults["tssid"];
			$vsid = $voiceResults["sid"];
			$vid = $voiceResults["uvid"];
			$cid = $voiceResults["cid"];
			$sid = $vsid;
			$voicetype = $voiceResults["voicetype"];
		
			if(!$vip || !$vport){
				$Event->EventLogAdd('', "Voice #$vid missing ip or port". time());
				return false;
			}elseif(!$direction && $voiceResults['active'] == "2"){
				$Event->EventLogAdd('', "Voice #$vid already $direction ". time());
				return false;
			} else {
			
				$GameCP->loadIncludes("control");
				$Control=new Control();

				if($tssid == "0" || $tssid == "" || $tssid == NULL){ 
					$Control->Ventrilo($vip, $vport, $method);
				} else { 
					if($voicetype == "ts3"){
						$Control->Teamspeak3($vip, $vport, $method, $tssid);
					} else $Control->Teamspeak($vip, $vport, $method, $tssid);
				}

				if(!$direction){
					mysql_query($safesql->query("UPDATE uservoice SET active='2' WHERE id = '%i';", array($GameCP->whitelist($vid, "int"))));
					$templatename = "Service-Suspended";
				} else $templatename = "Service-Unsuspended";

				$extravars=array();
				$extravars[]=array("var" => "\$Var1", "value" => "$vid");
				$this->Notify($templatename, $cid, $extravars);

				$hook_vars=$voiceResults;
				run_hook("suspend_voice");
				$Event->EventLogAdd($idd, "User #". $idd. " had voice #$vid $direction by ".$_SESSION['gamecp']['userinfo']['name']." ". time());
				return true;
			}
		}
		return false;
	}

	function VoiceRestore($vid, $idd=false){
		return $this->Voice($vid, $idd, 'unsuspend');
	}

	function Game($ugid){
		global $Event, $GameCP, $safesql;
		if(!$ugid) die('Missing user game id');
		$GameCP->loadIncludes("control");
		$Control=new Control();
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$gameInfo=$Panel->GetUserGame($ugid);

		$statq=sql_query($safesql->query("SELECT active FROM usergames WHERE id='%i' AND active='2'", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error()); 
		if(mysql_num_rows($statq) == 1){
			$Event->EventLogAdd('', "Game #$ugid already suspended ". time());
			return true;
		}

		$Control->Usergame($ugid, "stop");
		sql_query($safesql->query("UPDATE usergames SET active='2' WHERE id='%i'", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error()); 

		run_hook("suspend_game");

		$extravars=array();
		$extravars[]=array("var" => "\$Var1", "value" => "$ugid");
		$this->Notify("Service-Suspended", $gameInfo['userid'], $extravars);
		$Event->EventLogAdd('', "Game #$ugid suspended by ". isset($_SESSION['gamecp']) ? @$_SESSION['gamecp']['userinfo']['name'] : 'System'." ". time());
		return true;

	}

	function GameRestore($ugid){
		global $Event, $GameCP, $safesql;
		$GameCP->loadIncludes("control");
		$Control=new Control();

		$statq=sql_query($safesql->query("SELECT active FROM usergames WHERE id='%i' AND active='2'", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error()); 
		if(mysql_num_rows($statq) == 0){
			$Event->EventLogAdd('', "Game #$ugid already unsuspended ". time());
			return true;
		}


		sql_query($safesql->query("UPDATE usergames SET active='1' WHERE id='%i'", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error()); 
		$Control->Usergame($ugid, "start");
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$gameInfo=$Panel->GetUserGame($ugid);

		run_hook("unsuspend_game");

		$extravars=array();
		$extravars[]=array("var" => "\$Var1", "value" => "$ugid");
		$this->Notify("Service-Unsuspended", $gameInfo['userid'], $extravars);
		$Event->EventLogAdd('', "Game #$ugid un-suspended by ".$_SESSION['gamecp']['userinfo']['name']." ". time());
		return true;
	}

	function User($gcp_user_id){
		global $Event, $safesql, $Email, $GameCP;
		$GameCP->loadIncludes("control");
		$Control=new Control();

		if($gcp_user_id == 0) return false;
		$user_information = sql_query($safesql->query("SELECT U.id, U.username, U.password, U.name, U.active, U.storedpw, U.userlevel FROM users U WHERE `id` = '%i' LIMIT 1", array($GameCP->whitelist($gcp_user_id, "int")))) or die(mysql_error());
		if (mysql_num_rows($user_information) != 1) return false;
		$user_information = mysql_fetch_array($user_information);

		$GameCP->loadIncludes("panel");
		$GameCP->loadIncludes("user");
		$User=new User();
		$Panel=new Panel();

		$username = $user_information["username"];
		$current_password = $User->Password($gcp_user_id);
		$new_suspend_password = $Panel->RandomPassword();

		$ulevel = $user_information["userlevel"];
		if($ulevel == "1" || $ulevel == "3" || $ulevel == "2") return false;

		// Check if user already suspended
		if ($user_information["active"] == 0) return false;
		
		// Sutdown all user servers
		$shutdown_check = $Control->UserID($gcp_user_id, "stop");

		/* shut down voice servers */
		$this->Voice('', $gcp_user_id);

		$copy_password = $safesql->query("UPDATE `users` SET `active` = '0', `storedpw` = '%s' WHERE `id` = '%i' LIMIT 1 ;", array($GameCP->whitelist($current_password, "password"),$GameCP->whitelist($gcp_user_id, "int")));
		sql_query($copy_password) or die($error = mysql_error());

		$GameCP->loadIncludes("linux");
		$Linux=new Linux();

		$Linux->Password($gcp_user_id, $new_suspend_password);

		$GameCP->loadIncludes("game");
		$Game=new Game();
		$Game->ExecAllGames($gcp_user_id, "pkill -u ". $username);

		$GameCP->loadIncludes("user");
		$User=new User();
		$GameCP->SetPassword($gcp_user_id, $new_suspend_password, false, true);

		$GameCP->loadIncludes("modules");
		$Modules=new Modules();
		$Modules->ExecUserCommand($gcp_user_id, 'SuspendAccount');

		$this->Notify("User-Suspended", $gcp_user_id);

		run_hook("suspend_user");
		$Event->EventLogAdd('', "User #$gcp_user_id suspended");

		if (!isset($error)) {
			return true;
		} else return false;
	}

	function UserRestore($gcp_user_id){
		global $Event, $GameCP, $safesql;
		// Get User information
		$user_information = sql_query($safesql->query("SELECT U.id, U.username, U.password, U.name, U.active, U.storedpw FROM users U WHERE `id` = '%i' LIMIT 1", array($GameCP->whitelist($gcp_user_id, "int")))) or die(mysql_error());
		// Check that 1 record was retreived
		if (mysql_num_rows($user_information) != 1) {
			echo "--- Error: Specified user does not exist (ID: $gcp_user_id)\n";
			return FALSE;
		}
		// User information
		$user_information = mysql_fetch_array($user_information);
		$username = $user_information["username"];
		// needs decoded 
		$current_password = $user_information["password"];
		$old_password = $user_information["storedpw"];


		// Check if user is not suspended
		if ($user_information["active"] != 0) return TRUE;
				
		// Check if no password was stored
		if ($user_information["storedpw"] == "" OR NULL) {
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$old_password = $Panel->RandomPassword();
		}
		$GameCP->loadIncludes("user");
		$User=new User();
		$GameCP->SetPassword($gcp_user_id, $old_password, false, true);

		// Remove Stored password
		$remove_old_password = $safesql->query("UPDATE `users` SET `storedpw` = '', `active` = '1'  WHERE `id` = '%i' LIMIT 1 ;", array($GameCP->whitelist($gcp_user_id, "int")));
		sql_query($remove_old_password) or die($error = mysql_error());
	
		$GameCP->loadIncludes("linux");
		$Linux=new Linux();
		
		// Change back password on the servers
		$Linux->Password($gcp_user_id, $old_password);
		
		$this->Voice('', $gcp_user_id, "unsuspend");

		// Start all user servers
		$GameCP->loadIncludes("control");
		$Control=new Control();
		$Control->UserID($gcp_user_id, "start");
				
		$GameCP->loadIncludes("modules");
		$Modules=new Modules();
		$Modules->ExecUserCommand($gcp_user_id, 'UnsuspendAccount');

		run_hook("unsuspend_user");

		$Event->EventLogAdd('', "User #$gcp_user_id un-suspended by ".$_SESSION['gamecp']['userinfo']['name']." ". time());

		// Finished
		if ($error == "" OR NULL) {
			$this->Notify("User-Unsuspended", $gcp_user_id);
			return TRUE;
		} else return FALSE;
		
	}

}
?>