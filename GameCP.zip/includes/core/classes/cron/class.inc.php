<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


class Cron{

	function Send($url, $PostData){
		ob_start();
		$ch = curl_init();
		$PostData = http_build_query($PostData);
		$PostData=str_replace("&amp;", "&", $PostData);
		@set_time_limit(999999);
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $PostData);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 999999); 
		curl_setopt($ch, CURLOPT_TIMEOUT, 999999);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 0); 
		$output=curl_exec($ch);	
		echo $output;
		if(!$output) echo curl_error($ch);
		curl_close ($ch);
		unset($ch, $PostData);

		$result = ob_get_contents();
		ob_end_clean();

		return $result;

	}


	function SendKey(){
		return md5("game".gcplickey."cp");
	}

	function CheckKey($key){
		if($key == md5("game".gcplickey."cp")) return true;
		return false;
	}

	function ExecTask($task, $delay="900"){
		global $GameCP, $safesql, $Event;

		$task=$GameCP->whitelist($task, "clean");

		$taskTimeQ=sql_query($safesql->query("SELECT time FROM cron WHERE task ='%s' LIMIT 1;", array($task)));
		$taskTime=mysql_fetch_array($taskTimeQ);
		if(!$taskTime[0]){
			$taskTime[0]=time();
			sql_query($safesql->query("INSERT INTO cron SET time='".time()."', task ='%s';", array($task)));
		}

		if((time() - $taskTime[0]) >= $delay){
			$result=$this->Send(url."/includes/cron/".$task, array("noheader"=>"true","key"=>$this->SendKey()));
			sql_query($safesql->query("UPDATE cron SET time='".time()."' WHERE task ='%s' LIMIT 1;", array($task)));
			$Event->EventLogAdd('', "Cron Task Ran: ".$task."  Result: ". $result);

			return true;
		}
		return false;
	}

	function ExecSchedule($usermode=false){
		global $safesql;
		require_once(path.'/includes/core/classes/cron/parser.inc.php');

		if($usermode){
			 $tbl='userschedule';
		} else $tbl='schedule';
		
		$result = sql_query("SELECT * FROM $tbl ") or die(mysql_error());
		while ($row = mysql_fetch_array($result)){
			$cron_parser = new cron_parser($row['cron']);
			$next_time = $cron_parser->next_runtime();

			if($row['next_run'] <= time()){
				$this->RunSchedule($row, $usermode);
				sql_query($safesql->query("UPDATE $tbl SET next_run='%s', ran_last='%s' WHERE id ='%i' LIMIT 1;", array($next_time, time(), $row['id'])))or die(mysql_error());
			}
		}
	}

	function RunSchedule($data, $usermode=false){
		global $Event;


		require_once(path.'/includes/core/classes/commands/class.inc.php');
		$Command=new Command();

		if($usermode){
			$Event->EventLogAdd('', "User Scheduler ran: ".json_encode($data));
			$Command->UserGame($data['id']);
		} else {
			$Event->EventLogAdd('', "Scheduler ran: ".json_encode($data));
			switch ($data['cmd']){
				case "saved";
					if($data['cmdid']) $Command->Shell($data['cmdid'], $data['id']);
				break;

				case "gamecp";
					if($data['cmdid']) $Command->GameCP($data['cmdid']);
				break;

				case "games";
					$Command->Game($data['id']);
				break;
			}
		}

	}
}
?>