<?php
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/**
 * Billing class to manage GameCP bills
 * 
 * This class manages the billing system in GameCP
 * Call functions directly to perform tasks
 * 
 */

class Billing{

	function ValidateUser($cid, $bid){
		global $GameCP, $safesql;

		if($_SESSION['gamecp']['userinfo']['ulevel'] == "0") { 
			if($bid){
				$billQ = sql_query($safesql->query("SELECT cid FROM billing WHERE id='%i';", array($GameCP->whitelist($bid, "int"))));
				$billi=mysql_fetch_assoc($billQ);
				$cid=$billi['cid'];
			}
			if($cid != $_SESSION['gamecp']['userinfo']['id']){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->ErrorExit("Invalid access");
			}
		}
	}

	function InvoiceDescription($form, $info){
		global $smarty;
		$result=array();
		switch($form){
			case 'order':
				$result['product']=neworder_title." ". $info['packageName']." ".$info['packageSlots']." players @ ".$info['packageTerm'];
				$result['description']=neworder_description;
				$result['item']="0";
			break;

			case 'donation':
				$result['product']=donation_title." $info";
				$result['description']=donation_description;
				$result['item']=$info;
			break;

			case 'invoice':
				$result['product']=payment_title." ". $info['name'];
				$result['description']=payment_description .$info['bid'];
				$result['item']=$info['bid'];
			break;
		}

		$smarty->assign('id_description', $result['description']);
		$smarty->assign('id_item', $result['item']);
		$smarty->assign('id_product', $result['product']);
	}

	function ExchangeRate($exchange){
		global $safesql, $GameCP;
		$info = sql_query($safesql->query("SELECT * FROM currencies WHERE code = '%s' LIMIT 1", array($GameCP->whitelist($exchange, "clean")))) or die(mysql_error());
		if(mysql_num_rows($info) == 0) return false;
		return mysql_fetch_assoc($info);

	}

	function LoadGateway($gateway, $return=false){
		global $safesql, $GameCP, $paidPrice, $orderStatus, $transactionid, $responseMessage, $paidFee;

		$gateWayInfo = sql_query($safesql->query("SELECT * FROM gateways WHERE name='%s'", array($GameCP->whitelist($gateway))))  or die(mysql_error());
		$gateway = mysql_fetch_array($gateWayInfo);

		if($return){
			$gatewayFile=path."/includes/gateways/".$gateway['name']."/return.php";
		} else $gatewayFile=path."/includes/gateways/".$gateway['name']."/include.php";
		if(is_file($gatewayFile)) require_once($gatewayFile);

		return $gateway;
	}

	function PayOrder($qid, $paid, $fee=FALSE, $subscr_id=FALSE){
		global $GameCP;

		$checkQ = sql_query($safesql->query("SELECT user, status, `mod` FROM queue WHERE id='%i'", array($qid)))  or die(mysql_error());
		$qInfo=mysql_fetch_row($checkQ);

		$mod=unserialize($qInfo[2]);
		if($paid >= $mod['gross']) $mod['status']="Completed";
		$mod['paidPrice']=$paid;
		$mod['fee']=$fee;
		$mod['subscr_id']=$subscr_id;
		sql_query($safesql->query("UPDATE queue SET `mod`='%s' WHERE id='%i'", array(serialize($mod),$qid)))  or die(mysql_error());

		if($paidPrice >= $mod['gross'] && $qInfo[1] == "3"){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ExecQueue($qid);
		}

	}

	function TaxReduction($items){
		global $GameCP;

		if(taxType == "inclusive"){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();

			foreach($items as $i => $tem){
				if($tem[3] == "1" && $tem[4] > 0) $items[$i][2]=$Panel->FormatNumber($Panel->RemFormatNumber($tem[2])-$tem[4]);
			}
		}
		return $items;
	}

	function GetUserTax($country, $city, $level){
		global $GameCP, $safesql;

		$taxitems=array();
		if(!$country) $country="all";
		if(!$city) $city="all";

		$ub = sql_query($safesql->query("SELECT * FROM taxes WHERE country='%s' AND city='%s' AND level='%i'", array($GameCP->whitelist($country, "clean"),$GameCP->whitelist($city, "clean"), $level)), "bill taxes 1") or die(mysql_error());
		if(mysql_num_rows($ub) > 0){
			while($tr = mysql_fetch_assoc($ub)) $taxitems[]=$tr;
		} else {
			$ub2 = sql_query($safesql->query("SELECT * FROM taxes WHERE country='%s' AND city='all' AND level='%i'", array($GameCP->whitelist($country, "clean"), $level)), "bill taxes 1") or die(mysql_error());
			if(mysql_num_rows($ub2) > 0){
				while($tr2 = mysql_fetch_assoc($ub2)) $taxitems[]=$tr2;
			} else {
				$ub3 = sql_query($safesql->query("SELECT * FROM taxes WHERE country='all' AND city='all' AND level='%i'", array($level)), "bill taxes 1") or die(mysql_error());
				while($tr3 = mysql_fetch_assoc($ub3)) $taxitems[]=$tr3;
			}
		}
		
		return $taxitems;
	}

	function Taxes($bid){
		global $GameCP, $safesql;

		$final=array();
		$taxtotal="0";

		if(taxEnable == "yes"){

			$uba = sql_query($safesql->query("SELECT cid FROM userbills WHERE bid='%i' AND taxed='1' AND gross > '0'", array($GameCP->whitelist($bid, "int"))), "updating bill taxes") or die(mysql_error());
			$ucid = mysql_fetch_assoc($uba);

			$ub = sql_query($safesql->query("SELECT sum(gross) as 'gross' FROM userbills WHERE bid='%i' AND taxed='1' AND gross > '0'", array($GameCP->whitelist($bid, "int"))), "updating bill taxes") or die(mysql_error());
			$bill = mysql_fetch_assoc($ub);
			$totaltotax=$bill['gross'];

			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$userInfo=$Panel->GetUser($ucid['cid']);

			$types=array_merge($this->GetUserTax($userInfo['country'], $userInfo['state'], "1"), $this->GetUserTax($userInfo['country'], $userInfo['state'], "2"));




			$bi = sql_query($safesql->query("SELECT gross, id FROM userbills WHERE bid='%i' AND taxed='1' AND gross > '0'", array($GameCP->whitelist($bid, "int"))), "updating bill taxes") or die(mysql_error());
			while($bil = mysql_fetch_assoc($bi)){
				$mytax=$this->CalculateTax($bil['gross'], $types, true);
				$mytax[1]=$Panel->RemFormatNumber($mytax[1]);
				if($mytax[1] > 0) sql_query($safesql->query("UPDATE userbills SET tax='%s' WHERE id='%i'", array($mytax[1], $GameCP->whitelist($bil['id'], "int"))), "updating bill taxes") or die(mysql_error());
			}
		}
		
		if(isset($totaltotax) && $totaltotax > 0){
			$res=$this->CalculateTax($totaltotax, $types);
			$final=$res[0];
			$taxtotal=$res[1];
		}

		sql_query($safesql->query("UPDATE billing SET taxtotal='%s', taxes='%s' WHERE id = '%i'", array($taxtotal, serialize($final), $GameCP->whitelist($bid, "int"))), "updating taxes 2") or die(mysql_error());
	}

	function CalculateTax($totaltotax, $types, $ignoreinclusive=FALSE){
		global $GameCP;

		$final=array();
		$taxtotal=0;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		foreach($types as $tp){
			if($tp['rate'] < 1){
				$div=10;
			}else $div=100;


			if(taxCompound == "yes") $totaltotax=$Panel->RemFormatNumber($totaltotax)+$Panel->RemFormatNumber($taxtotal);
			if(taxType == "inclusive") $div=$div+$tp['rate'];
			$tp['total']=$Panel->FormatNumber(($Panel->RemFormatNumber($tp['rate'])/$div) * $totaltotax);
			$taxtotal=$Panel->FormatNumber($Panel->RemFormatNumber($taxtotal)+$Panel->RemFormatNumber($tp['total']));
			$final[]=$tp;
		}
		
		if(taxType == "inclusive" && $ignoreinclusive==FALSE) $taxtotal="0.00";

		return array($final, $taxtotal);
	}



	function updateBillTotals($bid){
		global $GameCP, $safesql;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$totala = sql_query($safesql->query("SELECT cid FROM userbills WHERE bid='%i'", array($GameCP->whitelist($bid, "int"))), "updating bill totals") or die(mysql_error());
		$ucid = mysql_fetch_array($totala);

		$total = sql_query($safesql->query("SELECT sum(gross), sum(fee) FROM userbills WHERE bid='%i'", array($GameCP->whitelist($bid, "int"))), "updating bill totals") or die(mysql_error());
		$total = mysql_fetch_array($total);

		$totalGross = $total[0];
		$totalFee = $total[1];

		sql_query($safesql->query("UPDATE billing SET gross='%s', fee='%s', taxes='', taxtotal='' WHERE id = '%i'", array($totalGross,$totalFee, $GameCP->whitelist($bid, "int"))), "updating bill totals 2") or die(mysql_error());

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$userInfo=$Panel->GetUser($ucid['cid'], '');

		if($userInfo['taxed'] == "1") $this->Taxes($bid);

	}

	function RefundInsert($bid, $total, $transactionid, $gateway){
		global $GameCP, $safesql, $Event;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		sql_query($safesql->query("INSERT INTO payments SET bid='%s', total='-%s', time='%s', subid='', ip='Refund',transactionid='%s', gateway='%s'", array(
			$GameCP->whitelist($bid, "int"),
			$GameCP->whitelist($Panel->RemFormatNumber($total), "clean"),
			$GameCP->whitelist(date('l jS \of F Y h:i:s A'), "clean"),
			$GameCP->whitelist($transactionid, "clean"),
			$GameCP->whitelist($gateway, "clean")
			))) or die(mysql_error());
	}

	function Refund($bid, $total, $refundtype, $refundpayments){
		global $GameCP, $safesql, $Event;

		if($refundpayments){
			$refqa="total, transactionid, gateway";
			$refq=" AND id='".$GameCP->whitelist($refundpayments, "clean")."'";
		} else {
			$refqa="sum(total)";
			$refq="";
		}
		$paymentTotalaQ = sql_query($safesql->query("SELECT sum(total) FROM payments WHERE bid='%i';", array($GameCP->whitelist($bid, "int"))));
		$globalTotal = mysql_fetch_row($paymentTotalaQ);

		
		$paymentTotalQ = sql_query($safesql->query("SELECT $refqa FROM payments WHERE bid='%i' $refq;", array($GameCP->whitelist($bid, "int"))));
		$paymentTotal = mysql_fetch_row($paymentTotalQ);
		if(!$total) $total=$paymentTotal[0];
		if(isset($paymentTotal[1])){
			$transactionid=$paymentTotal[1];
		} else $transactionid="";
		if(isset($paymentTotal[2])){
			$gateway=$paymentTotal[2];
		} else $gateway="";

		if($total > $paymentTotal[0]) $total=$paymentTotal[0];
		if($total > $globalTotal[0]) $total=$globalTotal[0];
		if($total <= 0) return false;

		if($refundtype == "credit") $this->CreditInsert($bid, $total);
		
		$this->RefundInsert($bid, $total, $transactionid, $gateway);

		$paymentTotalbQ = sql_query($safesql->query("SELECT sum(total) FROM payments WHERE bid='%i';", array($GameCP->whitelist($bid, "int"))));
		$finalTotal = mysql_fetch_row($paymentTotalbQ);
		if($finalTotal[0] <= "0") sql_query($safesql->query("UPDATE billing SET status='Refunded' WHERE id = '%i'", array($GameCP->whitelist($bid, "int")))) or die(mysql_error());

		$Event->EventLogAdd('', "Refunding  ".currencyChar."$total".currencyChar2." to  bill id #".$bid." <br><hr> ".serialize($_REQUEST)." <hr><br><br> - ". date('l jS \of F Y h:i:s A'));

		return true;

	}

	function CreditInsert($bid, $credit){
		global $GameCP, $safesql, $Event;

		$billInformation = sql_query($safesql->query("SELECT U.id, U.credit FROM billing B, users U WHERE B.cid = U.id AND B.id = '%i'", array($GameCP->whitelist($bid, "int")))) or die(mysql_error());
		$info = mysql_fetch_array($billInformation);
		$remainder=$info['credit']+$credit;
		if($remainder < 0) $remainder ="0";
		sql_query($safesql->query("UPDATE users SET credit='%s' WHERE id = '%i'", array($GameCP->whitelist($remainder, "clean"), $GameCP->whitelist($info['id'], "int")))) or die(mysql_error());

		$Event->EventLogAdd('', "Updating user credit to ".currencyChar."$remainder".currencyChar2." to user id #".$info['id']." for bill id #".$bid." <br><hr> ".serialize($_REQUEST)." <hr><br><br> - ". date('l jS \of F Y h:i:s A'));
	}

	function NotifyDonation($cid, $gross, $paid, $status, $email){
		global $GameCP;

		if($paid == '') $paid='0.00';
		$extravars[]=array("var" => "\$Paid", "value" => $paid);
		$extravars[]=array("var" => "\$Gross", "value" => $gross);
		$extravars[]=array("var" => "\$Status", "value" => $status);
		$extravars[]=array("var" => "\$Email", "value" => $email);
		$extravars[]=array("var" => "\$cid", "value" => $cid);

		$GameCP->loadIncludes('email');

		$Email = new Email();
		$Email->templatename = 'Payment-Donation';
		$Email->userid = $cid;
		$Email->bcc=$email;
		$Email->GetTemplateStuff();
		$Email->ReplaceStuff($extravars);
		$Email->send();

		$Email = new Email();
		$Email->templatename = "Payment-Donation-Admin";
		$Email->userid = $cid;
		$Email->GetTemplateStuff();
		$Email->ReplaceStuff($extravars);
		$Email->SendtoAllManagers();

	}

	function AddDonation($cid, $gateway, $gross, $fee, $paid, $transactionid, $status, $who, $email){
		global $GameCP, $safesql, $Event;
		sql_query($safesql->query("INSERT INTO donations SET 
										cid='%s',
										gateway='%s',
										gross='%s',
										fee='%s',
										paid='%s',
										transactionid='%s',
										status='%s',
										ipaddr='%s',
										email='%s',
										date='%s'
									", array(
										$GameCP->whitelist($cid, "int"),
										$GameCP->whitelist($gateway, "clean"),
										$GameCP->whitelist($gross, "clean"),
										$GameCP->whitelist($fee, "clean"),
										$GameCP->whitelist($paid, "clean"),
										$GameCP->whitelist($transactionid, "clean"),
										$GameCP->whitelist($status, "clean"),
										$GameCP->whitelist($who, "clean"),
										$GameCP->whitelist($email, "clean"),
										time()
									))) or die(mysql_error());

		$Event->EventLogAdd('', "Donation Accepted:\n ".currencyChar."$gross".currencyChar2." to user id #".$cid." <br><hr> ".serialize($_REQUEST)." <hr><br><br> - ". date('l jS \of F Y h:i:s A'));
		$this->NotifyDonation($cid, $gross, $paid, $status, $email);

	}
	
	function UserCreditInsert($cid, $credit){
		global $GameCP, $safesql, $Event;

		$billInformation = sql_query($safesql->query("SELECT id, credit FROM users WHERE id = '%i'", array($GameCP->whitelist($cid, "int")))) or die(mysql_error());
		$info = mysql_fetch_array($billInformation);
		$remainder=$info['credit']+$credit;
		if($remainder < 0) $remainder ="0";
		sql_query($safesql->query("UPDATE users SET credit='%s' WHERE id = '%i'", array($GameCP->whitelist($remainder, "clean"), $GameCP->whitelist($info['id'], "int")))) or die(mysql_error());

		$Event->EventLogAdd('', "Updating user credit to ".currencyChar."$remainder".currencyChar2." to user id #".$info['id']."<br><hr> ".serialize($_REQUEST)." <hr><br><br> - ". date('l jS \of F Y h:i:s A'));
	}

	function CreditDedeuctUser($cid, $credit){
		global $GameCP, $safesql, $Event;

		$billInformation = sql_query($safesql->query("SELECT U.id, U.credit FROM users U WHERE U.id = '%i'", array($GameCP->whitelist($cid, "int")))) or die(mysql_error());
		$info = mysql_fetch_array($billInformation);
		$remainder=$info['credit']-$credit;
		if($remainder < 0) $remainder ="0";
		sql_query($safesql->query("UPDATE users SET credit='%s' WHERE id = '%i'", array($GameCP->whitelist($remainder, "clean"), $GameCP->whitelist($info['id'], "int")))) or die(mysql_error());

		$Event->EventLogAdd('', "Updating user credit to ".currencyChar."$remainder".currencyChar2." to user id #".$info['id']." for client id #".$cid." <br><hr> ".serialize($_REQUEST)." <hr><br><br> - ". date('l jS \of F Y h:i:s A'));
	}


	function Credit($bid, $credit, $addtobill=true, $reason=false, $addtouser=true){
		global $GameCP, $safesql, $Event;

		if(!$credit) return false;

		$billInformation = sql_query($safesql->query("SELECT U.id, U.credit FROM billing B, users U WHERE B.cid = U.id AND B.id = '%i'", array($GameCP->whitelist($bid, "int")))) or die(mysql_error());
		$info = mysql_fetch_array($billInformation);
		$remainder=$info['credit']-$credit;
		if($remainder < 0) $remainder ="0";
		if($addtouser) sql_query($safesql->query("UPDATE users SET credit='%s' WHERE id = '%i'", array($GameCP->whitelist($remainder, "clean"), $GameCP->whitelist($info['id'], "int")))) or die(mysql_error());

		if($addtobill == true){
			sql_query($safesql->query("INSERT INTO userbills SET description='Credit', gross='-%s', bid = '%i', cid='%i'", array($GameCP->whitelist($credit, "clean"), $GameCP->whitelist($bid, "int"), $GameCP->whitelist($info['id'], "int")))) or die(mysql_error());
			$this->UpdateBillTotal($bid);
		}

		$Event->EventLogAdd('', "Updating user credit to ".currencyChar."$remainder".currencyChar2." to user id #".$info['id']." for bill id #".$bid." <br><hr> ".serialize($_REQUEST)." <hr><br><br> - ". date('l jS \of F Y h:i:s A'));

		return true;
	}

	function InvoiceData($cid, $bid){
		global $GameCP, $safesql;

		$dueDate='';
		$regDate='';

		$cid=$GameCP->whitelist($cid, 'int');
		$bid=$GameCP->whitelist($bid, 'int');

		$package=array();
		$pi=0;
		$pmi=0;

		if ($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
			$compAdmin = ""; 
		} else $compAdmin = "UB.cid='$cid' AND"; 

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$mainBillQ = mysql_query($safesql->query("SELECT UB.* FROM billing UB WHERE $compAdmin UB.id='%i'", array($bid))) or die(mysql_error());
		$mainBill = mysql_fetch_array($mainBillQ);

		$subBill = mysql_query($safesql->query("SELECT UB.gross, UB.id as 'ubid', UB.fee, B.daystill, B.date, UB.description, UB.pid FROM userbills UB, billing B WHERE $compAdmin UB.bid = '%i' AND UB.bid = B.id", array($bid)));
			while ($subrow = mysql_fetch_array($subBill)) {

				$daysTill = $subrow['daystill']; 	
				$pid = $subrow['pid'];
				$theDate = $subrow['date'];

				if($daysTill == "0" || $daysTill == "1" || !$daysTill) { 
					$daysPlus="0"; 
				}elseif($daysTill == "31") { 
					$daysPlus="1 month"; 
				} elseif($daysTill == "91") { 
					$daysPlus="3 months"; 
				} elseif($daysTill == "182") { 
					$daysPlus="6 months"; 
				} elseif($daysTill == "365") { 
					$daysPlus="1 year"; 
				} elseif($daysTill == "730") $daysPlus="2 years";
		
				$dueDate = date(dateformat, strtotime(date(dateformat, strtotime($theDate)) . " +".$daysPlus));
				$regDate =date(dateformat, strtotime($theDate));

				$billDetailsQ = sql_query($safesql->query("SELECT gross, id as 'ubid', fee, description, taxed, tax FROM userbills WHERE id='%i'", array($subrow['ubid'])));
				$billDetails = mysql_fetch_assoc($billDetailsQ);
				
				$packDetailsQ = sql_query($safesql->query("SELECT P.name as 'package', UP.name as 'product' FROM prices P, packages UP WHERE P.id = '%i' AND P.pid = UP.id ORDER BY P.name", array($pid)));
				$packDetails = mysql_fetch_assoc($packDetailsQ);

				if($subrow['description']){
					if($packDetails['product']){
						$description=$packDetails['product'].": ".$packDetails['package'] ." (".$subrow['description'].")";
					} else $description=$subrow['description'];
 				} else $description=$packDetails['product'].": ".$packDetails['package'];
				
				if($daysTill != "0"){
					if($daysPlus == "0"){
						$datetxt=$regDate;
					} else $datetxt=$regDate.' to '. $dueDate;
				} else $datetxt=$regDate;
				$package[$pi] =array($description, $datetxt,  $Panel->FormatNumber($subrow[0]), $billDetails['taxed'],$billDetails['tax']);
				$pi++;
			} // end subbill while

			$payments=array();
			$pmi=0;
			if(isset($_SESSION['gamecp']['subuser']['id'])){
				$bpsql="subid='".$_SESSION['gamecp']['subuser']['id']."' AND bid='$bid'";
			} else $bpsql="bid='$bid'";
			$billPayment = sql_query($safesql->query("SELECT total, time, cid, subid FROM payments WHERE $bpsql;", array()));
			if(mysql_num_rows($billPayment) > 0){
				while ($payrow = mysql_fetch_array($billPayment)) {

					if($payrow['subid']){
						$userInfo=$Panel->GetUser($payrow['subid'], '', true);
					} else $userInfo=$Panel->GetUser($payrow['cid'], '');
					
						$paidbyname=$userInfo['name'];

					$payments[$pmi] =array("total" => $Panel->FormatNumber($payrow[0]), "time" => $payrow[1], "paidby" => $paidbyname);
					$pmi++;
				} 
			}
		return array($payments, $package, $mainBill, $dueDate, $regDate);
	}

	function Remove($bid){
		global $GameCP, $safesql;
		sql_query($safesql->query("DELETE FROM billing WHERE id='%i';", array($GameCP->whitelist($bid, "int")))) or die(mysql_error()); 	
		sql_query($safesql->query("DELETE FROM userbills WHERE bid='%i';", array($GameCP->whitelist($bid, "int")))) or die(mysql_error()); 	
		sql_query($safesql->query("DELETE FROM payments WHERE bid='%i';", array($GameCP->whitelist($bid, "int")))) or die(mysql_error()); 	
	}


	function GetNewDay($daystillQ){
			if($daystillQ == "31") { 
				$daysPlus="1 month"; 
			} elseif($daystillQ == "91") { 
				$daysPlus="3 months"; 
			} elseif($daystillQ == "182") { 
				$daysPlus="6 months"; 
			} elseif($daystillQ == "365") { 
				$daysPlus="12 months"; 
			} elseif($daystillQ == "730") { 
				$daysPlus="24 months";
			} else $daysPlus=$daystillQ ." days"; 
		return $daysPlus;
	}


	function GetDueDate($base_time, $daystillQ){
		$months=$this->GetNewDay($daystillQ);
		$x_months_to_the_future = strtotime( "$base_time + $months");
		return date(dateformat, $x_months_to_the_future);
	} 

	function NotifyPayment($cid, $notifyuser=true, $bid, $orderStatus, $paidPrice, $message=FALSE){
		global $GameCP;

		switch($orderStatus){
			case "Failed":
				$emailtpl="Payment-Failed";
			break;

			case "Completed":
				$emailtpl="Payment-Completed";
			break;
			
			case "Pending":
				$emailtpl="Payment-Pending";
			break;

			case "IPN":
				$emailtpl="Payment-Pending";
			break;
		}

		$extravars=array();
		if(!$paidPrice) $paidPrice="0.00";
		$extravars[]=array("var" => "\$Var1", "value" => "Invoice");
		$extravars[]=array("var" => "\$Var2", "value" => $bid);
		$extravars[]=array("var" => "\$Var3", "value" => $message);
		$extravars[]=array("var" => "\$Status", "value" => $orderStatus);
		$extravars[]=array("var" => "\$Payment", "value" => $paidPrice);
		$extravars[]=array("var" => "\$cid", "value" => $cid);

		$GameCP->loadIncludes('email');

		if($notifyuser == true){
			$Email = new Email();
			$Email->templatename = $emailtpl;
			$Email->userid = $cid;
			$Email->billid = $bid;
			$Email->GetTemplateStuff();
			$Email->ReplaceStuff($extravars);
			$Email->send();
		}

		if(notifyadminpayment == '1'){
			$Email = new Email();
			$Email->templatename = $emailtpl."-Admin";
			$Email->userid = $cid;
			$Email->billid = $bid;
			$Email->GetTemplateStuff();
			$Email->ReplaceStuff($extravars);
			$Email->SendtoAllManagers();
		}

		return true;
	}


	function AddPayment($billId, $payment_amount, $subscr_id, $tranid=false, $gateway=false, $fee=false, $billdate=false, $billip=false, $notify=true, $remformat=true){
		global $Event, $GameCP, $safesql;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		if(!$billId){
			$bqlook = sql_query($safesql->query("SELECT id FROM billing WHERE subscr_id= '%s' LIMIT 1", array($GameCP->whitelist($subscr_id, "clean")))) or die(mysql_error());
			$bqlook = mysql_fetch_array($bqlook);
			$billId = $bqlook[0];
		}
		if(!$billId){
			$Event->EventLogAdd('', "Billing could not determine billID for payment $payment_amount <br><hr> ".serialize($_REQUEST)." <hr><br><br> - ". date('l jS \of F Y h:i:s A'));
		} else $Event->EventLogAdd('', "Billing system received payment $payment_amount for bill #$billId - ". date('l jS \of F Y h:i:s A'));

		$billInformation = sql_query($safesql->query("SELECT gross, cid, subscr_id, services, suspend, status FROM billing WHERE id = '%i'", array($GameCP->whitelist($billId, "int")))) or die(mysql_error());
		$info = mysql_fetch_array($billInformation);
		$grossDue=$info[0];
		$cid=$info[1];
		$services=unserialize($info[3]);
		$suspend=$info[4];
		$status=$info[5];

		$totalPaidQ = sql_query($safesql->query("SELECT sum(total) FROM payments WHERE bid = '%i'", array($GameCP->whitelist($billId, "int")))) or die(mysql_error());
		$totalPaid = mysql_fetch_array($totalPaidQ);
		$grossPaid=$totalPaid[0];
		$totalDue=$grossDue-$grossPaid;
		$totalWithPaid=$totalDue-$payment_amount;
		if($totalWithPaid <= "0"){
			if($totalWithPaid < "0"){
				/* over paid */
				$clientCreditQ = sql_query($safesql->query("SELECT credit FROM users WHERE id = '%i'", array($GameCP->whitelist($cid, "int")))) or die(mysql_error());
				$clientCredit = mysql_fetch_array($clientCreditQ);
				$credit=$clientCredit[0]+abs($totalWithPaid);
				sql_query($safesql->query("UPDATE users SET credit='%s' WHERE id = '%i'", array($GameCP->whitelist($credit, "clean"),$GameCP->whitelist($cid, "int")))) or die(mysql_error());
				$Event->EventLogAdd('', "Adding credit of $credit to user id #$cid <br><hr> ".serialize($_REQUEST)." <hr><br><br> - ". date('l jS \of F Y h:i:s A'));
			}

			/* Bill was fully paid */
			$orderStatus = "Completed";
			$totalLeft=$totalWithPaid;

		} else {
			/* Bill was not fully paid */
			$orderStatus = "Pending";
			$totalLeft=$totalWithPaid;
		}


		$gatewayInfoQ = sql_query($safesql->query("SELECT fullname FROM gateways WHERE name = '%s'", array($GameCP->whitelist($gateway, "clean")))) or die(mysql_error());
		$gatewayInfo = mysql_fetch_assoc($gatewayInfoQ);

		if($remformat){
			$payment_amount=$Panel->RemFormatNumber($payment_amount);
			$fee=$Panel->RemFormatNumber($fee);
		}

		if(!$billdate) $billdate=date('l jS \of F Y h:i:s A');
		if(!$billip) $billip=$_SERVER['REMOTE_ADDR'];
		if(!$payment_amount) $payment_amount="0.00";
		if($billId) sql_query($safesql->query("INSERT INTO payments SET total = '%s', cid='%i', bid='%i', time='%s', ip='%s', transactionid='%s', gateway='%s', fee='%s'", array(
					$GameCP->whitelist($payment_amount, "clean"),	
					$GameCP->whitelist($cid, "int"),	
					$GameCP->whitelist($billId, "int"),	
					$billdate,
					$GameCP->whitelist($billip, "clean"),	
					$GameCP->whitelist($tranid, "clean"),
					$GameCP->whitelist($gatewayInfo['fullname'], "clean"),
					$GameCP->whitelist($fee, "clean")
			)));
		
		$this->UpdateBillTotal($billId);

		sql_query($safesql->query("UPDATE billing SET status='%s' WHERE id='%i'", array($GameCP->whitelist($orderStatus, "clean"),$GameCP->whitelist($billId, "int")))) or die(mysql_error()); 
		if($subscr_id && !$info['subscr_id']) sql_query($safesql->query("UPDATE billing SET subscr_id='%s' WHERE id='%i'", array($GameCP->whitelist($subscr_id, "clean"),$GameCP->whitelist($billId, "int")))) or die(mysql_error()); 

		if($notify == true) $this->NotifyPayment($cid, true, $billId, $orderStatus, $payment_amount);

		if($orderStatus == "Completed" && $status == "Pending" && $suspend == "1"){
			if(is_array($services) && count($services) > 0){
				$GameCP->loadIncludes("suspend");
				$Suspend=new Suspend();
				// pick the service id, check if it was suspended
				foreach($services as $ser){
					if(preg_match("/game/s" ,$ser)){
						$serviceid=preg_replace("/game/s", '' ,$ser);
						$Suspend->GameRestore($serviceid);

					} else if(preg_match("/voice/s" ,$ser)){
						$serviceid=preg_replace("/voice/s", '' ,$ser);
						$Suspend->VoiceRestore($serviceid);
					}
				}
			}
		}
		return $totalLeft;
	}

	function UpdateServices($bid, $services=array()){
		global $GameCP, $safesql;
		sql_query($safesql->query("UPDATE billing SET services='%s' WHERE id='%i'", array(serialize($services),$GameCP->whitelist($bid, "int")))) or die(mysql_error()); 
	}

	/**
	 * add a bill to a user
	 */
	function AddBill($daystill='31', $cid, $date, $status, $gross, $fee, $subscr_id, $promo=FALSE){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$gross=$Panel->FormatNumber($gross);
		$fee=$Panel->FormatNumber($fee);
		sql_query($safesql->query("INSERT INTO billing SET 
				cid = '%i',
				date = '%s',
				status = '%s',
				gross = '%s',
				fee = '%s',
				`update` = '0',
				daystill = '%s',
				subscr_id='%s',
				promo='%s'", array(
			$GameCP->whitelist($cid, "int"),
			$GameCP->whitelist($date, "clean"),
			$GameCP->whitelist($status, "clean"),
			$GameCP->whitelist($gross, "clean"),
			$GameCP->whitelist($fee, "clean"),
			$GameCP->whitelist($daystill, "clean"),
			$GameCP->whitelist($subscr_id, "clean"),
			$GameCP->whitelist($promo, "clean")))) or die(mysql_error());
		$bid = mysql_insert_id();

		return $bid;
	}


	function UpdateBillTotal($bid){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$total = sql_query($safesql->query("SELECT sum(gross), sum(fee) FROM userbills WHERE bid='%i'", array($GameCP->whitelist($bid, "int")))) or die(mysql_error());
		$total = mysql_fetch_array($total);
		$totalGross = $Panel->FormatNumber($total[0]);
		$totalFee = $Panel->FormatNumber($total[1]);
		sql_query($safesql->query("UPDATE billing SET gross= '%s', fee= '%s' WHERE id = '%i'", array($totalGross,$totalFee, $GameCP->whitelist($bid, "int")))) or die(mysql_error());
	}


	function CreateSubBill($addbill, $bid, $ugid, $vid, $ordergame, $ordervoice, $cid, $promo, $paddons=FALSE, $taxes=FALSE, $description=FALSE, $moduleid=FALSE){
		if($bid && ($addbill == "yes" || $addbill == "1")){
			$services=array();
			if($ugid) $services[]="game$ugid";
			if($moduleid) $services[]="module$moduleid";
			if($vid && ($ordervoice['type'] == "1003" || $ordervoice['type'] == "1004")){
				$services[]="game$vid";
			} elseif($vid) $services[]="voice$vid";

			$this->UpdateServices($bid, $services);
			if(is_array($ordergame) && isset($ordergame['id']) && $ordergame['id']) $this->AddSubBill($bid, $cid, $ordergame['id'], $ordergame['cost'], $ordergame['fee'], $description, @$taxes[0], $ugid);
			if(is_array($ordervoice) && isset($ordervoice['id']) && $ordervoice['id']) $this->AddSubBill($bid, $cid, $ordervoice['id'], $ordervoice['cost'], $ordervoice['fee'], $description, @$taxes[1], false, $uvid);

			if(is_array($promo) && count($promo) > 0){
				foreach($promo as $pm => $pv) $this->AddSubBill($bid, $cid, '', "-".@$pv['total'], '', 'Promotions: '. $pm);
			}
			if(is_array($paddons) && count($paddons) > 0){
				foreach($paddons as $pm => $pv) $this->AddSubBill($bid, $cid, '', @$pv['total'], @$pv['fee'], @$pv['name'] ." ". @$pv['pname'], @$taxes[2]);
			}
			if((is_array($paddons) && count($paddons) > 0) || (is_array($promo) && count($promo) > 0) || (is_array($ordergame) && $ordergame['id']) || (is_array($ordervoice) && $ordervoice['id'])) $this->UpdateBillTotal($bid);
		}
	}

	function AddSubBill($bid, $cid, $pid="0", $gross, $fee, $description, $taxed=0, $ugid=false, $uvid=false){
		global $GameCP, $safesql;
		/* insert prices */

		sql_query($safesql->query("INSERT INTO userbills SET 
			cid='%s',
			bid='%s',
			pid='%s',
			gross='%s',
			fee='%s',
			description='%s',
			ugid='%i',
			uvid='%i',
			taxed='%i';", array(
				$GameCP->whitelist($cid, "int"),
				$GameCP->whitelist($bid, "int"),
				$GameCP->whitelist($pid, "int"),
				$GameCP->whitelist(str_replace(",", '', $gross), "clean"),
				$GameCP->whitelist(str_replace(",", '', $fee), "clean"),
				$GameCP->whitelist($description, "clean"),
				$GameCP->whitelist($ugid, "int"),
				$GameCP->whitelist($uvid, "int"),
				$GameCP->whitelist($taxed, "int")))) or die(mysql_error());
		return mysql_insert_id();
	}



	/**
	 * display the spent totals, this is a template item
	 */
	function ShowSpent() {
		global $smarty,$Panel; 

		if ($_SESSION['gamecp']['userinfo']['ulevel'] == "1") {

			$sql="SELECT SQL_CALC_FOUND_ROWS * FROM charges ORDER BY `id` DESC";
			/* page control */
			$formName="companycharges";

			if(isset($_REQUEST['show']) && $_REQUEST['show'] == "allcharges"){
				$pglimit="1000";
			} else $pglimit="4";

			$resultChar=Smarty_PageControl($sql, $formName, $formName, $pglimit);

			$all=array();
			while ($row = mysql_fetch_array($resultChar)) {
				$row['sum']=$Panel->FormatNumber($row['sum']);
				$all[]=$row;

				}
			$smarty->assign("charges", $all);

			return true;
		} // End If 

		return false;
	}

	/**
	 * return the time difference between 2 dates
	 */
	function DateDifference($start, $end) {
		return (strtotime($end)-strtotime($start))/86400;
	}

	/**
	 * send a valid API array to the Billing API
	 */
	function Send($args, $values) {
		$post = 'passphrase='.urlencode(mbpassword).'&debugging=true';
		if(is_array($values)){
			foreach ($values as $key => $value) {
				$post .= "&$key=".urlencode(str_replace('\'','',$value));
			}
		}
		$ch = curl_init(url . "/billing/mb/index.php?".$post);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		//curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		set_time_limit(120);
		$result = curl_exec($ch);      
		curl_close($ch);


		return $result;
	}

	/**
	 * used in the Billing API to verify the result was OK or not
	 */
	function GetStatus($r_result){
		
		if(!$r_result){
			return "GameCP did not reply to your command.<br>Please check your package configuration.<br> Please contact GameCP for support.";
		} elseif (preg_match("/Command Execution Result: Ok/i", strip_tags($r_result))){
			return "completed";
		} elseif(preg_match("/Unable to determine IP address/i", strip_tags($r_result))){
			return "GameCP was unable to select an ip address for this server.<br>Please check your machines slot and user quota.<br> Please contact GameCP for support.";
		} elseif (preg_match("/Passed Security Checks: Failed/i", strip_tags($r_result))){
			return "Your GameCP passphrase is incorrect.<br>Check your settings.<br> Please contact GameCP for support.";
		} else {
			print_r($r_result);
			return "There was an unknown problem with the API, check the debugging details below:<br>";
		}		
	}

	function GetUserTotals($cid){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$total = sql_query($safesql->query("SELECT sum(gross), sum(fee) FROM userbills WHERE cid='%i'", array($GameCP->whitelist($cid, "int")))) or die(mysql_error());
		$total = mysql_fetch_array($total);
		$totalGross = $Panel->FormatNumber($total[0]);
		$totalFee = $Panel->FormatNumber($total[1]);
		$total2 = sql_query($safesql->query("SELECT sum(total) FROM payments WHERE cid='%i'", array($GameCP->whitelist($cid, "int")))) or die(mysql_error());
		$total2 = mysql_fetch_array($total2);
		$totalPayments = $Panel->FormatNumber($total2[0]);

		return array("total" => $totalGross, "fee" => $totalFee, "paid" => $totalPayments);
	}

	function GetUserNextBills($cid){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$total = sql_query($safesql->query("SELECT * FROM billing WHERE `update`= '0' AND status !='Canceled' AND cid='%i'", array($GameCP->whitelist($cid, "int")))) or die(mysql_error());
		$result=array();
		while($row = mysql_fetch_array($total)){
			$result[]=array("date" => $this->GetDueDate($row['date'],  $row['daystill']), "invoice" => $row['id'], "total" => $Panel->FormatNumber($row['gross']));

		}
		return $result;
	}


}
?>