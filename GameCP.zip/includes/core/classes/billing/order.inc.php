<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/**
 * Order class to manage GameCP order system
 * 
 * This class manages the order system in GameCP
 * API and internal use
 * This class duplicates a few items from GameCP() & User()
 * That is done mainly for adapating it to an external API
 * 
 */

class Order{

	function LoadGateway($gateway){
		global $safesql, $GameCP;

		$gateWayInfo = mysql_query($safesql->query("SELECT * FROM gateways WHERE name='%s'", array($GameCP->whitelist($gateway))))  or die(mysql_error());
		$gateway = mysql_fetch_array($gateWayInfo);

		$gatewayFile=path."/includes/gateways/".$gateway['name']."/include.php";
		if(is_file($gatewayFile)) require_once($gatewayFile);
	}

	function AddToQueue(){
		$qid=$this->QueueUser();
		$this->SaveFraudStatus($qid);
		$this->QueueEmail($qid);
		if(sendorderreceipt == '1') $this->QueueEmailUser($qid);

		return $qid;
	}

	function SaveFraudStatus($qid){ 
		global $GameCP, $safesql;
		if(!isset($_SESSION['gamecp']['fraud_error'])) return false;
		$d=array();
		$d['status']=true;
		$d['reason']=$_SESSION['gamecp']['fraud_error'];
		$d['checks']=$_SESSION['gamecp']['fraud_check'];
		$d['refcode']=$_SESSION['gamecp']['fraud_ref_code'];
		$ub = sql_query($safesql->query("UPDATE queue SET fraudcheck='%s' WHERE id='%i'", array(json_encode($d), $GameCP->whitelist($qid, "int"))), "updatefraudcheck") or die(mysql_error());
	}

	function FormatNumber($num){
		$format=currencyFormat;
		if($num == "0") return "0.00";
		if(!$num) return "0.00";

		if(isset($_SESSION['gamecp']['exchange'])){
			$format=$_SESSION['gamecp']['exchange']['format'];
			$num=$num * $_SESSION['gamecp']['exchange']['rate'];
		}

		if(is_numeric($num) && function_exists("number_format")){
			switch($format){
				case "1":
					return number_format($num, 2, '.', ',');
				break;
				case "2":
					return number_format($num, 2, '.', '');
				break;
				case "3":
					return number_format($num, 2, ',', '.');
				break;
				case "4":
					return number_format($num, 0, '', ',');
				break;

			}
		} else return $num;
	}

	// we now display formatted, not code in it, so unused!
	function RemFormatNumber($num){
		$format=currencyFormat;
		
		switch($format){
			case "1":
				return str_replace(",",'',$num);
			break;
			case "2":
				return $num;
			break;
			case "3":
				$num=str_replace(".", "",$num);
				return str_replace(",",'.',$num);
			break;
			case "4":
				return str_replace(",",'',$num);
			break;

		}
	}



	function Taxes(){
		global $GameCP;

		$GameCP->loadIncludes("billing");
		$Billing=new Billing();
		$totaltotax="0";

		if($_SESSION['gamecp']['orderDetails']['taxproduct'] == "1") $totaltotax=$_SESSION['gamecp']['orderDetails']['packageGrossA'];
		if(isset($_SESSION['gamecp']['orderDetails']['voiceCost']) && $_SESSION['gamecp']['orderDetails']['voiceserver'] == true && $_SESSION['gamecp']['orderDetails']['taxvoice'] == "1") $totaltotax=$totaltotax+$_SESSION['gamecp']['orderDetails']['voiceCost'];
		if(isset($_SESSION['gamecp']['orderDetails']['atotal']) && $_SESSION['gamecp']['orderDetails']['atotal'] && $_SESSION['gamecp']['orderDetails']['taxaddons'] == "1") $totaltotax=$this->$totaltotax+$_SESSION['gamecp']['orderDetails']['atotal'];
		
		$types=array_merge($Billing->GetUserTax($_SESSION['gamecp']['orderDetails']['country'], $_SESSION['gamecp']['orderDetails']['state'], "1"), $Billing->GetUserTax($_SESSION['gamecp']['orderDetails']['country'], $_SESSION['gamecp']['orderDetails']['state'], "2"));
		$res=$Billing->CalculateTax($totaltotax, $types);

		$_SESSION['gamecp']['orderDetails']['taxes']=$res[0];
		$_SESSION['gamecp']['orderDetails']['taxtotal']=$res[1];

	}


	function ProcessAddon($aid, $atotal, $paddons, $packageTerm, $t, $intype, $multiply=false){

		$in=$this->GetAddon($aid);		

		if($packageTerm == "hourly"){
			$ct=$in['rate'] * $t;
		} elseif(isset($in[$packageTerm])){
			$ct=$in[$packageTerm];
		} else $ct="";

		if($intype['type'] == "quantity"){
			if(!$multiply) 	return array($paddons, $atotal);

			$intype['pname']=$multiply." x " .$in['name'];
		} elseif($intype['type'] == "input"){
			if(!$multiply) 	return array($paddons, $atotal);
			$intype['pname']=$in['name']. " = ". $multiply;
		} else $intype['pname']=$in['name'];

		if($ct){
			if($intype['type'] == "quantity") $ct=$ct*$multiply;
			//$ct=$this->FormatNumber($ct);
			$intype['total']=$ct;
			$atotal=$atotal+$ct;
		}
		$intype['cval']=$in['cval'];
		$intype['multiply']=$multiply;
		$paddons[]=$intype;

		return array($paddons, $atotal);

	}

	function GetAddon($pid){
		global $safesql, $GameCP;

		$info = sql_query($safesql->query("SELECT *, cost as 'monthly' FROM paddon WHERE id ='%i' LIMIT 1;", array($pid))) or die(mysql_error());
		return mysql_fetch_assoc($info);
	}

	function GetCategories(){
		$result=array();
		$info=Smarty_PageControl("SELECT SQL_CALC_FOUND_ROWS * FROM categories WHERE status='1' ORDER BY rank", "order", "order");
		while($cat = mysql_fetch_assoc($info)) $result[]=$cat;
		return $result;
	}

	function GetCategory($id){
		global $safesql, $GameCP;

		$info = sql_query($safesql->query("SELECT * FROM categories WHERE id ='%i' LIMIT 1;", array($id))) or die(mysql_error());
		return mysql_fetch_assoc($info);
	}

	function GetAddonType($pid){
		global $safesql, $GameCP;

		$info = sql_query($safesql->query("SELECT * FROM paddontype WHERE id ='%i' LIMIT 1", array($pid))) or die(mysql_error());
		$pinf = mysql_fetch_assoc($info);
		return $pinf;

	}

	function ProductAddons($pid, $pubpriv){
		global $safesql, $GameCP;
		$re=array();

		$info = sql_query($safesql->query("SELECT * FROM paddontype WHERE prodid ='%i' ORDER BY rank ASC", array($pid))) or die(mysql_error());
		while($pinf = mysql_fetch_assoc($info)){

			$prodid=$pinf['id'];
			$p2=array();

			$info2 = sql_query($safesql->query("SELECT * FROM paddon WHERE pid ='%i' AND (pubpriv = 'both' OR pubpriv='%s') ORDER BY rank ASC;", array($prodid, $pubpriv))) or die(mysql_error());
			if(mysql_num_rows($info2) > 0){
				while($prodinfo = mysql_fetch_assoc($info2)) $p2[]=$prodinfo;
				$pinf['items']=$p2;
				$re[]=$pinf;
			}
		}
		return $re;
	}


	function InvalidNames(){

		$invalidnames=array();
		$invalidnamesQ=sql_query("SELECT deny FROM denyusers;");
		while($inv=mysql_fetch_array($invalidnamesQ)){
			$invalidnames[]=$inv['deny'];
		}
		return $invalidnames;
	}

	function GetInstalledOn($packageGid){
		global $GameCP;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$gameInfo=$Panel->GetGame($packageGid);
		$d=unserialize($gameInfo['installedon']);
		$r=array();
		if(is_array($d) && count($d) > 0){
			foreach($d as $a => $b){
				if(trim($b)) $r[]=$a;
			}
		}
		return $r;
	}

	function GetDarkstarLocation(){
		global $GameCP;
		$a=array();
		if(usedarkstarvent == "yes"){
			$GameCP->loadIncludes("darkstarllc");
			$darkstar=darkstar_getLocations();
			$location="";
			$list=unserialize($darkstar['result']);
			if(is_array($list)){
				foreach($list as $row){
					if($row['name']) $a[]=$row;
				}
			}
		}
		return $a;
	}

	function CheckName($username){
		global $safesql, $GameCP;
		if(!$username) return "1";

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$invalidnames=$Panel->InvalidNames();

		if(in_array(strtolower($username), $invalidnames)) return "1";
		$uname = sql_query($safesql->query("SELECT name FROM users where name='%s'", array($this->whitelist($username, "clean")))) or die(mysql_error()); 
		return mysql_num_rows($uname);
	}

	function CheckEmail($email){
		global $safesql, $GameCP;
		if(!$email) return "1";
		$umailQ = sql_query($safesql->query("SELECT id FROM users where email='%s'", array($this->whitelist($email, "clean")))) or die(mysql_error()); 
		return mysql_num_rows($umailQ);
	}

	function CheckAvailability($gmid, $packageSlots, $serverLocation, $overLoad){
		global $GameCP, $LNG_SOLDOUT;

		$GameCP->loadIncludes("ip");
		$IP=new IP();
		$fip=$IP->GetIP($this->whitelist($gmid, "int"), $this->whitelist($packageSlots, "clean"), $this->whitelist($serverLocation, "clean"));

		if(!$fip){
			if($overLoad == "1"){
				$sidQ = sql_query("SELECT sid, (quota-used) as slots, os FROM servers WHERE quota != '0' AND active='1' ORDER BY slots DESC LIMIT 1") or die(mysql_error());
				$sidA = mysql_fetch_row($sidQ); 
				$GameCP->loadIncludes("ip");
				$IP=new IP();
				$fip=$IP->GetServer($sidA[0]);
			} else $this->Error($LNG_SOLDOUT);
		}
		return $fip;
	}

	function Error($msg){
		global $smarty;
		$smarty->assign("errorCode", $msg);
		$smarty->display("order/error.tpl");
		exit;
	}

	function GetQueueStatus(){
		global $safesql, $GameCP;
		$checkQ = sql_query($safesql->query("SELECT user, status, `mod` FROM queue where id='%i'", array($this->whitelist($_SESSION['gamecp']['orderDetails']['qid'], "int")))) or die(mysql_error()); 
		return mysql_fetch_row($checkQ);
	}

	function GetServer(){
		global $safesql, $GameCP;
		$sidQ = sql_query($safesql->query("SELECT S.os, S.sid FROM servers S, iptable I WHERE I.sid = S.sid AND I.ip='%s' AND S.active='1' LIMIT 1"), array($this->whitelist($_SESSION['gamecp']['orderDetails']['fip'], "clean"))) or die(mysql_error());
		return mysql_fetch_row($sidQ); 
	}


	function SetQueue($newmod){
		global $safesql, $GameCP;
		sql_query($safesql->query("UPDATE queue SET `mod`='%s' where id='%i'", array($newmod,$this->whitelist($_SESSION['gamecp']['orderDetails']['qid'], "int")))) or die(mysql_error()); 
	}

	function GetGateways($name=false){
		global $safesql, $GameCP;
		$gatewayList=array();
		if($name){
			$gateways = sql_query($safesql->query("SELECT * FROM gateways WHERE status='1' AND name='%s' LIMIT 1", array($this->whitelist($name, "clean")))) or die(mysql_error());
		} else $gateways = sql_query("SELECT * FROM gateways WHERE status='1' ORDER BY name") or die(mysql_error());

		while ($row = mysql_fetch_array($gateways)) {
			$gatewayList[]=$row;
		}
		return $gatewayList;
	}

	function GetPromotions(){
		global $safesql, $GameCP;
		$promoQ = sql_query($safesql->query("SELECT * FROM promotions where name='%s' LIMIT 1;", array($this->whitelist($_REQUEST['code'], "clean")))) or die(mysql_error());
		return mysql_fetch_array($promoQ);
	}

	function GetPromotionUse($id){
		global $safesql, $GameCP;
		$usesQ = sql_query($safesql->query("SELECT * FROM promotionsuse WHERE pmid ='%s'", array($this->whitelist($id, "int")))) or die(mysql_error());
		return mysql_num_rows($usesQ);
	}

	function GetPromotionByUser($id, $uid){
		global $safesql, $GameCP;
		$usrusesQ = sql_query($safesql->query("SELECT * FROM promotionsuse WHERE pmid ='%s' AND cid='%s'", array($this->whitelist($id, "int"),$this->whitelist($uid, "int")))) or die(mysql_error());
		return mysql_num_rows($usrusesQ);
	}

	function GetLocations($gmid=FALSE, $slots=FALSE){
		global $safesql, $GameCP;
		$a=array();
		$game_machines=array();
		$gquery='';

		if($gmid){
			$gameInfoQ = sql_query($safesql->query("SELECT installedon FROM game WHERE id='%i'", array($GameCP->whitelist($gmid, "int")))) or die(mysql_error()); 
			$gameInfo=mysql_fetch_array($gameInfoQ);
			$installed=unserialize($gameInfo['installedon']);
			if(is_array($installed) && count($installed) > 0){
				$machineInfoQ = sql_query("SELECT distinct(sid) FROM iptable WHERE ip IN ('" . implode("','", $installed) . "');") or die(mysql_error()); 
				while($machineInfo=mysql_fetch_array($machineInfoQ)) $game_machines[]=$machineInfo['sid'];
			} else $installed=array();
		}
		if(is_array($game_machines) && count($game_machines) > 0) $gquery="AND sid IN ('" . implode("','", $game_machines) . "')";

		$q = "SELECT DISTINCT location, os, ip,quota-used as 'available', slotquota-slotused as 'slotsavail' FROM `servers`
												WHERE                                            
												 gamehost = 'yes'
												 AND (slotquota-slotused >= '$slots' OR slotquota = '0')
												 AND quota-used >= '1'
												 AND active='1'
												 $gquery";
		$locationQ = sql_query($q);
		while($row=mysql_fetch_array($locationQ)) $a[]=$row;
		return $a;
	}

	function GetVoiceLocations($type, $slots){
		global $GameCP, $safesql;
		$a=array();
		switch($type){

			case "1000":
				$typeQ="ts2='1'";
			break;
			case "1002":
				$typeQ="ts3host='1'";
			break;
			case "1001":
				$typeQ="vent='1'";
			break;
			case "1003":
				$typeQ="mohawk='1'";
			break;
			case "1004":
				$typeQ="mumble='1'";
			break;
		}

		if($type == "1001" && usedarkstarvent == "yes"){
			$darkstar=$this->GetDarkstarLocation();
			if(is_array($darkstar)){
				foreach($darkstar as $row)$a[$row['id']]=$row['name']; 
			}
		} else {

			$q=$safesql->query("SELECT DISTINCT location, os, ip, quota-used as 'available', slotquota-slotused as 'slotsavail' FROM `servers`
												WHERE                                            
												 $typeQ
												 AND (slotquota-slotused >= '%i' OR slotquota = '0')
												 AND quota-used >= '1' AND active='1';", array($GameCP->whitelist($slots, "int")));
			$locationQ = sql_query($q);
			while($row=mysql_fetch_array($locationQ)) $a[]=$row;
		}
		return $a;
	}

	function GetPackageInfo($gmida){
		global $safesql, $GameCP;
		$pName = sql_query($safesql->query("SELECT * FROM packages WHERE id = '%i' LIMIT 1", array($this->whitelist($gmida, "int")))) or die(mysql_error());
		return mysql_fetch_array($pName);
	}

	function GetPackageGame($packageGid){
		global $safesql, $GameCP;
		$gName = sql_query($safesql->query("SELECT * FROM game WHERE id='%i'", array($this->whitelist($packageGid, "int")))) or die(mysql_error());
		return mysql_fetch_array($gName);
	}

	function GetResellerList(){
		global $safesql, $GameCP;
		$resellerList=array();
		if(isset($_COOKIE["gcporderrsid"])){
			$packageResult = sql_query($safesql->query("SELECT id, name FROM users WHERE name='%s' OR id='%i' LIMIT 1", array($this->whitelist($_COOKIE["gcporderrsid"], "clean"),$this->whitelist($_COOKIE["gcporderrsid"], "clean")))) or die(mysql_error());
			while ($row1 = mysql_fetch_array($packageResult)){
				if($row1['name']) $resellerList[]=$row1;
			}
		} else {
			$packageResult = sql_query("SELECT id, name FROM users WHERE userlevel='4'") or die(mysql_error());
			while ($row1 = mysql_fetch_array($packageResult)){
				if($row1['name']) $resellerList[]=$row1;
			}
		}
		return($resellerList);
	}


	function GetPriceList($gmid){
		global $safesql, $GameCP;
		$ab=array();
		$packageInfo = sql_query($safesql->query("SELECT cost as 'monthly', fee, name, quarterly, semiannualy, annauly, 2years, slots, rate as 'hourly', id, type FROM prices WHERE pid='%i' ORDER BY slots ASC", array($this->whitelist($gmid, "int")))) or die(mysql_error());
		while($a=mysql_fetch_array($packageInfo)) $ab[]=$a;
		return $ab;
	}



	function GetPriceInfo($gmid){
		global $safesql, $GameCP;
		$a=array();
		$packageInfo = sql_query($safesql->query("SELECT cost as 'monthly', fee, name, quarterly, semiannualy, annauly, 2years, slots, rate as 'hourly', id FROM prices WHERE id='%i'", array($this->whitelist($gmid, "int")))) or die(mysql_error());
		return mysql_fetch_array($packageInfo);
	}

	function GetPackages($doVoice, $gmid, $cat=false){
		global $safesql, $GameCP;
		$packArray=array();

		$doVoiceSql=""; 
		if($doVoice == "1") $doVoiceSql="WHERE gid !='1001'"; 
		if($doVoice == "2") $doVoiceSql="WHERE (gid !='1000' AND gid !='1002' AND gid !='1003' AND gid !='1004')"; 
		
		if($gmid){
			if($cat) $cat=$safesql->query(" AND category='%s'", array($cat));
			$game = $safesql->query("SELECT SQL_CALC_FOUND_ROWS id, name, active, gid, img, description FROM packages WHERE gid='%i'  AND active='1' $cat ORDER BY name", array($this->whitelist($gmid, "int")));
		} else {
			if($cat){
				if($doVoiceSql){
					$cat=$safesql->query(" AND category='%s' AND active='1'", array($cat));
				} else $cat=$safesql->query("WHERE category='%s' AND active='1'", array($cat));
			}
			$game = "SELECT SQL_CALC_FOUND_ROWS id, name, active, gid, img, description FROM packages $doVoiceSql $cat ORDER BY name";
		}
		
		$game=Smarty_PageControl($game, "order", "order");
		while ($row = mysql_fetch_array($game)) $packArray[]=$row;
		return $packArray;
	}

	function GetVoiceListHTML($name, $ts2id, $term="cost"){
		global $safesql, $GameCP;

		if($term == "monthly") $term="cost";
		if($term == "hourly") $term="rate";
		if(!$term) $term="cost";

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$voiceList="";
		$voice = sql_query($safesql->query("SELECT * FROM prices WHERE pid = '%i' AND type='Public' AND $term !='' ORDER BY rank ASC", array($ts2id))) or die(mysql_error());
		if(mysql_num_rows($voice) > 0){
			$voiceList.="<option value=\"\">$name</option>";

			if(isset($_SESSION['gamecp']['currency'])){

				$GameCP->loadIncludes("billing");
				$Billing=new Billing(); 
				$exchange=$Billing->ExchangeRate($_SESSION['gamecp']['currency']);
				if(isset($exchange['code'])){
					$currencyChar=$exchange['prefix'];
					$currencyChar2=$exchange['suffix'];
				}else{
					$currencyChar=currencyChar;
					$currencyChar2=currencyChar2;
				}


			} else {
				$currencyChar=currencyChar;
				$currencyChar2=currencyChar2;

			}

			while ($row = mysql_fetch_array($voice)) {
				if($row[$term]) $voiceList.= "<option value=\"". $ts2id . ":" . $row['id'] ."\">&nbsp;&nbsp;". $row['name']." ". $currencyChar . $this->FormatNumber($row[$term]).$currencyChar2;
			}
		}
		return $voiceList;
	}

	function GetPrices($gmida, $packagePubPriv="Public", $voice=false, $default=false){
		global $safesql, $GameCP, $LNG_NOTPROPCONFIG;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		
		$pName = sql_query($safesql->query("SELECT P.name, P.gid, P.id, UP.description, P.tax, P.addontax FROM packages P, prices UP WHERE UP.pid = '%i' AND UP.pid = P.id LIMIT 1", array($this->whitelist($gmida, "int")))) or die(mysql_error());
		if($voice == true) return mysql_fetch_array($pName);
	
		if($packagePubPriv == "undefined") $packagePubPriv="Public";
		$productList=array();

		$pName = mysql_fetch_assoc($pName);
		$packageName = $pName['name'];
		$packageHasGame = $pName['gid'];
		$packageId = $pName['id'];

		if($packageHasGame && $packageHasGame > 0 && $packageHasGame !="1000" && $packageHasGame != "1001" && $packageHasGame != "1002"){
			$gameCheckQ = sql_query($safesql->query("SELECT id FROM game WHERE id='%i' LIMIT 1", array($this->whitelist($packageHasGame, "clean")))) or die(mysql_error());
			if(mysql_num_rows($gameCheckQ) == 0) $this->Error($LNG_NOTPROPCONFIG);
		}

		$defaultq = sql_query($safesql->query("SELECT * FROM prices WHERE id = '%i' LIMIT 1", array($this->whitelist($default, "int"))));
		$defaultqq=mysql_fetch_assoc($defaultq);

		$game = $safesql->query("SELECT SQL_CALC_FOUND_ROWS * FROM prices WHERE pid = '%i' AND type = '%s' ORDER BY rank", array($this->whitelist($gmida, "int"),$this->whitelist($packagePubPriv, "clean")));

		$game=Smarty_PageControl($game, "order", "order");

		if(mysql_num_rows($game) == "0") return false;
		while ($row = mysql_fetch_array($game)) {
			if($row['rate']) $row['rate']=$this->FormatNumber($row['rate']);
			if($row['cost'] != "-1") $productList[]=$row;
		}
		return array($productList, $packageName, $packageId, $packageHasGame, $pName['description'], $pName['tax'], $pName['addontax'], $defaultqq);
	}

	function GetVoicePackageID(){
		global $safesql, $GameCP;
		$game = sql_query("SELECT id, name, active, gid, img, description FROM packages WHERE gid = '1000' OR gid = '1001' OR gid = '1002' OR gid = '1003' OR gid = '1004' ORDER BY name") or die(mysql_error());
		while ($row = mysql_fetch_array($game)) {
			if($row['gid'] == "1000") $ts2id=$row['id'];
			if($row['gid'] == "1001") $ventid=$row['id'];
			if($row['gid'] == "1002") $ts3id=$row['id'];
			if($row['gid'] == "1003") $mohawk=$row['id'];
			if($row['gid'] == "1004") $mumble=$row['id'];
		}
		return array("ts2id" => @$ts2id, "ts3id" => @$ts3id, "vent" => @$ventid, "mohawk" => @$mohawk, "mumble" => @$mumble);
	}


	function PackageDaysTill($packageTerm){
		if($packageTerm == "hourly") { $daystill="1"; } else
		if($packageTerm == "monthly") { $daystill="31"; } else
		if($packageTerm == "quarterly") { $daystill="91"; } else
		if($packageTerm == "semiannualy") { $daystill="182"; } else
		if($packageTerm == "annualy") { $daystill="365"; } else
		if($packageTerm == "2years") { $daystill="730"; }else $daystill="31"; 
		return $daystill;
	}

	function QueueUser(){
		global $safesql, $LNG_MISSINGSETTING;

		$orderDetails=$_SESSION['gamecp']['orderDetails'];
		$vars=array();

		if(!isset($orderDetails['email'])) $this->Error($LNG_MISSINGSETTING);
		$daystill=$this->PackageDaysTill($orderDetails['packageTerm']);

		if(isset($orderDetails['paddons']) && is_array($orderDetails['paddons']) && count($orderDetails['paddons']) > 0){
			foreach($orderDetails['paddons'] as $p => $a){
				if($a['cvar']){
					if($a['cval']){
						$vars[]=array("cvar" => $a['cvar'], "value" => $a['cval']);
					} elseif($a['multiply']) $vars[]=array("cvar" => $a['cvar'], "value" => $a['multiply']);
				}				
			}
		}

		$queueDetails=array('fname'			=> @$orderDetails['username'],
							'femail'		=> $orderDetails['email'],
							'pid'			=> $orderDetails['packageGid'], 
							'fusername'		=> @$orderDetails['username'], 
							'fuserlevel'	=> '0', 
							'fpassword'		=> @$orderDetails['password'], 
							'fip'			=> '',
							'fport'			=> '',
							'phone'			=> @$orderDetails['phone'], 
							'address'		=> utf8_encode(@$orderDetails['address']), 
							'city'			=> utf8_encode(@$orderDetails['city']), 
							'state'			=> utf8_encode(@$orderDetails['state']), 
							'country'		=> utf8_encode(@$orderDetails['country']), 
							'zip'			=> @$orderDetails['zip'], 
							'clienturl'		=> @$orderDetails['website'], 
							'installtype'	=> "install",
							'fnote'			=> utf8_encode(@$orderDetails['fnote']), 
							'firstname'		=> @$orderDetails['firstname'], 
							'lastname'		=> @$orderDetails['lastname'], 
							'payment'		=> @$orderDetails['paymentMethod'], 
							'address2'		=> @$orderDetails['address2'], 
							'ftsip'			=> '', 
							'loginpath'		=> orderssh,
							'today'			=> date(dateformat, time()),
							'fconfig'		=> '', 
							'fstartmap'		=> '', 
							'fmaxclients'	=> @$orderDetails['packageSlots'], 
							'fpubpriv'		=> @$orderDetails['packagePubPriv'], 
							'date'			=> time(), 
							'status'		=> "Pending",
							'gross'			=> $this->RemFormatNumber(@$orderDetails['packageGross']), 
							'fee'			=> $this->RemFormatNumber(@$orderDetails['packageFee']), 
							'daystill'		=> $daystill,
							'installtype'	=> "install", 
							'startserver'	=> "yes",
							'fsendinfo'		=> "yes",
							'addbill'		=> '1', 
							'orderpage'		=> '1', 
							// this is the package ID used in billing
							'ordergame'		=> array(
								"id"		=> @$orderDetails['gmid'], 
								"cost"		=> $this->RemFormatNumber(@$orderDetails['originalCost']), 
								"fee"		=> $this->RemFormatNumber(@$orderDetails['originalFee'])
							),
							// the package id for voice
							'ordervoice'	=> array("
								id"			=> @$orderDetails['voicePackageID'],
								"cost"		=> $this->RemFormatNumber(@$orderDetails['voiceCost']),
								"fee"		=> $this->RemFormatNumber(@$orderDetails['voiceFee']), 
								"type"		=> @$orderDetails['voiceType']
							),
							'fmip'			=> orderfmip, 
							'queue'			=> '1', 
							'voiceInstall'	=> @$orderDetails['voiceInstall'], 
							'voiceType'		=> @$orderDetails['voiceType'], 
							'voiceMaxClients'=> @$orderDetails['voiceMaxClients'], 
							'RCONPASSWORD'	=> @$orderDetails['rconpass'], 
							'SPECPASSWORD'	=> @$orderDetails['specpass'], 
							'PRIVPASSWORD'	=> @$orderDetails['privpass'], 
							'subscr_id'		=> '', 
							'HOSTNAME'		=> @$orderDetails['hostname'], 
							'MOTD'			=> @$orderDetails['motd'], 
							'WEBSITE'		=> @$orderDetails['website'], 
							'freseller'		=> @$orderDetails['freseller'], 

							'start_time'	=> @$orderDetails['start_time'], 
							'end_time'		=> @$orderDetails['end_time'], 
							'hours'			=> @$orderDetails['hours'], 

							'voiceName'		=> @$orderDetails['voiceName'], 
							'voiceIP'		=> '', 
							'flimit'		=> "+1", 
							'voicePort'		=> '', 
							'suspend_notpaid'		=> true, 
							'subdirectory'	=> ordersubdir, 
							'location'		=> @$orderDetails['serverLocation'], 
							'existingsignup'=> @$orderDetails['existingcustomer'], 
							'promo'			=> serialize(@$orderDetails['promoUsed']), 
							'vars'			=> serialize($vars), 
							'paddons'			=> serialize(@$orderDetails['paddons']), 
							'paddonsOriginal'	=> serialize(@$orderDetails['paddonsOriginal']), 

							'taxproduct'	=> @$orderDetails['taxproduct'], 
							'taxvoice'		=> @$orderDetails['taxvoice'], 
							'taxes'			=> serialize(@$orderDetails['taxes']), 
							'taxtotal'		=> @$orderDetails['taxtotal'], 
							'taxaddon'		=> @$orderDetails['taxaddon'], 
							'currency'		=> @$orderDetails['currency'], 
							'ip_address'	=> $_SERVER['REMOTE_ADDR'], 
							'servicebillingid' => '',
							'transactionid' =>'',

							'fmanager'		=> '2');

		if(isset($_SESSION['gamecp']['fraud_error'])){
			$sta='4';
		} else $sta='3';

		sql_query($safesql->query("INSERT INTO queue SET ref='1', user='%s', status='%s', `mod`='%s'", array($orderDetails['email'],$sta,serialize($queueDetails) ))) or die(mysql_error());
		$qid=mysql_insert_id();

		if(!$qid) return false;
		return $qid;
	}

	function ProcessAddonCost($paddon, $packageTerm, $t){
		$paddons=array();
		$atotal="";
		foreach($paddon as $pid => $aid){
			$intype=$this->GetAddonType($pid);
			if($intype['type'] == "quantity"){
				foreach($aid as $id=>$val){
					if(is_numeric($val) && $val > 0){
						$are=$this->ProcessAddon($id, $atotal, $paddons, $packageTerm, $t, $intype, $val);
						$paddons=$are[0];
						$atotal=$are[1];
					}
				}
			}elseif($intype['type'] == "input"){
				foreach($aid as $id=>$val){
					$are=$this->ProcessAddon($id, $atotal, $paddons, $packageTerm, $t, $intype, $val);
					$paddons=$are[0];
					$atotal=$are[1];
				}
			}elseif($intype['type'] == "checkbox"){
				foreach($aid as $a=>$id){
					$are=$this->ProcessAddon($id, $atotal, $paddons, $packageTerm, $t, $intype);
					$paddons=$are[0];
					$atotal=$are[1];
				}
			} elseif(is_numeric($aid)) {
				$are=$this->ProcessAddon($aid, $atotal, $paddons, $packageTerm, $t, $intype);
				$paddons=$are[0];
				$atotal=$are[1];
			}
		}
		return array($are,$paddons, $atotal);
	}


	function QueueEmailUser($qid){
		global $GameCP;

		$orderDetails=$_SESSION['gamecp']['orderDetails'];

		$GameCP->loadIncludes('email');
		$Email = new Email();

		$Email->emailto = $orderDetails['email'];

		$convert=array();
		$convert[]=array("var" => "\$ORDERID", "value" => $qid);
		$convert[]=array("var" => "\$USERNAME", "value" => $orderDetails['username']);
		$convert[]=array("var" => "\$PRODUCT", "value" => $orderDetails['packageName']);
		$convert[]=array("var" => "\$SUBPRODUCT", "value" => $orderDetails['packageSubName']);
		$convert[]=array("var" => "\$PLAYERS", "value" => $orderDetails['packageSlots']);

		$Email->templatename = "Order-Confirmation";
		$Email->GetTemplateStuff();

		$Email->ReplaceStuff($convert);
		$Email->send();
	}

	function QueueEmail($qid){
		global $banknum, $routing, $checknum, $bankname, $GameCP;

		$orderDetails=$_SESSION['gamecp']['orderDetails'];

		$daystill=$this->PackageDaysTill($orderDetails['packageTerm']);

		$subject = neworder_title . ' '.$orderDetails['email']." - ".@$orderDetails['firstname']. " ". @$orderDetails['lastname'];

		$email_body = "<h3>A new client has been added to the order queue</h3>\n\nYou will want to verify this user has paid before processing the order.\nPayments with PayPal, 2Checkout.com or Authorize.net are typically processed automatically.\n\nVERIFY ALL ORDERS!\n\n";
		$email_body .= "<b>Process this order once payment is completed:</b><br>".url."/manage/orders.php?mode=run&qid=".$qid."\n\n";

		$email_body .= " Package Gross: ".currencyChar.$orderDetails['packageGross'].currencyChar2." \n";
		$email_body .= " Payment Method: ".$orderDetails['paymentMethod']."\n";
		$email_body .= " Payment Term: ".$orderDetails['packageTerm']." @ ".$daystill." days\n";
		$email_body .= "<h3>USER DETAILS</h3>\n";
		$email_body .= " User Name: ".@$orderDetails['username']."\n";
		$email_body .= " Password: ".$orderDetails['password']."\n";
		$email_body .= " First Name: ".$orderDetails['firstname']."\n";
		$email_body .= " Last Name: ".$orderDetails['lastname']."\n";
		$email_body .= "<h3>GAME DETAILS</h3>\n";
		$email_body .= " Product: ".$orderDetails['packageName']." \n";
		$email_body .= " Sub-Product: ".$orderDetails['packageSubName']."\n";
		$email_body .= " Public/Private: ".$orderDetails['packagePubPriv']."\n";
		$email_body .= " Game: ".$orderDetails['packageGame']."\n";
		$email_body .= " Player Slots: ".$orderDetails['packageSlots']."\n";
		$email_body .= "\n";

		if($orderDetails['voiceType']){
			$email_body .= "\n";
			$email_body .= "<h3>VOICE DETAILS</h3>\n";
			$email_body .= "This user has ordered a voice server.\n";
			$email_body .= " Type: ".$orderDetails['voiceType']."\n";
			$email_body .= " Package: ".$orderDetails['voiceName']."\n";
			$email_body .= " Cost: ".$orderDetails['voiceCost']."\n";
			$email_body .= "\n";
		}


		$email_body .= "\n\n\n".serialize($orderDetails)."\n\n\nThank You.\n\n\n";

		if(EMAIL == "text/html"){
			$email_body=nl2br($email_body);
		} else $email_body=strip_tags($email_body);

		$GameCP->loadIncludes('email');
		$Email = new Email();

		$Email->emailsubject = $subject;
		$Email->emailbody = $email_body;
		$Email->SendtoAllManagers();
	}




// duplicated from gamecp class


	function CleanAll($document, $substr=FALSE){
		$search = array('@<script[^>]*?>.*?</script>@si',  // Strip out javascript
					   '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
					   '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
					   '@<![\s\S]*?--[ \t\n\r]*>@'        // Strip multi-line comments including CDATA
		);
		$text = preg_replace($search, '', $document);
		$text = strip_tags($text);
		$text = stripslashes($text);
		if($substr) $text = substr($text, 0, $substr);

		return $text;
	}

	function CleanJavascript($document){
		$search = array('@<script[^>]*?>.*?</script>@si',  // Strip out javascript
					   '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
					   '@<![\s\S]*?--[ \t\n\r]*>@'        // Strip multi-line comments including CDATA
		);
		$text = preg_replace($search, '', $document);
		return $text;
	}

	function whitelist($data, $type=FALSE){
		switch($type){
			case "int":
				$string="/[^0-9.-]/";
			break;

			case "text":
				$string="/[^a-zA-Z]/";
			break;

			case "useredit":
				$string="/[^a-zA-Z0-9@_.\-\/]/";
			break;

			case "password":
				$string="/[^a-zA-Z0-9_.\-;'{}!^*()\=\+\$]/";
			break;

			case "web":
				$data=$this->CleanJavascript($data);
			break;

			case "clean":
				$data=$this->CleanAll($data);
				$data=$this->CleanJavascript($data);
			break;

			default:
				$string="/[^a-zA-Z0-9_.\-@ ]/";
			break;


		}

		if(isset($string) && $string != ""){
			$dirty_array = str_split($data);
			$clean_data="";
			foreach($dirty_array as $char){
				$clean_char=preg_replace( $string, "", $char );
				$clean_data=$clean_data.$clean_char;
			}
			$data=$clean_data;
		}
		return $data;
	}


	function Complete($ipnNotifyEmail, $mod){
		global $GameCP;

		$GameCP->loadIncludes('email');
		$Email= new Email();
		$Email->emailto = $ipnNotifyEmail;
		$Email->emailsubject = "Payment Received";
		$Email->emailbody = "This payment was received and marked as Completed.<br><hr>Total Paid: ".$mod['paidPrice']."<br>Time: ".time()."<br>".serialize($_SESSION['gamecp']['orderDetails'])."<hr>- GameCP Billing System<br>";
		$Email->send();

	}


	function CheckOnServer($username){
		global $GameCP;
		if($_SESSION['gamecp']['orderDetails']['fip']){
			$sidA=$this->GetServer();
			$os = $sidA[0];
			$sid = $sidA[1];

			if($os != "1"){
				$GameCP->loadIncludes("backend");
				$Backend=new Backend();
				$serveruserA = $Backend->QueryResponse($sid, '', "command:_:grep \"^$username:\" /etc/passwd");
			} else $serveruserA = "";
		} else $serveruserA = "";
		return $serveruserA;
	}


	function GetUser($email){
		global $GameCP,$safesql;
			$userInfoQ = sql_query($safesql->query("SELECT * FROM users WHERE email='%s'", array($this->whitelist($email, "clean")))) or die(mysql_error());
			$userInfo = mysql_fetch_array($userInfoQ);
			$cid=$userInfo['id'];
			$userInfo['password']=$this->Password($cid);
			return $userInfo;
	}


	function Password($idd, $table="users"){
		global $GameCP;
		
		$idd=$this->whitelist($idd, "int");
		$GameCP->loadIncludes("user");
		$User=new User();
		return $User->Password($idd, $table);
	}

}
?>