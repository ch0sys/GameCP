<?php 

class XML
{
    public function ParseLine($line, $key)
    {
        preg_match_all("" . "/\\<" . $key . "\\>(.*?)\\<\\/" . $key . "\\>/s", $line, $res);
        if( isset($res[1][0]) ) 
        {
            return $res[1][0];
        }

    }

    public function MirrorList()
    {
        $mirrors = array(  );
        $postfields = array(  );
        $postfields["alt"] = "true";
        $postfields["mirrors"] = "true";
        $postfields["passphrase"] = "ceb52a186e62ea853ebadbff53c3afe0";
		$xml = json_decode(file_get_contents($_SERVER['DOCUMENT_ROOT'] .'/assets/xml/common.xml'));			
        foreach( $xml as $line ) 
        {
            $name = $this->ParseLine($line, "name");
            $id = $this->ParseLine($line, "id");
            $url = $this->ParseLine($line, "url");
            $logo = $this->ParseLine($line, "logo");
            $mirrors[] = array( "name" => $name, "id" => $id, "url" => $url, "logo" => $logo );
        }
        return $mirrors;
    }

    public function GameInfo($gid, $myDetails)
    {
        global $GameCP;
        global $safesql;
        $gameInfo = array(  );
        $postfields = array(  );
        $postfields["alt"] = "true";
        $postfields["game_id"] = $gid;
        $postfields["details"] = $myDetails;
		$xml = json_decode(file_get_contents($_SERVER['DOCUMENT_ROOT'].'/assets/xml/'.$gid.'.xml'));		
	
        foreach( $xml as $line ) 
        {
            $download = $this->ParseLine($line, "download");
            $date = $this->ParseLine($line, "date");
            $name = $this->ParseLine($line, "name");
            $export = $this->ParseLine($line, "export");
            $steamid = $this->ParseLine($line, "steamid");
            $steammod = $this->ParseLine($line, "steammod");
            $id = $this->ParseLine($line, "id");
            $dlsize = $this->ParseLine($line, "dlsize");
            $windlsize = $this->ParseLine($line, "windlsize");
            $windownload = $this->ParseLine($line, "windownload");
            $linuxmd5 = $this->ParseLine($line, "linuxmd5");
            $winmd5 = $this->ParseLine($line, "winmd5");
            $url = $this->ParseLine($line, "url");
            $updateQ = sql_query($safesql->query("SELECT updated FROM game WHERE name = '%s' LIMIT 1;", array( $GameCP->whitelist($name, "clean") ))) or exit( mysql_error() );
            $updated = mysql_fetch_array($updateQ);
            $updateA = $updated[0];
            $update = $updated[0];
            if( !$update ) 
            {
                $update = "1/01/2010";
            }

            if( $date ) 
            {
                $date = strtotime($date);
            }

            $update = strtotime($update);
            $gameInfo = array( "id" => $id, "name" => $name, "export" => $export, "date" => $date, "download" => $download, "windownload" => $windownload, "steamid" => $steamid, "steammod" => $steammod, "url" => $url, "dlsize" => $dlsize, "windlsize" => $windlsize, "linuxmd5" => $linuxmd5, "winmd5" => $winmd5 );
        }
        return $gameInfo;
    }

    public function GameList()
    {
        global $GameCP;
        global $safesql;
        $defaultGames = array(  );
        $postfields = array(  );
        $postfields["alt"] = "true";

		$xml = json_decode(file_get_contents($_SERVER['DOCUMENT_ROOT'].'/assets/xml/GameList.xml'));
        foreach( $xml as $line ) 
        {
            $download = $this->ParseLine($line, "download");
            $name = $this->ParseLine($line, "name");
            $id = $this->ParseLine($line, "id");
            $description = $this->ParseLine($line, "description");
            $date = $this->ParseLine($line, "date");
            $updatedl = $this->ParseLine($line, "updatedl");
            $fulldl = $this->ParseLine($line, "fulldl");
            $winmd5 = $this->ParseLine($line, "winmd5");
            $linuxmd5 = $this->ParseLine($line, "linuxmd5");
            $windownload = $this->ParseLine($line, "windownload");
            $windlsize = $this->ParseLine($line, "windlsize");
            $dlsize = $this->ParseLine($line, "dlsize");
            $steamid = $this->ParseLine($line, "steamid");
            $steammod = $this->ParseLine($line, "steammod");
            $url = $this->ParseLine($line, "url");
            $updateQ = sql_query($safesql->query("SELECT updated FROM game WHERE name = '%s' LIMIT 1;", array( $GameCP->whitelist($name, "clean") ))) or exit( mysql_error() );
            $updated = mysql_fetch_array($updateQ);
            $updateA = $updated[0];
            $update = $updated[0];
            if( !$update ) 
            {
                $update = "1/01/2001";
            }

            if( $date ) 
            {
                $date = strtotime($date);
            }

            $update = strtotime($update);
            $defaultGames[] = array( "installed" => mysql_num_rows($updateQ), "id" => $id, "name" => $name, "description" => $description, "date" => $date, "download" => $download, "windownload" => $windownload, "updatedl" => $updatedl, "updateA" => $updateA, "update" => $update, "dlsize" => $dlsize, "windlsize" => $windlsize, "winmd5" => $winmd5, "linuxmd5" => $linuxmd5, "steamid" => $steamid, "steammod" => $steammod, "url" => $url );
        }
        return $defaultGames;
    }

}


