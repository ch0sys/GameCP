<?php 

class Subunuo
{
    public function validate($data)
    {
        global $GameCP;
        $url = "https://api.subuno.com/v1/?";
        $PostData = array(  );
        $PostData["apikey"] = subunokey;
        $PostData["customer_name"] = trim($data["firstname"] . " " . $data["lastname"]);
        $PostData["ip_addr"] = $_SERVER["REMOTE_ADDR"];
        $PostData["price"] = $data["packageGross"];
        $PostData["bill_street1"] = $data["address"];
        $PostData["bill_street2"] = $data["address2"];
        $PostData["bill_city"] = $data["city"];
        $PostData["bill_state"] = $data["state"];
        $PostData["bill_country"] = $data["country"];
        $PostData["bill_zip"] = $data["zip"];
        $PostData["phone"] = $data["phone"];
        $PostData["email"] = $data["email"];
        $PostData["source"] = "gamecp";
        $res = $GameCP->SendCurl($url, $PostData);
        $result = json_decode($res);
        if( !isset($result->action) || !$result->action ) 
        {
            return false;
        }

        if( $result->action == "accept" || subunomanual == "yes" && $result->action == "manual_review" ) 
        {
            return "";
        }

        $_SESSION["gamecp"]["fraud_error"] = $result->action;
        $_SESSION["gamecp"]["fraud_ref_code"] = $result->ref_code;
        $_SESSION["gamecp"]["fraud_check"] = array(  );
        return str_replace("_", " ", $result->action);
    }

}


