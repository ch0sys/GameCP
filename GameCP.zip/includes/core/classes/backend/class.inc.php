<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2010 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/**
 * Backend class to query remote servers
 * 
 * This class manages the backend actions to query remote servers
 * You only need to use Query, QueryResponse or UpdateFTP
 * All other functions are internal
 * 
 */

class Backend{
	var $_cmd;
	var $_debugging=false;



	function ServiceLoad($sid, $os, $ugid, $user){
		global $GameCP;

		if($os == "1"){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$uginfo=$Panel->GetUserGame($ugid);
			$ginfo=$Panel->GetGame($uginfo['gid']);
			$servicefile=$Panel->GetServiceFolder($ugid, false);
			if($ginfo['exedir']) $servicefile.='/'.$ginfo['exedir'];
			$servicefile.='/'.$ginfo['winexec'];
			$servicefile=str_replace("/", "\\", $servicefile);
			$servicefile=str_replace("\\\\", "\\", $servicefile);
			$usedmem=$this->QueryResponse($sid, "", "processusage:_:\$MAINDIR\home\\$user\\$servicefile");

			$load=$this->QueryResponse($sid, '', "sysstats:_:");
			$load0=explode("::", $load);
			$totalmem=$load0[3]*1024;

			return round($usedmem/$totalmem * 100, 2);



		}else{
			$pid='';
			$r=explode("\n", $this->QueryResponse($sid, "", "command:_:SCREENPID=`screen -list | grep service$ugid | awk -F . '{ print $1 }' | sed -e s/.//` ; pstree \$SCREENPID -pA", $user));
			$p=explode('-+-', $r[0]);
			$l=explode("---", $p[0]);
			foreach($l as $a=>$b){
				preg_match('/(?<=\()(.+)(?=\))/is', $b, $match);
				$pid.=$match[0].',';
			}
			return trim($this->QueryResponse($sid, "", "command:_:ps -p ".rtrim($pid,',')." -o %cpu,%mem | awk 'NR > 0 { s +=$1 }; END {print \$1, \$2}'", $user));
		}
	}


	function Install($mip, $distro, $mname="Server", $mlocation="", $mcost="0", $slotquota="200", $mquota="10", $msshport="22", $mftpport="21", $malias="", $mts2=FALSE, $mvent=FALSE, $winport="240"){
		global $GameCP, $safesql;


		if(!isset($distro) || $distro == ""){
			$_SESSION['error']="Server Operating System is required.";
			return false;
		}
		if(!$mip){
			$_SESSION['error']="Server IP Address is required.";
			return false;
		}

		if(!$mname){
			$_SESSION['error']="Server name is required.";
			return false;
		}
		$mip = str_replace(' ', '', $mip);

		$sidQ=sql_query($safesql->query("SELECT id, passphrase FROM servers WHERE sid='%s'", array($mip))) or die(mysql_error());
		if(mysql_num_rows($sidQ) > 0){
			$data=mysql_fetch_row($sidQ);
			return array($data[0], $data[1]);
		}

		$msid=$mip;
		
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$passphrase=$Panel->RandomPassword();
		if(!$msshport) $msshport ="22";
		if(!$mftpport) $mftpport ="21";
		if(!$winport) $winport ="240";

		sql_query($safesql->query("INSERT INTO servers 
										SET	sid='%s',
										ip='%s',
										name='%s',
										quota='%s',
										cost='%i',
										ts2='%s',
										vent='%s',
										location='%s',
										os='%s',
										sshport='%s',
										ftpport='%s',
										slotquota='%s',
										alias='%s',
										passphrase='%s',
										winport='%i'",
			array($GameCP->whitelist($mip, "clean"), $GameCP->whitelist($mip, "clean"),
			$GameCP->whitelist($mname, "clean"),
			$GameCP->whitelist($mquota, "clean"),
			$GameCP->whitelist($mcost, "int"),
			$GameCP->whitelist($mts2, "clean"),
			$GameCP->whitelist($mvent, "clean"), 
			$GameCP->whitelist($mlocation, "clean"), 
			$GameCP->whitelist($distro, "clean"), 
			$GameCP->whitelist($msshport, "clean"), 
			$GameCP->whitelist($mftpport, "clean"), 
			$GameCP->whitelist($slotquota, "clean"),
			$GameCP->whitelist($malias, "clean"),
			$GameCP->whitelist($passphrase, "clean"),
			$GameCP->whitelist($winport, "int")
			))) or die(mysql_error());
		$newid=mysql_insert_id();
		if(!$newid){
			$_SESSION['error']="Unable to create new server in database.";
			return false;
		}
		if($Panel->CheckMySQLRow("iptable", "sid", "ip", $GameCP->whitelist($mip, "clean"), $GameCP->whitelist($mip, "clean"))){
			sql_query("INSERT INTO iptable SET sid='".$GameCP->whitelist($mip, "clean")."', ip='".$GameCP->whitelist($mip, "clean")."', useinternal='0'") or die(mysql_error());
			$GameCP->loadIncludes("ip");
			$IP=new IP();
			$IP->UpdateIPUse($mip);
		}
		

		return array($newid, $passphrase);
	}


	/**
	 * send a query to remote server with no reply
	 * @param string $sid server id
	 * @param integer  $fport server query port, not required
	 * @param string $query the command to send
	 * @param string $user the user to run as (linux,freebsd)
	 * @return true 
	 */
	function Query($sid, $fport="240", $query, $user=FALSE){
		$this->SelectMachine($sid);
		$this->InsertCommand($user, $query,'yes', 'no');
		$this->Execute();
		return true;
	}

	/**
	 * send a query to remote server with reply
	 * @param string $sid server id
	 * @param int $fport server query port, not required
	 * @param string $query the command to send
	 * @param string $user the user to run as (linux,freebsd)
	 * @return string 
	 */
	function QueryResponse($sid, $fport="240", $query, $user=FALSE){
		$this->SelectMachine($sid);
		$this->InsertCommand($user, $query,'yes', 'yes');
		$this->Execute();
		return $this->ResponseCode;
	}

	/**
	 * select machine to manage
	 * @param string $_sid servers id
	 */
	function SelectMachine($_sid){
		global $GameCP;
		require_once(path.'/includes/core/classes/gamecp/panel.inc.php');
		$Panel=new Panel();
		if(preg_match("/\./s", $_sid)){
			$machineInfo=$Panel->GetServer($_sid);
		} else $machineInfo=$Panel->GetServer('',false,$_sid);
		$this->SetDetails($machineInfo['ip'],$machineInfo['winport'] , $machineInfo['id'], $machineInfo['passphrase'], $machineInfo['timeout'], $machineInfo['os']);
	}

	/**
	 * set all information to connect
	 * @param string $_ip server ip
	 * @param integer $_port server query port, not required
	 * @param string $_sid server id #
	 * @param string $_pass server passphrase
	 */
	function SetDetails($_ip, $_port="240", $_sid, $_pass, $_timeout=30, $_os){
		$this->Debugging("Setting details.");
		$this->IP = $_ip;
		$this->PORT = $_port;
		$this->SID = $_sid;
		$this->PASSPHRASE = $_pass;
		$this->Timeout=$_timeout;
		$this->os=$_os;
		$this->ResponseCode="";
	}

	/**
	 * insert command to send
	 * @param string $sid server id
	 * @param integer $fport server query port, not required
	 * @param string $query the command to send
	 * @param string $user the user to run as (linux,freebsd)
	 * @return string 
	 */
	 function InsertCommand($_user, $_cmd, $_close, $_return){
		if(!$_user) $_user = "root";
		$this->_cmd=$_cmd;
		$this->_user=$_user;
		$this->_close=$_close;
		$this->_return=$_return;
	}



	/**
	 * does nothing
	 * @param string $_debug server id
	 */
	function Debugging($_debug){
		//echo $_debug."<br>";
	}


	/**
	 * does nothing
	 * @param string $_error server id
	 */
	 function Error($_error){
		//echo "Error Message:";
		//print_r($_error);
		
	}

	/**
	 * check information before sending commands
	 */
	function Validate(){
		if(!isset($this->IP)){
			$this->Error("Missing ip address.");
			return false;
		}
		if(!isset($this->PORT)){
			$this->Error("Missing port.");
			return false;
		}

		return true;
	}
	
	/**
	 * parse the reply from Execute
	 * @param string $_buffer reply text
	 */
	function ParseBuffer($_buffer){
		if(!isset($this->ResponseCode)) $this->ResponseCode='';
		if($_buffer != "")
		{
			/*  USER RELATED CALLS */
			if(preg_match("/Account Created/i", $_buffer)){
				$this->ResponseCode="001";
			}elseif(preg_match("/User does not exist/i", $_buffer)){
				$this->ResponseCode="002";
			}elseif(preg_match("/User Exists/i", $_buffer)){
				$this->ResponseCode="003";
			}elseif(preg_match("/Account Deleted/i", $_buffer)){
				$this->ResponseCode="004";
			}elseif(preg_match("/Account does not exist/i", $_buffer)){
				$this->ResponseCode="005";
			// returns on fresh start of backend
			}elseif(preg_match("/Received invalid directive/i", $_buffer)){
				if(!$this->err){
					$this->err=true;
					return $this->Execute();
				}
			//}elseif(preg_match("/cmd_return:/i", $_buffer) && preg_match("/cmd_exec:/i", $_buffer)){
			}elseif(preg_match("/Error: 3/i", $_buffer)){
				$this->ResponseCode="200";

			/* SERVICE RELATED CALLS */
			}elseif(preg_match("/Server added/i", $_buffer)){
				$this->ResponseCode="100";
			} else {
				/* not a reply defineable, post all output to a var */
				$this->ResponseCode=$this->ResponseCode.$_buffer;
			}

		}
	}

	function PutCMD($fp, $cmd){
		if($this->os == "1"){
			fputs($fp, $cmd.PHP_EOL);
		} else fputs($fp, strlen($cmd).':'.$cmd);
	}

	/**
	 * run command on remote server
	 */
	function Execute(){

		if(isset($_SESSION['server'][$this->IP]['status']) && $_SESSION['server'][$this->IP]['status']=="down" && $_SESSION['server'][$this->IP]['time'] > (time() - rescandelay)){
			$this->ResponseCode= "Remote down - command not sent, try again in ". ($_SESSION['server'][$this->IP]['time'] - (time() - rescandelay)) ." seconds<br>";
			return false;
		}

		if($this->Validate() == true){

			$this->Debugging("Executing command.");
			set_time_limit($this->Timeout+2);
			$fp = @fsockopen($this->IP, $this->PORT, $errno, $errdesc, $this->Timeout); 
			if (!$fp) {
					set_time_limit($this->Timeout);
					$this->ResponseCode="Unable to connect to the remote, $errdesc";
					$this->Error($errdesc . $this->IP. " " . $this->PORT);
					$_SESSION['server'][$this->IP]['status']="down";
					$_SESSION['server'][$this->IP]['time']=time();
					return false;
			} else {
					stream_set_blocking($fp, TRUE);

					$this->Debugging("Connected to server.");
					
					$cmd="SID ".  $this->SID;
					$this->PutCMD($fp, $cmd);
					stream_set_timeout($fp, $this->Timeout);
					set_time_limit($this->Timeout+1);
					$i=0;
					while (!feof($fp)) {
						$i++;

							$buffer = @fgets($fp);
							if($buffer != "")
							{
								
								if(preg_match("/Correct SID received/i",$buffer))
								{
									if($this->_debugging) echo "<b>$i</b> Correct SID received: $buffer<br>";
									$cmd="Passphrase ". $this->PASSPHRASE;
									$this->PutCMD($fp, $cmd);
								}
								elseif(preg_match("/Correct passphrase received/i", $buffer))
								{
									if($this->_debugging) echo "<b>$i</b> Correct passphrase received: $buffer<br>";
									$cmd="cmd_return: ". $this->_return;
									$this->PutCMD($fp, $cmd);
								}
								elseif(preg_match("/Return received/i", $buffer))
								{

									if($this->_debugging) echo "<b>$i</b> Return received: $buffer<br>";
									$cmd="cmd_user: ". $this->_user;
									$this->PutCMD($fp, $cmd);

								}
								elseif(preg_match("/User received/i", $buffer))
								{
									if($this->_debugging) echo "<b>$i</b> User received: $buffer<br>";
									$cmd="cmd_close: ". $this->_close;
									$this->PutCMD($fp, $cmd);

								}
								elseif(preg_match("/Bytes received/i", $buffer))
								{
									if($this->_debugging) echo "<b>$i</b> Bytes received: $buffer<br>";
									$cmd="cmd_exec: ". $this->_cmd;
									$this->PutCMD($fp, $cmd.PHP_EOL);
									if($this->_return != "yes"){
										fclose($fp);
										return true;
									}
								}
								elseif(preg_match("/Close received/i", $buffer))
								{
									$cmd="cmd_exec: ". $this->_cmd;
									if($this->_debugging) echo "<b>$i</b> Close received: $buffer<br>";
									if($this->os == "1"){
										$this->PutCMD($fp, 'cmd_size: '. strlen($cmd));
										// next loop runs the above Bytes received
									} else {
										$this->PutCMD($fp, $cmd);

										if($this->_return != "yes"){
											fclose($fp);
											return true;
										}
									}
								}
								else{				
									if($this->_debugging) echo "<b>$i</b> Buffer did not match: $buffer<br>";
									$this->ParseBuffer($buffer);
								}

								$buffer=null;
							} else {
								$buffer=null;
								break;
							}
					} 
					
				fclose($fp);

			}
			@set_time_limit(30);
			$fp=null;
			unset($fp);
		}
	}

	/**
	 * update all the ftp for Windows servers for a particular user
	 * @param string $machineid server id
	 */
	function UpdateAllFTP($idd){
		global $GameCP, $safesql;
		$row = sql_query($safesql->query("SELECT distinct(I.sid), U.name, S.os FROM users U, iptable I, usergames UG, servers S WHERE U.id= '%i' AND I.ip = UG.ip AND UG.cid=U.id AND I.sid = S.sid", array($GameCP->whitelist($idd, "clean")))) or die(mysql_error());
		while($srv=mysql_fetch_array($row)){
			if($srv['os'] == "1") $this->UpdateFTP($srv['sid']);
		}
	}

	/**
	 * update the ftp for Windows servers
	 * @param string $machineid server id
	 */
	function UpdateFTP($machineid){
		global $GameCP, $safesql;
		if(!empty($machineid))
		{

			$query = sql_query($safesql->query("SELECT ftpd, winport FROM `servers` WHERE sid='%s' LIMIT 1", array($machineid)));
			if($query && mysql_num_rows($query) == 1)
			{

				$row = mysql_fetch_array($query);
				if($row['ftpd'] == "filezilla")
				{	// If the ftpd is filezilla lets do some shit
					$xmldata = $this->FilezillaXML($machineid, $machineid, $row['winport']);
					if(!empty($xmldata))
					{
						$GameCP->loadIncludes("backend");
						$Backend=new Backend();
						$tmp1 = $Backend->QueryResponse($machineid, $row['winport'], "writefile:_:\$MAINDIR\\ftpd\FileZilla Server\FileZilla Server.xml:_:$xmldata");
						$tmp2 = $Backend->QueryResponse($machineid, $row['winport'], "\"\$MAINDIR\\ftpd\FileZilla Server\FileZilla server.exe\":_:-reload-config");
					}
				} 
			}
		}
	}


	function FilezillaUsers($xmlusername, $xmlpassword, $xmlenabled, $homedir, $cid, $basepath, $mainuser, $subuser=FALSE){

$xml = '
		<User Name="'.$xmlusername.'">
			<Option Name="Pass">'.$xmlpassword.'</Option>
			<Option Name="Group"/>
			<Option Name="Bypass server userlimit">0</Option>
			<Option Name="User Limit">0</Option>
			<Option Name="IP Limit">0</Option>
			<Option Name="Enabled">'.$xmlenabled.'</Option>
			<Option Name="Comments"/>
			<Option Name="ForceSsl">0</Option>
			<IpFilter>
				<Disallowed/>
				<Allowed/>
			</IpFilter>
			<Permissions>
				<Permission Dir="'.$homedir.'">
					<Option Name="FileRead">1</Option>
					<Option Name="FileWrite">0</Option>
					<Option Name="FileDelete">0</Option>
					<Option Name="FileAppend">0</Option>
					<Option Name="DirCreate">0</Option>
					<Option Name="DirDelete">0</Option>
					<Option Name="DirList">1</Option>
					<Option Name="DirSubdirs">1</Option>
					<Option Name="IsHome">1</Option>
					<Option Name="AutoCreate">0</Option>
				</Permission>';

						$ins=true;
						if(is_array($subuser) && count($subuser > 0)){
							$s=join('","', $subuser);
							if($s){
								$sq="AND UG.id IN(\"".$s."\")";
							} else {
								$sq="";
								$ins=false;
							}
						} else $sq="";
						$gamequery = sql_query("SELECT UG.subdirectory, UG.port, UG.ip, UG.gid, G.winappdir, UG.id FROM usergames UG, game G WHERE G.id = UG.gid AND UG.cid='".$cid."' $sq") or die(mysql_error());
						if($gamequery && mysql_num_rows($gamequery) > 0){
							while($gamedata = mysql_fetch_array($gamequery)){

								if($gamedata['subdirectory'] == "yes"){ 
									if(ipsubdir == "true"){
										$gamepath=$gamedata['ip']."-".$gamedata['port'];
									} else $gamepath="service".$gamedata['id'];
								} else $gamepath = $gamedata['winappdir'];
if($ins != false) $xml .= '
				<Permission Dir="'.$basepath.'\\'.$mainuser.'\\'.$gamepath.'">
					<Aliases>
						<Alias>/'.$gamepath.'</Alias>
					</Aliases>
					<Option Name="FileRead">1</Option>
					<Option Name="FileWrite">1</Option>
					<Option Name="FileDelete">1</Option>
					<Option Name="FileAppend">1</Option>
					<Option Name="DirCreate">1</Option>
					<Option Name="DirDelete">1</Option>
					<Option Name="DirList">1</Option>
					<Option Name="DirSubdirs">1</Option>
					<Option Name="IsHome">0</Option>
					<Option Name="AutoCreate">0</Option>
				</Permission>';
							}
						}
$xml .= '
			</Permissions>
			<SpeedLimits DlType="1" DlLimit="10" ServerDlLimitBypass="0" UlType="1" UlLimit="10" ServerUlLimitBypass="0">
				<Download/>
				<Upload/>
			</SpeedLimits>
		</User>';

		return $xml;
	}

	/**
	 * manage FileZillas XML
	 * @param string $machineid server id
	 * @param string  $serverip server ip
	 * @param integer $port server port
	 */
	function FilezillaXML($machineid, $serverip, $port){
		global $GameCP, $safesql;
		if(isset($machineid) && !empty($machineid))
		{
			$queryserver = sql_query($safesql->query("SELECT ftpmotd, ftpadminport, ftpadminpass, ftpport FROM servers WHERE sid='%s' LIMIT 1", array($machineid)));
			if($queryserver && mysql_num_rows($queryserver) == "1") { $serverdata = mysql_fetch_array($queryserver); }
$xml = '<FileZillaServer>
	<Settings>
		<Item name="Serverports" type="string">'.$serverdata['ftpport'].'</Item>
		<Item name="Admin port" type="numeric">'.$serverdata['ftpadminport'].'</Item>
		<Item name="Initial Welcome Message" type="string">'.$serverdata['ftpmotd'].'</Item>
	</Settings>
	<Groups/>
	<Users>';

			$GameCP->loadIncludes("backend");
			$Backend=new Backend();
			$basepath = $Backend->QueryResponse($serverip, $port, "whereami:_:");
			$basepath=str_replace("\n", "", $basepath);
			$basepath=str_replace("\r", "", $basepath);
			$basepath=str_replace("\r\n", "", $basepath);
			$basepath=$basepath."home";
			
			$query = sql_query($safesql->query("SELECT distinct(UG.cid) FROM usergames UG, iptable I, servers S WHERE UG.ip = I.ip and I.sid = S.sid and S.sid='%s'", array($machineid)));
			if($query && mysql_num_rows($query) > 0)
			{
				while($row2 = mysql_fetch_array($query))
				{

					$queryuser = sql_query("SELECT name, active FROM users WHERE id='".$row2['cid']."' AND bash !='noftp' LIMIT 1;");
					if($queryuser && mysql_num_rows($queryuser) > 0)
					{
						$userdata = mysql_fetch_array($queryuser);
						$xmlusername = $userdata['name'];

						$GameCP->loadIncludes("user");
						$User=new User();
						$xmlpassword = md5($User->Password($row2['cid']));

						if($userdata['active'] == "1"){$xmlenabled = "1";} else { $xmlenabled = "0";}
						
						$homedir = "C:\\home\\$xmlusername"; // How the hell do we do this one
						
						$xml.=$this->FilezillaUsers($xmlusername, $xmlpassword, $xmlenabled, $homedir, $row2['cid'], $basepath, $xmlusername);

						unset($xmlpassword, $xmlenabled);

						$querysubuser = sql_query("SELECT id, name, active, games FROM usersubaccounts WHERE cid='".$row2['cid']."';");
						while($subuserdata = mysql_fetch_assoc($querysubuser)){
							if($subuserdata['active'] == "1"){$xmlenabled = "1";} else { $xmlenabled = "0";}
							$xmlpassword = md5($User->Password($subuserdata['id'], 'usersubaccounts'));
							$gam=unserialize($subuserdata['games']);
							if(is_array($gam) && count($gam) > 0){
								foreach($gam as $g=>$m){
									if($m=="" && isset($game[$g])) unset($game[$g]);
								}
							}
							$xml.=$this->FilezillaUsers($subuserdata['name'], $xmlpassword, $xmlenabled, $homedir, $row2['cid'], $basepath, $xmlusername, $gam);
						}
					}
				}
$xml .= '
	</Users>
</FileZillaServer>';
						
				return $xml;
			}
		}
	}


} 


?>