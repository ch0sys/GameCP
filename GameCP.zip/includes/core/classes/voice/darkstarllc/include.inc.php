<?php

require_once("api.client.php");
require_once("api.xml.php");

global $locationsListing;

function darkstar_GetServerList(){
	global $locationsListing;

	$parameters = array(
		'reseller_id' => VENTRILO_RESELLER_ID,
	);
	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"getFullServerList",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return $result;
}


function darkstar_CreateAccount($params){
	global $locationsListing;

	$parameters = array(
		'reseller_id' => VENTRILO_RESELLER_ID,
		'slots' => (int)$params['slots'],
		'location_id' => (int)$params['location_id'],
		'uniqueid' => (int)$params['serviceid'],
		'email' => html_entity_decode($params['email'], ENT_QUOTES),
		'password' => html_entity_decode($params['password'], ENT_QUOTES)
	);
	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"vent_auto_setup",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return $result;
}

function darkstar_StopServer($accountid) {

	$parameters = array(
		'reseller_id' => VENTRILO_RESELLER_ID,
		'serverId' => (int)$accountid
	);
	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"stopVentriloServer",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return $result;
}


function darkstar_ReStartServer($accountid) {

	$parameters = array(
		'reseller_id' => VENTRILO_RESELLER_ID,
		'serverId' => (int)$accountid
	);
	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"restartVentriloServer",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return $result;

}


function darkstar_TerminateAccount($accountid) {

	$parameters = array(
		'reseller_id' => VENTRILO_RESELLER_ID,
		'uniqueid' => (int)$accountid
	);
	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"deleteServerByUniqueid",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return $result;
}


function darkstar_SuspendAccount($accountid) {

	$parameters = array(
		'reseller_id' => VENTRILO_RESELLER_ID,
		'uniqueid' => (int)$accountid
	);
	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"suspendServerByUniqueid",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return $result;
}


function darkstar_UnsuspendAccount($accountid){

	$parameters = array(
		'reseller_id' => VENTRILO_RESELLER_ID,
		'uniqueid' => (int)$accountid
	);
	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"unsuspendServerByUniqueid",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return $result;

}


function darkstar_retrieveFile($type, $serverId){

	$parameters = array(
		'serverId' => $serverId,
		'type' => $type,
		'urlencode' => 1,
		'reseller_id' => VENTRILO_RESELLER_ID);
	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"getVentriloConfiguration",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return($result);
}


function darkstar_saveFile($serverId, $data){
	@set_time_limit(90);

	$parameters = array(
		'serverId' => $serverId,
		'postdata' => serialize($data),
		'reseller_id' => VENTRILO_RESELLER_ID);

	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"updateVentriloServerIniFile",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return($result);
}

function darkstar_retrieveDetails($serverId){

	$parameters = array(
		'serverId' => $serverId,
		'reseller_id' => VENTRILO_RESELLER_ID);

	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"getVentriloServerDetails",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return($result);
}


function darkstar_createAction($type,$serverId, $data){

	$parameters = array(
		'serverId' => $serverId,
		'postdata' => serialize($data),
		'type' => $type,
		'reseller_id' => VENTRILO_RESELLER_ID);

	$api = new API_Client();

	switch($type){
		case "usr":
			$apitype="createVentriloUser";
		break;
		case "ban":
			$apitype="createVentriloBan";
		break;
		case "chn":
			$apitype="createVentriloChannel";
		break;

	}
	$result = $api->get_xml_response(
		'reseller',
		$apitype,
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return($result);
}


function darkstar_deleteAction($type,$serverId, $data){

	$parameters = array(
		'serverId' => $serverId,
		'type' => $type,
		'reseller_id' => VENTRILO_RESELLER_ID);

	$api = new API_Client();

	switch($type){
		case "usr":
			$parameters['userId']=$data;
			$apitype="deleteVentriloUser";
		break;
		case "ban":
			$parameters['banId']=$data;
			$apitype="deleteVentriloBan";
		break;
		case "chn":
			$parameters['channelId']=$data;
			$apitype="deleteVentriloChannel";
		break;

	}
	$result = $api->get_xml_response(
		'reseller',
		$apitype,
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return($result);
}



function darkstar_editAction($type, $serverId, $data){

	switch($type){
		case "usr":
			$apitype="updateVentriloUser";
		break;
		case "ban":
			$apitype="updateVentriloBan";
		break;
		case "chn":
			$apitype="updateVentriloChannel";
		break;

	}

	$parameters = array(
		'serverId' => $serverId,
		'postdata' => serialize($data),
		'type' => $type,
		'reseller_id' => VENTRILO_RESELLER_ID);

	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		$apitype,
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return($result);
}



function darkstar_updateMotd($serverId, $motd){

	$parameters = array(
		'serverId' => $serverId,
		'motd' => base64_encode($motd),
		'reseller_id' => VENTRILO_RESELLER_ID);

	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"updateVentriloMotd",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return($result);
}



function darkstar_getLocations(){

	$parameters = array(
		'reseller_id' => VENTRILO_RESELLER_ID);

	$api = new API_Client();

	$result = $api->get_xml_response(
		'reseller',
		"getVentriloLocationOptions",
		$parameters,
		VENTRILO_REMOTE_ID,
		VENTRILO_REMOTE_ACCESS_KEY
	);

	return($result);
}




function array2ini($array){
    $res = "";
    foreach($array as $key => $val)
    {
        if(is_array($val))
        {
            $res.= "[$key]\n";
            foreach($val as $skey => $sval) $res.= "$skey = ".(is_numeric($sval) ? $sval : '"'.$sval.'"')."\n";
        }
        else $res.= "$key = ".(is_numeric($val) ? $val : '"'.$val.'"\n\n');
    }
    return $res;
}

?>