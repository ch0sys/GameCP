<?php

	/**
	 * This is the class to handle the actual parsing of XML data.
	 * Used in the API system for Darkstar's Reseller Customers.
	 * 
	 * @author Brett Guarnieri / Nobis Tech.
	 * @updated February 11, 2008.
	 *
	 */

	class API_Parser 
	{
	
		/**
		 * Output of data.
		 *
		 * @var <Array>
		 */
		var $arrOutput = array();
		
		/**
		 * PHP XML Parser Resource Object
		 *
		 * @var <Resource>
		 */
		var $resParser;
		
		/**
		 * Our raw XML Data.
		 *
		 * @var <String>
		 */
		var $strXmlData;
		
		/**
		 * Constructor. Does not do anything.
		 */
		function API_Parser() { }
	
		/**
		 * Parses our XML code into useable data.
		 *
		 * @param <String> $strInputXML
		 * 
		 * @return <String>
		 */
		function parse($strInputXML)
		{
			/**
			 * Setup parser.
			 */
			$this->resParser = xml_parser_create();
			xml_set_object($this->resParser,$this);
			xml_set_element_handler($this->resParser, "tagOpen", "tagClosed");
			xml_set_character_data_handler($this->resParser, "tagData");
			
			/**
			 * Gather and free data.
			 */
			$this->strXmlData = xml_parse($this->resParser,$strInputXML );
			if(!$this->strXmlData)
			{
				$data = xml_error_string(xml_get_error_code($this->resParser)) ." at line ". xml_get_current_line_number($this->resParser) .".";
				xml_parser_free($this->resParser);
				return $data;
			}

			/**
			 * Free/Return.
			 */
			xml_parser_free($this->resParser);
			return $this->arrOutput;
		}
	   
	   /**
	    * Open's XML Tag.
	    *
	    * @param <Resource> $parser
	    * @param <String> $name
	    * @param <String> $attrs
	    * 
	    * @return <Void>
	    */
	   function tagOpen($parser, $name, $attrs)
	   {
		   $tag=array("name"=>$name,"attrs"=>$attrs);
		   array_push($this->arrOutput,$tag);
	   }
	
		/**
		 * Handles the data in the tag.
		 *
		 * @param <Resource> $parser
		 * @param <String> $tagData
		 * 
		 * @return <Void>
		 */
		function tagData($parser, $tagData)
		{
		   if(trim($tagData)) {
			   if(isset($this->arrOutput[count($this->arrOutput)-1]['tagData'])) {
				   $this->arrOutput[count($this->arrOutput)-1]['tagData'] .= $tagData;
			   }
			   else {
				   $this->arrOutput[count($this->arrOutput)-1]['tagData'] = $tagData;
			   }
		   }
		}
	
		/**
		 * Closes the tag.
		 *
		 * @param <Resource> $parser
		 * @param <String> $name
		 * 
		 * @return <Void>
		 */
		function tagClosed($parser, $name)
		{
		   $this->arrOutput[count($this->arrOutput)-2]['children'][] = $this->arrOutput[count($this->arrOutput)-1];
		   array_pop($this->arrOutput);
		}
	}

?>