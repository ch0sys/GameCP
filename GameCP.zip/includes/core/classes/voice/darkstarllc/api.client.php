<?php

	/*

		Date:
			@ May 22nd, 2007

		Purpose:
			@ This class will handle all API Client functionality. Written for PHP 4.3.x or higher.

		Methodology:
			@ The idea is to provide a communication method for the client.

		Requirements:
			@ PHP 4.3.x+, MySQL 4.1.x+

	*/


	class API_Client
	{




		// @ Xml Parser
		// @ Type: Object
		var $parser;

		// @ Construct for PHP 4
		// @ Return: Void
	


		// @ Constructor
		// @ Return: Void
		function __construct()
		{
			require_once('api.xml.php');
			$this->parser = new API_Parser;
		}

		// @ Sends our message to the API Server.
		// @ Return: Result
		function send_message($xml_data, $r_id, $r_key)
		{
			// @ Create our XML Signature.
			$xml_signature = base64_encode($this->__CalcHmacSha1($xml_data, $r_key));

			// @ Encode data.
			$xml_data = base64_encode($xml_data);

			// @ Post Data
			$post_data = array(
				'remote_id' => $r_id,
				'xml_request' => $xml_data,
				'xml_signature' => $xml_signature
			);

			// @ Get curl response.
			return $this->get_curl_response($post_data, "http://api.darkstarllc.com/api.php");
		}

		// @ Get our curl response and send it.
		// @ Type: Result
		function get_curl_response($post_vars, $url)
		{
			// @ Initiate and set options.
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_vars);

			// @ Execute and send response.
			$response = curl_exec($ch);
			return(trim($response));
			if (curl_errno($ch))
				print curl_error($ch);
		}

		function __CalcHmacSha1($data, $key)
		{
			// @ Check for errors.
			$error_function_name = "__CalcHmacSha1()";

			// The $data and $key variables must be populated.
			$blocksize = 64;
			$hashfunc = 'sha1';
			if (strlen($key) > $blocksize)
				$key = pack('H*', $hashfunc($key));
			$key = str_pad($key, $blocksize, chr(0x00));
			$ipad = str_repeat(chr(0x36), $blocksize);
			$opad = str_repeat(chr(0x5c), $blocksize);

			// @ Return packed data.
			$hmac = pack('H*', $hashfunc(($key^$opad).pack('H*', $hashfunc(($key^$ipad).$data))));
			return $hmac;
		}

		// @ Function to create the XML message to be sent to
		function get_xml_response($class, $func, $params, $r_id, $r_key)
		{
			require_once('api.xml.php');
			$parser = new API_Parser;
			// @ This is required no matter what
			$xml_msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n";

			// @ Method String
			$xml_msg .= "<" . $func . " xmlns=\"http://api.darkstarllc.com/schemas/" . $class . "\">\r\n";

			// @ Remote ID
			$xml_msg .= "<remoteid>" . $r_id . "</remoteid>\r\n";

			// @ Parameters
			$xml_msg .= "<parameters>\r\n";
			foreach ($params as $key=>$value)
			{
				// @ Array
				if(is_array($params[$key]))
				{
					$xml_msg .= "<" . $key . ">\r\n";
					foreach($params[$key] AS $loop_key=>$loop_val)
					{
						$xml_msg .= "<" . $loop_key . ">";
						$xml_msg .= $loop_val;
						$xml_msg .= "</" . $loop_key . ">\r\n";
					}
					$xml_msg .= "</" . $key . ">\r\n";
				}

				// @ Non-Array
				{
					$xml_msg .= "<" . $key . ">";
					$xml_msg .= $value;
					$xml_msg .= "</" . $key . ">\r\n";
				}
			}
			$xml_msg .= "</parameters>\r\n";

			// @ End the request
			$xml_msg .= "</" . $func . ">\r\n";

			// @ Get the results of the request
			$response = $this->send_message($xml_msg, $r_id, $r_key);

			$response = preg_replace("/\t/s","",$response);
			//echo "X:". $response;

			if (stristr($response, "Specified API class not found or is un-supported"))
				return ("Error - " . $response);

			if (stristr($response, "Specified API function was not found or is un-supported"))
				return ("Error - " . $response);

			// @ And, finally, process the info and return an array
			$xml = $parser->parse($response);

			// @ Make sure that the message is a response
			if ((!($xml[0]['name'] == "RESPONSE")))// || (!(isset($xml[0]['name']))) || ($xml[0]['name']==""))
				return ("Invalid return - Response expected");

			// @ Make sure we have a paramter set
			if (!($xml[0]['children'][0]['name'] == "PARAMETERS"))
				return ("Invalid return - Paramaters expected");

			// @ Check to see if we got an error
			if (stristr($xml[0]['children'][0]['children'][0]['name'], "ERROR"))
				return ("Error - " . $xml[0]['children'][0]['children'][0]['tagData']);

			$result_set = array();

/*
			print "<PRE>>";
			print_r($xml);
			print "</PRE>";
*/
			if (count($xml[0]['children'][0]['children']) > 0)
				foreach ($xml[0]['children'][0]['children'] as $key)
				{
					$result_set[strtolower($key['name'])] = $key['tagData'];
				}

			return ($result_set);

		}









}//class



?>