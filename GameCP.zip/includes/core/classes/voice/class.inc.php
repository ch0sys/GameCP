<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Voice{
	var $ts3userport='9988';
	var $ts2userport='8767';
	var $ventuserport='3784';

	function AddVoiceUser($fname, $fpassword, $femail){
		global $GameCP, $safesql;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		if (!$fpassword) $fpassword = $Panel->RandomPassword();

		sql_query($safesql->query("INSERT INTO users SET 
						name = '%s',
						username = '%s',
						password = '%s',
						userlevel = '10',
						active = '1',
						ip = '',
						port = '',
						sid = '',
						joindate='%s',
						email='%s'", array(
							$GameCP->whitelist($fname, "username"),
							$GameCP->whitelist($fname, "username"),
							$GameCP->whitelist($fpassword, "password"),
							time(),
							$GameCP->whitelist($femail, "useredit")))) or die(mysql_error());
		$cid=mysql_insert_id();
		$GameCP->loadIncludes("user");
		$User=new User();
		$GameCP->SetPassword($cid, $fpassword);

		return $cid;
	}

	function AddVoiceDB($cid, $fname, $fpassword, $fmaxclients, $fip, $fport, $fservername, $billingid, $type, $tssid, $api_id=FALSE, $token=FALSE, $api_id2=FALSE){
		global $GameCP, $safesql;
		if($type == "vent"){
			$vid="0";
		} else $vid="1";

		sql_query($safesql->query("INSERT INTO uservoice SET 
						cid='%i',
						vid='%i',
						tssid='%i', 
						user='%s',
						pass='%s',
						maxclients='%s',
						ip='%s',
						port='%s',
						servername='%s',
						voicetype='%s',
						active='1',
						ts3token='%s',
						billingId='%i',
						api_id='%i',
						api_id2='%i'", array(
								$GameCP->whitelist($cid, "int"),
								$GameCP->whitelist($vid, "int"),
								$GameCP->whitelist($tssid, "int"),
								$GameCP->whitelist($fname, "useredit"),
								$GameCP->whitelist($fpassword, "clean"),
								$GameCP->whitelist($fmaxclients, "clean"),
								$GameCP->whitelist($fip, "clean"),
								$GameCP->whitelist($fport, "int"),
								$GameCP->whitelist($fservername, "useredit"),
								$GameCP->whitelist($type, "clean"),
								$GameCP->whitelist($token, "clean"),
								$GameCP->whitelist($billingid, "int"),
								$GameCP->whitelist($api_id, "int"),
								$GameCP->whitelist($api_id2, "int")))) or die(mysql_error());
		return mysql_insert_id();
	}


	function AddVentrilo($cid, $fip, $fport, $fname, $fservername, $fadminpassword, $fpassword, $method, $fmaxclients, $fquerypassword, $fvoiceformat=FALSE, $fauthtype="0", $altreturn=FALSE, $billingid=FALSE){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if($fmaxclients == "" || $fmaxclients == NULL || $fmaxclients < 8 ) $fmaxclients = 8;
		if(!$fservername) $fservername="Ventrilo Server";
		if(!isset($fphonetic)) $fphonetic = "0";
		if(!isset($fcomment)) $fcomment = "0";
		if(!isset($fvoiceformat)) $fvoiceformat = "0";
		if (!$fadminpassword)	$fadminpassword = $Panel->RandomPassword(); 
		if (!$fquerypassword)	$fquerypassword = $Panel->RandomPassword();
		if (!$fpassword)		$fpassword = $Panel->RandomPassword(); 

		if(usedarkstarvent == "yes" && !extension_loaded('curl')) return "Darkstar support requires PHP Curl to be installed";

		if(usedarkstarvent != "yes"){
			$userport=$this->ventuserport;

			/* auto assign ip */
			if(!$fip) { 
				$GameCP->loadIncludes("ip");
				$IP=new IP();
				$fip=$IP->GetVoice("vent", $fmaxclients);
				if(!$fip) return "No machines enabled for Ventrilo servers.";
			} 
			$GameCP->loadIncludes("ports");
			$Ports=new Ports();
			if(!$fport){
				$fport=$userport;
				$fport=$Ports->GetPortAuto($fip, $fport);
			}


			if(!$fport) return "Unable to determine port";
			//if($Ports->CheckDB($fip, $fport) == true) return $fip.":".$fport." already assigned to a voice server.";
			

			$machineInfo=$Panel->GetServer('', $fip);
			$os=$machineInfo['os'];
			$sid=$machineInfo['sid'];
			if(!$sid) return "Unable to determine server id.";
		}

		$GameCP->loadIncludes("user");
		$User=new User();

		if($cid){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$userinfo=$Panel->GetUser($cid);
			$fname = $userinfo['name'];
			$fpassword = $userinfo['password'];
			$femail = $userinfo['email'];
		}elseif(!$User->CheckName($fname)){
			return "Username already exists."; 
		}
		

		if(usedarkstarvent == "yes"){

			$GameCP->loadIncludes("darkstarllc");

			$voiceIdQ =darkstar_GetServerList();
			$voiceIds=unserialize($voiceIdQ['result']);
			$uniquids=array();
			foreach($voiceIds as $v => $ids) $uniquids[$ids['unique_id']]=$ids['unique_id'];
			$uniquids[1022]=1022;
			$uniqueid= max($uniquids)+1;

			if($fip){
				$darkstarlocal=$fip;
				if(!is_integer($darkstarlocal)){
					$darkstar=darkstar_getLocations();
					$list=unserialize($darkstar['result']);
					foreach($list as $li=>$st){
						if($st['name']==$darkstarlocal){
							$darkstarlocal=$st['id'];
							break;
						}
					}
				}
			} else {
				$darkstar=darkstar_getLocations();
				$list=unserialize($darkstar['result']);
				$darkstarlocal=$list[0]['id'];
			}

			$params=array("serviceid" => $uniqueid, "location_id" => $darkstarlocal, "password" => $fpassword, "slots" => $fmaxclients, "email"=> $femail);

			$result=darkstar_CreateAccount($params);
			if(preg_match("/Duplicate server detected for uniqueid of/i", $result['RESPONSE'])){
				$uniqueid=$uniqueid+4;
				$params['serviceid']=$uniqueid;
				$result=darkstar_CreateAccount($params);
			}


			if(is_array($result) && $result['ip'] != "" && $result['port'] != ""){
				if(isset($result['server_id'])){
					$server_id=$result['server_id'];
					$fport=$result['port'];
					$fip=$result['ip'];
				} else return "Darkstarllc did not return an id.<br><br>". $result;
			} else return "Darkstarllc reported an error.<br><br>". $result;
		} else { 
			/* not darkstar  */
			$GameCP->loadIncludes("backend");
			$Backend=new Backend();

			if($os != "1"){
				$serveruserA = $Backend->QueryResponse($sid, '', "command:_:id vent > /dev/null ; echo $?");
				if ($serveruserA == 0) { 

					/* add vent line */
					$Backend->Query($sid, '', "mkdir:_:/home/vent/$fip\:$fport", 'vent');
					$Backend->Query($sid, '', "command:_:cd /home/vent/$fip\:$fport  ;  cp -R \$MAINDIR/installs/ventsrv/* ./", 'vent');

					$ventfile="/home/vent/$fip:$fport/ventrilo_srv.ini";
$ventcfg="[Server]
Name=$fservername
Phonetic=$fphonetic
Port=$fport
Auth=$fauthtype
Duplicates=1
AdminPassword=$fadminpassword
Password=$fpassword
MaxClients=$fmaxclients
SendBuffer=0
RecvBuffer=0
Diag=0
LogonTimeout=5
CloseStd=1
TimeStamp=0
PingRate=10
ExtraBuffer=0
ChanWidth=0
ChanDepth=0
ChanClients=0
DisableQuit=1
VoiceCodec=0
VoiceFormat=$fvoiceformat
SilentLobby=0
AutoKick=0

[Intf]
Intf=$fip";
					$Backend->Query($sid,'', "writefile:_:$ventfile:_:$ventcfg", 'vent');
					/* start the voice server? */
					$GameCP->loadIncludes("control");
					$Control=new Control();

					$Control->Ventrilo($fip, $fport, "start");

				} else return "Vent user does not exist on server $sid";
			} else return "Windows is not supported";
			
		}



		/* new user */
		if(!$cid){
			$femail=$_REQUEST['femail'];
			$cid=$this->AddVoiceUser($fname, $fpassword, $femail);
			if($billingid) echo "uid:$cid";

			$GameCP->loadIncludes("user");
			$User=new User();
			$GameCP->SetPassword($cid, $fpassword);

		} else if(isset($_SESSION['gamecp']['order_api']) && $_SESSION['gamecp']['order_api']==true && $billingid) echo "UGID";

		$fservername=str_replace("\ ", " ", $fservername);
		$fcomment=str_replace("\ ", " ", $fcomment);
		
		return $this->AddVoiceDB($cid, $fname, $fpassword, $fmaxclients, $fip, $fport, $fservername, $billingid, "vent", '', $server_id, '', $uniqueid);

	}

	function AddTeamSpeak2($cid, $tip, $tport, $tservername, $tmaxclients, $fpassword=FALSE, $newname=FALSE, $femail=FALSE, $altreturn=FALSE, $billingid=FALSE){
		global $GameCP, $safesql;

		/* default ports */
		$userport=$this->ts2userport;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		/* server info */
		if(!$tip) { 
			$GameCP->loadIncludes("ip");
			$IP=new IP();
			$tip=$IP->GetVoice("ts2", $fmaxclients);
			if(!$tip){
				return $Panel->Error("No machines enabled for Teamspeak servers.");
			}
		} 

		$machineInfo=$Panel->GetServer('', $tip);
		//$tip=$machineInfo['sid'];
		$superpass=$machineInfo['tspass'];
		$superuser=$machineInfo['tsadmin'];
		$adminport=$machineInfo['ts2port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }
		if(!$tservername) $tservername = "Team Speak 2 Server."; 
		$fname=$newname;
		$GameCP->loadIncludes("user");
		$User=new User();

		if($cid){
			$userinfo=$Panel->GetUser($cid);
			$fname = $userinfo['name'];
			$fpassword = $userinfo['password'];
		}elseif(!$User->CheckName($newname)){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error("Username already exists."); 
		}
		if(!$fpassword) $fpassword = $Panel->RandomPassword();  
		


		/* scan up ports - failes to scan if server is down */
		if (!$tport) { 
			$fpA=@fsockopen($tip, $adminport, $errno, $errstr, 5);
			if (!$fpA) { $Panel->Error("Failed to connect to Teamspeak 2 server. $errstr ($errno)"); return false; } else {

				set_time_limit(5);
				stream_set_timeout($fpA, 2);
				fwrite($fpA,"sl\n");
					$outputA.= fread($fpA, 26);
					$outputA.= fread($fpA, 26000);
					$outputA = explode("\n", $outputA);

				fclose($fpA);
				$port=$userport;

					while ($portused == false):
						
						if (!array_search($port."\r", $outputA)){
							$tport=$port;
							$portused = true; 
						}
						$port++;
					endwhile;
			}  // end opening fsock
		} // end port check

		if($tport == "") {
			$Panel->ErrorHeader("Teamspeak did not report back with an port when scanned, install failed.");
			return false;
		}

		$fp=@fsockopen($tip, $adminport, $errno, $errstr, 5);

		if (!$fp) {
			$Panel->ErrorHeader("Unable to connect to Teamspeak 2 server $tip.");
		   return false;
		} else {
			// superadmin, superadmin pass, ip, port, newuser port,

			// login as the superadmin
			fwrite($fp,"slogin ".$superuser." ".$superpass."\n");
			$output.= fread($fp, 26);

			// add the server
			fwrite($fp,"serveradd ".$tport."\n");
			$output.= fread($fp, 26);

			// select the server
			fwrite($fp,"sel ".$tport."\n");
			$output.= fread($fp, 26);

			// add the server user admin
			fwrite($fp,"dbuseradd ".$fname." ".$fpassword. " ".$fpassword." 1\n");
			$output.= fread($fp, 26);

			// set the servers name
			fwrite($fp,"serverset server_name ".$tservername."\n");
			$output.= fread($fp, 26);

			// set the servers max clients
			fwrite($fp,"serverset server_maxusers ".$tmaxclients."\n");
			$output.= fread($fp, 26);

			//print_r($output);
			
			// we want to get the servers internal id, this can define any other vars we need
			$fpB=fsockopen($tip, $adminport);
			set_time_limit(4);
			stream_set_timeout($fpB, 2);
			fwrite($fpB,"si ".$tport."\n");
				$outputB.= fread($fpB, 26);
				$outputB.= fread($fpB, 26000);
			fclose($fpB);
			
			$outputB = explode("\n", $outputB);

			while (list($key, $val) = each($outputB)) {
				//echo "$key = $val<br>";
				// we know the servers id will always be key #1
				if($key == "1"){ 
					$tssid = explode("=", $val);
					$tssid = $tssid[1];
				}
			}

			fwrite($fp,"quit\n");
			$output.= fread($fp, 26);
			$output.= fread($fp, 26000);

			fclose($fp);

			/* final error checkting */

			$output = explode("\n", $output);

			while (list($key, $val) = each($output)) {
				if($key == "1" && $val != "OK\r"){ echo $val; $Panel->Error( "Unable to login as a Team Speak superuser.");$err="1"; }
				if($key == "2" && $val != "OK\r" && $err !="1"){ $Panel->Error( "Unable to add new server, port already in use."); $err="1";}
				if($key == "3" && $val != "OK\r" && $err !="1"){ $Panel->Error( "Unable to select new server."); $err="1";}
				if($key == "4" && $val != "OK\r" && $err !="1"){ $Panel->Error( "Unable to add new user, failed dbuseradd.");$err="1"; }
				if($key == "5" && $val != "OK\r" && $err !="1"){ $Panel->Error( "Unable to set server name."); $err="1";}
				if($key == "6" && $val != "OK\r" && $err !="1"){ $Panel->Error( "Unable to set server max clients."); $err="1"; }
			}

			if($tssid == "") {
				$Panel->ErrorHeader("<br>Teamspeak did not report back with an id, install failed.");
				return false;
			}
			if($err=="1"){
				return false;
			}


			/* new! auto-create the user here like we do for vent */
			if(!$cid && $newname){
				$cid=$this->AddVoiceUser($fname, $fpassword, $femail);
				$GameCP->loadIncludes("user");
				$User=new User();
				$GameCP->SetPassword($cid, $fpassword);
				if($billingid) echo "uid:$cid";

			} else if(isset($_SESSION['gamecp']['order_api']) && $_SESSION['gamecp']['order_api']==true && $billingid) echo "UGID";


			return $this->AddVoiceDB($cid, $fname, $fpassword, $tmaxclients, $tip, $tport, $tservername, $billingid, "ts2", $tssid);

		}
	}

	function SyncTS3GetData($mid){
		global $GameCP, $safesql;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$serverDetails=$Panel->GetServer('','',$mid);
		$superuser=$serverDetails['ts3admin'];
		$superpass=$serverDetails['ts3pass'];
		$adminport=$serverDetails['ts3port'];
		$tip=$serverDetails['ip'];

		require_once("ts3admin.class.php");
		$tsAdmin = new ts3admin($tip, $adminport);

		$active=array();
		$result = sql_query($safesql->query("SELECT tssid FROM uservoice WHERE voicetype ='ts3' AND ip='%s';", array($tip))) or die(mysql_error());
		while($row = mysql_fetch_assoc($result)) $active[]=$row['tssid'];

		
		$sync=array();
		if($tsAdmin->getElement('success', $tsAdmin->connect())) {
			$tsAdmin->login($superuser, $superpass);

			$serverlist=$tsAdmin->serverList();
			$serverlist=$serverlist['data'];
			if(is_array($serverlist)){
				foreach($serverlist as $tsp){
					if(!in_array($tsp['virtualserver_id'], $active)) $sync[]=$tsp;
				}
			}
		}
		return $sync;
	}

	function SyncTS3($mid, $dataq){
		$res='';
		foreach($dataq as $d=>$data){
			if($data['sync']=="yes"){
				if($data['newuser']) $data['cid']=$this->AddVoiceUser($data['newuser'], '', '');
				if($data['cid']){
					if($newid=$this->AddVoiceDB($data['cid'], $data['newuser'], '', $data['maxclients'], $data['ip'], $data['port'], $data['hostname'], '', "ts3", $d, '', @$data['token'])){
						$res.="<strong>$d</strong>: added $newid<br>";
					} else $res.="<strong>$d</strong>: failed to add to database<br>";
				} else $res.="<strong>$d</strong>: missing client details<br>";
			}
		}
		return $res;
	}

	function Teamspeak3NewToken($tip, $tport){
		global $GameCP, $safesql;
		
		$userVoiceQ=sql_query($safesql->query("SELECT * from uservoice WHERE ip='%s' AND port='%s'", array($GameCP->whitelist($tip, "clean"),$GameCP->whitelist($tport, "int"))));
		$userVoice=mysql_fetch_array($userVoiceQ);

		$tssid=$userVoice['tssid'];
		
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$machineInfo=$Panel->GetServer('', $tip);
		$tip=$machineInfo['ip'];
		$superpass=$machineInfo['ts3pass'];
		$superuser=$machineInfo['ts3admin'];
		$adminport=$machineInfo['ts3port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }

		require_once("ts3admin.class.php");
		$tsAdmin = new ts3admin($tip, $adminport);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect())) {
			$tsAdmin->login($superuser, $superpass);

			$tsAdmin->selectServer($tssid, 'serverId');

			$tokenList=$tsAdmin->tokenList();
			$data=$tokenList['data'];	
			$token_type='';
			$token_id1='';
			$token_id2='';
			if(is_array($data) && count($data) > 0){
				foreach($data as $id=>$val){
					if($val['token'] == $userVoice['ts3token']){
						$token_type=$val['token_type'];
						$token_id1=$val['token_id1'];
						$token_id2=$val['token_id2'];
					}	
					$tsAdmin->tokenDelete($userVoice['ts3token']);
				}
			}

			$token=$tsAdmin->tokenAdd($token_type, $token_id1, $token_id2);
			if($token['success'] == '1' && isset($token['data']['token'])){
				sql_query($safesql->query("UPDATE uservoice SET ts3token='%s' WHERE ip='%s' AND port='%s'", array($token['data']['token'], $GameCP->whitelist($tip, "clean"),$GameCP->whitelist($tport, "int"))));
				return $token['data']['token'];
			} else return false;
		}
	}

	function AddTeamSpeak3($cid, $tip, $tport, $tservername, $tmaxclients, $fpassword=FALSE, $newname=FALSE, $femail=FALSE, $altreturn=FALSE, $billingid=FALSE){
		global $GameCP, $safesql;

		/* default ports */
		$userport=$this->ts3userport;

		/* server info */
		if(!$tip) { 
			$GameCP->loadIncludes("ip");
			$IP=new IP();
			$tip=$IP->GetVoice("ts3", $tmaxclients);
			if(!$tip){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				return $Panel->Error("No machines enabled for Teamspeak servers.");
			}
		} 

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$machineInfo=$Panel->GetServer('', $tip);
		$tip=$machineInfo['ip'];
		$superpass=$machineInfo['ts3pass'];
		$superuser=$machineInfo['ts3admin'];
		$adminport=$machineInfo['ts3port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }
		if(!$tservername) $tservername = "Team Speak 3 Server."; 
		$fname=$newname;
		$GameCP->loadIncludes("user");
		$User=new User();

		if($cid){
			$userinfo=$Panel->GetUser($cid);
			$fname = $userinfo['name'];
			$fpassword = $userinfo['password'];
		}elseif(!$User->CheckName($newname)){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error("Username already exists."); 
		}
		
		if(!$fpassword){
			$fpassword = $Panel->RandomPassword(); 
		}
		
		require_once("ts3admin.class.php");
		$tsAdmin = new ts3admin($tip, $adminport);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect())) {
			$tsAdmin->login($superuser, $superpass);

			/* scan up ports - failes to scan if server is down */
			if (!$tport) { 
				$serverlist=$tsAdmin->serverList();
				$serverlist=$serverlist['data'];
				$scanport=array();
				if(is_array($serverlist)){
					foreach($serverlist as $tsp){
						if($tsp['virtualserver_port'])$scanport[]=$tsp['virtualserver_port'];
					}
				}

				$port=$userport;
				$portused=false;

				while ($portused == false):
					
					if (!in_array($port, $scanport)){
						$tport=$port;
						$portused = true; 
					} else $port++;
				endwhile;

				$tport=$port;
			} // end port check


			$tmpservername=$this->OutputTeamspeak3($tservername, "convert");
			$tsdata=array();
			$tsdata['virtualserver_name']=$tmpservername;
			$tsdata['virtualserver_port']=$tport;
			$tsdata['virtualserver_maxclients']=$tmaxclients;
			$serverCreate=$tsAdmin->serverCreate($tsdata);
			$tssid=$serverCreate['data']['sid'];
			$token=$serverCreate['data']['token'];
			

			if($tssid == "" || $token == "") {
				$tsdebug=$tsAdmin->getDebugLog();
				if($tsdebug[0] != "" && preg_match("/virtualserver limit reached/i", $tsdebug[0])){
					$Panel->ErrorHeader("Teamspeak Virtual Server Limit Reached<br>Remove a Virtual Server or upgrade your Teamspeak license");
				} else $Panel->ErrorHeader("Teamspeak did not report back with an id, install failed. Port $tport<br><br>". $tsdebug[0]);
				return false;
			}
			
			/* new! auto-create the user here like we do for vent */
			if(!$cid && $newname){
				$cid=$this->AddVoiceUser($fname, $fpassword, $femail);
				$GameCP->loadIncludes("user");
				$User=new User();
				$GameCP->SetPassword($cid, $fpassword);
				if($billingid) echo "uid:$cid";

			} else if(isset($_SESSION['gamecp']['order_api']) && $_SESSION['gamecp']['order_api']==true && $billingid) echo "UGID";

			return $this->AddVoiceDB($cid, $fname, $fpassword, $tmaxclients, $tip, $tport, $tservername, $billingid, "ts3", $tssid, '', $token);

		} else {
			$Panel->ErrorHeader("Unable to connect to Teamspeak 3 server $tip.");
			return false;
		}
	} 

	function Remove($vid, $idd=false){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("control");
		$Control=new Control();
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if($idd){ 
			$sql = $safesql->query("SELECT * FROM uservoice WHERE cid = '%i'", array($GameCP->whitelist($idd, "int")));
		} else $sql = $safesql->query("SELECT * FROM uservoice WHERE id = '%i' LIMIT 1", array($GameCP->whitelist($vid, "int")));
		
		$voiceResult = sql_query($sql) or die(mysql_error());
		if(mysql_num_rows($voiceResult) == 0) return false;
		while ($voiceResults = mysql_fetch_array($voiceResult)) {
			$vip = $voiceResults["ip"];
			$vport = $voiceResults["port"];
			$tssid = $voiceResults["tssid"];
			$vid = $voiceResults["id"];
			$api_id = $voiceResults["api_id"];
			$api_id2 = $voiceResults["api_id2"];
			$voicetype = $voiceResults["voicetype"];
		
			if(!$vip || !$vport) return false;

			if($tssid == "0" || $tssid == "" || $tssid == NULL){ 
				if(usedarkstarvent == "yes"){
					$GameCP->loadIncludes("darkstarllc");
					$Control->Ventrilo($vip, $vport, "stop");
					$result=darkstar_TerminateAccount($voiceResults['api_id2']);
				} else {
					$Control->Ventrilo($vip, $vport, "stop");
					sleep(2);
					$serverInfo=$Panel->GetServer('', $vip);
					$Backend->Query($serverInfo['sid'], '', "deldir:_:/home/vent/$vip:$vport", 'vent');
				}
				sql_query($safesql->query("DELETE FROM uservoice WHERE id='%i' LIMIT 1", array($GameCP->whitelist($vid, "int")))) or die(mysql_error()); 
				return true;
			} else { 
				if($voicetype == "ts3"){
					return $this->RemoveTeamspeak3($vip, $vport, $tssid, $vid);
				} else return $this->RemoveTeamspeak2($vip, $vport, $tssid, $vid);
			}
		}
		return false;
	}

	function GetTeamspeak2Info($vid){
		global $GameCP, $safesql;
		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1") { $ucQuery = " AND uservoice.cid='".$_SESSION['gamecp']['userinfo']['id']."'"; } else $ucQuery='';
		$ts2Result = sql_query($safesql->query("SELECT uservoice.ip, uservoice.port, iptable.sid, uservoice.user, uservoice.cid, uservoice.tssid, uservoice.pass, uservoice.ts3token FROM uservoice, iptable WHERE uservoice.id='%i' AND iptable.ip = uservoice.ip $ucQuery", array($GameCP->whitelist($vid, "int")))) or die(mysql_error());
		$tsResult = mysql_fetch_array($ts2Result);
		return $tsResult;
	}

	function SetTeamspeak2Password($user, $pass, $ip, $port){
		global $GameCP;

		$userport=$this->ts2userport;

		/* server info */
		$machineInfo=$Panel->GetServer('', $ip);
		$superpass=$machineInfo['tspass'];
		$superuser=$machineInfo['tsadmin'];
		$adminport=$machineInfo['ts2port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }

		$fp=@fsockopen($ip, $adminport, $errno, $errstr, 5);
		@set_time_limit(4);
		@stream_set_timeout($fp, 2);

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		
		if (!$fp) {
			$Panel->ErrorHeader("Unable to connect to Teamspeak 2 server.");
		   return false;
		} else {
			
			fwrite($fp,"slogin ". $superuser ." " . $superpass."\n");
			$output.= fread($fp, 26);
			
			fwrite($fp,"sel ". $port ."\n");
			$output.= fread($fp, 26);
			
			fwrite($fp,"dbuserid " . $user ."\n");
			$output.= fread($fp, 26);
			/* seems hackish */
			$userid= explode("OK", fread($fp, 26));


			if($userid[0]) fwrite($fp,"dbuserchangepw ". $GameCP->whitelist($userid[0], "int") ." " . $pass ." " . $pass ."\n");
			$output.= fread($fp, 26);

			$output.= fread($fp, 26000);
			fclose($fp);

			$output = explode("\n", $output);

			while (list($key, $val) = each($output)) {
				if($key == "1" && $val != "OK\r"){ echo $val; $Panel->Error( "Unable to login as a Team Speak superuser.");$err="1"; }
				if($key == "2" && $val != "OK\r" && $err !="1"){ $Panel->Error( "Unable to select server."); $err="1";}
				if($key == "3" && $val != "OK\r" && $err !="1"){ $Panel->Error( "Unable to change password.");$err="1"; }
			}
			if($err){
				return false;
			} else return true;
		}
		return false;
	}

	function SetTeamspeak2Players($user, $clients, $ip, $port){
		global $GameCP;

		$userport=$this->ts2userport;

		/* server info */
		$machineInfo=$Panel->GetServer('', $ip);
		$superpass=$machineInfo['tspass'];
		$superuser=$machineInfo['tsadmin'];
		$adminport=$machineInfo['ts2port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }

		$fp=fsockopen($ip, $adminport, $errno, $errstr, 5);
		set_time_limit(4);
		stream_set_timeout($fp, 2);

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		
		if (!$fp) {
			$Panel->ErrorHeader("Unable to connect to Teamspeak 2 server.");
			return false;
		} else {
			
			fwrite($fp,"slogin ". $superuser ." " . $superpass."\n");
			$output.= fread($fp, 26);
			
			fwrite($fp,"sel ". $port ."\n");
			$output.= fread($fp, 26);
			
			fwrite($fp,"serverset server_maxusers ".$clients."\n");
			$output.= fread($fp, 26);

			$output.= fread($fp, 26000);
			fclose($fp);

			$output = explode("\n", $output);

			while (list($key, $val) = each($output)) {
				if($key == "1" && $val != "OK\r"){ echo $val; echo "Unable to login as a Team Speak superuser.<br>";$err="1"; }
				if($key == "2" && $val != "OK\r" && $err !="1"){ echo "Unable to select server.<br>"; $err="1";}
				if($key == "3" && $val != "OK\r" && $err !="1"){ echo "Unable to change clients.<br>";$err="1"; }
			}
			if($err){
				return false;
			} else return true;
		}
		return false;
	}

	function MessageTeamspeak2($message, $ip, $port){
		global $GameCP;

		$userport=$this->ts2userport;

		/* server info */
		$machineInfo=$Panel->GetServer('', $ip);
		$superpass=$machineInfo['tspass'];
		$superuser=$machineInfo['tsadmin'];
		$adminport=$machineInfo['ts2port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }
			
		$fp=fsockopen($ip, $adminport, $errno, $errstr, 5);
		set_time_limit(4);
		stream_set_timeout($fp, 2);
		
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if (!$fp) {
			$Panel->ErrorHeader("Unable to connect to Teamspeak 2 server.");
			return false;
		} else {
			fwrite($fp,"slogin ". $superuser ." " . $superpass."\n");
			$output.= fread($fp, 26);
			
			fwrite($fp,"sel ". $port ."\n");
			$output.= fread($fp, 26);
			
			fwrite($fp,"msg " . $message ."\n");
			$output.= fread($fp, 26);

			$output.= fread($fp, 26000);
			fclose($fp);

			$output = explode("\n", $output);

			if($output[3] == "OK\r"){
				return true;
			} else return false;

		}
	}

	function ExecTeamspeak2Array($cmd, $fip, $fport){
		$banList=$this->ExecTeamspeak2($cmd, $fip, $fport);

		if(is_array($banList)){
			$i=0;
			$banArray=array();
			foreach($banList as $bl){
				if($i > 3 && $bl != "OK\r"){
					$res=explode("\t", $bl);
					if(is_array($res) && count($res) > 1) $banArray[]=$res;
				}
				$i++;
			}
			return $banArray;
		} else return false;
	}

	function ExecTeamspeak2($cmd, $ip, $port){
		global $GameCP;

		$userport=$this->ts2userport;

		$machineInfo=$Panel->GetServer('', $ip);
		$superpass=$machineInfo['tspass'];
		$superuser=$machineInfo['tsadmin'];
		$adminport=$machineInfo['ts2port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }
		
		$fp=@fsockopen($ip, $adminport, $errno, $errstr, 5);
		@set_time_limit(4);
		@stream_set_timeout($fp, 2);
		
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if (!$fp) {
			$Panel->ErrorHeader("Unable to connect to Teamspeak 2 server.");
			return false;
		} else {
			/* server info */
			fwrite($fp,"slogin ". $superuser ." " . $superpass."\n");
			$output.= fread($fp, 26);
			
			fwrite($fp,"sel ". $port ."\n");
			$output.= fread($fp, 26);
			
			fwrite($fp,$cmd."\n");
			$output.= fread($fp, 26);
			fwrite($fp,"sel ". $port ."\n");
			sleep(2);
			$output.= fread($fp, 26000);
			fclose($fp);

			$output = explode("\n", $output);

			if($output){
				return $output;
			} else return false;

		}
	}

	function RemoveTeamspeak2($vip, $vport, $tssid, $vid){
		global $GameCP, $safesql;

		$GameCP->loadIncludes("control");
		$Control=new Control();
		$Control->Teamspeak($vip, $vport, "stop", $tssid); 
	
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		/* server info */
		$machineInfo=$Panel->GetServer('', $vip);
		$superpass=$machineInfo['tspass'];
		$superuser=$machineInfo['tsadmin'];
		$adminport=$machineInfo['ts2port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }
		

		$fp=@fsockopen($vip, $adminport, $errno, $errstr, 5);
		@set_time_limit(4);
		@stream_set_timeout($fp, 2);
		if (!$fp) {
			$Panel->ErrorHeader("Unable to connect to Teamspeak 2 server.");
			return false;
		} else {
			fwrite($fp,"slogin ". $superuser ." " . $superpass."\n");
			$output.= fread($fp, 26);
			fwrite($fp,"serverdel " . $tssid ."\n");
			$output.= fread($fp, 26);
			$output.= fread($fp, 26000);
			fclose($fp);
			
			sql_query($safesql->query("DELETE FROM uservoice WHERE id='%i' LIMIT 1", array($GameCP->whitelist($vid, "int")))) or die(mysql_error()); 
			return true;
		}
	}


	function ExecTeamspeak3($cmd, $value, $ip, $port){
		global $GameCP, $safesql;

		$result='';

		$userport=$this->ts3userport;

		$userVoiceQ=sql_query($safesql->query("SELECT * from uservoice WHERE ip='%s' AND port='%s'", array($GameCP->whitelist($ip, "clean"),$GameCP->whitelist($port, "int"))));
		$userVoice=mysql_fetch_array($userVoiceQ);
		$tssid=$userVoice['tssid'];
		/* server info */

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$machineInfo=$Panel->GetServer('',$ip);
		$ip=$machineInfo['ip'];
		$superpass=$machineInfo['ts3pass'];
		$superuser=$machineInfo['ts3admin'];
		$adminport=$machineInfo['ts3port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }

		require_once("ts3admin.class.php");
		$tsAdmin = new ts3admin($ip, $adminport);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect())) {
			$tsAdmin->login($superuser, $superpass);

			$tsAdmin->selectServer($tssid, 'serverId');

			switch($cmd){
				case "serveredit";
					$newSettings = array();
					$newSettings['virtualserver_maxclients']=$value;
					$result=$tsAdmin->serverEdit($newSettings);
				break;

				case "sendtextmessage";
					$result=$tsAdmin->sendMessage("3", $tssid, $value);
				break;

				case "banlist";
					$result=$tsAdmin->banList();
				break;

				case "banadd";
					$result=$tsAdmin->banAddByIp($value, time());
				break;
				case "bandel";
					$result=$tsAdmin->banDelete($value);
				break;
				case "bandelall";
					$result=$tsAdmin->banDeleteAll();
				break;
				case "tokendel";
					$result=$tsAdmin->tokenDelete($value);
				break;
				case "tokenadd";
					$result=$tsAdmin->tokenAdd('0', $value);
					return $result;
				break;
				case "tokenlist";
					$result=$tsAdmin->tokenList();
				break;
			}
			
			//print_r($tsAdmin->getDebugLog());
			$result=$result['data'];
			
		}else $Panel->ErrorHeader("Unable to connect to Teamspeak 3 server.");

		return $result;
	}

	function OutputTeamspeak3($output, $direction="convert"){
		if($direction == "convert"){
			$output=str_replace("/", "\/", $output);
			$output=str_replace(" ", "\s", $output);
			$output=str_replace("|", "\p", $output);
		}else{
			$output=str_replace("\/", "/", $output);
			$output=str_replace("\s", " ", $output);
			$output=str_replace("\p", "|", $output);
		}

		return $output;
	}

	function RemoveTeamspeak3($vip, $vport, $tssid, $vid){
		global $GameCP, $safesql;

		$userport=$this->ts3userport;

		/* server info */
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$machineInfo=$Panel->GetServer('', $vip);
		$superpass=$machineInfo['ts3pass'];
		$superuser=$machineInfo['ts3admin'];
		$adminport=$machineInfo['ts3port'];
		if(!$superuser) $superuser="superadmin";
		if(!$superpass){ $Panel->Error("Superadmin password required."); return false; }

		require_once("ts3admin.class.php");
		$tsAdmin = new ts3admin($vip, $adminport);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect())) {
			$tsAdmin->login($superuser, $superpass);
			$tsAdmin->serverDelete($tssid);
			sql_query($safesql->query("DELETE FROM uservoice WHERE id='%i' LIMIT 1", array($GameCP->whitelist($vid, "int")))) or die(mysql_error()); 
			return true;
		}else{
			$Panel->ErrorHeader("Unable to connect to Teamspeak 3 server.");
			return false;
		}

			
	}

	function SetTeamspeak3Players($user, $clients, $ip, $port){
		return $this->ExecTeamspeak3("serveredit", $clients, $ip, $port);
	}

	function SetTeamspeak3Password($user, $pass, $ip, $port){
		return true;
	}

	function MessageTeamspeak3($message, $ip, $port){
		return $this->ExecTeamspeak3("sendtextmessage", $message, $ip, $port);
	}


}
?>