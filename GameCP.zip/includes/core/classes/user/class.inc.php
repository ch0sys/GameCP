<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class User{

	var $subuser=false;

	function ChangePassword($id, $pass){
		global $GameCP;
		$id=$GameCP->whitelist($id, "int");
		$pass=$GameCP->whitelist($pass, "password");

		if($_SESSION['gamecp']['userinfo']['ulevel'] == "0") $id = $_SESSION['gamecp']['userinfo']['id'];

		run_hook("change_password");

		$GameCP->loadIncludes("user");
		$User=new User();

		if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes"){
			$GameCP->SetPassword($_SESSION['gamecp']['subuser']['id'], $pass, true);
		} else $GameCP->SetPassword($id, $pass, false, true);

		$GameCP->loadIncludes("modules");
		$Modules=new Modules();
		$Modules->ExecUserCommand($id, 'ChangePassword');

	}

	function Profile($idd, $profiletpl=false){
		global $GameCP, $safesql, $smarty;

		$idd=$GameCP->whitelist($idd, "int");
		$specialid = $idd;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$userInfo = $Panel->GetUser($specialid);

		if(!$userInfo['theme']) $userInfo['theme']=USERTHEME;
		if(!$userInfo['style']) $userInfo['style']=styleclient;

		$Panel->GetThemes($userInfo['theme'], $userInfo['style']);

		if($userInfo['country'] == "0") $userInfo['country'] = "US";

		$resellers=array();
		$packageResult = sql_query("SELECT id, name FROM users WHERE userlevel='4'") or die(mysql_error());
		while ($row1 = mysql_fetch_array($packageResult)) $resellers[]=$row1['name'];
		$smarty->assign("resellerList", $resellers);

		$gatewayList=array();
		$gateways = sql_query("SELECT name, fullname FROM gateways WHERE status='1'") or die(mysql_error());
		while($row = mysql_fetch_array($gateways)) $gatewayList[]=$row;
		$smarty->assign("gatewayList", $gatewayList);
		
		$currencyList=array();
		$gateways = sql_query("SELECT * FROM currencies") or die(mysql_error());
		while($row = mysql_fetch_array($gateways)) $currencyList[]=$row;
		$smarty->assign("currencyList", $currencyList);

		if($userInfo['rsid']){
			$packageResult = sql_query($safesql->query("SELECT name FROM users WHERE id = '%i' AND userlevel='4' LIMIT 1;", array($userInfo['rsid']))) or die(mysql_error());
			$resel=mysql_fetch_row($packageResult);
			$freseller=$resel[0];
		}else $freseller="";
		$smarty->assign("rsid", $freseller);

		$smarty->assign("userInfoapiaccess", $GameCP->whitelist($userInfo['apiaccess'], "clean"));
		$smarty->assign("userInfoCurrency", $GameCP->whitelist($userInfo['currency'], "clean"));
		$smarty->assign("userInfolimit", $GameCP->whitelist($userInfo['limit'], "int"));
		$smarty->assign("userInfofilemanager", $GameCP->whitelist($userInfo['filemanager'], "useredit"));
		$smarty->assign("userInfofirstname", $GameCP->whitelist($userInfo['firstname'], "useredit"));
		$smarty->assign("userInfolastname", $GameCP->whitelist($userInfo['lastname'], "useredit"));
		$smarty->assign("userInfoaddress", $GameCP->whitelist($userInfo['address'], "useredit"));
		$smarty->assign("userInfoaddress2", $GameCP->whitelist($userInfo['address2'], "useredit"));
		$smarty->assign("userInfoemail", $GameCP->whitelist($userInfo['email'], "useredit"));
		$smarty->assign("userInfoSMSaddress", $GameCP->whitelist($userInfo['smsaddress'], "useredit"));
		$smarty->assign("userInfophone", $GameCP->whitelist($userInfo['phone'], "useredit"));
		$smarty->assign("userInfocity", $GameCP->whitelist($userInfo['city'], "useredit"));
		$smarty->assign("userInfostate", $GameCP->whitelist($userInfo['state'], "useredit"));
		$smarty->assign("userInfocountry", $GameCP->whitelist($userInfo['country'], "useredit"));
		$smarty->assign("userInfozip", $GameCP->whitelist($userInfo['zip'], "useredit"));
		$smarty->assign("userInfowebsite", $GameCP->whitelist($userInfo['website'], "useredit"));
		$smarty->assign("userInfoclan", $GameCP->whitelist($userInfo['clan'], "useredit"));
		$smarty->assign("payment", $GameCP->whitelist($userInfo['payment'], "useredit"));
		$smarty->assign("userInfoDemo", $GameCP->whitelist($userInfo['demo'], "useredit"));
		$smarty->assign("billingid", $GameCP->whitelist($userInfo['billingid'], "useredit"));
		$smarty->assign("taxid", $GameCP->whitelist($userInfo['taxid'], "useredit"));
		$smarty->assign("userInfopassword", $GameCP->whitelist($userInfo['password'], "password"));
		$smarty->assign("taxed", $GameCP->whitelist($userInfo['taxed'], "useredit"));
		$smarty->assign("theme", $GameCP->whitelist($userInfo['theme'], "useredit"));
		$smarty->assign("style", $GameCP->whitelist($userInfo['style'], "useredit"));
		$smarty->assign("userInfo", $userInfo);
		if($userInfo['joindate']){ 
			$smarty->assign("userInfojoindate", $GameCP->whitelist(date(dateformat, $userInfo['joindate']), "useredit"));
		} else $smarty->assign("userInfojoindate", "Unknown");
		$smarty->assign("userInfouserlevel", $userInfo['userlevel']);
		$smarty->assign("userInfobash", $userInfo['bash']);
		$smarty->assign("userInfoactive", $userInfo['active']);
		$smarty->assign("userperms", unserialize($userInfo['permissions']));
		$smarty->assign("credit", $userInfo['credit']);
		$smarty->assign("gcplang", $userInfo['lang']);
		$smarty->assign("userInfoextranotes", $userInfo['extranotes']);
		$smarty->assign("userInfousername", $userInfo['name']);
		$smarty->assign("userInfolastlogin", $userInfo['lastlogin']);
		$smarty->assign("userInfoLocation", $userInfo['location']);
		$smarty->assign("suspend", $userInfo['suspend']);
		$smarty->assign("idd", $specialid);

		$smarty->assign("defaultperms", $GameCP->ClientPermissions());

		if($profiletpl){
			$smarty->display("manageusers/profile.tpl");
		} else $smarty->display("manageusers/manageclients-edit.tpl");
	}

	function GetDiskUsage($cid, $sid=false){
		global $GameCP, $safesql, $Backend;
		$final=array();
		$q="SELECT DISTINCT(S.sid), os, username, S.id FROM game G, usergames UG, users U, iptable I, servers S WHERE G.id = UG.gid AND U.id = '%i' AND UG.cid = U.id AND UG.ip = I.ip AND I.sid = S.sid AND S.active='1'";
		$d=array($GameCP->whitelist($cid, "int"));
		if($sid){
			$q.=" AND S.id = '%s'";
			$d[]=$sid;
		}
		$gameInfoQ = sql_query($safesql->query($q, $d)) or die(mysql_error());
		while($gi = mysql_fetch_array($gameInfoQ)){
			$GameCP->loadIncludes("backend");
			$Backend=new Backend();
			if($gi['os'] == "1"){
				$df=explode("\t",$Backend->QueryResponse($gi['sid'], '', "bin\du.exe:_:-bs \$MAINDIRhome\\".$gi['username']));
			} else $df=explode("\t",$Backend->QueryResponse($gi['sid'], '', "command:_:du -bs /home/".$gi['username']));
			$final[$gi['id']]=$df[0];
		}
		return $final;
	}

	function CheckResellerLimits($assign=false){
		global $GameCP, $safesql, $smarty;

		$resultClient = sql_query($safesql->query("SELECT `limit`, `slotlimit` FROM users WHERE id='%i' LIMIT 1;", array($_SESSION['gamecp']['userinfo']['id']))) or die(mysql_error()); 
		$clientInfo=mysql_fetch_array($resultClient);

		$clientGamesQ = sql_query($safesql->query("SELECT id FROM users WHERE rsid='%i'", array($_SESSION['gamecp']['userinfo']['id']))) or die(mysql_error()); 
		$total=0;
		$resellerGames=0;
		while($ug=mysql_fetch_array($clientGamesQ)){
			$rug = sql_query($safesql->query("SELECT id, maxplayers FROM usergames WHERE cid='%i' LIMIT 1;", array($ug['id']))) or die(mysql_error()); 
			$ugi=mysql_fetch_array($rug);
			if($ugi['id']){
				//$total=$total+$ugi['maxplayers'];
				$resellerGames++;
			}
		}
		$resellerSlotsQ = sql_query("SELECT sum(maxplayers) FROM users U, usergames UG WHERE U.id = UG.cid AND U.rsid='".$_SESSION['gamecp']['userinfo']['id']."'") or die(mysql_error());
		$resellerSlots = mysql_fetch_array($resellerSlotsQ);
		$total=$resellerSlots[0];



		if($resellerGames >= $clientInfo['limit']){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("Your account has reached its maximum servers allowed.");	
		}
		if($total >= $clientInfo['slotlimit']){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("Your account has reached its maximum player slots allowed.");	
		}

		if($assign == true){
			$smarty->assign("res_totalslots", $total);
			$smarty->assign("res_totalgames", $resellerGames);
			$smarty->assign("res_limitgame", $clientInfo['limit']);
			$smarty->assign("res_limitslot", $clientInfo['slotlimit']);
		}
	}

	function CheckThenAdd($sid, $fname, $fpassword, $ubash){
		global $GameCP;

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$fname=strtolower($fname);

		if (!$Backend->QueryResponse($sid, '', "checkuser:_:$fname")) { 
			$Backend->QueryResponse($sid, '', "adduser:_:$ubash:_:$fname:_:$fpassword");
			$hook_vars=array($fname, $fpassword, $ubash);
			run_hook("add_user_toserver", $hook_vars);

			$serveruserA = "a".trim($Backend->QueryResponse($sid, '', "checkuser:_:$fname"))."b";
			if ($serveruserA != "aexistsb") return false;
		} else $Backend->QueryResponse($sid, '', "changepass:_:$fname:_:$fpassword");

		return true;
	}

	function CheckName($username){
		global $safesql, $GameCP;

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$invalidnames=$Panel->InvalidNames();

		if(in_array($username, $invalidnames)){
			$total="1";
		} else {
			$uname = sql_query($safesql->query("SELECT name FROM users where name='%s' LIMIT 1;", array($GameCP->whitelist($username, "useredit")))) or die(mysql_error());
			$total= mysql_num_rows($uname);
		}

		if($total > "0"){
			return false;
		} else return true;
	}

	function GetShell($loginpath, $demo){
		if ($loginpath == "yes" && !$demo) {
			return "/bin/bash"; 
		}elseif ($loginpath == "noftp" && !$demo) {
			return  "/sbin/noftp"; 
		}else return "$(which nologin)"; 
	}

	function AddGame($fname, 
					$cuser, 
					$gmid, 
					$fip, 
					$fport, 
					$fqueryport, 
					$outmodedhltvport, 
					$scanport,
					$fmaxclients,
					$pubpriv="public", 
					$orderpage,
					$flimit, 
					$subdirectory,
					$fstartmap,
					$RCONPASSWORD,
					$SPECPASSWORD,
					$PRIVPASSWORD,
					$HOSTNAME,
					$MOTD,
					$WEBSITE, 
					$fconfig,
					$installtype='install',
					$startserver='yes',
					$addons=FALSE,
					$game_addons=FALSE,
					$affinty=FALSE,
					$newuser=FALSE,
					$start_time=FALSE,
					$end_time=FALSE,
					$queue=FALSE,
					$billingid=FALSE,
					$fsendinfo="yes",
					$maingid=FALSE,
					$location=FALSE,
					$fpassword=false,
					$fmip=FALSE
							){
		global $Backend, $Event, $GameCP, $safesql, $smarty;
		if(!$gmid || $gmid == "0") return true;

		if(isset($_SESSION['gamecp']['userinfo']['name'])){
			$nm = $_SESSION['gamecp']['userinfo']['name'];
		} else $nm="System";

		$Event->EventLogAdd($fname, "User ". $fname. " is having game #$gmid created by ".$nm." ". time());

		set_time_limit("1200");

		$fname=strtolower($fname);
		$cuser=strtolower($cuser);

		run_hook("add_game_pre");

		if(!$fip){
			$GameCP->loadIncludes("ip");
			$IP=new IP();
			$fip=$IP->GetIP($gmid, $fmaxclients, $location);
		}

		if(!$fip){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error("<a href=\"https://linkonym.appspot.com/?http://wiki.gamecp.com/FAQ#Unable_to_automatically_determin_IP_address.\">Unable to automatically determine IP address.</a> Please check machine or game configuration.", $queue, "1"); 
		}

		if($gmid == "1000" || $gmid == "1001" || $gmid == "1002"){
			$GameCP->loadIncludes("voice");
			$Voice=new Voice();

			switch($gmid){
				case "1000":
					$vid=$Voice->AddTeamSpeak2($cuser, $fip, '', $HOSTNAME, $fmaxclients, $fpassword, '','','',$billingid);
				break;
				case "1002":
					$vid=$Voice->AddTeamSpeak3($cuser, $fip, '', $HOSTNAME, $fmaxclients, $fpassword, '','','',$billingid);
				break;
				case "1001":
					$vid=$Voice->AddVentrilo($cuser, $fip, '', $fname, $HOSTNAME, $fpassword, $fpassword, '', $fmaxclients, $fpassword,'','','',$billingid);
				break;
			}
			
			if($vid == false){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				return $Panel->Error("The voice server was not installed.", $queue, "1");
			}

			if($fsendinfo == "yes"){
				$GameCP->loadIncludes("email");
				$Email = new Email();
				$Email->SendDetails($cuser);
			}

			if(is_numeric($vid)) {
				if(isset($_SESSION['gamecp']['order_api']) && $_SESSION['gamecp']['order_api']==true) echo "UGID:$vid:<br>"; 
				return $vid;
			} else {
				if(isset($_SESSION['gamecp']['order_api']) && $_SESSION['gamecp']['order_api']==true) echo $vid;
				return false;
			}
		}

		if(isset($start_date) && isset($end_date)){
			$use_sched = "1";
		} else $use_sched = "0";
		
		$affy="";
		if(isset($affinity) && is_array($affinity)){
			foreach($affinity as $ai){
				$affy.=$ai.",";
			}
		} else if(isset($affinity) && $affinity) $affy=$affinity;

		if(!$cuser){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error("Unable to determine user id."); 
		}

	
		if (!$fname){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error("Missing field name, not adding.");
		}
		if ($fname == "root"){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error("Panel User of Root is not allowed.");
		}

		/* machine info */
		$gsidQ = sql_query($safesql->query("SELECT I.sid, S.os, S.winport, S.winadminpass, S.winuser, I.internal, I.useinternal, S.iptablesconf from iptable I, servers S WHERE I.ip = '%s' AND I.sid=S.sid", array($GameCP->whitelist($fip, "useredit")))) or die(mysql_error());
		$gsid = mysql_fetch_array($gsidQ);
		$sid = $gsid[0];
		if(!$sid){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error("Unable to determine Server ID.<br>Please try another ip address.");
		}
		$os = $gsid['os'];
		$winport = $gsid['winport'];
		$winadminpass = $gsid['winadminpass'];
		$winuser = $gsid['winuser'];
		$iptablesconfig=$gsid['iptablesconf'];
		$serverip = $fip;
		$ogip=$fip;
		if($gsid['useinternal'] == "1") $fip = $gsid['internal'];
		/* user info */
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$userInfo=$Panel->GetUser($cuser);
		$fname=$userInfo['name'];
		$fpassword=$userInfo['password'];
		$usrid=$userInfo['id'];
		$loginpath=$userInfo['bash'];
		$limit=$userInfo['limit'];
		$demo=$userInfo['demo'];

		$isNewUserQ=sql_query($safesql->query("SELECT I.sid FROM iptable I, usergames UG WHERE UG.ip = I.ip AND I.sid='%s' AND UG.cid='%i' LIMIT 1;", array($GameCP->whitelist($sid, "useredit"), $GameCP->whitelist($usrid, "int"))));
		$newuser='0';
		if(mysql_num_rows($isNewUserQ) == "0") $newuser='1'; 

		/* clean up the user password */
		$fpassword=$GameCP->whitelist($fpassword, 'password');

		if(!$winport) $winport="240";

		/* verify the server is online first */
		$GameCP->loadIncludes("query");
		$Query=new Query();
		$restatus=$Query->Status($sid);
		if($restatus == false){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error("Unable to communicate with remote server", $queue, "1");
		}

		$gameInfoQ = sql_query($safesql->query("SELECT 
							id, name, fsgame,
							gcode, startmode, game, 
							install, protocol, installfile,
							scontrolname, premode, 
							port, map, queryport,
							maxplayers, config, hostname, 
							website, motd, winexec,
							winparams, winappdir, wininstall,
							winpremode, installLine,
							gamemonitor,
							deleteinstall, customvars, vars,
							wininstallLine, branding, brandingon, winappdir,
							maxplayers2, altinstall, altinstallwin, disableftp, ports
					FROM game WHERE id = '%i' LIMIT 1;", array($GameCP->whitelist($gmid, "int")))) or die(mysql_error());
		$gameInfo = mysql_fetch_array($gameInfoQ);
		$gid=$gameInfo[0];
		if(!$gid) return $Panel->Error("Unable to add game, missing game id.");
		
		/* define information for this game */
		$default_port=$gameInfo[11];
		$default_map=$gameInfo[12];
		$default_config=$gameInfo[15];
		$default_queryport=$gameInfo[13];
		$linuxsci=$gameInfo['startmode'];
		$winsci=$gameInfo['winparams'];
		$DefaultArchive=$gameInfo['wininstall'];
		$ports=unserialize($gameInfo['ports']);
		$LinuxInstallCommand=$gameInfo['installLine'];
		$WindowsInstallCommand=$gameInfo['wininstallLine'];
		$fsgame=$gameInfo['fsgame'];
		$gamemonitor=$gameInfo['gamemonitor'];
		$deleteinstall=$gameInfo['deleteinstall'];
		$winexec=$gameInfo['winexec'];
		$scontrolName=$gameInfo[9];
		$winappdir=$gameInfo['winappdir'];
		$queryport=$gameInfo['queryport'];
		$winparams=$gameInfo['winparams'];
		$DefaultInstall = $gameInfo[8];
		$branding=$gameInfo['branding'];
		$brandingon=$gameInfo['brandingon'];
		$disableftp=$gameInfo['disableftp'];

		if($os == "1"){
			$altinstall=$gameInfo['altinstallwin'];
		} else $altinstall=$gameInfo['altinstall'];

		if($os == "1" && !$winexec) return $Panel->Error("No Windows executable defined for game."); 

		$GameCP->loadIncludes("game");
		$Game=new Game();

		if($os =="1"){ 
			$installdir=$gameInfo['winappdir'];
			$premode=$gameInfo['winpremode'];
			$final_install=$Game->FinalInstall($os, $DefaultArchive);
		} else {
			$installdir=$gameInfo[6];
			$premode=$gameInfo[10];
			$final_install=$Game->FinalInstall($os, $DefaultInstall);
		}
		
		if(!$altinstall && $Game->IsDownload($final_install) == false && $Game->CheckInstallFiles($sid, $winport, $os, $final_install) == false) return $Panel->Error("$sid Missing: ".str_replace("\$MAINDIR", "", $final_install));

		if (!$HOSTNAME) $HOSTNAME = $gameInfo[16];
		if (!strlen($WEBSITE) > 3) $WEBSITE = $gameInfo[17];
		if (strtoupper($PRIVPASSWORD) == "PUBLIC" || strtoupper($PRIVPASSWORD) == "PUB") $PRIVPASSWORD = "";

		if(!strlen($MOTD) > 3) {
			$MOTD = $gameInfo[18];
		} else $MOTD = str_replace(".PIPE", "|", $MOTD);

		//if($brandingon == "1" && $branding) $HOSTNAME=$branding." ".$HOSTNAME;

		$pubpriv=strtolower($pubpriv);

		if($pubpriv == "1"){
			$pubpriv="private";
		} else if(!$pubpriv) $pubpriv="public";

		if(!$PRIVPASSWORD) $PRIVPASSWORD ="";
		if(($pubpriv == "private") && ($PRIVPASSWORD == FALSE || $PRIVPASSWORD == NULL)) $PRIVPASSWORD = $Panel->RandomPassword();

		if(!$fport){
			if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
				$GameCP->loadIncludes("ports");
				$Ports=new Ports();
				$resellerport=$Ports->Reseller($fport);
				if($resellerport == false){
					$fport=$default_port;
				} else $fport=$resellerport[0];
			} else $fport=$default_port;
		}

		if(!$fstartmap) $fstartmap=$default_map;
		if(!$fconfig) $fconfig=$default_config;

		if(!$gameInfo['maxplayers2']) $gameInfo['maxplayers2']=$gameInfo['maxplayers'];
		if(!$fmaxclients) $fmaxclients=$gameInfo['maxplayers'];

		$limitdifference=$gameInfo['maxplayers2']-$gameInfo['maxplayers'];
		$clientplayers=$fmaxclients;
		$fmaxclients=$fmaxclients+$limitdifference;

		if (isset($_SESSION['gamecp']['userinfo']['ulevel']) && ($_SESSION['gamecp']['userinfo']['ulevel'] == "5" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4")) {
			$resellerSlotsQ = sql_query("SELECT sum(maxplayers) FROM users U, usergames UG WHERE U.id = UG.cid AND U.rsid='".$_SESSION['gamecp']['userinfo']['id']."'") or die(mysql_error());
			$resellerSlots = mysql_fetch_array($resellerSlotsQ);
			$availslots=$_SESSION['gamecp']['userinfo']['slotlimit']-$resellerSlots[0];
			if($fmaxclients > $availslots){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				return $Panel->Error("Not enough player slots assigned to create this user, $availslots available out of ".$_SESSION['gamecp']['userinfo']['slotlimit'].".", $queue, "1");
			}
		}

		if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "4") $this->CheckResellerLimits();
	
		$cb="";
		$ubash = $this->GetShell($loginpath, $demo);
		if ($loginpath != "yes" && $loginpath != "no" && $loginpath != "noftp") $cb=", bash='no'";
		
		sql_query($safesql->query("UPDATE users SET userlevel='0' $cb WHERE name = '%s'", array($fname)));

		/* load port scanning */
		$GameCP->loadIncludes("ports");
		$Ports=new Ports();

		/* scan the initial port */
		if($scanport == "yes") $fport=$Ports->GetPortAuto($serverip, $fport); 

		if($Ports->CheckReseller($fport) == true){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error();
		}

		/* all ports are based on this difference */
		$portdiff=$fport-$default_port;

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		if($os !="1"){
			if($newuser == '1'){
				if($installtype == "install"){
					$serveruserA = "a".trim($Backend->QueryResponse($sid, $winport, "checkuser:_:$fname"))."b";
					if ($serveruserA == "aexistsb") { 
						$GameCP->loadIncludes("panel");
						$Panel=new Panel();
						return $Panel->Error("USER ALREADY EXISTS. '$fname' is already installed on this machine when it should not be.");
					}

					$Backend->QueryResponse($sid, $winport, "adduser:_:$ubash:_:$fname:_:$fpassword");
					$hook_vars=array($fname, $fpassword, $ubash, $sid, $winport);
					run_hook("add_user_toserver");
				} else $Backend->QueryResponse($sid, '', "changepass:_:$fname:_:$fpassword");
			}

			$serveruserA = "a".trim($Backend->QueryResponse($sid, $winport, "checkuser:_:$fname"))."b";
			if ($serveruserA != "aexistsb") { 
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				return $Panel->Error("USER DOES NOT EXIST. Unable to run 'adduser $fname'. Is your servers hard-drive full?");
			}
			$valid=true;
		} else $valid=true;

		if($valid == true){
			if($os != "1" && $os != "3") {
				$startmode=$linuxsci;
			} else $startmode=$winsci;

			$serverip	= trim($serverip);
			$fport		= trim($fport);
			$queryport	= trim($queryport);
		
			if ($installtype == "install"){
				$status="4";
			} else $status="";

			if(is_array($game_addons)) $_REQUEST['cvars']=$game_addons;

			if(!$HOSTNAME)		$HOSTNAME = $gameInfo[16];
			if(!$WEBSITE)		$WEBSITE = $gameInfo[17];
			if(!$MOTD)			$MOTD = $gameInfo[18];
			if(!$RCONPASSWORD)	$RCONPASSWORD=$Panel->RandomPassword();
			if(!$SPECPASSWORD)	$SPECPASSWORD=$Panel->RandomPassword();

			/* Game related data */
			$IP = $fip;
			$PORT = $fport;
			$GAMETYPE = $gameInfo[2];
			$MAXPLAYERS = $fmaxclients;
			$STARTMAP = $fstartmap;
			$USERNAME = $fname;
			if(!isset($_REQUEST['vars'])) $_REQUEST['vars']=array();
			if(!isset($_REQUEST['cvars'])) $_REQUEST['cvars']=array();

			$configSave=array('SPECPASSWORD' => $SPECPASSWORD,
							'PRIVPASSWORD' => $PRIVPASSWORD,
							'HOSTNAME' => $HOSTNAME,
							'MOTD' => $MOTD,
							'WEBSITE' => $WEBSITE);

			$queryport=$Ports->GetPort($queryport, $serverip, $default_port, $portdiff);
			
			if(is_array($ports) && count($ports) > 0){
				foreach($ports as $p=>$t) $ports[$p]['port']=$Ports->GetPort($t['port'], $serverip, $default_port, $portdiff);
			}
			$regular_ports=array(array("cvar" =>"PORT", "port"=>$fport),array("cvar"=>"QUERYPORT","port"=>$queryport)); 
			$all_ports=array_merge($regular_ports, is_array($ports) ? $ports : array());

			$safeQ=$safesql->query("INSERT INTO usergames SET  
								created='%s',
								cid = '%i', 
								config = '%s',
								ip = '%s', 
								port = '%i',
								gid = '%i', 
								startmap = '%s', 
								clientplayers = '%i', 
								maxplayers = '%i',
								pubpriv = '%s',
								rconpass='%s', 
								scontrol='%s', 
								scan='1', 
								subdirectory='%s', 
								affinity='%s',
								gametype='%s',
								addons='%s',
								start_time='%s',
								end_time='%s',
								queryport='%i', 
								vars='%s',
								customvars='%s',
								use_sched='%i',
								mgid='%i',
								status='%i',
								startserver='%s',
								defaultinfo='%s',
								firewallports='%s',
								branding='%s',
								brandingon='%i',
								permissions='a:12:{s:4:\"name\";s:4:\"true\";s:7:\"players\";s:4:\"true\";s:3:\"eac\";s:4:\"true\";s:8:\"hostname\";s:4:\"true\";s:4:\"motd\";s:4:\"true\";s:7:\"website\";s:4:\"true\";s:8:\"rconpass\";s:4:\"true\";s:8:\"specpass\";s:4:\"true\";s:8:\"privpass\";s:4:\"true\";s:8:\"gametype\";s:4:\"true\";s:6:\"config\";s:4:\"true\";s:3:\"map\";s:4:\"true\";}'", 
				array(time(),
				$GameCP->whitelist($cuser, "int"), 
				$GameCP->whitelist($fconfig, "useredit"), 
				$GameCP->whitelist($serverip, "useredit"), 
				$GameCP->whitelist($fport, "int"), 
				$GameCP->whitelist($gmid, "int"), 
				$GameCP->whitelist($fstartmap, "useredit"), 
				$GameCP->whitelist($fmaxclients, "int"), 
				$GameCP->whitelist($clientplayers, "int"), 
				$GameCP->whitelist($pubpriv, "useredit"), 
				$GameCP->whitelist($RCONPASSWORD, "useredit"), 
				$GameCP->whitelist($scontrolName, "useredit"), 
				$GameCP->whitelist($subdirectory, "useredit"), 
				$GameCP->whitelist($affy, "useredit"), 
				$GameCP->whitelist($fsgame, "useredit"), 
				$GameCP->whitelist(serialize($addons), 'serialize', "useredit"), 
				$GameCP->whitelist($start_time, "useredit"), 
				$GameCP->whitelist($end_time, "useredit"), 
				$GameCP->whitelist($queryport, "int"), 
				serialize($_REQUEST['vars']),
				serialize($_REQUEST['cvars']),
				$GameCP->whitelist($use_sched, "int"),
				$GameCP->whitelist($maingid, "int"),
				$GameCP->whitelist($status, "int"),
				$GameCP->whitelist($startserver, "useredit"),
				serialize($configSave),
				serialize($all_ports),
				$GameCP->whitelist($branding, "clean"),
				$GameCP->whitelist($brandingon, "int")
			));
			sql_query($safeQ);
			$ugid=mysql_insert_id();

			if(!$ugid){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				return $Panel->Error("Unable to add game.");
			}

			$scontrolName="gcp-".$fname."-".$ugid;
			sql_query($safesql->query("UPDATE usergames SET `scontrol`='%s' WHERE id='%i'", array($GameCP->whitelist($scontrolName, "string"),$GameCP->whitelist($ugid, "int")))) or die(mysql_error());
			
			if($os == "1"){
				$GameCP->loadIncludes("backend");
				$Backend->UpdateFTP($sid);
			}

			if($disableftp == "1"){
				$GameCP->loadIncludes("linux");
				$Linux=new Linux();
				$Linux->SSHAccess($cuser, "noftp", true);
				sql_query($safesql->query("UPDATE users SET filemanager='1' WHERE id='%i'", array($GameCP->whitelist($cuser, "username")))) or die(mysql_error());
			}

			$GameCP->loadIncludes("control");
			$Control=new Control();

			if(!$Control->Build($ugid, "add")) return $Panel->Error("Unable to create service control.", $queue, "1");

			if($billingid) sql_query($safesql->query("UPDATE usergames SET billingid='%i' WHERE id='%i'", array($GameCP->whitelist($billingid, "int"),$GameCP->whitelist($ugid, "int")))) or die(mysql_error());
			
			if($flimit == "+1"){
				$flimit=$userInfo['limit']+1;
				sql_query($safesql->query("UPDATE users SET `limit`='%i' WHERE id='%i'", array($GameCP->whitelist($flimit, "int"),$GameCP->whitelist($cuser, "username")))) or die(mysql_error());
			}
		}

		if ($installtype == "install"){
			$GameCP->loadIncludes("game");
			$Game=new Game();

			/* install files */
			if($Game->InstallFiles($fname, $ugid, $serverip, $fport, $sid, $os, $winport, $DefaultInstall, $subdirectory, $premode,$gameInfo['wininstall'],$installdir,$DefaultArchive, $deleteinstall, '', $altinstall) == false){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				return array($ugid,$Panel->Error("Unable to copy or extract service repository.", $queue, "1"));
			}


			/* firewall */
			$open_ports=array();
			foreach($all_ports as $a=>$p) $open_ports[]=$p['port'];
			$this->ExecFirewall($sid, $os, $serverip, $open_ports, "open", $iptablesconfig);

			if($gamemonitor){
				$gmcmd="-q --tries=2 --spider --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --bind-address $serverip http://master.game-monitor.com/heartbeat.php?p=$fport&e2=$gamemonitor";
				if($os == "1"){
					$mres=$Backend->QueryResponse($sid, $winport, "bin\wget:_:$gmcmd");
				} else $mres=$Backend->QueryResponse($sid, $winport, "command:_:wget $gmcmd");
				
				$Event->EventLogAdd($fname, "Game-monitor.com triggered for $ugid: wget $gmcmd , result: $mres");
			}
		}
		
		if($fsendinfo == "yes"){
			$GameCP->loadIncludes("email");
			$Email = new Email();
			$Email->SendDetails($cuser);
		}

		if($fmip == "yes") sql_query($safesql->query("UPDATE iptable SET assigned = '1' WHERE ip = '%s'", array($serverip)));

		$GameCP->loadIncludes("ip");
		$IP=new IP();
		$IP->UpdateIPUse($sid);

		$Event->EventLogAdd($fname, "User ". $fname. " had game $ugid created on $sid by ".$nm);

		if(isset($_SESSION['gamecp']['order_api']) && $_SESSION['gamecp']['order_api']==true) echo "UGID:$ugid:<br>USER: $fname ::<br>"; 
	
		run_hook("add_game", array('id'=>$ugid, 'maxplayers'=>$fmaxclients, 'gid'=>$gmid));
	
		if(isset($_SESSION['gamecp']['nav_control'])) unset($_SESSION['gamecp']['nav_control']);

		return $ugid;
	} 

	function ExecFirewall($sid, $os, $serverip, $ports, $direction,$iptablesconfig){
		global $Backend, $Event;
		if(!$iptablesconfig) $iptablesconfig="/etc/iptables.conf";
		
		$Event->EventLogAdd('', "Firewall Triggered on $serverip $direction ". serialize($ports));

		if($direction == "open"){
			if($os == "1"){
				$direction="add";
			} else $direction="open";
		} else {
			if($os == "1"){
				$direction="delete";
			} else $direction="close";
		}

		foreach($ports as $serverport){
			if($serverport && $serverport != "0"){
				if(doiptables == "1"){
					if($os == "1"){
						$Backend->Query($sid, '', "netsh:_:firewall $direction portopening UDP $serverport game");
						$Backend->Query($sid, '', "netsh:_:firewall $direction portopening TCP $serverport game");
					} else {
						if($direction == "open"){
							$Backend->Query($sid, '', "command:_:iptables -D INPUT -p tcp -d $serverip --dport $serverport -j ACCEPT; iptables -D INPUT -p udp -d $serverip --dport $serverport -j ACCEPT; iptables -A INPUT -p tcp -d $serverip --dport $serverport -j ACCEPT; iptables -A INPUT -p udp -d $serverip --dport $serverport -j ACCEPT; iptables-save > $iptablesconfig");
						} else $Backend->Query($sid, '', "command:_:iptables -D INPUT -p tcp -d $serverip --dport $serverport -j ACCEPT; iptables -D INPUT -p udp -d $serverip --dport $serverport -j ACCEPT; iptables-save > $iptablesconfig");					
					}
				}
			}
		}

		global $hook_vars;
		$hook_vars=array($serverip, $ports, $sid, $os, $direction);
		run_hook("firewall");
	}
		
	function RemoveStatsDir($ip, $port){
		global $GameCP;

		if(DIRECTORY_SEPARATOR == '\\'){
			$statsdir=path."/includes/stats/$ip-$port";
		} else $statsdir=path."/includes/stats/$ip:$port";

		if(is_dir($statsdir)) {
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->RemoveRecursiveDir($statsdir);
		}

		
	}

	function RemoveGame($ggid, $suspendUser="yes", $deleteUser="no", $remSubGames="no", $asktoremove=false, $removerride=false, $deletesql=true,$orderpage=false,$dorm=true,$dorm2=false){
		global $GameCP, $Backend, $Event, $safesql;

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$userdataQ = sql_query($safesql->query("SELECT G.scontrolname, I.sid, U.name,
									G.remove, S.os, UG.ip, UG.port,
									S.winport, UG.id, U.id, UG.subdirectory,
									G.install, G.id, G.gcode, G.fsgame, G.vars,
									G.customvars, UG.vars, U.bash, G.winremove, S.iptablesconf, UG.fastdl, UG.firewallports
								FROM 
									usergames UG, users U, game G, 
									iptable I, servers S 
								WHERE 
									UG.id='%i' AND U.id = UG.cid AND UG.gid = G.id AND I.ip=UG.ip AND I.sid = S.sid
								LIMIT 1;", array($ggid))) or die(mysql_error()); 	


		if(mysql_num_rows($userdataQ) == 0){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();

			return $Panel->Error("Service not found");
		}

		run_hook("remove_game_pre");

		$userdata = mysql_fetch_array($userdataQ); 
		$sci = $userdata[0]; 
		$sid = $userdata[1];
		$os=$userdata[4];
		$fip=$userdata[5];
		$fport=$userdata[6];
		$winport=$userdata[7];
		$gid=$userdata[8];
		$fname = $userdata[2];
		$removeLine = $userdata[3];
		$winremoveLine = $userdata['winremove'];
		$idd= $userdata[9];
		$sci=$sci.".".$gid;
		$subdirectory=$userdata[10];
		$install=$userdata[11];
		$gameid=$userdata[12];
		$querycode=$userdata[13];
		$fsgame=$userdata[14];
		$ugvars=unserialize($userdata[17]);
		$gvars=unserialize($userdata[15]);
		$customvars=unserialize($userdata[16]);
		$bash=$userdata[18];
		$iptablesconfig=$userdata['iptablesconf'];
		if($subdirectory == "yes"){ 
			if(ipsubdir == "true"){
				$thesubdir=$fip."-".$fport;
			} else $thesubdir="service".$ggid;
		}
		if($install != ""){
			if(isset($thesubdir)) $install =$thesubdir."/".$install;
		} else $install=$thesubdir;


		/* verify the server is online first */
		$GameCP->loadIncludes("query");
		$Query=new Query();
		$res=$Query->Status($sid);
		if(!$res && !isset($_SESSION['gamecp']['userinfo']['ulevel'])){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			return $Panel->Error("Service not removed - a server was offline");
		}

		$isLastGameQ=sql_query($safesql->query("SELECT UG.id FROM iptable I, usergames UG WHERE UG.ip = I.ip AND I.sid='%s' AND UG.cid='%i'", array($sid, $idd)));
		$isLastGame=mysql_num_rows($isLastGameQ);

		$GameCP->loadIncludes("control");
		$Control=new Control();
		
		$Control->Run($fname, $sid, $gid, $os, $sci, "stop", $fip, $fport, '0');

		$GameCP->loadIncludes("game");
		$Game=new Game();
		$Game->GameCommand("remove", $ggid);

		$this->RemoveStatsDir($fip, $fport);

		if($userdata['fastdl'] != ''){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$fastdlserver=$Panel->GetServer($userdata['fastdl']);
			if(isset($fastdlserver['webroot'])) $Backend->Query($fastdlserver['fastdl'], '', "deldir:_:".$fastdlserver['webroot'].'/rsync/'.$ggid.'/');
		}

		if($os == "1") {
			$Backend->Query($sid, $winport, "removeserver:_:gcp-$fname-$ggid");
			$Backend->UpdateFTP($sid);

			if($install || (!$install && $thesubdir)){
				if($dorm) $Backend->Query($sid, $winport, "deldir:_:\$MAINDIR\\home\\$fname\\$install");
				if($dorm2 && $thesubdir) $Backend->Query($sid, $winport, "deldir:_:\$MAINDIR\\home\\$fname\\$thesubdir");
			}

			$removeLine=$winremoveLine;

		} else { 
			$Backend->Query($sid, $winport, "deletefile:_:/home/$fname/.screenrc.$ggid:_:yes");
			$Backend->Query($sid, $winport, "deletefile:_:/home/$fname/screenlog.$ggid:_:yes");

			if($install || (!$install && $thesubdir)){
				if($dorm) $Backend->Query($sid, $winport, "deldir:_:/home/$fname/$install", $fname);
				if($dorm2 && $thesubdir) $Backend->Query($sid, $winport, "deldir:_:/home/$fname/$thesubdir", $fname);
			}
		} 

		/* firewall */
		$all_ports=array();
		$firewall_ports=unserialize($userdata['firewallports']);
		if(is_array($firewall_ports)){
			foreach($firewall_ports as $f =>$p) $all_ports[]=$p['port'];
			if(count($all_ports) > 0 ) $this->ExecFirewall($sid, $os, $fip, $all_ports, "close", $iptablesconfig);
		}

		if(debugging =="1") echo "<div class='debuggingwindow'>";

		if ($asktoremove == true && $isLastGame == "1") { 
			if(debugging =="1") echo "Removing user from server.<br>";
			$this->RemoveUserAccount($sid, $winport, $os, $Backend, $fname);
		} 

		
		if($deletesql==true){

			if(debugging =="1") echo "Removing from userconfigs table.<br>";
			sql_query($safesql->query("DELETE FROM userconfigs WHERE ugid='%i'", array($ggid))) or die(mysql_error()); 

			if(debugging =="1") echo "Removing from usergames table.<br>";
			sql_query($safesql->query("DELETE FROM usergames WHERE id='%i'", array($ggid))) or die(mysql_error()); 	

			if(debugging =="1") echo "Removing from ipban table.<br>";
			sql_query($safesql->query("DELETE FROM ipban WHERE ugid='%i'", array($ggid))) or die(mysql_error()); 	

			if(debugging =="1") echo "Removing from config_buildersave table.<br>";
			sql_query($safesql->query("DELETE FROM config_buildersave WHERE ugid='%i'", array($ggid))) or die(mysql_error()); 	

		}


		$isLastIPQ=sql_query("SELECT id FROM usergames WHERE ip='$fip'");
		$isLastIP=mysql_num_rows($isLastIPQ);

		$ipAssignedQ=sql_query("SELECT id FROM iptable WHERE ip='$fip' AND assigned='1'");
		$ipAssigned=mysql_num_rows($ipAssignedQ);

		if($isLastIP == "0" && $ipAssigned == "1"){
			if(debugging =="1") echo "Unmarking $fip as used.";
			sql_query("UPDATE iptable SET assigned='0' WHERE ip='$fip'") or die(mysql_error());

			$GameCP->loadIncludes("ip");
			$IP=new IP();
			$IP->UpdateIPUse($sid);
		}


		$Event->EventLogAdd($_SESSION['gamecp']['userinfo']['username'], "Service ID# ". $ggid. " has been removed ");

		if($remSubGames == "yes"){
			$removeSubGamesQ=sql_query($safesql->query("SELECT id FROM usergames WHERE cid='%i' AND mgid='%i';", array($idd, $ggid)));
			$removeSubGames=mysql_num_rows($removeSubGamesQ);
			if ($removeSubGames > "0") { 
				while($remgame=mysql_fetch_array($removeSubGamesQ)){
					$sgid=$remgame['id'];
					if(debugging =="1") echo "Removing sub-game #$sgid";
					$this->RemoveGame($sgid, $suspendUser, $deleteUser, $remSubGames, $asktoremove);
				}
			}
		}

		/* Client Exec hates last users cause its stupid */
		$overallLastGameQ=sql_query($safesql->query("SELECT id FROM usergames WHERE cid='%i' LIMIT 1;", array($idd)));
		$overallLastGame=mysql_num_rows($overallLastGameQ);
		if ($overallLastGame == "0") { 
			if($suspendUser == "yes")
			{
				if(debugging =="1") echo "User has no more games, suspending.<br>";
				$GameCP->loadIncludes("suspend");
				$Suspend=new Suspend();
				$Suspend->User($idd);
			}
			elseif($deleteUser == "yes")
			{
				if(debugging =="1") echo "User account has been removed.<br>";
				 $this->Remove($idd);
			}
		}

		run_hook("remove_game_post");

		if(debugging =="1") echo "Users game removed.</div>";

		return "removed";
	}

	function RemoveUserAccount($sid, $winport, $os, $Backend, $fname){
		global $hook_vars;

		if($os != "1") {
			$Backend->Query($sid, $winport, "deluser:_:$fname");
			$hook_vars=$fname;
			run_hook("remove_user_fromserver");
			$Backend->Query($sid, $winport, "deletefile:_:/etc/logrotate.d/$fname");

			$serveruserA = "a".trim($Backend->QueryResponse($sid, '', "checkuser:_:$fname"))."b";
			if ($serveruserA == "aexistsb") return false;

		} else $Backend->Query($sid, $winport, "deldir:_:\$MAINDIR\\home\\$fname");

		run_hook("remove_user_account", array($sid, $fname));

		return true;
	}

	function Remove($idd, $remacctd=false, $orderpage=false){
		global $GameCP, $Backend, $Event, $safesql, $hook_vars;
		
		set_time_limit(99999);
		$remvalid=0;

		if($_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
			$resQ=" AND rsid = ". $_SESSION['gamecp']['userinfo']['id'];
		} else $resQ="";

		$userInfoQ = sql_query($safesql->query("SELECT name, username, bash FROM users WHERE id='%i' $resQ LIMIT 1;", array($idd))) or die(mysql_error()); 
		$doThis=mysql_num_rows($userInfoQ);
		
		if($doThis == "0"){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->Error("User already removed from GameCP");
			return false;
		}
			
		
		$userInfo = mysql_fetch_array($userInfoQ);
		$uname = $userInfo[0];
		$name = $userInfo[0];
		$bash = $userInfo[2];
			

		if($uname == "admin") { 
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->Error("Removing Admin user is not allowed");
			return false;
		}
		
		$GameCP->loadIncludes("voice");
		$Voice=new Voice();
		$Voice->Remove('', $idd);

		// Grab all the information & shut down servers.
		$gameInfoQ = sql_query($safesql->query("SELECT UG.id as 'gid' FROM users U, usergames UG, game G, iptable I, servers S WHERE U.id = '%i' AND UG.cid = U.id AND UG.gid = G.id AND I.ip = UG.ip AND I.sid = S.sid", array($idd))) or die(mysql_error());
		if(mysql_num_rows($gameInfoQ) > 0){

			if(isset($_POST['removeUserAccount']) && $_POST['removeUserAccount'] == "1" || $remacctd == true){
				$rem=true;
			} else $rem=false;

			while ($gameInfo = mysql_fetch_array($gameInfoQ)) 
				if($this->RemoveGame($gameInfo['gid'], '', '', '', $rem) != "removed")$remvalid++;

			
		} 
		if($remvalid > "0" && !isset($_SESSION['gamecp']['userinfo']['ulevel'])){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->Error("User account not removed - a server was offline");
			return false;
		} else {

			$GameCP->loadIncludes("modules");
			$Modules=new Modules();
			$Modules->ExecUserCommand($idd, 'TerminateAccount');

			$hook_vars=$idd;
			run_hook("remove_user");

			// no errors!
			if(debugging =="1") echo "<div class='debuggingwindow'>";

			if(debugging =="1") echo "<br>Removing from users table.<br>";
			sql_query($safesql->query("DELETE FROM users WHERE id='%i'", array($idd))) or die(mysql_error()); 	

			if(debugging =="1") echo "Removing from trouble tickets table.<br>";
			sql_query($safesql->query("DELETE FROM ttsystem WHERE cid='%i'", array($idd))) or die(mysql_error()); 	

			if(debugging =="1") echo "Removing from billing table.<br>";
			sql_query($safesql->query("DELETE FROM billing WHERE cid='%i'", array($idd))) or die(mysql_error()); 	

			if(debugging =="1") echo "Removing from user bills table.<br>";
			sql_query($safesql->query("DELETE FROM userbills WHERE cid='%i'", array($idd))) or die(mysql_error()); 	

			if(debugging =="1") echo "Removing from payments table.<br>";
			sql_query($safesql->query("DELETE FROM payments WHERE cid='%i'", array($idd))) or die(mysql_error()); 	

			if(debugging =="1") echo "Removing from uservoice table.<br>";
			sql_query($safesql->query("DELETE FROM uservoice WHERE cid='%i'", array($idd))) or die(mysql_error()); 

			if(debugging =="1") echo "Removing subusers.<br>";
			sql_query($safesql->query("DELETE FROM usersubaccounts WHERE cid='%i'", array($idd))) or die(mysql_error());

			if(debugging =="1") echo "Removing donations.<br>";
			sql_query($safesql->query("DELETE FROM donations WHERE cid='%i'", array($idd))) or die(mysql_error());

			if(debugging =="1") echo "Removing from promotionsuse.<br>";
			sql_query($safesql->query("DELETE FROM promotionsuse WHERE cid='%i'", array($idd))) or die(mysql_error()); 

			if(debugging =="1") echo "Removing from module_services.<br>";
			sql_query($safesql->query("DELETE FROM module_services WHERE cid='%i'", array($idd))) or die(mysql_error()); 


			if(debugging =="1") echo "</div>";

			/*if(debugging =="1") echo "Updating cron.<br>";
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->Crontab();*/

			if($orderpage == true) echo "<br>User with id ". $idd ." has been removed from the control panel.";   
			$Event->EventLogAdd($uname, "User ". $uname. " has been removed ");

		}

		return true;
	}

	function RemoveSQL($idd){
		global $GameCP, $safesql;
		$userInfoQ = sql_query($safesql->query("SELECT name, userlevel FROM users WHERE id ='%i' LIMIT 1;", array($idd))) or die(mysql_error()); 
		$doThis=mysql_num_rows($userInfoQ);
		if($doThis == "0"){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->Error("User already removed from GameCP");
			return false;
		}
			
			
		$userInfo=mysql_fetch_row($userInfoQ);
		$fuserlevel = $userInfo[1];
		
		if($fuserlevel == "4"){
		$resellRemove = sql_query($safesql->query("SELECT id, name FROM users WHERE rsid='%i'", array($idd))) or die(mysql_error());
		$doResell=mysql_num_rows($resellRemove);
			if($doResell != "0"){
				while ($doResellR = mysql_fetch_row($doResell)) {
					$tmpid=$doResellR[0];
					$fname=$doResellR[1];
					if(debugging =="1") echo "Removing reseller id from $fname.<br>";
		
					sql_query("UPDATE users SET rsid='' WHERE id='$tmpid' LIMIT 1");
				}
			}
		}
		if(debugging =="1") echo "<br>Removing from users table.<br>";
		sql_query($safesql->query("DELETE FROM users WHERE id='%i'", array($idd))) or die(mysql_error());
		
		if(debugging =="1") echo "<br>Removing from uservoice table.<br>";
		sql_query($safesql->query("DELETE FROM uservoice WHERE cid='%i'", array($idd))) or die(mysql_error()); 

		run_hook("remove_user_sql", $idd);

		
		return true;
	}

	function Export($idd){
		global $GameCP, $safesql;
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$userinfo=$Panel->GetUser($idd);
		$args['user_information']=$userinfo;

		$exportlist="";
		$result="";
		 $userGames = sql_query($safesql->query("SELECT * FROM usergames UG, servers S, iptable I WHERE UG.cid='%i' AND UG.ip = I.ip AND I.sid = S.sid", array($idd))) or die(mysql_error());
			while ($ugames = mysql_fetch_array($userGames)){ 
				$args['gamecp_info']=$ugames;

			$urlvars = array(
				"action" => "create", 
				"function"   => "createacct",
				"username"   => $args['user_information']['username'],
				"password"   => $args['user_information']['password'],
				"customerid"  => $args['user_information']['id'],
				"packageid"  => "",
				// profile information
				"emailaddr"  => $args['user_information']['email'],
				"firstname"  => $args['user_information']['firstname'],
				"lastname"   => $args['user_information']['lastname'],
				"address"    => $args['user_information']['address'],
				"city"       => $args['user_information']['city'],
				"state"      => $args['user_information']['state'],
				"country"    => $args['user_information']['country'],
				"zipcode"    => $args['user_information']['zip'],
				"phonenum"   => $args['user_information']['phone'],
				// Game server information
				"game_id"     => $args['gamecp_info']['gid'],
				"max_players" => $args['gamecp_info']['maxplayers'],
				"pub_priv"    => $args['gamecp_info']['pubpriv'],
				"website"     => $args['user_information']['website'],
				"hostname"    => "",
				"motd"   	  => "",
				"rcon_password"    => $args['gamecp_info']['rconpass'],
				"priv_password"    => $args['gamecp_info']['rconpass'],
				"sv_location" => $args['gamecp_info']['location'],
				"addons" => serialize(@$args['package_addons']));

		 $result= serialize($urlvars)."\n";
		}

		return $result;
	}

	function Password($idd, $table="users", $md5pass=false){
		// moved for security
		global $GameCP;
		if($md5pass){
			 return md5($GameCP->Password($idd, $table));
		}else return $GameCP->Password($idd, $table);
	}

	function Random(){
		$userQ=sql_query("select id from users where userlevel='0' and active='1' order by rand() limit 1");
		$userD=mysql_fetch_array($userQ);
		return($userD['id']);
	}

	function GetServers($cid, $ugid=FALSE, $userLimit=FALSE){
		global $safesql;
		if($ugid) $ugid = "AND id != '$ugid'";
		$activeUserServers = sql_query($safesql->query("SELECT id FROM usergames WHERE cid='%i' AND active='1' $ugid", array($cid)), "total user servers") or die(mysql_error()); 
		$activeUserServers=mysql_num_rows($activeUserServers);

		if(!isset($userLimit)){
			$totalUserServers = sql_query($safesql->query("SELECT U.limit FROM users U, usergames UG WHERE UG.cid='%i' AND U.id = UG.cid", array($cid))) or die(mysql_error()); 
			$userLimit=mysql_fetch_row($totalUserServers);
			$userLimit=$userLimit[0];
			$totalUserServers=mysql_num_rows($totalUserServers);
		}else{
			$totalUserServers="0";
			$userLimit="0";
		}


		return array($activeUserServers, $totalUserServers, $userLimit);
	}

	function CleanName($fname){
		global $GameCP;
		$fname=str_replace (" ", "", $GameCP->whitelist($fname, "username"));
		$userstring = str_split($fname);
		$fnameout="";
		foreach($userstring as $char) {
			if(preg_match("/^[0-9a-zA-Z_]+$/", $char)) $fnameout.=$char;
		}
		$fname=$fnameout;
		return strtolower($fname);
	}

	function AddUser($data){
		global $GameCP, $safesql, $Event;

		extract($data);

		if(isset($_SESSION['gamecp']['userinfo']['name'])){
			$nm=$_SESSION['gamecp']['userinfo']['name'];
		} else $nm="Automatic";

		$Event->EventLogAdd($fname, "User ". $fname.", ". $femail. ", is being created by ".$nm." ". time());

		$GameCP->loadIncludes("user");
		$User=new User();
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if ($queue != "0") ob_start(); 
		
		if ($demo == "yes") $loginpath = "no"; 

		if (!$fpassword){
			$fpassword = $Panel->RandomPassword();  
		}else $fpassword=$GameCP->whitelist($fpassword, 'password');

		if($freseller){
			$reseller=", rsid='".$GameCP->whitelist($freseller)."'";
		} else $reseller="";

		/* clean up name */
		$fname=$this->CleanName($fname);

		if (strlen($fname) < 3) return $Panel->Error("Username must be larger then 3 chars.", $queue, "1", false); 
		if (strlen($fname) > 16) return $Panel->Error("Username must be less then 16 chars.", $queue, "1", false); 
		if (!$fname) return $Panel->Error("Missing field username, not adding.", $queue, "1", false); 

		
		/* Check to see if the `path` has /home/ in it - if so detect the user this is installed to so GameCP cant add people as that name */
		if (preg_match("/\/home/i", path)){
			$homecheck=explode("/", path);
			if ($fname == $homecheck[2]) return $Panel->Error("User matches the username where GameCP is installed, select another name.<br>".path, $queue, "1", false); 
		}

		$invalidnames=$Panel->InvalidNames();
		if (in_array($fname,$invalidnames)) return $Panel->Error("The user name $fname is not allowed.", $queue, "1", false); 
		
		$unameQ = sql_query($safesql->query("SELECT id FROM users where name='%s'", array($fname))) or die(mysql_error());
		if (mysql_num_rows($unameQ) != 0) return $Panel->Error("A user with the username $fname already exists, not adding.", $queue, "1", false); 

		$unameQ = sql_query($safesql->query("SELECT email FROM users WHERE email='%s'", array($femail))) or die(mysql_error());
		if (mysql_num_rows($unameQ) != 0) return $Panel->Error("A user with the e-mail $femail already exists, not adding.", $queue, "1", false); 

		if(isset($fmanager)){
			$fmanager=$GameCP->whitelist($fmanager, 'int');
		} else $fmanager="0";

		if(taxEnable == "yes"){
			$taxuser="1";
		} else $taxuser="0";

		if(isset($demo) && $demo == "yes"){
			$demo="1";
		} else $demo="0";

		/* add the user to the db */
		sql_query($safesql->query("INSERT INTO users SET
						clan = '%s', 
						name = '%s', 
						email = '%s', 
						username = '%s',
						userlevel = '%s',
						active = '1', 
						phone = '%s', 
						address = '%s',
						city = '%s', 
						state = '%s', 
						country = '%s',
						zip = '%s', 
						website = '%s',
						extranotes = '%s',
						firstname = '%s',
						lastname = '%s',
						payment = '%s', 
						address2 = '%s', 
						bash = '%s', 
						indexsort='%s',
						joindate = '%s', 
						`limit`='0',
						filemanager='%i',
						taxed='%i', 
						demo='%i',
						billingid='%i',
						currency='%s',
						permissions='%s'
						$reseller", array(
							$GameCP->whitelist($clan, "useredit"),
							$GameCP->whitelist($fname, "useredit"),
							$GameCP->whitelist($femail, "useredit"),
							$GameCP->whitelist($fname, "useredit"),
							$GameCP->whitelist($fuserlevel, "useredit"),
							$GameCP->whitelist($phone, "useredit"),
							$GameCP->whitelist($address, "useredit"),
							$GameCP->whitelist($city, "useredit"),
							$GameCP->whitelist($state, "useredit"),
							$GameCP->whitelist($country, "useredit"),
							$GameCP->whitelist($zip, "useredit"),
							$GameCP->whitelist($clienturl, "useredit"),
							$GameCP->whitelist($extrainfo, "useredit"),
							$GameCP->whitelist($firstname, "useredit"),
							$GameCP->whitelist($lastname, "useredit"),
							$GameCP->whitelist($payment, "useredit"),
							$GameCP->whitelist($address2, "useredit"),
							$GameCP->whitelist($loginpath, "useredit"),
							indexClient,
							time(),
							$GameCP->whitelist($fmanager, "int"),
							$taxuser,
							$GameCP->whitelist($demo, "int"),
							$GameCP->whitelist($billingid, "int"),
							$GameCP->whitelist($currency, "clean"),
							userpermissions
						))) or die(mysql_error());

		$cid = mysql_insert_id();
		if(!$cid) return $Panel->Error("Unable to add user to the database, please check your settings and try again.", $queue, "1", false);
		
		
		$GameCP->SetPassword($cid, $fpassword);

		run_hook("add_gamecp_user", array($cid, $fname, $fpassword));

		$Event->EventLogAdd($fname, "User ". $fname. " was created by ".$nm." ". time());

		return $cid;
	}

	function Add($fname,
		$femail,
		$pid,
		$fusername,
		$fuserlevel,
		$fpassword, 
		$fip, $fport,
		$phone,
		$address,
		$city,
		$state,
		$country,
		$zip,
		$clienturl,
		$installtype,
		$extrainfo, 
		$firstname, 
		$lastname,
		$payment,
		$address2,
		$ftsip,
		$loginpath,
		$today,
		$fconfig,
		$fip, $fport,
		$fstartmap,
		$fmaxclients,
		$fpubpriv, 
		$date,
		$status,
		$gross,
		$fee,
		$daystill, 
		$installtype,
		$startserver,
		$fsendinfo,
		$addbill,
		$orderpage, 
		$ordergame,
		$fmip,
		$queue, 
		$voiceInstall=FALSE,
		$voiceType=FALSE,
		$voiceMaxClients=FALSE, 
		$RCONPASSWORD=FALSE,
		$SPECPASSWORD=FALSE,
		$PRIVPASSWORD=FALSE,
		$subscr_id=FALSE,
		$HOSTNAME=FALSE,
		$MOTD=FALSE,
		$WEBSITE=FALSE, 
		$freseller=FALSE, 
		$start_time=FALSE,
		$end_time=FALSE,
		$queryport=FALSE, 
		$addons=FALSE, 
		$game_addons=FALSE,
		$affinty=FALSE, 
		$voiceName=FALSE, 
		$voiceIP=FALSE, 
		$voicePort=FALSE,
		$subdirectory=FALSE,
		$billingid=FALSE,
		$billingid2=FALSE,
		$location=FALSE,
		$promo=FALSE,
		$fmanager=FALSE,
		$ordervoice=FALSE,
		$paymentDetails=FALSE
	){

		global $demo, $Event, $GameCP, $smarty, $safesql;

		$GameCP->loadIncludes("user");
		$User=new User();
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if ($queue != "0") ob_start(); 
		
		if ($demo == "yes") $loginpath = "no"; 
		if (!$fpassword){
			$fpassword = $Panel->RandomPassword();  
		}else $fpassword=$GameCP->whitelist($fpassword, 'password');

		if($freseller){
			$reseller=", rsid='$freseller'";
		} else $reseller="";
		if (!$fport) { 
			$scanport="yes";
		} else $scanport="no";

		/* clean up name */
		$fname=$this->CleanName($fname);
		$fusername=$fname;

		/* new user error checking */
		$unameQ = sql_query($safesql->query("SELECT name FROM users where name='%s'", array($fname))) or die(mysql_error());
		$uname = mysql_fetch_row($unameQ);

		if ($fname == $uname[0]) return $Panel->Error("User already exists, not adding.", $queue, "1"); 
		if (strlen($fname) < 3) return $Panel->Error("Username must be larger then 3 chars.", $queue, "1"); 
		if (strlen($fname) > 16) return $Panel->Error("Username must be less then 16 chars.", $queue, "1"); 
		if (!$fname) return $Panel->Error("Missing field username, not adding.", $queue, "1"); 
		
		/* Check to see if the `path` has /home/ in it - if so detect the user this is installed to so GameCP cant add people as that name */
		if (preg_match("/\/home/i", path)){
			$homecheck=explode("/", path);
			if ($fname == $homecheck[2]) return $Panel->Error("User matches the username where GameCP is installed, select another name.<br>".path, $queue, "1"); 
		}

		$invalidnames=$Panel->InvalidNames();
		if (in_array($fname,$invalidnames)) return $Panel->Error("Server User of $fname is not allowed.", $queue, "1"); 
		
		if(isset($fmanager)){
			$fmanager=$GameCP->whitelist($fmanager, 'int');
		} else $fmanager="0";

		if(isset($_SESSION['gamecp']['userinfo']['name'])){
			$nm=$_SESSION['gamecp']['userinfo']['name'];
		} else $nm="Automatic";
		$Event->EventLogAdd($fname, "User ". $fname. " was created by ".$nm." ". time());

		if(taxEnable == "yes"){
			$taxuser="1";
		} else $taxuser="0";

		/* add the user to the db */
		sql_query($safesql->query("INSERT INTO users SET 
						name = '%s', 
						email = '%s', 
						username = '%s',
						userlevel = '%s',
						active = '1', 
						phone = '%s', 
						address = '%s',
						city = '%s', 
						state = '%s',
						country = '%s',
						zip = '%s', 
						website = '%s',
						extranotes = '%s',
						firstname = '%s',
						lastname = '%s',
						payment = '%s', 
						address2 = '%s', 
						bash = '%s', 
						indexsort='%s',
						joindate = '%s', 
						`limit`='1',
						filemanager='%i', 
						permissions='%s',
						taxed='%i' $reseller", array(
							$GameCP->whitelist($fname, "useredit"),
							$GameCP->whitelist($femail, "useredit"),
							$GameCP->whitelist($fusername, "useredit"),
							$GameCP->whitelist($fuserlevel, "useredit"),
							$GameCP->whitelist($phone, "useredit"),
							$GameCP->whitelist($address, "useredit"),
							$GameCP->whitelist($city, "useredit"),
							$GameCP->whitelist($state, "useredit"),
							$GameCP->whitelist($country, "useredit"),
							$GameCP->whitelist($zip, "useredit"),
							$GameCP->whitelist($clienturl, "useredit"),
							$GameCP->whitelist($extrainfo, "useredit"),
							$GameCP->whitelist($firstname, "useredit"),
							$GameCP->whitelist($lastname, "useredit"),
							$GameCP->whitelist($payment, "useredit"),
							$GameCP->whitelist($address2, "useredit"),
							$GameCP->whitelist($loginpath, "useredit"),
							indexClient,
							time(),
							$GameCP->whitelist($fmanager, "int"),
							userpermissions,
							$taxuser
						))) or die(mysql_error());

		$cid = mysql_insert_id();
		if(!$cid) return $Panel->Error("Unable to add user to the database, please check your settings and try again.", $queue, "1");
		
		
		$GameCP->SetPassword($cid, $fpassword);
		
		if($billingid) sql_query($safesql->query("UPDATE users SET billingid='%s' WHERE id = '%i'", array($billingid, $cid))) or die(mysql_error());
		if($addbill == "yes" || $addbill == "1"){
			$GameCP->loadIncludes("billing");
			$Billing=new Billing();	
			$bid=$Billing->AddBill($daystill, $cid, $date, $status, $gross, $fee, $subscr_id, $promo);
		}

		$installGames=true;

		/* new template has games in its own tab, not enabled to install by default! */
		if(isset($_REQUEST['gameInstall']) && $_REQUEST['gameInstall'] != "yes") $installGames = false;

		if($installGames == true && $pid != "0"){
			/* add game */
			$ugid=$this->AddGame($fname, $cid, $pid, $fip, $fport, $queryport, '', $scanport,
									$fmaxclients,
									$fpubpriv, 
									$orderpage,
									'', 
									$subdirectory,
									$fstartmap,

									$RCONPASSWORD,
									$SPECPASSWORD,
									$PRIVPASSWORD,
									$HOSTNAME,
									$MOTD,
									$WEBSITE, 
									$fconfig,

									$installtype,
									$startserver,
									$addons,
									$game_addons,
									$affinty,
									"1",
									$start_time,
									$end_time,
									$queue,
									$billingid2, "no", '', $location, $fpassword, $fmip);
			if(!is_numeric($ugid)){
				if($voiceInstall != "yes"){
					if(is_array($ugid)){
						$this->RemoveGame($ugid[0], "no", "yes", "yes", false, true);
					} else sql_query($safesql->query("DELETE FROM users WHERE id='%i' LIMIT 1;", array($cid))) or die(mysql_error());
					return false;
				}
			}
			/* do sub installs, woot! */
			$configInfoQ = sql_query($safesql->query("SELECT * FROM gamesubinstalls WHERE gid='%i' AND install='1'", array($pid))) or die(mysql_error());
			while($configInfo = mysql_fetch_array($configInfoQ)){
				// flimit = if no flimit it adds one
				if($configInfo['limit'] == "0" || !$configInfo['limit']){
					$flimit="";
				} else $flimit=$configInfo['limit'];

				$this->AddGame($fname, $cid, $configInfo['sgid'], $fip, '', '', '', "yes",
										$configInfo['maxplayers'],
										$configInfo['pubpriv'], 
										$orderpage,
										$flimit, 
										$configInfo['subdir'],
										'',
										$RCONPASSWORD,
										$SPECPASSWORD,
										$PRIVPASSWORD,
										$configInfo['hostname'],
										$MOTD,
										$WEBSITE, 
										'',
										'install',
										'yes',
										$addons,
										$game_addons,
										$affinty, '', '', '', '', '', '', '', '', '', '', '', '', $ugid, $location, $fpassword, $fmip);
			}

		} // end if install games is true


		
		if($voiceInstall == "yes"){
			$GameCP->loadIncludes("voice");
			$Voice=new Voice();

			if($voiceType == "1000") $vid=$Voice->AddTeamSpeak2($cid, $voiceIP, $voicePort, $voiceName, $voiceMaxClients, $fpassword, '', '', true, $billingid);
			if($voiceType == "1001") $vid=$Voice->AddVentrilo($cid, $voiceIP, $voicePort, $fname, $voiceName, $fpassword, $fpassword, '', $voiceMaxClients, $fpassword, '', '', '', $billingid);
			if($voiceType == "1002") $vid=$Voice->AddTeamSpeak3($cid, $voiceIP, $voicePort, $voiceName, $voiceMaxClients, $fpassword, '', '', true, $billingid);
			if($voiceType == "1003") $vid=$this->AddGame($fname, $cid, '1003', '', $voicePort, '', '', 'yes', $voiceMaxClients, '', '0', '+1', $subdirectory, $fstartmap,$RCONPASSWORD, $SPECPASSWORD, $PRIVPASSWORD, $voiceName, $MOTD, $WEBSITE, '',$installtype, $startserver, FALSE,FALSE,FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, $billingid);
			if($voiceType == "1004") $vid=$this->AddGame($fname, $cid, '1004', '', $voicePort, '', '', 'yes', $voiceMaxClients, '', '0', '+1', $subdirectory, $fstartmap,$RCONPASSWORD, $SPECPASSWORD, $PRIVPASSWORD, $voiceName, $MOTD, $WEBSITE, '',$installtype, $startserver, FALSE,FALSE,FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, $billingid);

			if((isset($ugid) && !is_numeric($ugid)) && (!isset($vid) || isset($vid) && $vid == false)){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				return $Panel->Error("The voice server was not installed.", $queue, "1");
			}else if(!is_numeric($vid)) echo "The voice server was not installed.<br>";
			
			if(isset($vid)) $smarty->assign("vid", $vid);

		} 

		if($addbill == "yes" || $addbill == "1"){
			if(!isset($ugid)) $ugid="";
			$paidPrice=$paymentDetails['paid'];
			$transactionid=$paymentDetails['transactionid'];
			$suspend_notpaid=$paymentDetails['suspend_notpaid'];
			$paddons=$paymentDetails['paddons'];

			$Billing->CreateSubBill($addbill, $bid, $ugid, $vid, $ordergame, $ordervoice, $cid, unserialize($promo), unserialize($paddons), array($paymentDetails['taxproduct'], $paymentDetails['taxvoice'], $paymentDetails['taxaddon']));
			if($paidPrice) $Billing->AddPayment($bid, $paidPrice, $subscr_id, $transactionid, $payment, $fee);
			$Billing->updateBillTotals($bid);

			if($suspend_notpaid == true && $paidPrice < $gross ){
				$GameCP->loadIncludes("suspend");
				$Suspend=new Suspend();
				if($ugid) $Suspend->Game($ugid);
				if($vid && ($ordervoice['type'] == "1003" || $ordervoice['type'] == "1004")){
					 $Suspend->Game($vid);
				}elseif($vid) $Suspend->Voice($vid);
			}
			$smarty->assign("bid", $bid);
		}

		if($fsendinfo == "yes"){
			$GameCP->loadIncludes("email");
			$Email = new Email();
			$Email->SendDetails($cid);
		}

		$smarty->assign("fname", $fname);
		$smarty->assign("cid", $cid);
		if(isset($_SESSION['gamecp']['order_api']) && $_SESSION['gamecp']['order_api']==true){
			echo "User " . $fname . " has been added.";
			echo "<br>uid:$cid:$ugid:<br>";
			echo "USER: $fname ::<br>"; 
		}

		if(isset($_SESSION['gamecp']['nav_control'])) unset($_SESSION['gamecp']['nav_control']);

		if($ugid) return $ugid;
	} 
}
?>