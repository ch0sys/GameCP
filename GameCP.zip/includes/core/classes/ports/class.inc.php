<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

class Ports{

	var $service_ports;

	function Reseller($fport){
		global $GameCP, $safesql;

		if( $_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
			$resultClient = sql_query("SELECT portrange FROM users WHERE id='" . $_SESSION['gamecp']['userinfo']['id'] ."' LIMIT 1;") or die(mysql_error()); 
			$clientInfo=mysql_fetch_array($resultClient);
			if($clientInfo['portrange']){
				$portrange=explode("-", $clientInfo['portrange']);
				return $portrange;
			} else return false;
		} else return false;
	}

	function CheckReseller($fport){
		global $LNG_PORTOUTARANGE, $LNG_MAXSERVERS;
		if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
			$resultClient = sql_query("SELECT `limit`, portrange FROM users WHERE id='" . $_SESSION['gamecp']['userinfo']['id'] ."' LIMIT 1;") or die(mysql_error()); 
			$clientInfo=mysql_fetch_array($resultClient);
			$portrange=explode("-", $clientInfo['portrange']);

			if($clientInfo['portrange']){
				if($fport >= $portrange[0] && $fport <= $portrange[1]){
				} else {
					echo $LNG_PORTOUTARANGE." " . $clientInfo['portrange'] .".";	
					return true;
				}
			}			
		}

		return false;
	}

	function Generate($port, $add){
		$port=$port+$add;
		return $port;
	}

	function GetPort($var, $serverip, $default_port, $portdiff){
		if($var == $default_port){
			return $this->Generate($var, $portdiff);
		} elseif($var){
			return $this->GetPortAuto($serverip, $this->Generate($var, $portdiff));
		}
	}

	function GetServicePorts($ip){
		global $GameCP, $safesql;
	
		$ports=array();
		$portsQ = sql_query($safesql->query("SELECT firewallports FROM usergames WHERE ip= '%s'", array($GameCP->whitelist($ip, "clean")))) or die(mysql_error());
		while($row=mysql_fetch_array($portsQ)){
			$p=unserialize($row[0]);
			foreach($p as $a=>$b) $ports[]=$b['port'];
		}

		$this->service_ports=$ports;

	}

	function CheckDBQuery($ip, $port, $table){
		global $GameCP, $safesql;
		
		$port=$GameCP->whitelist($port, "int");
		if($table=="uservoice"){
			$sql="port='$port'";
			$q=sql_query($safesql->query("SELECT * FROM $table WHERE ip = '%s' AND $sql LIMIT 1;", array($GameCP->whitelist($ip, "clean"))));
			if(mysql_num_rows($q) >0) return true;
		} else {
			$sql="(port='$port' OR queryport='$port')";
			$q=sql_query($safesql->query("SELECT * FROM $table WHERE ip = '%s' AND $sql LIMIT 1;", array($GameCP->whitelist($ip, "clean"))));
			if(mysql_num_rows($q) >0) return true;
			if(in_array($port, $this->service_ports)) return true;		
		}

		return false;
	}

	function CheckDB($ip, $port){
		global $GameCP, $safesql;

		$this->GetServicePorts($ip);

		$portCheck = $this->CheckDBQuery($ip, $port, 'usergames');
		$portCheckVoice = $this->CheckDBQuery($ip, $port, 'uservoice');
		if($portCheck == true || $portCheckVoice == true) { 
			if(debugging =="1") echo "<span style='color: red'>$port</span>, "; 
			return true; 
		} else { 
			return false; 
		}

	}

	function GetPortAuto($ip, $requested_port, $max_ports_to_scan = 45){
		global $GameCP, $safesql;
		

		// Init vars
		$port_found = FALSE;
		$port = $requested_port;

		$counter = 0;
		$max_ports_to_scan=portLimit;

		if(debugging == "1") echo "<div class='debuggingwindow'><h3>Scanning for open ports on $ip starting at $requested_port</h3>";

		// Do this, while port is not found
		while($port_found != TRUE && $max_ports_to_scan > $counter) {

			// Check if port used in db
			if ($this->CheckDB($ip, $port) == false) {
				if (portchecking == 1) {
						$sidQ = sql_query($safesql->query("SELECT S.sid, S.os FROM servers S, iptable I WHERE I.ip = '%s' AND S.sid = I.sid LIMIT 1;", array($GameCP->whitelist($ip, "clean")))) or die(mysql_error());
						$machineQ=mysql_fetch_array($sidQ);
						$sid=$machineQ['sid'];
						$os=$machineQ['os'];
						if($os != "1"){
							$GameCP->loadIncludes("backend");
							$Backend=new Backend();
							if(trim($Backend->QueryResponse($sid, '', "command:_:netstat -an | grep $ip:$port > /dev/null ; echo $?")) != "0"){
								 $port_found = TRUE;
							} else $port_found = FALSE;
						} else $port_found = TRUE;
				} else $port_found = TRUE;
			}
			
			// Check if port found yet..
			if ($port_found != TRUE) {
				$port=$port+portIncrament;
				$counter++;
			}
		}

		
		if ($port_found != TRUE) {
			//Port not found - rescan it with the last port used
			if(debugging =="1") echo "Unable to locate a port with scan limit of ".portLimit.", trying again:"; 
			$port=$this->GetPortAuto($ip, $port);
		} else {
			// Proceed
			if(debugging =="1") echo "<span style='color: green'>$port</span><br>"; 
		}

		if(debugging == "1") echo "</div>";
		return $port;
	}



}
?>