<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


if(!isset($noheader)){
	if (isset($_SERVER['HTTP_ACCEPT_ENCODING']) && substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip') && extension_loaded('zlib')){
		if (ob_get_length() > 0) ob_end_clean(); 
		if (function_exists('ob_gzhandler') && ini_get('zlib.output_compression')&& strstr($_SERVER["HTTP_USER_AGENT"],'compatible')){
			@ob_start('ob_gzhandler');
		} else @ob_start();

	}
    header("Expires: 0");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
}

if (version_compare(PHP_VERSION, '5.2.0', '>=')) {
	$cpm = session_get_cookie_params(); 
	session_set_cookie_params($cpm['lifetime'], $cpm['path'], $cpm['domain'], $cpm['secure'],  true); 
} 

@session_start();

if(isset($_SESSION['gamecp']['orderapi'])) unset($_SESSION['gamecp']['orderapi']);

if(!isset($_SESSION['gamecp']['userinfo']['username'],$_SESSION['gamecp']['user']['password'],$_SESSION['gamecp']['userinfo']['ulevel'])){
	$ajax='';
	if(isset($_REQUEST['ajax'])) $ajax='?ajax=true';
	header("location: ../index.php".$ajax); 
	exit;
}

?>