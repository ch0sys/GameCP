<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/* intended for older versions of php */

@ini_set('magic_quotes_runtime', false);
@ini_set('zend.ze1_compatibility_mode', '0');


if(function_exists("date_default_timezone_set") && function_exists("date_default_timezone_get")) @date_default_timezone_set(@date_default_timezone_get());

function magic_quotes($var){
	if(get_magic_quotes_gpc()){
		return $var;
	} else return addslashes($var);
}


// force quotes disabled!
if (get_magic_quotes_gpc()) {
    $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
    while (list($key, $val) = each($process)) {
        foreach ($val as $k => $v) {
            unset($process[$key][$k]);
            if (is_array($v)) {
                $process[$key][stripslashes($k)] = $v;
                $process[] = &$process[$key][stripslashes($k)];
            } else $process[$key][stripslashes($k)] = stripslashes($v);
        }
    }
    unset($process);
}


if( !function_exists('parse_ini_string') ){
    function parse_ini_string( $string ) {
        $array = Array();
        $lines = explode("\n", $string );
        foreach( $lines as $line ) {
            $statement = preg_match("/^(?!;)(?P<key>[\w+\.\-]+?)\s*=\s*(?P<value>.+?)\s*$/", $line, $match );
            if( $statement ) {
                $key    = $match[ 'key' ];
                $value    = $match[ 'value' ];
                if( preg_match( "/^\".*\"$/", $value ) || preg_match( "/^'.*'$/", $value ) ) $value = mb_substr( $value, 1, mb_strlen( $value ) - 2 );
                $array[ $key ] = $value;
            }
        }
        return $array;
    }
}

if ( !function_exists('htmlspecialchars_decode') )
{
    function htmlspecialchars_decode($text)
    {
        return strtr($text, array_flip(get_html_translation_table(HTML_SPECIALCHARS)));
    }
}

if (!function_exists('json_encode')) {
    function json_encode($data) {
        switch ($type = gettype($data)) {
            case 'NULL':
                return 'null';
            case 'boolean':
                return ($data ? 'true' : 'false');
            case 'integer':
            case 'double':
            case 'float':
                return $data;
            case 'string':
                return '"' . addslashes($data) . '"';
            case 'object':
                $data = get_object_vars($data);
            case 'array':
                $output_index_count = 0;
                $output_indexed = array();
                $output_associative = array();
                foreach ($data as $key => $value) {
                    $output_indexed[] = json_encode($value);
                    $output_associative[] = json_encode($key) . ':' . json_encode($value);
                    if ($output_index_count !== NULL && $output_index_count++ !== $key) {
                        $output_index_count = NULL;
                    }
                }
                if ($output_index_count !== NULL) {
                    return '[' . implode(',', $output_indexed) . ']';
                } else {
                    return '{' . implode(',', $output_associative) . '}';
                }
            default:
                return ''; // Not supported
        }
    }
}
 if (!function_exists('json_decode')) {
    function json_decode($json) {
      $comment = false;
      $out     = '$x=';
      for ($i=0; $i<strlen($json); $i++) {
        if (!$comment) {
          if (($json[$i] == '{') || ($json[$i] == '[')) {
            $out .= 'array(';
          }
          elseif (($json[$i] == '}') || ($json[$i] == ']')) {
            $out .= ')';
          }
          elseif ($json[$i] == ':') {
            $out .= '=>';
          }
          elseif ($json[$i] == ',') {
            $out .= ',';
          }
          elseif ($json[$i] == '"') {
            $out .= '"';
          }
          /*elseif (!preg_match('/\s/', $json[$i])) {
            return null;
          }*/
        }
        else $out .= $json[$i] == '$' ? '\$' : $json[$i];
        if ($json[$i] == '"' && $json[($i-1)] != '\\') $comment = !$comment;
      }
      eval($out. ';');
      return $x;
    }
  }
 ?>