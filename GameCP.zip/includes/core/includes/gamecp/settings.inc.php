<?php $gcpVersion = '1.4.64'; $gcpVersionDate='Fri Apr 10 20:34:19 UTC 2015'; ?>
<?php 
if(!isset($gcpVersion)){
	$gcpVersion = 'Beta';
	$gcpVersionDate='Tue Nov 5 00:00:01 EST 2009'; 
}

/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


if(isset($_REQUEST['test_suite'])) define("debugging", "1");


if(!defined('_GAMECP_')) die("Invalid access");


require_once("compat.inc.php");


function sql_query($query, $reason=FALSE){
	//if(!$reason) $reason=$query;
	//echo "ran query for $reason<br>";
	return mysql_query($query);
}

function setcharset($charset){
	if(function_exists("mysql_set_charset")){
		mysql_set_charset($charset);
	} else {
		mysql_query("SET NAMES ".$charset); 
		mysql_query('SET CHARACTER SET '.$charset);
	}
}


/* individual users can be demos - disable any of their shit */
if(isset($_SESSION['demo'])){
	define("DEMO","yes");
	$DEMO="yes";
}

if(isset($_SESSION['gamecp']['constant_settings']) && (time() - $_SESSION['gamecp']['constant_settings']['last_ran'] < '300')){
	//echo " cached constant<br>";
} else {
	// we must force charset before loading settings for utf8 items in settings themselves
	$settingsRows = sql_query("SELECT value FROM settings WHERE name='force_sqlcharset';", "constant force_sqlcharset") or die(mysql_error());
	$srow = mysql_fetch_assoc($settingsRows);
	if($srow['value'] == "true"){
		$settingsRows = sql_query("SELECT value FROM settings WHERE name='sqlcharset';", "constant force_sqlcharset") or die(mysql_error());
		$srow = mysql_fetch_assoc($settingsRows);
		setcharset($srow['value']);
	}
	$_SESSION['gamecp']['constant_settings']=array();
	$settingsRows = sql_query("SELECT * FROM settings", "constant settings") or die(mysql_error());
	while ($srow = mysql_fetch_assoc($settingsRows))  $_SESSION['gamecp']['constant_settings'][$srow['name']]=$srow['value'];
	unset($settingsRows);
	$_SESSION['gamecp']['constant_settings']['last_ran']=time();
}

$GameCPSettings=array();
foreach($_SESSION['gamecp']['constant_settings'] as $const_name => $const_value){
	if($const_name == "debugging" && $const_value == "2"){
		if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
			@define($const_name, "1");
		} else @define($const_name, "0");
	} else if(!defined($const_name)) define($const_name, $const_value);
	$GameCPSettings[]=array("name"=>$const_name, "value"=>$const_value);
}

@set_time_limit(PHPTIMEOUT);


if(isset($_SESSION['userlang'])){
	$_SESSION['gamecp']['lang']=$_SESSION['userlang'];
	unset($_SESSION['userlang']);
}
if(force_sqlcharset == "true") setcharset(sqlcharset);

if(isset($_SESSION['gamecp']['lang'])){
	$lang=$_SESSION['gamecp']['lang'];
} elseif(isset($_COOKIE['gcplang']) && $_COOKIE['gcplang']){
	$string="/[^a-zA-Z0-9_]/";
	$lang=preg_replace( $string, "", $_COOKIE['gcplang'] );
	if(!isset($_SESSION['gamecp']['lang'])) $_SESSION['gamecp']['lang']=$lang;
} else {
	$_SESSION['gamecp']['lang']=defaultlang;
	$lang=defaultlang;
}

if(!is_file(path."/includes/lang/$lang.ini")){
	$_SESSION['gamecp']['lang']="en";
	$lang="en";
}

/* legacy support */
if(!@ipsubdir) define("ipsubdir", false);

/* redefine stuff so some scripts can read it */
	$pgrefresh = pgrefresh;
	$domain = domainName;
	$limit = displayLimit;
	$PATH = path;
	$GLOBALS['url'] = url;
	$url = url;

	require_once(path.'/includes/core/classes/mysql/SafeSQL.class.php');
	$safesql = new SafeSQL_MySQL();


	if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
		$TEMPLATE = USERTHEME;
		$STYLESHEET = styleclient;
	} else{
		$TEMPLATE = THEME;
		$STYLESHEET = styleadmin;
	}

	if(isset($_SESSION['gamecp']['userinfo']) && $_SESSION['gamecp']['userinfo']['reseller']){
		if(!isset($_SESSION['gamecp']['userinfo']['resellerDetails'])){
			$usrnfoQ = sql_query($safesql->query("SELECT * FROM users WHERE id = '%i';", array($_SESSION['gamecp']['userinfo']['reseller']))) or die(mysql_error());     
			$usrnfo = mysql_fetch_array($usrnfoQ);
			$_SESSION['gamecp']['userinfo']['resellerDetails']=$usrnfo;
		}
		if($_SESSION['gamecp']['userinfo']['resellerDetails']['theme']) $TEMPLATE = $_SESSION['gamecp']['userinfo']['resellerDetails']['theme'];
		if($_SESSION['gamecp']['userinfo']['resellerDetails']['style']) $STYLESHEET = $_SESSION['gamecp']['userinfo']['resellerDetails']['style'];
	} else {
		if(isset($_SESSION['gamecp']['userinfo']) && $_SESSION['gamecp']['userinfo']['theme']) $TEMPLATE = $_SESSION['gamecp']['userinfo']['theme'];
		if(isset($_SESSION['gamecp']['userinfo']) && $_SESSION['gamecp']['userinfo']['style']) $STYLESHEET = $_SESSION['gamecp']['userinfo']['style'];
	}

	$template = $url. "/includes/template/" .$TEMPLATE; 
	$sessionTimeout = sessionTimeout;


/* booo */
	if(!empty($_GET)) extract($_GET, EXTR_SKIP);
	if(!empty($_POST)) extract($_POST, EXTR_SKIP);



/* new session forcing */
if(!isset($orderPage) && isset($sessionTimeout) && $sessionTimeout > "0"){
	if(ini_get("session.gc_maxlifetime") > "12000000") ini_set("session.gc_maxlifetime", $sessionTimeout);
	if(isset($_SESSION['gamecp']['security']['timeout'])) {
		$session_life = time() - $_SESSION['gamecp']['security']['timeout'];
		if($session_life > $sessionTimeout){ 
			if(isset($_SESSION['gamecp'])) unset($_SESSION['gamecp']);
			header("Location: $url?mode=logout");
		}
	}
	$_SESSION['gamecp']['security']['timeout'] = time();
}



/* redefine session id for scripts that are confused */
if(isset($_SESSION['gamecp']['userinfo']['id'])) {
	$id		= $_SESSION['gamecp']['userinfo']['id'];
	$cid	= $_SESSION['gamecp']['userinfo']['id'];	
	$ucid	= $_SESSION['gamecp']['userinfo']['id'];

}



/* validate smarty has a writeable dir */
$template_dir = path . '/includes/cache/';
if (!is_writable($template_dir)) die("Smartys compiled templates directory is not writable! $template_dir");


/* Roll out everything else! */
require_once(path.'/includes/smarty/libs/Smarty.class.php');
require_once(path .'/includes/core/includes/gamecp/smarty.inc.php');
$smarty->assign("stylesheet", $STYLESHEET);


require_once(path.'/includes/core/classes/gamecp/class.inc.php');
$GameCP = new GameCP();

require_once(path.'/includes/core/classes/gamecp/event.inc.php');
$Event = new Event();

$smarty->assign("GameCP", $GameCP);

if(debugging == 0) {
	error_reporting(0);
} else error_reporting(E_ALL | E_STRICT);


/* copyright removal should be purchased, removing manually is illegal */
if(is_file("includes/copyright.php") || (isset($_SESSION['gamecp']['copyright']) && $_SESSION['gamecp']['copyright'] == "1")){
	$smarty->assign('copyrightRemoval', "1");
	$copyrightRemoval=true;
}


/* for security require mbpassword in settings */
if(!mbpassword){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$tmppw=$Panel->RandomPassword();
	sql_query("UPDATE settings SET value='".$tmppw."' WHERE name='mbpassword';") or die(mysql_error());
	define('mbpassword', $tmppw);
	unset($tmppw);
}

/* kick out if maintentance is on */
if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] != "1" && MAINTENANCE == "yes"){
	$smarty->display("portal/maintenance.tpl");
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->Kill();
}

/* kick out sessions with no id or ulevels - helps with bugs when logging out */
if(isset($_SESSION['gamecp']['userinfo'])){
	if($_SESSION['gamecp']['userinfo']['id'] == "" && $_SESSION['gamecp']['userinfo']['ulevel'] == "") $_SESSION['gamecp']=array();

	if(!isset($_SESSION['gamecp']['security']['checkme']['usertime']) || time() > ($_SESSION['gamecp']['security']['checkme']['usertime'] + userrechekcdelay)){
		$_SESSION['gamecp']['security']['checkme']['usertime']=time();

		$usrnfoQ = sql_query($safesql->query("SELECT * FROM users WHERE id = '%i';", array($_SESSION['gamecp']['userinfo']['id']))) or die(mysql_error());     
		$usrnfo = mysql_fetch_array($usrnfoQ);
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->SetUserSession($usrnfo);

		/* check both user & subuser if they have been suspended */
		if(mysql_num_rows($usrnfoQ) == 0 || $_SESSION['gamecp']['userinfo']['active'] != "1"){
			$smarty->display("portal/suspend.tpl");
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->Kill();
		}

		if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes"){
			$activeSql="SELECT active FROM usersubaccounts WHERE name='".$_SESSION['gamecp']['subuser']['name']."' LIMIT 1;";
			$activeCheckQ=sql_query($activeSql, "user active status") or die(mysql_error());
			$activeCheck=mysql_fetch_array($activeCheckQ);

			if($activeCheck['active'] != "1"){
				$smarty->display("portal/suspend.tpl");
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->Kill();
			}
		}

	}

}

/* simple user agent validation */
if(!isset($orderPage)){
	if(isset($_SERVER['HTTP_USER_AGENT'])){
		$security_string = md5("GCOSEC".$_SERVER['HTTP_USER_AGENT']."URITY101");
		if (isset($_SESSION['gamecp']['security']['HTTP_USER_AGENT'])){
			if ($_SESSION['gamecp']['security']['HTTP_USER_AGENT'] != $security_string){
				$smarty->assign("error", "A session security risk has been detected, you have been logged out. (1)");
				$smarty->display("portal/error.tpl");
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->Kill();
			}
		} else $_SESSION['gamecp']['security']['HTTP_USER_AGENT'] = $security_string;
	}

	if(isset($_SESSION['gamecp']['userinfo']['id']) && ($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4")){
		$smarty->assign("mainadmin", $_SESSION['gamecp']['user']['mainadmin']); 
		$smarty->assign("advedit", $_SESSION['gamecp']['user']['advedit']); 
	}
}


/* url, path & ip validation */
if(
	isset($_SESSION['gamecp']['security']['key']) && (
		$_SESSION['gamecp']['security']['key']!=$GameCP->GetSessionKey() || 
		$_SESSION['gamecp']['security']['path']!= path || 
		$_SESSION['gamecp']['security']['url']!= url
	)
){
	$smarty->assign("error", "A session security risk has been detected, you have been logged out. (2)");
	$smarty->display("portal/error.tpl");
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->Kill();
}


/* file manage download - here because needs to be above headers */
if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && isset($mode) && $mode == "download" && preg_match("/files.php/i", $_SERVER['PHP_SELF'])) { 
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "5"){ 
		$fname=$_SESSION['gamecp']['fileuser'];
		$fgame=$_SESSION['gamecp']['filegame'];
		$sid=$_SESSION['gamecp']['filesid'];
		$fcid = $_SESSION['gamecp']['filecid'];
	} else { 
		$fname = $_SESSION['gamecp']['userinfo']['username'];
		$fcid = $_SESSION['gamecp']['userinfo']['id'];
		if(isset($_POST['sid'])) { 
			$sid= $_POST['sid']; 
		} else $sid = $_SESSION['gamecp']['filesid']; 
	}

	$GameCP->loadIncludes("user");
	$User=new User();
	$fpass = $User->Password($fcid);

	if ($afile) {
		$local_file = $upldir.$afile;
		$path=$_SESSION['gamecp']['fmpath'];
		$path = explode("/home/$fname/", $path);
		$path = $path[1];
		$afile = $path. "/" . $afile;
		$afile=str_replace(":_:", " ", $afile);

		if($fname && $fpass && $sid && $afile){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$serverInfo=$Panel->GetServer($sid);
			if($serverInfo['alias']) $sid=$serverInfo['alias'];

			header("location: ftp://".$fname.":".$fpass."@".$sid."/".$afile);

		} else echo "Missing information for ftpd.";
	} else echo "File not selected."; 
}

if(isset($_REQUEST['mode'])) $_REQUEST['mode']=$GameCP->whitelist($_REQUEST['mode']);

/* include the header */
if(@$noheader == false) require_once(path .'/includes/core/editable/header.inc.php');

require_once("hooks.inc.php");
run_hook("page_load");


?>