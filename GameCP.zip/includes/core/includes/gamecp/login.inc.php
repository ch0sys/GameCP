<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


if(!defined('_GAMECP_')) die("Invalid access");


/* login cookies */
if (isset($_REQUEST["lang"])){ 
	$lang=$_REQUEST['lang']; 
	@setcookie("gcplang", $lang, time()+900000, '', '', '', true); 
}

/* whmcs over-ride */
if(isset($_REQUEST['username']) && isset($_REQUEST['password'])){
	$_REQUEST['sublogin']=true;
	$_REQUEST['user']=$_REQUEST['username'];
	$_REQUEST['pass']=$_REQUEST['password'];
}

/* validate login */
if(isset($_REQUEST['sublogin'])){
   /* Check that all fields were typed in */
   if(!$_REQUEST['user'] || !$_REQUEST['pass']){
 		$smarty->assign("error", "You didn't fill in a required field.");
		$smarty->display("portal/error.tpl");
		exit;
	}

	if(!gcplickey){
		$machineTotal = sql_query("SELECT * FROM `servers`") or die(mysql_error());
		$userTotal = sql_query("SELECT * FROM `users` WHERE userlevel !='1'") or die(mysql_error());
		if(mysql_num_rows($machineTotal) > 0 || mysql_num_rows($userTotal) > 0) $GameCP->Error("A key is required to manage services with this software.");
	} else {
		$checkkey=explode('-', gcplickey);
		if(!isset($checkkey[0]) || ($checkkey[0] != 'Full' && $checkkey[0] != 'Basic' && $checkkey[0] != 'Trial')) $GameCP->Error("A valid key is required to manage services with this software. A key must include Trial-, Full- or Basic-.");
	}

   $_REQUEST['user'] = trim($_REQUEST['user']);

	/* admins can switch to users now and go back */
	if(isset($_REQUEST['switchto']) && isset($_SESSION['gamecp']['userinfo']['ulevel']) && $_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
		$_SESSION['switch_gamecp']=$_SESSION['gamecp'];
		setcookie("gcppage", $url."/system", time()+9000);
	}

	/* Checks that username is in database and password is correct */

	if(isset($_REQUEST['userlogin'])){
		$login_type=false;
	} else $login_type=true;

	$GameCP->loadIncludes("user");
	$User=new User();
	$result = $GameCP->Login($_REQUEST['user'], $_REQUEST['pass'], false, $login_type);

	/* Check error codes */
	if($result == 1 || $result == 2 || $result == 3){
	   // login wrong
		$smarty->assign("error", $result);
		$smarty->display("portal/error.tpl");
		exit;
	}else if($result == 0){
		// reset session for this user 
		$GameCP->LoginSession();

		$username = $_REQUEST['user'];
		$password = $_REQUEST['pass'];
		$_SESSION['gamecp']['user']['password'] = $_REQUEST['pass'];

		@setcookie("gcpemail", $_REQUEST['user'], time()+900000, '', '', '', true); 		

		/* grab sub-user profile details */
		if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes"){
			/* sub users */
			$maincidQ=sql_query($safesql->query("SELECT cid, id, perms, files, name, games, active FROM usersubaccounts WHERE email='%s';", array($username))) or die(mysql_error()); 
			$subUserInfo=mysql_fetch_array($maincidQ);
			$subid=$subUserInfo['id'];
			$maincid=$subUserInfo['cid'];

			$usrnfo = sql_query($safesql->query("SELECT * FROM users WHERE id='%i';", array($maincid))) or die(mysql_error());     
			$usrnfo = mysql_fetch_assoc($usrnfo);

			$usrnfo['active']=$subUserInfo['active'];

			$_SESSION['gamecp']['subuser']['id'] = $subid;
			
			$_SESSION['gamecp']['subuser']['files'] = unserialize($subUserInfo['files']);
			$_SESSION['gamecp']['subuser']['perms'] = unserialize($subUserInfo['perms']);
			$_SESSION['gamecp']['subuser']['games'] = unserialize($subUserInfo['games']);
			if(!is_array($_SESSION['gamecp']['subuser']['perms']))$_SESSION['gamecp']['subuser']['perms']=array();
			$_SESSION['gamecp']['subuser']['name'] = $subUserInfo['name'];
			if(in_array('5', $_SESSION['gamecp']['subuser']['perms'])) $_SESSION['gamecp']['userinfo']['aiManageFiles'] = "pergame";

		} else {
		/* grab user profile details */
			$usrnfo = sql_query($safesql->query("SELECT * FROM users WHERE email = '%s';", array($username))) or die(mysql_error());     
			$usrnfo = mysql_fetch_assoc($usrnfo);
		}

		/* help prevent session hijacks */
		@session_regenerate_id();

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->SetUserSession($usrnfo);

		$isactiveuser = $usrnfo['active'];
		if(isset($usrnfo['demo']) && $usrnfo['demo'] == "1")$_SESSION['demo']='yes';
		if(isset($lang)){
			$_SESSION['userlang'] = $lang;
		} else if(isset($usrnfo['lang'])) $_SESSION['userlang']=$usrnfo['lang'];

		$Event->EventLogAdd($usrnfo['name'], "User ". $usrnfo['name']. " has logged in at ". time());

		if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
			if($usrnfo['mainadmin'] == '1'){
				$mainadmin=true;
			} else $mainadmin=false;
			if($usrnfo['advedit'] == '1'){
				$advedit=true;
			} else $advedit=false;
			$_SESSION['gamecp']['user']['mainadmin']=$mainadmin;
			$_SESSION['gamecp']['user']['advedit']=$advedit;

			if(!is_array($GameCP->GetLogin())){
			    return NULL;
			}

		} else if(MAINTENANCE == "yes"){
			$smarty->display("portal/maintenance.tpl");
			$Panel->Kill();
		}

		// user has been suspended 
		if($isactiveuser == "0"){
			sql_query($safesql->query("DELETE FROM `usersonline` WHERE ip = '%s';", array($_SERVER['REMOTE_ADDR'])))or die(mysql_error()); 
			$smarty->display("portal/suspend.tpl");
			$Panel->Kill();
		}

		if(isset($_COOKIE["gamecp-redirect"])){
			switch($GameCP->whitelist($_COOKIE["gamecp-redirect"])){
				case "Dashboard":
					header("location: $url/system/");
				break;
				case "TT":
					header("location: $url/system/tt.php?mode=view");
				break;
				case "NewTT":
					header("location: $url/system/tt.php?mode=new");
				break;
				default:
					header("location: $url/system/");
			}
		//} elseif(isset($_COOKIE['gcppage'])){
		//	header("location: ".$_COOKIE['gcppage']);
		} else {
			if($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
				header("location: $url/system/");
			} else header("location: $url/manage/");
		}

		return;
	}else{
		// invalid result
		$smarty->assign("error", "Invalid login result");
		$smarty->display("portal/error.tpl");
	}
}


?>