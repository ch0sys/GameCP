<?php
/* hooks! */
function add_hook($loc, $function){
    global $hooks;
    
    if(isset($hooks[$loc]) && is_array($hooks[$loc])){
        $hooks[$loc][count($hooks[$loc])] = $function;
    }else{
        $hooks[$loc][0] = $function;
    }
}

function check_hooks($loc){
    global $hooks;
    $return = array();

    if(isset($hooks[$loc]) && is_array($hooks[$loc]))    {
        foreach($hooks[$loc] as $key => $value)       {
            if(function_exists($value))          {
                $return[] = $value;
            }
        }
        return $return;
    }
    return false;
}
function run_hook($loc, $code=false){
	$hook=check_hooks($loc);
	if(is_array($hook) && count($hook)>0){
		foreach($hook as $key => $value){
			$value($code);
		}
	}
}

$dir=path."/includes/hooks/";
if ( ( $dh = opendir( $dir ) ) !== false ){
    while ( ( $entry = readdir( $dh ) ) !== false ){
        if ( $entry != "." && $entry != ".." ){
            if ( is_file( $dir.$entry ) ){
				$path_info = pathinfo($dir.$entry);
				 if($path_info['extension'] == "php") require( $dir.$entry );
            }
        }
    }
}
closedir( $dh );


?>