<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

if(!defined('_GAMECP_')) die("Invalid access");


if(!is_dir(path."/includes/template/" . $TEMPLATE . "/smarty")) $TEMPLATE="x";

$compileDir=path.'/includes/cache/'. $TEMPLATE;
if(!@dir($compileDir)) mkdir($compileDir);

$smarty = new Smarty();
$smarty->config_dir = path.'/includes/smarty/';
$smarty->plugins_dir = path.'/includes/smarty/libs/plugins/';
$smarty->template_dir = array(path.'/includes/template/hooks/', path.'/includes/template/'. $TEMPLATE . '/smarty/', path.'/includes/template/default/smarty/');
$smarty->compile_dir = $compileDir;
$smarty->compile_check = false;
$smarty->debugging = false;
$smarty->force_compile = false;
$smarty->caching = false;
$smarty->config_booleanize = false;
$smarty->cache_lifetime = 120;
$smarty->error_reporting = E_ALL & ~E_NOTICE;

/*
$smarty->security = TRUE; 
$smarty->secure_dir[] = $smarty->template_dir; 
$smarty->secure_dir[] = path.'/includes/lang'; 
*/


$langIni=path.'/includes/lang/'.$lang. ".ini";

if(is_file($langIni)){
	$langConf=$langIni;
} else $langConf=path."/includes/lang/en.ini";
$smarty->configLoad($langConf, $lang);

extract($smarty->getConfigVars());
$smarty->default_modifiers = array('escape:"html":"'.$LNG_CHARSET.'"');

$smarty->assign("lang", $lang);

/* mobile detection */
require_once (path.'/includes/core/classes/mobile/Mobile_Detect.php');
$detect = new Mobile_Detect;
$deviceType = ($detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'phone') : 'computer');
$smarty->assign("deviceType", $deviceType);
//$smarty->assign("deviceType", 'mobile');

/* SESSION REDEFINES SMARTY QUERYS */

if(isset($_SESSION['gamecp']['userinfo']['id'])) $smarty->assign("sessionUserID", $_SESSION['gamecp']['userinfo']['id']);
if(isset($_SESSION['gamecp']['userinfo']['username'])) $smarty->assign("sessionUser", $_SESSION['gamecp']['userinfo']['username']);
if(isset($_SESSION['gamecp']['userinfo']['ulevel'])) $smarty->assign("sessionUserLevel", $_SESSION['gamecp']['userinfo']['ulevel']);
if(isset($_SESSION['gamecp']['subaccount'])) $smarty->assign("sessionSubAccount", $_SESSION['gamecp']['subaccount']);
if(isset($_SESSION['gamecp']['basic'])) $smarty->assign("sessionClan", $_SESSION['gamecp']['basic']);

/* END SESSION SMARTY QUERYS */

/* SETTINGS DEFINE SMARTY QUERYS */
 foreach ($GameCPSettings as $row) {
	$smarty->assign($row['name'], $row['value']);
 }
 unset($GameCPSettings);
/* END SETTINGS DEFINE SMARTY QUERYS */

/* MISC DEFINES SMARTY QUERYS */
$smarty->assign("template", $template);
if(isset($gcpVersion)) $smarty->assign("gcpVersion", $gcpVersion);
$smarty->assign("dateConfig", '%m/%d %H:%M %a');
$smarty->assign("dateOnlyConfig", '%m/%d');



if(isset($billingPage) && $billingPage==true) $smarty->assign("billingPage", "true");

/* ENDMISC DEFINES SMARTY QUERYS */


/* DISPLAY NAVIGATION SMARTY QUERYS */
if(!isset($orderPage) && isset($_SESSION['gamecp']['userinfo'])){


	if(isset($_SESSION['gamecp']['userinfo']['ulevel']) && ($_SESSION['gamecp']['userinfo']['ulevel'] == "10" || $_SESSION['gamecp']['userinfo']['ulevel'] == "0")) {
		if(isset($_SESSION['gamecp']['userinfo']['id'])){

			if(isset($_SESSION['gamecp']['userinfo']['showGames']) && $_SESSION['gamecp']['userinfo']['showGames'] == "yes"){ 
				$smarty->assign("showGames", "yes");
				$smarty->assign("userHasGames", $_SESSION['gamecp']['userinfo']['userHasGames']);
				$smarty->assign("userHasServices", $_SESSION['gamecp']['userinfo']['userHasServices']);
			} else if(!isset($_SESSION['gamecp']['userinfo']['showGames'])){

				$displayGameManagement = sql_query("SELECT id FROM usergames WHERE cid = '".$_SESSION['gamecp']['userinfo']['id']."'");
				$gameRows=mysql_num_rows($displayGameManagement);

				$displayGameManagementQ = sql_query("SELECT id FROM usergames WHERE cid = '".$_SESSION['gamecp']['userinfo']['id']."'");
				$serviceRows=mysql_num_rows($displayGameManagementQ);
				$smarty->assign("userHasServices", $serviceRows);
				$_SESSION['gamecp']['userinfo']['userHasServices']=$serviceRows;

				if($gameRows > "0"){ 
					$smarty->assign("showGames", "yes");
					$smarty->assign("userHasGames", $gameRows);
					$_SESSION['gamecp']['userinfo']['showGames']="yes";
					$_SESSION['gamecp']['userinfo']['userHasGames']=$gameRows;
				}
			}


			if(isset($_SESSION['gamecp']['userinfo']['showBills']) && $_SESSION['gamecp']['userinfo']['showBills'] == "yes"){ 
				$smarty->assign("showBills", "yes");
			} else if(!isset($_SESSION['gamecp']['userinfo']['showBills'])){
				$displayBillingSystem = sql_query("SELECT id FROM billing WHERE cid = '".$_SESSION['gamecp']['userinfo']['id']."'");
				if(mysql_num_rows($displayBillingSystem) != "0"){ 
					$smarty->assign("showBills", "yes");
					$_SESSION['gamecp']['userinfo']['showBills']="yes";
				} else $_SESSION['gamecp']['userinfo']['showBills']="no";
			}


			if(isset($_SESSION['gamecp']['userinfo']['aiManageFiles']) && $_SESSION['gamecp']['userinfo']['aiManageFiles'] == "yes" || isset($_SESSION['gamecp']['userinfo']['aiManageFiles']) && $_SESSION['gamecp']['userinfo']['aiManageFiles'] == "pergame"){ 
				$smarty->assign("aiManageFiles", $_SESSION['gamecp']['userinfo']['aiManageFiles']);
			} else if(!isset($_SESSION['gamecp']['userinfo']['aiManageFiles'])){
				if($_SESSION['gamecp']['userinfo']['filemanager'] == "0"){
					$smarty->assign("aiManageFiles", "yes");
					$_SESSION['gamecp']['userinfo']['aiManageFiles']="yes";
				}elseif($_SESSION['gamecp']['userinfo']['filemanager'] == "2"){
					$smarty->assign("aiManageFiles", "pergame");
					$_SESSION['gamecp']['userinfo']['aiManageFiles']="pergame";

				}
			}
		}
	}

	/* END DISPLAY NAVIGATION SMARTY QUERYS */
	$aiPlayerGraphs="";
	if(isset($_SESSION['gamecp']['userinfo']['aiPlayerGraphs']) && $_SESSION['gamecp']['userinfo']['aiPlayerGraphs'] == "yes"){
		$aiPlayerGraphs = "yes";
	}elseif(!isset($_SESSION['gamecp']['userinfo']['aiPlayerGraphs'])){
		if(is_file(path."/includes/stats/graph.rrd")){
			$aiPlayerGraphs="yes";
		}else $aiPlayerGraphs="";
		
		$_SESSION['gamecp']['userinfo']['aiPlayerGraphs']=$aiPlayerGraphs;
	}
}


function Smarty_PageControl($sql, $formName, $formField, $limit2=FALSE){
	global $GameCP, $LNG_NEXT, $LNG_PREV, $limit, $smarty, $GameCP;
	require_once(path.'/includes/smarty/libs/SmartyPaginate.class.php');


	$formName=$GameCP->whitelist($formName);
	$formField=$GameCP->whitelist($formField);

	if(isset($_REQUEST[$formName])) $_REQUEST[$formName]=$GameCP->whitelist($_REQUEST[$formName], 'int') ;
	SmartyPaginate::connect($formName);
	SmartyPaginate::setUrlVar($formName, $formName);
	if(!isset($_REQUEST[$formName]) || (isset($_REQUEST[$formName]) && (empty($_REQUEST[$formName]) || $_REQUEST[$formName] == "0" || $_REQUEST[$formName] == "" ))){
		SmartyPaginate::setCurrentItem('1', $formName);
	} else SmartyPaginate::setCurrentItem($_REQUEST[$formName], $formName);

	SmartyPaginate::setNextText($LNG_NEXT, $formName);
	SmartyPaginate::setPrevText($LNG_PREV, $formName);
	if($limit) SmartyPaginate::setLimit($limit, $formName);
	if($limit2) SmartyPaginate::setLimit($limit2, $formName);

	if(isset($_REQUEST['initial'])){
		$url=$_SERVER['PHP_SELF'].'?initial='.$GameCP->whitelist($_REQUEST['initial'][0]);
	}elseif(isset($_REQUEST['status'])){
		$url=$_SERVER['PHP_SELF'].'?status='.$GameCP->whitelist($_REQUEST['status']);
	}elseif(isset($_REQUEST['mode'])){
		$url=$_SERVER['PHP_SELF'].'?mode='.$GameCP->whitelist($_REQUEST['mode']);
	}elseif(isset($_REQUEST['view']) && $_REQUEST['view'] != "all"){
		$url=$_SERVER['PHP_SELF'].'?view='.$GameCP->whitelist($_REQUEST['view']);
	}else $url=$_SERVER['PHP_SELF'];


	if(isset($_REQUEST['noheader']))$url.="&noheader=true";
	if(isset($_REQUEST['cat']))$url.="&cat=".$_REQUEST['cat'];
	if(isset($_REQUEST['pid']))$url.="&pid=".$_REQUEST['pid'];
	if(isset($_REQUEST['gmid']))$url.="&gmid=".$_REQUEST['gmid'];
	if(isset($_REQUEST['gmida']))$url.="&gmida=".$_REQUEST['gmida'];
	if(isset($_REQUEST['packagePubPriv']))$url.="&packagePubPriv=".$_REQUEST['packagePubPriv'];

	SmartyPaginate::setUrl($url, $formName);

	if((isset($_REQUEST['view']) && $_REQUEST['view'] == "all") || (isset($_REQUEST['show']) && $_REQUEST['show'] == "all")){ 
		$sqlLimited=$sql; 
	} else $sqlLimited = $sql . " LIMIT ".SmartyPaginate::getCurrentIndex($formName).", ".SmartyPaginate::getLimit($formName);
	
	$result = mysql_query($sqlLimited) or die(mysql_error());
	$rowsQ=sql_query("SELECT FOUND_ROWS() as total");
	$rows=mysql_fetch_array($rowsQ);

	SmartyPaginate::setTotal($rows['total'], $formName);
	SmartyPaginate::assign($smarty, $formField, $formName);

	return $result;
}

?>