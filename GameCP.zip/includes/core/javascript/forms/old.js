function checkAll() {
  for (var i = 0; i < document.sci.elements.length; i++) {
    if(document.sci.elements[i].type == 'checkbox'){
      document.sci.elements[i].checked = !(document.sci.elements[i].checked);
    }
  }
}
function checkAll2() {
  for (var i = 0; i < document.sci2.elements.length; i++) {
    if(document.sci2.elements[i].type == 'checkbox'){
      document.sci2.elements[i].checked = !(document.sci2.elements[i].checked);
    }
  }
}
function unCheckAll() {
  for (var i = 0; i < document.sci.elements.length; i++) {
    if(document.sci.elements[i].type == 'checkbox'){
      document.sci.elements[i].checked = 0
    }
  }
}
function unCheckAll2() {
  for (var i = 0; i < document.sci2.elements.length; i++) {
    if(document.sci2.elements[i].type == 'checkbox'){
      document.sci2.elements[i].checked = 0
    }
  }
}
function checkAllTickets() {
  for (var i = 0; i < document.tickets.elements.length; i++) {
	if(document.tickets.elements[i].type == 'checkbox'){
	  document.tickets.elements[i].checked = !(document.tickets.elements[i].checked);
	}
  }
}
function checkAllUsers() {
  for (var i = 0; i < document.userlistform.elements.length; i++) {
    if(document.userlistform.elements[i].type == 'checkbox'){
      document.userlistform.elements[i].checked = !(document.userlistform.elements[i].checked);
    }
  }
}
function checkPw(form) {
	pw1 = form.pass1.value;
	pw2 = form.pass.value;

	if (pw1 != pw2) {
		alert ("Please enter the same password twice.")
		return false;
	}
	if (pw1 == "") {
		alert ("You must enter a password.")
		return false;
	}
	else return true;
}
function checkResult2(form) {
	opt = form.opt.value;



	uid = form.uid.value;
		if (opt == "") {
		alert ("Please select an option.")
		return false;
	}
	else 
		if (uid == "") {
		alert ("Please select a user.")
		return false;
	} else if (opt=="delete")
	{


		if(confirm('Are you sure you want to remove?')){
			 form.submit();

		}

	}
	else 
		 form.submit();
}


function checkResult(form) {
	opt = form.opt.value;
	if (opt == "") {
		alert ("Please select an option.")
		return false;
	}
	else 
		 form.submit();
}

/* phazed out in 09 */
function checkIe(){
	var browser=navigator.appName;
	if(browser=="Microsoft Internet Explorer") return true;
	return false;
}
function getElementsByClassName(searchClass, domNode, tagName) {
    if (domNode == null) domNode = document;
    if (tagName == null) tagName = '*';
    var el = new Array();
    var tags = domNode.getElementsByTagName(tagName);
    var tcl = " "+searchClass+" ";
    for(i=0,j=0; i<tags.length; i++) {
        var test = " " + tags[i].className + " ";
        if (test.indexOf(tcl) != -1)
        el[j++] = tags[i];
    }
    return el;
}
/* // phazed out in 09 */


function showexport(div) {
	var id='#export_options' + div;
	var link='#showHideLink' + div;

	if ($(id).is(':visible')) {
		$(id).hide();
		$(link).html('Show');
	} else  {
		$(id).show();
		$(link).html('Hide');
	}
}

function removeInnerHTMLSubUser(divNum){
	$('#'+divNum).remove();
}
function showhidediv(exportID) {
	if ((navigator.userAgent.indexOf("MSIE")!=-1)||(navigator.userAgent.indexOf("MSIE")!=-1)){ 
		var displayStyle = 'inline'; 
	} else {
		var displayStyle = 'table'; 
	}	

	var exportOptions = $(exportID);
	if (exportOptions.style.display == displayStyle) {		
		exportOptions.style.display = 'none';
	} else {		
		exportOptions.style.display = displayStyle;
	}	
}
