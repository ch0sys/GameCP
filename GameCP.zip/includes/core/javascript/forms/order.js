

function userLoginForm(){
	$('#accinfo, #ordprofile').hide();
	$('#userlogin').show();
	//$('#ordermail, #firstname, #lastname, #password, #password2').removeClass('required reqinput');

	$('.required').addClass('notrequired notreqinput');
	$('.required').removeClass('required reqinput');
	//$('#loginreceiptspace').html($('#receiptStorage').html());
	//$('#receiptStorage').html('')

}
function userLoginFormHide(){
	$('#userlogin').hide();
	$('#accinfo, #ordprofile').show();
	//$('#ordermail, #firstname, #lastname, #password, #password2').addClass('required reqinput');


	$('.notrequired').addClass('required reqinput');
	$('.notrequired').removeClass('required reqinput');
	//$('#receiptStorage').html($('#loginreceiptspace').html());
	//$('#loginreceiptspace').html('')


}
//



function checkClient(client, pass){
	 $.ajax({
	   type: "GET",
	   url: "ajax.php",
	  data: "mode=checkuser&user="+client+"&pass="+pass,
		error: function(msg, textStatus, errorThrown){ 

		} ,
	   beforeSend: function(){
	   },
	   success: function(msg){
		   if(msg == "true"){
			   $('#userlogin').hide();
			   $('#userloggedin').show();
			   $('#userloggeddata').html('You been have logged in as ' +client+'.');
			   $("#password").rules("remove");
			   $("#password2").rules("remove");
			   $("#username").rules("remove");
			   $('#ordprofile, #ordermail, #username, #password, #password2').remove();

		   } else {
				alert('Login failed.');
		   }
	   }
	 });
}





	function findterm(string){
	var separator = ':';
	var stringArray = string.split(separator);
		return stringArray[1];
	}	
	function findterm2(string){
	var separator = ':';
	var stringArray = string.split(separator);
		return stringArray[0];
	}		


function ValidateForm(){
	$("#paymentForm").validate({
		submitHandler: function(form) { 
			if(checkTos()){  
				$('input[type=submit]', form).attr('disabled', 'disabled');
				form.submit();
				$(form).submit(function(){ return false;});
			}
		}
	});
}

function checkTos(){
	if (document.getElementById('tos').checked == false)
	{
		alert('You must agree to the Terms and Conditions of Use before ordering.');
		return false;
	} else return true;
}


var checkObjects	= new Array();
var errors		= "";
var returnVal		= false;
var language		= new Array();
language["header"]	= "The following field(s) are required:"
language["start"]	= "";
language["field"]	= " - ";
language["require"]	= " is required";
language["min"]		= " and must have at least ";
language["max"]		= " and must not have more than ";
language["minmax"]	= " and no more than ";
language["chars"]	= " characters";
language["num"]		= " and must contain a number";
language["email"]	= " must contain a valid e-mail address";

function define(n, type, HTMLname, min, max, d) {
var p;
var i;
var x;
if (!d) d = document;
if ((p=n.indexOf("?"))>0&&parent.frames.length) {
d = parent.frames[n.substring(p+1)].document;
n = n.substring(0,p);
}
if (!(x = d[n]) && d.all) x = d.all[n];
for (i = 0; !x && i < d.forms.length; i++) {
x = d.forms[i][n];
}
for (i = 0; !x && d.layers && i < d.layers.length; i++) {
x = define(n, type, HTMLname, min, max, d.layers[i].document);
return x;       
}
eval("V_"+n+" = new formResult(x, type, HTMLname, min, max);");
checkObjects[eval(checkObjects.length)] = eval("V_"+n);
}
function formResult(form, type, HTMLname, min, max) {
this.form = form;
this.type = type;
this.HTMLname = HTMLname;
this.min  = min;
this.max  = max;
}
function validate() {
if (checkObjects.length > 0) {
errorObject = "";
for (i = 0; i < checkObjects.length; i++) {
validateObject = new Object();
validateObject.form = checkObjects[i].form;
validateObject.HTMLname = checkObjects[i].HTMLname;
validateObject.val = checkObjects[i].form.value;
validateObject.len = checkObjects[i].form.value.length;
validateObject.min = checkObjects[i].min;
validateObject.max = checkObjects[i].max;
validateObject.type = checkObjects[i].type;
if (validateObject.type == "num" || validateObject.type == "string") {
if ((validateObject.type == "num" && validateObject.len <= 0) || (validateObject.type == "num" && isNaN(validateObject.val))) { errors += language['start'] + language['field'] + validateObject.HTMLname + language['require'] + language['num'] + "\n";
} else if (validateObject.min && validateObject.max && (validateObject.len < validateObject.min || validateObject.len > validateObject.max)) { errors += language['start'] + language['field'] + validateObject.HTMLname + language['require'] + language['min'] + validateObject.min + language['minmax'] + validateObject.max+language['chars'] + "\n";
} else if (validateObject.min && !validateObject.max && (validateObject.len < validateObject.min)) { errors += language['start'] + language['field'] + validateObject.HTMLname + language['require'] + language['min'] + validateObject.min + language['chars'] + "\n";
} else if (validateObject.max && !validateObject.min &&(validateObject.len > validateObject.max)) { errors += language['start'] + language['field'] + validateObject.HTMLname + language['require'] + language['max'] + validateObject.max + language['chars'] + "\n";
} else if (!validateObject.min && !validateObject.max && validateObject.len <= 0) { errors += language['start'] + language['field'] + validateObject.HTMLname + language['require'] + "\n";
   }
} else if(validateObject.type == "email") {
if ((validateObject.val.indexOf("@") == -1) || (validateObject.val.charAt(0) == ".") || (validateObject.val.charAt(0) == "@") || (validateObject.len < 6) || (validateObject.val.indexOf(".") == -1) || (validateObject.val.charAt(validateObject.val.indexOf("@")+1) == ".") || (validateObject.val.charAt(validateObject.val.indexOf("@")-1) == ".")) { errors += language['start'] + language['field'] + validateObject.HTMLname + language['email'] + "\n"; }
      }
   }
}
if (errors) {
alert(language["header"].concat("\n" + errors));
errors = "";
returnVal = false;
} else {
returnVal = true;
   }
}






	function checkCheckBox(f){
		if (f.tos.checked == false )
		{
			alert('You must agree to the Terms and Conditions of Use.');
			return false;
		}else
			return true;


	}

$(window).load(function() {
	$(".numericonly").keydown(function (event) { 
	if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) // 0-9 or numpad 0-9 
	{ 
	// check textbox value now and tab over if necessary 
	} 
	else if (event.keyCode != 8 && event.keyCode != 46 && event.keyCode != 37 && event.keyCode != 39) // not esc, del, left or right 
	{ 
	event.preventDefault(); 
	} 
	// else the key should be handled normally 
	}); 
	}); 
