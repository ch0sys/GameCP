/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2008 All Rights Reserved.	
`	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your system.
	
	http://gamecp.com/terms.php

	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


function sshTerminal(sid, url, input, console){
	if(!sid){
	   $('.terminalwindow').append("<b>Missing server id, select a machine first.</b> <br>");
	   return false
	}
	 $.ajax({
	   type: "GET",
	   url: url+"/includes/process.php?ajax=true&code="+input+"&sid="+sid,
	   data: "sshTerminal=true",
	   beforeSend: function(){
		   $('#termin').val('');
			$('#termin').prop("disabled", true); 
			$('#loadingdiv').show();
	   },
	   success: function(msg){
		   	var sshdata=msg.split(":_:");
			$('#termin').removeAttr("disabled"); 
			$('#loadingdiv').hide();

			$('.terminalwindow').append("<b>["+sshdata[0]+" "+sshdata[1]+"]</b> "+input+"<br>");
			if(sshdata[2]) $('.terminalwindow').append(sshdata[2]+"<br>");
			$('.terminalwindow').append("<b>["+sshdata[0]+" "+sshdata[1]+"]</b> <br>");
			$(".terminalwindow").prop({ scrollTop: $(".terminalwindow").prop("scrollHeight") });
			$("#termuser").html(sshdata[0]);

			$.ajax({
				type: "GET",
				url: url+"/includes/process.php?code="+$('.terminalwindow').html()+"&sid="+sid,
				data: "sshTerminalSave=true"
			});
	   }


	 });
}





function checkPromo(url, promo){
	 $.ajax({
	   type: "GET",
	   url: url+"/order/ajax.php?ajax=true&code="+promo,
	   data: "checkPromo=true",
	   beforeSend: function(){
		   $('#promoreply').html();
	   },
	   success: function(msg){

			var promodata=msg.split(":_:");

		if(promodata[0] == "failed"){
				$('#promoreply').html('Invalid code');
				$('#discount').hide();
				$('#totaldue').html(promodata[1]);
				if ($("#recurrtotal").length > 0) $('#recurrtotal').html(promodata[1]);
	   } else if(promodata[0] == "failed2") {
				$('#promoreply').html('A promotion is already used');
	   } else if(promodata[0]) {

				if ($("#recurrtotal").length > 0) $('#recurrtotal').html(promodata[2]);
				$('#totaldue').html(promodata[0]);
				$('#discounttotal').html(promodata[1]);
				$('#discount').show();
				$('#promoreply').html('');

		   }
	   }
	 });
}

function loadServerBoxClient(){
	 $.ajax({
	   type: "GET",
	   url: url+"/includes/process.php?ajax=true",
	   data: "showServerBox=true",
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,
	   beforeSend: function(){
		$('#serverBoxUpdatediv').parent().fadeIn();
	   },
	   success: function(msg){
		   $('#serverBoxUpdatediv').html(msg);
	   }
	 });
}
function loadMapImage(ugid, map, updatediv){
	 $.ajax({
	   type: "GET",
	   url: url+"/includes/process.php",
	   data: "ajax=true&managemapload=true&ugid="+ugid+"&map="+map,
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,
	   success: function(msg){
		  if(msg){
			  $('#'+updatediv).html("<img src=\""+url+"/"+msg+"\" width=\"150\">");
		  } else $('#'+updatediv).html('');
	   }
	 });
}


function deleteUserSched(me, id){
	$(me).closest('tr').remove();

	 $.ajax({
	   type: "GET",
	   url: url+"/system/userservices.php",
	   data: "ajax=true&mode=deleteSched&sched_id="+id,
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,
	   success: function(msg){
		  if(msg) $('#ugschedluer').html(msg);
	   }
	 });
}

function saveUserSched(ugid){
	
	var cron=$('#sched_result').val();
	var name=$('#task_name').val();
	var action=$('#task_action').val();
	var task_settings=$('#task_settings').val();

	 $.ajax({
	   type: "GET",
	   url: url+"/system/userservices.php",
	   data: "ajax=true&mode=saveSched&ugid="+ugid+"&cron="+cron+"&name="+name+"&action="+action+"&settings="+task_settings,
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,
	   success: function(msg){
		  if(msg) $('#ugschedluer').html(msg);
			$('#task_name').val('');
			$('#task_action').val('');
			$('#task_settings').val('');
			  
	   }
	 });
}


function varloadPage(load){
	if(load) loadPage=load;
	return loadPage;
}

function ajaxSubmitPage(page, replydiv){
		var io = { 
			//target:        replydiv, 
			beforeSubmit: function() {
				$('input[type=submit]', page).prop('disabled', 'disabled');
				$('input[type=submit]', page).addClass('inputdisabled');
				$('#savingdiv').show();
			},

			success:       function(a) {
				$('html, body').animate({scrollTop:0}, 'slow'); 
				$('#savingdiv').hide();
				$('input[type=submit]', page).removeAttr('disabled');
				$('input[type=submit]', page).removeClass('inputdisabled');

				if(replydiv) $(replydiv).html(a);

				if('#altsavediv'){
					$('#altsavediv').show();
				} else $('#saveddiv').show();

			   setTimeout(function() {
					if('#altsavediv'){
						$('#altsavediv').fadeOut();
					} else $('#saveddiv').fadeOut();
				}, '7000'); 
			},
			timeout:   '90000'
		}; 
		$(page).ajaxSubmit(io); 
		return false; 
}


function ajaxSubmitLink(page,postdata, replydiv){
	 $.ajax({
	   type: "POST",
	   url: page,
	   data: "ajax=true&"+postdata,
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,
	   beforeSend: function(){
			$('#savingdiv').show();
	   },
	   success: function(msg){
		   if(replydiv) $(replydiv).html(msg);
		   $('#savingdiv').hide();

			if('#altsavediv'){
				//$('html, body').animate({scrollTop:0}, 'slow'); 
				$('#altsavediv').show();
			} else $('#saveddiv').show();

		   setTimeout(function() {
				if('#altsavediv'){
					$('#altsavediv').fadeOut();
				} else $('#saveddiv').fadeOut();
			}, '7000'); 


	   }
	 });
}




function AjaxUpdate(){
	 $.ajax({
	   type: "POST",
	   url: url+'/manage/update.php?ajax=true&mode=run',
	   success: function(msg){
		   $('#updating').hide();

			if(jQuery.trim(msg)){
			   $('#updatediv').html("<h4>"+msg+"</h4><a href=\"?mode=run&ignoreerrors=true\">Force update and ignore errors</a>");
			} else {
				$('#updatediv').html("<h3>Update Complete</h3><input class=\"button\" type=\"submit\" value=\"Continue\" onclick=\"window.location='update.php'\">");
				window.location=url+'/manage/update.php?mode=download';
			}
		}
	 });
}

function loadSaveAfterSubmit(){
	$(document).ready(function() { 
		//$('html, body').animate({scrollTop:0}, 'slow'); 
		$('#altsavediv').show();

	   setTimeout(function() {
			$('#altsavediv').hide();
		}, '7000'); 
	});
}
function ajaxLoadPage(page, updater, loading, reload){
	//if($('#ajaxlog')) $('#ajaxlog').append('ajaxLoadPage for ' +  page + ' reload at ' + reload + '<br>');

	 $.ajax({
	   type: "GET",
	   url: page,
	   data: "ajax=true&noheader=true",
	   beforeSend: function(){
		if(loading == "alt"){
			if(loading)$(updater).html(loadingIcon2);
		} else if(loading)$(updater).html(loadingIcon);
	   },
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,

	   success: function(msg){
			$(updater).hide();

			$(updater).html(msg);

			if(reload && $(updater) && reload_ajax_pages == 'true'){
			   setTimeout(function() {
				if(loading == "alt") loading="";
					ajaxLoadPage(page, updater, loading, reload)
				}, reload); 
			}

			$(updater).show();

			if($('#leftsort').html() || $('#rightsort').html()){
				$('#leftsort .sortableTrigger, #rightsort .sortableTrigger').hover(
					function(){
					   $("#leftsort").sortable('enable');
					   $("#rightsort").sortable('enable');
					},
					function(){
					   $("#leftsort").sortable('disable');
					   $("#rightsort").sortable('disable');
					}
				);
				doMoveItems();
			}
	   }
	 });
}
function ajaxLoadPageStatus(page, updater, loading, reload, cache){
	//if($('#ajaxlog')) $('#ajaxlog').append('ajaxLoadPage for ' +  page + ' reload at ' + reload + '<br>');
	if(cache == "true"){
		cache="&forcecache=true";
		var tmpreload=reload-15000;
	} else {
		var tmpreload=reload;
		cache='';
	}

	 $.ajax({
	   type: "GET",
	   url: page,
	   data: "ajax=true&noheader=true"+cache,
	   beforeSend: function(){
	   },
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,

	   success: function(msg){
		   $(updater).hide();
		   $(updater).html(msg);
		   if(reload && $(updater) && reload_ajax_pages == 'true'){
			   setTimeout(function() {
					if(loading == "alt") loading="";
					ajaxLoadPageStatus(page, updater, loading, reload, false)
				}, tmpreload); 

		   }

		   $(updater).show();
	   }
	 });
}


function removeParents(m){
	var parentEls = $(m).parents()

	.map(function () { 
		if(this.tagName == "DIV"){ 
			var mm=this.id;
			var me=mm.split("_");
			
			if(mm == "serverlistPopin" || mm == "serverlistFilePopin"){
				$('#'+mm).fadeOut();
				$('#'+mm).prop('src', '');
			} else if(me[0] == "sort"){
				if( $('#'+mm) ){
					 $('#'+mm).fadeOut(800, function () {
						$('#'+mm).remove();
						saveSort();
					  });
				}
			}
		}
	});

}

function ajaxLoadConsolePage(page, updater, loading, reload){
	 $.ajax({
	   type: "GET",
	   url: page,
	   data: "ajax=true&noheader=true",
	   beforeSend: function(){
			if(updater == "#screenlog" || updater == "#playersdiv") $(updater+'loading').toggle();
	   },
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #3');
		} ,
	   success: function(msg){
		   $(updater).html(msg);
		   
			if(updater == "#screenlog") {
				if(!$("#screenlog").is(":hover")) $(updater).prop({ scrollTop: $(updater).prop("scrollHeight") });
			}
	
			if(updater == "#screenlog" || updater == "#playersdiv") $(updater+'loading').hide();
		  
			if(reload){
				if($("#screenlog").css('display') == 'block'){
				   setTimeout(function() {
					  if($("#screenlog").css('display') == 'block') ajaxLoadConsolePage(page, updater, loading, reload)
					}, reload); 
				}
			}
	   }
	 });
}
function loadServerStatus(url, ugid, iteration, first){
	$(window).load(function() {	
		var updatediv=$('#serverStatus'+ugid);
		var delay=iteration*5;
		var finaldelay = '30000' - delay;
		if (updatediv) {
			setTimeout(function() {
				ajaxLoadPageStatus(url+'/includes/serverstatus.php?ugid='+ugid, updatediv, '',finaldelay, first);
			}, delay*30); 
		}
	});
}
function loadServerStatus2(url, ugid, iteration){
	$(window).load(function() {	
		var updatediv=$('#serverStatus'+ugid);
		var delay=iteration*3;
		var finaldelay = '150000' - delay;
		if (updatediv) ajaxLoadPage(url+'/includes/serverstatus.php?alt=true&ugid='+ugid, updatediv, '',finaldelay)
	});
}

function loadVoiceStatus(url, ugid){
	var updatediv=$('#voiceStatus'+ugid);
	if (updatediv) ajaxLoadPage(url+'/includes/serverstatus.php?mode=voice&vid='+ugid, updatediv, '','200000')
}
function showGameOptions(gameid){
	var loadurl=url+'/includes/process.php?showGameOptions=true&gid='+gameid;
	ajaxLoadPage(loadurl, $('#gameOptionsDiv'));
}
function showVoiceOptions(type){
	var loadurl=url+'/includes/process.php?showVoiceOptions=true&type='+type;
	ajaxLoadPage(loadurl, $('#voiceOptionsDiv'));
}
function showBillOptions(type, term,pubpriv){
	if(type){
		var loadurl=url+'/includes/process.php?showBillOptions=true&type='+type+'&packageTerm='+term+'&pubpriv='+pubpriv;
		ajaxLoadPage(loadurl, $('#billOptionsDiv'));
		$('.bill_fee,.bill_gross').hide();
	} else {
		$('.bill_fee,.bill_gross').show();
		$('#billOptionsDiv').html('');
	}

}

function removeCronEntry(cronid){
	 $.ajax({
	   type: "GET",
	   url: url+"/manage/schedule.php",
	   data: "ajax=true&mode=remove&cronid="+cronid,
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,
	   success: function(msg){
			$('#altsavediv').show();
			   setTimeout(function() {
					$('#altsavediv').hide();
				}, '7000'); 
				$('#cronrow'+cronid).remove();
	   }
	 });

}
function InstallCron(sid){
	 $.ajax({
	   type: "POST",
	   url: url+"/manage/machines.php",
	   data: "ajax=true&mode=installcron&msid="+sid,
	   success: function(msg){
			$('#altsavediv').show();
			   setTimeout(function() {
					$('#altsavediv').hide();
				}, '7000'); 
	   }
	 });

}
function UpdateFTPD(sid){
	 $.ajax({
	   type: "POST",
	   url: url+"/manage/machines.php",
	   data: "ajax=true&mode=updateftpd&msid="+sid,
	   success: function(msg){
			$('#altsavediv').show();
			   setTimeout(function() {
					$('#altsavediv').hide();
				}, '7000'); 
	   }
	 });

}





function UpdateRemote(sid){
	 $.ajax({
	   type: "POST",
	   url: url+"/manage/machines.php",
	   data: "ajax=true&mode=updatebackend&msid="+sid,
	   success: function(msg){
			$('#altsavediv').show();
			   setTimeout(function() {
					$('#altsavediv').hide();
				}, '7000'); 
	   }
	 });

}

function UpdateStatus(updater, loading, reload, ugid, showlog, pagett){
	page=url+'/system/userservices.php?mode=edit2&opt=cmdupdatestatus&noheader=true&ggid='+ugid+'&showlog='+showlog;
	//if($('#ajaxlog')) $('#ajaxlog').append('ajaxLoadPage for ' +  page + ' reload at ' + reload + '<br>');

	 $.ajax({
	   type: "GET",
	   url: page,
	   data: "ajax=true&noheader=true",
	   beforeSend: function(){
		if(loading == "alt"){
			if(loading)$(updater).html(loadingIcon2);
		} else if(loading)$(updater).html(loadingIcon);
	   },
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,

	   success: function(msg){
		  // $(updater).hide();
		   if(msg == "Update completed."){
			   if(pagett == "serverlist"){
					$(updater).html(msg);
					$('#usergamerow'+ugid).removeClass('blue yellow green red orange');

			   } else {

					$('#movestatushead, #loadingbars'+ugid).hide();
					//$('#logresult', '#logresult'+ugid).html($('#logarea').html());
					//$(updater).html('');
					$('#logresult, #movedone, #wrapcontrols').show();

					if(pagett == "ugedit"){
						window.location=url+'/system/userservices.php?mode=edit2&opt=edit&ggid='+ugid;
					}
			   }
			
		   
		   }else{
				
			  if(msg) $(updater).html(msg);

			   if(reload &&  $(updater)){
				   setTimeout(function() {
						if(loading == "alt") loading="";
						UpdateStatus(updater, loading, reload, ugid, showlog, pagett);
					}, reload); 

			   }
		   }

		$(updater).show();
		if(showlog == "true")$(window).scrollTop($(document).height());
	   }
	 });
}

function UpdateSteamCMDStatus(updater, loading, reload, ugid, showlog){
	page=url+'/manage/machines.php?mode=steamstatus&mid='+ugid+'&showlog='+showlog;
	//if($('#ajaxlog')) $('#ajaxlog').append('ajaxLoadPage for ' +  page + ' reload at ' + reload + '<br>');

	 $.ajax({
	   type: "GET",
	   url: page,
	   data: "ajax=true&noheader=true",
	   beforeSend: function(){
		if(loading == "alt"){
			if(loading)$(updater).html(loadingIcon2);
		} else if(loading)$(updater).html(loadingIcon);
	   },
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,

	   success: function(msg){
		   if(msg == "Update completed."){
				$('#movestatushead, #loadingbars'+ugid).hide();
				$('#logresult, #movedone, #wrapcontrols').show();
		   }else{
				
			  if(msg) $(updater).html(msg);

			   if(reload &&  $(updater)){
				   setTimeout(function() {
						if(loading == "alt") loading="";
						UpdateSteamCMDStatus(updater, loading, reload, ugid, showlog);
					}, reload); 

			   }
		   }

		$(updater).show();
		if(showlog == "true")$(window).scrollTop($(document).height());
	   }
	 });
}



function CheckInstallStatus(ugid, divid, a){

	 $.ajax({
	   type: "POST",
	   url: url+"/includes/process.php",
	   data: "ajax=true&checkServerStatus=true&ugid="+ugid,
	   success: function(msg){
		   if(msg == "") $(divid).html(loadingIcon2);
		   if(msg != "ok" && msg != ""){ 
			   //alert(msg) 
			   alert("There was a problem while starting service #"+ugid);
		   } else if(msg == "ok") {
				$(divid).html("Completed");

				var _timer=setInterval(function(){
					clearInterval(_timer);
					if(a == "alt"){
						window.location=url+'/system/userservices.php?mode=edit2&opt=edit&ggid='+ugid;
					} else window.location.reload();
				},3000);		
		   }
		   setTimeout(function() {
				CheckInstallStatus(ugid, divid, a);
			}, '10000'); 
	   }
	 });

}

