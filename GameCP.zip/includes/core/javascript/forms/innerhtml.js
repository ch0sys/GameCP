/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2008 All Rights Reserved.	
`	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your system.
	
	http://gamecp.com/terms.php

	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

function insertVar(){ var addvalue=$("#newquickmod").val();  $("#quickmods").prepend('<option selected="selected" value="' + addvalue + '">' + addvalue+ '</option>'); }
function removeVar(){ $("#quickmods option:selected").remove(); }
function insertVar2(){ var addvalue=$("#newquickcfg").val(); $("#quickConfig").prepend('<option selected="selected" value="' + addvalue + '">' + addvalue+ '</option>'); }
function removeVar2(){ $("#quickConfig option:selected").remove(); }


function configBuilder(){
	var num = +($("#contentDIVID").val()) + 1;
	$("#contentDIVID").val(num);
	$('#configbuilder').append('<tr class="even"><td>	<input type="button" value="Remove" onclick="$(this).closest(\'tr\').remove();"></td>		<td><input type="text" value="0" name="row['+num+'][rank]" style="width: 30px">		<td><input type="text" name="row['+num+'][name]"></td>		<td><textarea style="height: 24px; width: 200px" cols="4" rows="1" name="row['+num+'][value]"></textarea></td>		<td><input type="text" name="row['+num+'][cvar]" style="width: 100px"></td>		<td><select style="width: 95px" name="row['+num+'][type]"><option value="&nbsp;">&nbsp;</option><option value="multiselect">multiple select</option><option value="select">select</option><option value="radio">radio</option><option value="checkbox">checkbox</option><option value="input">input</option><option value="textarea">textarea</option><option value="quantity">quantity</option><option value="title">title</option><option value="row">blank row</option></select><input type="hidden" value="1" name="row['+num+'][editable]"><input type="hidden" value="0" name="row['+num+'][required]"></td></tr>');
	 $('#bewrap').prop({ scrollTop: $('#bewrap').prop("scrollHeight") });
}

function insertInnerHTML(){
	var ni = $('#contentDIV');
	var num = +($("#contentDIVID").val()) + 1;
	$("#contentDIVID").val(num);
	var divIdName = num;
	var newdiv = document.createElement('div');
	newdiv.setAttribute("id",divIdName);
	newdiv.innerHTML = "<table style='display:none' width=100% cellpadding=0 cellspacing=0 border=0>						<tr><td align=\"right\">Display Name: </td><td><input type=\"text\" name=\"customconf["+divIdName+"][cfgname]\" value=\""+$('#newcfg').val()+"\" style=\"width:100px;\"></td>						<td>&nbsp;</td><td align=\"right\">File Name: </td><td><input type=\"text\" name=\"customconf["+divIdName+"][cfgfile]\" value=\"\" style=\"width:100px;\"></td>						</tr><tr><td align=\"right\" width=\"120\">Linux Config Folder: </td><td><input type=\"text\" name=\"customconf["+divIdName+"][cfgdir]\" value=\"\" style=\"width:180px;\"></td>	<td>&nbsp;</td><td align=\"right\">Windows Config Folder: </td><td><input type=\"text\" name=\"customconf["+divIdName+"][wincfgdir]\" value=\"\" style=\"width:180px;\"></td></tr>											<tr><td align=\"right\" width=\"150\">Auto-install Config: </td>							<td colspan=\"3\"><select name=\"customconf["+divIdName+"][autoinstall]\">				<option value=\"1\">Yes				<option value=\"0\">No			</select>		</td>						</tr>						<tr>								<td colspan=\"5\" align=\"left\" style=\"border-bottom: 1px solid black;\"><b>Config Contents:</b><br>										<textarea name=\"customconf["+divIdName+"][contents]\" cols=\"70\" rows=\"5\" style=\"width:99%; height: 200px;\"></textarea><br>													<a class=\"button\" href=\"javascript:;\" onclick=\"$(\'#"+divIdName+"\').remove();\">Remove</a><br><br></td></tr></table><br>";
	ni.append(newdiv);
	$('#formGames').submit();
	$('#configSettings').show();
}
function insertInnerHTML2(){
	var ni = $('#contentsubDIV');
	var num = +($("#contentsubDIVID").val()) + 1;
	$("#contentsubDIVID").val(num);

	var clon=$('#gameList').clone();
	var divIdName = "my"+num+"Div";
	var newdiv = document.createElement('div');
	newdiv.setAttribute("id",divIdName);
	newdiv.innerHTML = "<table width=100% cellpadding=0 cellspacing=2 border=0>	<tr>		<td align=\"right\">Game: </td>	<td><select id=\"game"+divIdName+"\" name=\"customgame['"+divIdName+"'][sgid]\">"+clon.html()+"</select></td>		<td>&nbsp;</td>		<td align=\"right\">Hostname: </td>		<td><input type=\"text\" name=\"customgame['"+divIdName+"'][hostname]\" style=\"width:140px;\"></td>	</tr>	<tr>		<td align=\"right\">Max Players: </td>		<td><input type=\"text\" name=\"customgame['"+divIdName+"'][maxplayers]\" style=\"width:30px;\"></td>		<td>&nbsp;</td>		<td align=\"right\" width=\"150\">Auto-install: </td>		<td valign=\"middle\">			<select name=\"customgame['"+divIdName+"'][autoinstall]\">				<option value=\"1\">Yes				<option value=\"0\">No			</select>	<input type=\"hidden\" name=\"customgame['"+divIdName+"'][gid]\" value=\"<?php  echo $gmid; ?>\">		</td></tr>	<tr>		<td align=\"right\">Increase Limit: </td>		<td>			<select name=\"customgame['"+divIdName+"'][flimit]\">				<option value=\"1\">No				<option value=\"0\" >Yes			</select>			</td>		<td>&nbsp;</td>		<td align=\"right\" width=\"150\">Private Server: </td>		<td valign=\"middle\">			<select name=\"customgame['"+divIdName+"'][pubpriv]\">				<option value=\"public\">No				<option value=\"private\">Yes			</select>		</td>	</tr>	<tr>		<td align=\"right\">Sub Directory: </td>	<td>		<select name=\"customgame['"+divIdName+"'][subdir]\">			<option value=\"yes\">Yes<option value=\"no\">No		</select>	</td>	<td>&nbsp;</td>	<td align=\"right\" width=\"150\">&nbsp;</td>	<td valign=\"middle\">&nbsp;	</td></tr><tr><td colspan=\"5\">&nbsp;</td></tr><tr><td colspan=\"5\"><br>													<a class=\"button\" href=\"javascript:;\" onclick=\"$(\'#"+divIdName+"\').remove();\">Remove</a><br><br></td></tr></table><br>";
	ni.append(newdiv);


}
function insertInnerHTML3(){
	var ni = $('#cvarUpdateDiv');
	var num = +($("#cvarUpdateDivID").val()) + 1;
	$("#cvarUpdateDivID").val(num);
	if (num%2 == 0){
		classs='odd';
	} else classs='even';


	var divIdName = num;
	var newdiv = document.createElement('div');
	newdiv.setAttribute("id",divIdName);
	newdiv.innerHTML = "<table cellpadding=\"2\" cellspacing=\"0\"><tr class='"+classs+"'>					<td class='iconwrapper'><input type=\"button\" class=\"button danger\" value=\"Remove\" onclick=\"$('#"+divIdName+"').remove();\"></td>					<td align=\"center\"><input type=\"checkbox\" value=\"1\" name=\"cvars["+divIdName+"][user]\"></td>					<td><input type=\"text\" name=\"cvars["+divIdName+"][cvar]\"></td>					<td><input type=\"text\" name=\"cvars["+divIdName+"][value]\"></td>				</tr></table>";
	ni.append(newdiv);
}

function insertInnerHTML4(){
	var ni = $('#cvarUpdateDiva');
	var num = +($("#cvarUpdateDivIDa").val()) + 1;
	$("#cvarUpdateDivIDa").val(num);
	if (num%2 == 0){
		classs='odd';
	} else classs='even';


	var divIdName = num;
	var newdiv = document.createElement('div');
	newdiv.setAttribute("id",divIdName);
	newdiv.innerHTML = "<table cellpadding=\"2\" cellspacing=\"0\"><tr class='"+classs+"'>					<td class='iconwrapper'><input type=\"button\" class=\"button danger\" value=\"Remove\"  onclick=\"$('#"+divIdName+"').remove();\"></td>					<td><input type=\"text\" name=\"ports["+divIdName+"][cvar]\"></td>					<td><input type=\"text\" name=\"ports["+divIdName+"][port]\"></td>				</tr></table>";
	ni.append(newdiv);
}


function insertInnerHTMLSubUser(){
	var ni = $('#contentDIV');
	var num = +($("#contentDIVID").val()) + 1;
	$("#contentDIVID").val(num);
	var divIdName = "my"+num+"Div";
	var newdiv = document.createElement('div');
	newdiv.setAttribute("id",divIdName);
	newdiv.innerHTML = "<input type=\"text\" name=\"feditcfg[]\" value=\"\"> <a href=\"javascript:;\" onclick=\"$(\'#"+divIdName+"\').remove();\" class=\"button icon remove\" >x</a><br>";
	ni.append(newdiv);
}


function insertInnerHTMLClientFiles(){
	var totalrows = $('#userfiles tr').length-3;
	var item=totalrows+1;
	var checked2=$('#isfolder').attr('checked');
	if(checked2){
		checked2 = "checked=checked";
	} else checked2="";
	
	$('#userfiles').append('<tr><td><input class="button danger" type="button" value="Delete" onclick="$(this).parent().parent().remove();"></td><td><input type="text" style="width: 240px;" name="item['+item+'][path]" value="'+$('#ispath').val()+'"></td><td align="center"><input type="checkbox" '+checked2+' name="item['+item+'][folder]"></td></tr>');
	$('#ispath').val("");
	$('#isfolder').attr('checked', false);

}
