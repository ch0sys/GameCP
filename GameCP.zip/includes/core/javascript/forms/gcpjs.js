/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2008 All Rights Reserved.	
`	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your system.
	
	http://gamecp.com/terms.php

	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/


var wt_firstload="8000";
var nt_firstload="6000"
var gentloadedtableservers=false;
var gentloadedtableserversinactive=false;
var gentloadedtableserverssuspended=false;
var loadingIcon="<img src='"+url+"/includes/core/javascript/jquery/ajax-loader.gif' alt='Loading...' title='Loading...' style='padding: 10px;' />";
var loadingIcon2="<img src='"+url+"/includes/core/javascript/jquery/ajax-loader2.gif' alt='Loading...' title='Loading...' style='padding: 10px; margin-bottom: 8px;'  />";

var showMenuManageMachines=function(a){$.ajax({type:"GET",error:function(c,d,b){if($("#ajaxlog")){$("#ajaxlog").append("There was a problem with the Ajax call #2")}},url:url+"/manage/machines.php?mode=edit2&noheader=true&gmid="+a,beforeSend:function(){$("#export_contents").html("<br><center>Please wait while the machine details are loaded<br><br>"+loadingIcon2+"</center><br><br>");$(".machineDetails").center();$(".machineDetails").show();$("#loadingdiv").show()},success:function(b){$("#export_contents").html(b);$("#portatus").load(url+"/includes/process.php?showMachinePing=true&gmid="+a);$("#loadingdiv").hide();$(".machineDetails").center();$("#export_options").draggable({handle:"#draghand"})}})};
var showConfigBuilder=function(a,b){$.ajax({type:"GET",error:function(d,e,c){if($("#ajaxlog")){$("#ajaxlog").append("There was a problem with the Ajax call #2")}},url:url+"/manage/configbuilder.php?noheader=true&mode=edit2&configid="+a,beforeSend:function(){if(!b){$("#export_contents").html("<br><center>Please wait while the details are loaded<br><br>"+loadingIcon2+"</center><br><br>")}$(".cbDetails").center();$(".cbDetails").show();$("#loadingdiv").show()},success:function(c){$("#export_contents").html(c);$("#loadingdiv").hide();$(".cbDetails").center();$("#export_options").draggable({handle:"#draghand"})}})};

function webcron(){$.getJSON(url+"/includes/cron/cron.php",function(e){$(e).each(function(e,t){$.gritter.add({title:"�",text:t})})})}
function webcronTimer(){$(window).load(function(){setTimeout(function(){webcron();webcronTimer()},wt_firstload);wt_firstload=8e4})}
function notifications(){$.getJSON(url+"/includes/process.php?notifications=true",function(e){$(e).each(function(e,t){$.gritter.add({title:"�",text:t["text"]})})})}
function notificationTimer(){$(window).load(function(){setTimeout(function(){notifications();notificationTimer()},nt_firstload);nt_firstload=6e4})}$(document).ready(function(){var e="";var t=0;$.each($(".notification"),function(n,r){e=e+$(r).html();if(t>0)$(r).remove();t++});$(".notification").html(e)});
function runGameControl(method, ugid, mini, total, thisdelay){	var currentTotal=$('#scitotal').val();	var totalleft=total - $('#scitotal').val();	if(method == "stop"){		var limitr='4';	} else var limitr='2';	if (currentTotal >= limitr){		setTimeout(function() {			runGameControl(method, ugid, mini, total, thisdelay)		}, '1000'); 	} else {		$('#scitotal').val(Number(currentTotal) + Number(1));		setTimeout(function() {			$('.masschecklog').append(thisdelay + ' timed ' +ugid+'<br>');			controlGame(method, ugid, mini, true);		}, thisdelay); 	} }
function loadRegularTab(tab, elei){ $('.tabBg').hide(); $(".tabLit").attr("class", "tabReg"); $('#'+tab).show(); elei.className='tabLit'; }
function checkTos(){ if ($('#tos').prop('checked') == false){ alert(LNG_AGREETOTOS); return false; } else return true; }
function popUp(URL) {day = new Date();	window.open(URL,day.getTime(),'width=720,height=330,toolbar=0,menubar=0,location=0,status=0,scrollbars=1,resizable=1,left=0,top=0');	return false;}
function submitInfo(c,b,d,a){if(c=="console"){$("#settingsframe1").attr("src",url+"/system/console.php?ucid="+d+"&gid="+b+"&consoleDisplay=detached");showConsole("#gameControlLoading"+b)}else{if(c=="stop"||c=="start"||c=="restart"){controlGame(c,b,a)}else{if(c=="managefiles"){document.getElementById("settingsframe2").src=url+"/system/userservices.php?mode=edit2&opt=editfiles&noheader=true&ggid="+b;showFileMenu("#gameControlLoading"+b)}else{if(c=="remove"){if(confirm(LNG_AREYOUSUREREMOVE+"?")){window.location="userservices.php?mode=none&opt=remove&ggid="+b}}else{window.location=c}}}}}
function submitVoiceInfo(b,a){if(b=="remove"){if(confirm("Are you sure you want to remove this server?")){window.location=url+"/system/voice.php?mode=remove&vid="+a}}else{window.location=b}};
function manageControlledServers(b,c,a){if(a=="true"){if(c=="start"||c=="stop"){$("#usergamerow"+b).remove()}}else{if(a=="usergame"){window.location.href=window.location}else{if(c=="start"||c=="stop"){$("#usergamerow"+b).remove()}}}};
function checkAllBoxes(ele){ var checkclass=$(ele).attr('class'); var checked_status = ele.checked; ele.checked = checked_status; $("input[class="+checkclass+"]").each(function(){ this.checked = checked_status; }); };var showMenuGadgets = function(el, menu) { var pos = $(el).offset();            var eWidth = $(el).outerWidth();        var mWidth = $(menu).outerWidth();        var top = pos.top + 30 + "px";        $(menu).css( {                 position: 'absolute',                zIndex: 5004, top: top } ); if($(menu).css("display") != "none"){ var hidediv=true;	} if(hidediv  != true){ $(menu).hide().fadeIn(); } else $(menu).fadeOut();  };
function validateQuickNav() { if ($('#quickselect_opt').val() == "") { alert (selectOption); return false;	} else if ($('#quickselect_id').val() == "") { alert (selectUser); return false;	} else if ($('#quickselect_opt').val() == "delete"){ if(confirm(confirmRemove)) $('#quickselect_form').submit(); } else $('#quickselect_form').submit(); }
function deleteConfigBuilder(a,b){$.ajax({type:"GET",url:url+"/manage/configbuilder.php?noheader=true&mode=removeitem&itemid="+a,success:function(c){showConfigBuilder(b,true)}})};
function ajaxSaveBuilder(page, replydiv, cfgid){$(document).ready(function() { $(page).validate({ submitHandler: function() { ajaxSaveBuilderSubmit(page, replydiv, cfgid); } }); }); }
function ajaxSaveBuilderSubmit(b,c,a){var d={beforeSubmit:function(){$("input[type=submit]",b).prop("disabled","disabled");$("input[type=submit]",b).addClass("inputdisabled");$("#savingdiv").show()},success:function(e){$("#savingdiv").hide();$("input[type=submit]",b).removeAttr("disabled");$("input[type=submit]",b).removeClass("inputdisabled");if(c){$(c).html(e)}if("#altsavediv"){$("#altsavediv").show()}else{$("#saveddiv").show()}showConfigBuilder(a,true);setTimeout(function(){if("#altsavediv"){$("#altsavediv").hide()}else{$("#saveddiv").hide()}},"7000")},timeout:"90000"};$(b).ajaxSubmit(d);return false};


function doMoveItems(){
		$('.sortableTrigger').css('cursor', 'move'); 
		$('.sortableTrigger').prop('title', 'Move'); 
		$(".tableTop").hover(
		  function () {
			if( $(this).find(".sortControlItems").length == 0 && $(this).find(".remove").length == 0){
				var children = $(this).find("td:last").children();
				if(!$(children).hasClass('button icon remove')) $(this).find("td:last").append($("<span class='sortControlItems'><a class='button icon icon-blank remove ' href='#remove_block' title='Remove'  onclick='removeParents(this);'></a></span>"));
			}
		  },  function () {
        $(this).find(".sortControlItems").remove();
      }
    );

}

function gameCPDoThatSort(){
	$(window).load(function(){
		doMoveItems();
		$("#leftsort").sortable({
			connectWith: ["#leftsort", "#rightsort"],
			forcePlaceholderSize: true,
			forceHelperSize: true,
			cursor: "pointer",
			tolerance: 'pointer',
			placeholder: 'ui-state-highlight',
			over: function(event, ui)  { $(this).attr("style", "border: 2px dashed #ccc"); },
			out:  function(event, ui)  { $(this).attr("style", "border: 0px"); },
			opacity: 0.7,
            delay: 100,
			stop: function(event, ui){
				var this_id = $(ui.item).attr("id");
			},
			update: function(event, ui){ 
				var this_id = $(ui.item).attr("id");
				saveSort();
			}
		});

		$("#rightsort").sortable({
			connectWith: ["#rightsort", "#leftsort"],
			forcePlaceholderSize: true,
			forceHelperSize: true,
			cursor: "pointer",
			tolerance: 'pointer',
			placeholder: 'ui-state-highlight',
			over: function(event, ui)  { $(this).attr("style", "border: 2px dashed #ccc"); },
			out:  function(event, ui)  { $(this).attr("style", "border: 0px"); },
			opacity: 0.7,
            delay: 100,
			stop: function(event, ui){ 
				var this_id = $(ui.item).attr("id");
			},
			update: function(event, ui){ 
				var this_id = $(ui.item).attr("id");
				saveSort();
			}
		});


		$("#dragIcons").sortable({
			connectWith: ["#leftsort", "#rightsort"],
			forcePlaceholderSize: true,
			placeholder: 'ui-state-highlight',
			cursor: "pointer", 
			opacity: 0.7,
			revert: 300,
            delay: 100,
			start: function(){}, 
			update: function(data, ui){ 
				if(ui.item.parent().attr("id") != "dragIcons"){
					var this_id = $(ui.item).attr("id");
					$("#"+this_id).html(loadingIcon);
					$("#"+this_id).load(url+"/system/index.php?noheader=true&loadItem="+this_id);
					$("#"+this_id).fadeIn();
					$("#"+this_id).attr("class", "");
				}
			}
		});

		$('.sortableTrigger').hover(
			function(){
			   $("#leftsort").sortable('enable');
			   $("#rightsort").sortable('enable');
			},
			function(){
			   $("#leftsort").sortable('disable');
			   $("#rightsort").sortable('disable');
			}
		);


		$("#leftsort").sortable('disable');
		$("#rightsort").sortable('disable');
		$('#dragIconsWrapper').show();
		$('.portlet').fadeIn();
	

	}); 
}
function saveSort(){ order = $('#leftsort').sortable('serialize', {key: "sort_left[]"}); 	 order2 = $('#rightsort').sortable('serialize', {key: "sort_right[]"}); 	 $.ajax({		  url: url+"/includes/process.php",		  type: "GET",			error: function(msg, textStatus, errorThrown){ 			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');		} ,		  data: order+"&"+order2+"&saveIndexSort=true"	  }); }
function controlGame(mode, ugid, indexpage, nopagereload, altpage){
	var menu=$('#gameControlLoading'+ugid);
	$.ajax({
		type: "GET",
		url: url+"/includes/process.php?gamecontrol=true&noheader=true&mode="+mode+"&gid="+ugid,
			beforeSend: function(){	
				$(menu).html(loadingIcon2);	
				$('#gameControlIcons'+ugid).hide();
				$(menu).show();
			},	
			error: function(msg, textStatus, errorThrown){ 
				if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #1');
				$(menu).hide();	
				$('#gameControlIcons'+ugid).show();	
			} ,
			success: function(msg){
			if(msg != ''){	
					$(menu).html(msg);	
					setTimeout(function() {	
						$(menu).hide();
						$('#gameControlIcons'+ugid).show();
						}, '25000');	
			} else { 	
				$(menu).html('');	
				$('#gameControlIcons'+ugid).show();	
				if(nopagereload != true){		
					manageControlledServers(ugid, mode, indexpage);		
				} else if(mode == "start" || mode == "stop") 
					$('#usergamerow'+ugid).remove();			
				}		
			if($('#scitotal')){			
				var theval=$('#scitotal').val();		
				$('#scitotal').val(Number(theval) - Number(1));
				$('#usergamerow'+ugid+ ' .userGameControlBox').prop('disabled', false);	
				$('#usergamerow'+ugid).fadeTo("slow", 1); 
			} 
			if(mode == "restart"){	
				if(!altpage){
					var updatediv=$('#serverStatus'+ugid);	
					ajaxLoadPage(url+'/includes/serverstatus.php?ugid='+ugid, updatediv);
				}else loadServerStatus2(url, ugid, '1');
			}		
		} 	
	});
}




jQuery.fn.center = function () {
    this.css("position","absolute");
    this.css("top", (($(window).height() - this.outerHeight()) / 2) + $(window).scrollTop()-100 +  "px");
    this.css("left", (($(window).width() - this.outerWidth()) / 2) + $(window).scrollLeft() + "px");
    return this;
}



var showConsole = function(el) {	
	$("#serverlistPopin").center();		
	$("#serverlistPopin").hide().fadeIn();
};

var showFileMenu = function(el) {	 
	$("#serverlistFilePopin").center();		
	$("#serverlistFilePopin").hide().fadeIn();
};
var showSubUsers = function(el, menu, txt) { 
	
	if($(menu).css("display") != "none") var hidediv=true;	
	
	$('.billDetails').hide();
	
	if(hidediv != true){ 
		$(menu).hide().fadeIn();
		$(menu).center();
	}
};



function checkGameDownload(gid, servers, updatediv){
	$.ajax({
		type: "GET",
		url: url+"/manage/installgames.php?noheader=true&mode=checkdlstatus&servers="+servers+"&gid="+gid,
		success: function(msg){
			$(updatediv).html(msg);	
			setTimeout(function() {	
				checkGameDownload(gid, servers, updatediv);
			}, '7000');	
		}
	});
}

function checkRepoHealth(gid){
	$.ajax({
		type: "GET",
		url: url+"/manage/repos.php?noheader=true&mode=health&gmid="+gid,
		success: function(msg){
			$('#repohealth'+gid).html(msg);	
			setTimeout(function() {	
				checkRepoHealth(gid);
			}, '3600');	
		}
	});
}

function RepoMD5UpdateStatus(updater, loading, reload, ugid){
	page=url+'/manage/repos.php?mode=md5check&gmid='+ugid;

	 $.ajax({
	   type: "GET",
	   url: page,
	   data: "ajax=true&noheader=true",
	   beforeSend: function(){
		if(loading == "alt"){
			if(loading)$(updater).html(loadingIcon2);
		} else if(loading)$(updater).html(loadingIcon);
	   },
		error: function(msg, textStatus, errorThrown){ 
			if($('#ajaxlog')) $('#ajaxlog').append('There was a problem with the Ajax call #2');
		} ,

	   success: function(msg){
		   if(msg == "Update completed."){
				$('#movestatushead, #loadingbars'+ugid).hide();
				$('#logresult, #movedone'+ugid+', #wrapcontrols').show();
		   }else{
			  if(msg) $(updater).html(msg);
		   }

		$(updater).show();
	   }
	 });
}

function RepoUpdateStatus(d,e,c,b){page=url+"/manage/repos.php?mode=checkstatus&gmid="+b;var a;$.ajax({type:"GET",url:page,data:"ajax=true&noheader=true",beforeSend:function(){if(e=="alt"){if(e){$(d).html(loadingIcon2)}}else{if(e){$(d).html(loadingIcon)}}},error:function(g,h,f){if($("#ajaxlog")){$("#ajaxlog").append("There was a problem with the Ajax call #2")}},success:function(f){if(f.match(/Update completed, checking files./)){clearTimeout(a);RepoMD5UpdateStatus(d,e,c,b)}else{if(f){$(d).html(f)}if(c&&$(d)){a=setTimeout(function(){if(e=="alt"){e=""}RepoUpdateStatus(d,e,c,b)},c)}}$(d).show()}})};
function checkAddon(a,c,b){$.ajax({type:"GET",url:url+"/system/userservices.php?noheader=true&mode=checkaddonstatus&aid="+c+"&ugid="+a,success:function(d){var e=d.split(":_:");if(e[0]=="completed"){$(b).html(e[1]);$("#addon1, #loadingbars").hide();$("#addon2").show();$("#continuebutton").show()}else{$(b).html(d);setTimeout(function(){checkAddon(a,c,b)},"5000")}$(window).scrollTop($(document).height())}})};
function HideHelper(){$.ajax({type:"POST",url:url+"/includes/process.php?hideHelper=true",success:function(a){$("#helper-lite").remove()}})}
function ToggleFormEditable(a,b){if(b=="yes"){$(a).removeAttr("disabled","");$(a).removeClass("disabled")}else{$(a).attr("disabled","");$(a).addClass("disabled")}}
function removeGameConfig(a,b){if(confirm(a)){$("#confrow"+b).remove();$("#config"+b+"delete").val("1");$("#confrowyo"+b).hide();$("#formGames").submit()}};