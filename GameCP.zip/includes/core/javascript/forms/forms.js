/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2008 All Rights Reserved.	
`	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your system.
	
	http://gamecp.com/terms.php

	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/* language for this file */
var selectOption="Please select an option.";
var selectUser="Please select a user.";
var confirmRemove='Are you sure you want to remove?';

function submitValid(page){ $(document).ready(function() { $(page).validate({ }); }); }
function ajaxSubmitValid(page, replydiv){ $(document).ready(function() { $(page).validate({ submitHandler: function() { ajaxSubmitPage(page, replydiv); } }); }); }
function selectIt(){ selectAllMultiple('quickmods'); selectAllMultiple('quickConfig'); }
function checkWindows(field){ if(field.value == "1"){ $('.winhide').hide(); } else $('.winhide').show(); }
function ignoreSpaces(string) {	var temp = "";	string = '' + string;	splitstring = string.split(" ");	for(ii = 0; ii < splitstring.length; ii++)	temp += splitstring[ii];	return temp;}
function stringFilter (input) {	s = input.value; var ii;	var returnString = "";	for (ii = 0; ii < s.length; ii++) { 	var c = s.charAt(ii);	if (c.match(/^[0-9a-zA-Z_]+$/))returnString += c; }		input.value = returnString.toLowerCase();}
function selectAllMultiple(field){ $("#"+field).each(function(){$("#"+field+" option").prop("selected","selected"); }); }
function deSelectAllMultiple(field){ $("#"+field).each(function(){$("#"+field+" option:selected").prop("selected", false); }); }
