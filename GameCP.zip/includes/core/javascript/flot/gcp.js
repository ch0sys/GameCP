function changeTime(elei){
	$(".timelit").removeClass("timereg");
	elei.addClass='timelit';
	update($('#placeholder'));
}


function years(offset){
	var d=new Date();
	return d.getUTCFullYear()-offset;
}

function months(offset){

	var d=new Date();
	var month=new Array(12);

	month[0]="January";
	month[1]="February";
	month[2]="March";
	month[3]="April";
	month[4]="May";
	month[5]="June";
	month[6]="July";
	month[7]="August";
	month[8]="September";
	month[9]="October";
	month[10]="November";
	month[11]="December";
	tmpset=d.getMonth()-offset;
	if(tmpset < 0){
		offset=12+tmpset;
		return month[offset];
	}
	return (month[d.getMonth()-offset]);
}

function weekendAreas(axes) {
	var markings = [];
	var d = new Date(axes.xaxis.min);
	d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 1) % 7))
	d.setUTCSeconds(0);
	d.setUTCMinutes(0);
	d.setUTCHours(0);
	var i = d.getTime();
	do {
		markings.push({ xaxis: { from: i, to: i + 2 * 24 * 60 * 60 * 1000 } });
		i += 7 * 24 * 60 * 60 * 1000;
	} while (i < axes.xaxis.max);

	return markings;
}

function update(graphdiv) {
	$.ajax({
		url: url+"/includes/graph.php?rrd=true&chart="+chart+"&graph="+graph,
		method: 'POST',
		dataType: 'json',
		beforeSend: function(){
			$('#loadingdiv').show();
		},
		success: function onDataReceived(series) { 
			$('#loadingdiv').hide();
			$(graphdiv).empty(); 
			var plot=$.plot(graphdiv, series, defaultOptions()); 
			plot=$.plot(graphdiv, series, defaultOptions()); 
			$(graphdiv).bind('plotzoom', function (event, plot) { var axes = plot.getAxes(); });
		}
	});
}



function updatehome(graphdiv) {
	$.ajax({
		url: url+"/includes/graph.php?home=true",
		method: 'POST',
		dataType: 'json',
		error: function(xhr, status, thrown){ alert(xhr+' ' +status+' ' +thrown)},
		success: function onDataReceived(series) { 
			var options= {
				colors: [barcolor],
				series: {
					bars: {
					  show: true,
					  barWidth: 0.6,
					  fill: true,
					  fillColor: { colors: [ { opacity: 1 }, { opacity: 0.4 } ] } ,
					  align: "center"
						 
					}

				},
				grid: { 
					backgroundColor: backgroundcolor,
					hoverable: true,
					clickable: true,
					mouseActiveRadius: 100,
					borderWidth:borderwidth,
					borderColor: bordercolor
				},
				yaxis: { show: false,ticks: 2, tickColor: '#ccc'},
				xaxis: { 
					color: textcolor,
					ticks: [[1,'Bills Pending'], [2,'Bills Due'], [3,'Bills Overdue'], [4,'Tickets'], [5,'Active Clients'], [6,'Inactive Clients'], [7,'Voice'], [8,'Machines'], [9,'Games'], [10,'Players']]
				}
			};

			// double draw because of display bug
			$(graphdiv).empty(); 
			var plot = $.plot(graphdiv, [series],options);
			plot=$.plot(graphdiv, [series], options); 
		}
	});
	flotTip(graphdiv, true);
}

function flot2(graphdiv, graph) {
	if(graph != "yearly"){
		var ticks=[[1,months(0)], [2,months(1)], [3,months(2)], [4,months(3)], [5,months(4)], [6,months(5)]];
	} else var ticks=[[1,years(0)], [2,years(1)], [3,years(2)], [4,years(3)]]

	
	$.ajax({
		url: url+"/includes/graph.php?"+graph+"=true",
		method: 'POST',
		dataType: 'json',
		success: function onDataReceived(series) { 
			var plot = $.plot(graphdiv, [series], altOptions(ticks));
		}
	});
	flotTip(graphdiv, true);
}



function flot(graphdiv, opt){
	update(graphdiv, opt);
	flotTip(graphdiv, false);

	window.setInterval(function() {
		update(graphdiv, opt);
	}, 50000);
}

function showChartTooltip(x, y, contents) {
	$('<div id="charttooltip">' + contents + '</div>').css( {
		position: 'absolute',
		display: 'none',
		top: y + 15,
		left: x + 15,
		border: '1px solid #bfbfbf',
		padding: '2px',
		'background-color': '#ffffff',
		'color': '#000',
		opacity: 1
	}).appendTo("body").fadeIn(200);
}

function altOptions(ticks){
	return options = {
		colors: [barcolor],
		series: {
			bars: {
			  show: true,
			  barWidth: 0.6,
			  fill: true,
			  fillColor: { colors: [ {opacity: 1 }, { opacity: 0.4 } ] } ,
			  align: "center"
			}
		},
		grid: { 
			backgroundColor: backgroundcolor,
			hoverable: true,
			mouseActiveRadius: 100,
			borderWidth:borderwidth,
			borderColor: bordercolor


		},
		yaxis: { ticks: 1, color: textcolor },
		xaxis: { ticks: ticks, color: textcolor }
	};
	
}
function defaultOptions(){ 
	return options = {
        colors: ["#edc240", "#afd8f8", "#cb4b4b", "#4da74d", "#9440ed"],
		series: {
			lines: { 
				show: true,
				fill: true

			}
		},
		legend: { noColumns: 10, margin: 20, container: $('#leg')},
		xaxis: { mode: 'time', zoomRange: [0, 500] },
		yaxis: { min: 0,  zoomRange: [0, 500] },
		selection: { mode: "x" },
		grid: { 
			markings: weekendAreas,
			backgroundColor:backgroundcolor,
			hoverable: true,
			clickable: true,
			borderWidth:borderwidth,
			borderColor: bordercolor
		}
	};
}

function flotTip(placeholder, alt){
	placeholder.bind("plothover", function (event, pos, item) {
		if(!pos) return false;
		if(pos.x) $("#x").text(pos.x.toFixed(2));
		if(pos.y) $("#y").text(pos.y.toFixed(2));
		if (item) {
			$("#charttooltip").remove();
			y = item.datapoint[1];
			var x = item.datapoint[0];

			if(alt == true){
				showChartTooltip(item.pageX, item.pageY,'' +y);
			} else {
				var d = new Date(x);
				var tiptime = d.getDate()+'-'+ d.getMonth()+1+'-'+d.getFullYear() + ' @ '+ d.getUTCHours()+':'+d.getUTCMinutes();
				showChartTooltip(item.pageX, item.pageY,'Value: ' +y+'<br>Time: '+tiptime);
			}
		} else {
			$("#charttooltip").remove();
		}
	});
}