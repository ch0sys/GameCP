<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

if(!defined('_GAMECP_')) die("Invalid access");


if(!isset($packageName  )) $packageName  ="";
if(!isset($sid  )) $packageTerm ="";

/* This e-mail is sent to admins when a server is purchased */
$subject = "New Client: $fname $packageSlots $packagePubPriv $packageGame";
$email = "A new client has been created with the following information:\n";

$email .= "GAME DETAILS\n";
if($packageName) $email .= " Product: $packageName \n"; 
if($packagePubPriv) $email .= " Public/Private: $packagePubPriv\n"; 
if($packageGame) $email .= " Game: $packageGame\n"; 
if($packageSlots) $email .= " Player Slots: $packageSlots\n"; 
if($fname) $email .= " User Name: $fname\n"; 
if($fpassword) $email .= " Password: $fpassword\n"; 

$email .= "\n";
if($paymentMethod == "bankTransfer") { 
		$email .= "\n";
		$email .= "BANK INFORMATION\n";
		$email .= " Account #: $banknum\n";
		$email .= " Routing #: $routing\n";
		$email .= " Check #: $checknum\n";
		$email .= " Bank Name: $bankname\n";
		$email .= "\n";
		$email .= "This user selected to pay by bank transfer, you will need to do this manually.\n";
		$email .= "You will need to manually install this user from the queue once they have completed payment.\n";
}
if($paymentMethod == "snailMail") { 
		$email .= "\n";
		$email .= "This user selected to pay by regular mail, please contact them to verify.\n";
		$email .= "You will need to manually install this user from the queue once they have completed payment.\n";
		$email .= "\n";
}
$email .= "Thank You.";


?>