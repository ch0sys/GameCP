<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your system.
	
	

	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

if(!defined('_GAMECP_')) die("Invalid access");


if(!isset($noheader) && !isset($_REQUEST['noheader']) && !isset($_REQUEST['mini']) && !isset($copyrightRemoval)) $smarty->assign('copyright', '&copy; 2004 - '.date('Y').' <a href="http://gamecp.com" target="_blank">GameCP</a>');
if(!isset($noheader) && !isset($_REQUEST['noheader']) && !isset($_REQUEST['mini'])) $smarty->display('footers/footer.tpl');


@mysql_close($conn);
unset($conn, $smarty);


?>