<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

if(!defined('_GAMECP_')) die("Invalid access");

$GameCP->loadIncludes("panel");
$Panel=new Panel();

$badExtensions=$Panel->InvalidUploads();

function isVisible($obj, $defined_files_and_folders){
	$path = $obj["0"];
	$type = $obj["1"];
	$i = 0;
	$x = 0;
	for($i=0 ; $i<sizeof($defined_files_and_folders) ; $i++) {
		if($type == "folder" && $defined_files_and_folders[$i]["1"] == "folder") {
			if( (strpos($defined_files_and_folders[$i]["0"],$path) !== FALSE ) && (strstr($defined_files_and_folders[$i]["1"],$type) !== FALSE)	&& (strpos($path,".") === FALSE))
			return true;
		}
		if($type == "file" && $defined_files_and_folders[$i]["1"] == "file") {
			if(strpos($path,".") !== FALSE) {

				if(((strpos($defined_files_and_folders[$i]["0"],$path) !== FALSE)) && (strpos($defined_files_and_folders[$i]["1"],$type) !== FALSE)) {
					return true;
				}
				$x = strpos ($path, "*");
				$x = $x-strlen($path)+1;
				if((strpos($path,"*") !== FALSE) && (strcmp(substr($path, $x),substr($defined_files_and_folders[$i]["0"], $x)) == 0)){
					return true;
				}
				return false;
			}
		}
	}
	return false;
}


/* paths were changed to use sessions so they dont need to be passed via urls anymore */
if(!isset($_SESSION['gamecp']['fmpath']) && isset($path)) $_SESSION['gamecp']['fmpath']=$path;
$path=$_SESSION['gamecp']['fmpath'];
if(isset($_SESSION['gamecp']['fmpath'])) $_REQUEST['path']=$_SESSION['gamecp']['fmpath'];


if(isset($afile)) $afile=str_replace(":_:", " ", $afile);
$path=str_replace(":_:", " ", $path);

if($mode == "quickmanage") { 
	$fileslist="";
	if(is_array($_POST['filebox'])){
		foreach($_POST['filebox'] as $afile => $na) { 
			if($manageoption == "archive"){
				if($os != "1" && $os !="3"){ 
					$fileslist.=$afile." ";
				} else $fileslist.="\$MAINDIR".$path."/".$afile." ";
			}
			if($manageoption == "remove"){
				if(!isset($permissions['files']['remove'])) FMError("You do not have permission to view this location<br> Error: FILEPERM-E."); 

				$GameCP->SecureHome($fname, $path);

				if(!empty($afile) && $path){
					$GameCP->loadIncludes("backend");
					$Backend=new Backend();
					if($os != "1"){ 
						$path=str_replace(":_:", "\ ", $path);
						$afile=$path."/".$afile;
						$afile=$GameCP->whitelist($afile, "clean");
						$ext = pathinfo($afile);
						if($ext['filename'] == $ext['basename']){
							$Backend->Query($sid, $winport, "command:_:rmdir \"$afile\"", $_SESSION['gamecp']['fileuser']);
						} else $Backend->Query($sid, $winport, "command:_:rm -f \"$afile\"", $_SESSION['gamecp']['fileuser']);
						$path=str_replace("\ ", ":_:", $path);
					} else {
						$path=str_replace("/", "\\", $path);
						$afile=str_replace("/", "\\", $afile);
						$afile=$path.DIRECTORY_SEPARATOR.$afile;
						if($ext['filename'] == $ext['basename']){
							$Backend->Query($sid, $winport, "command:_:rmdir \"$afile\" /s /q", $_SESSION['gamecp']['fileuser']);
						} else $Backend->Query($sid, $winport, "deletefile:_:\$MAINDIR$afile");


						$path=str_replace("\\", "/", $path);
						$afile=str_replace(":_:", " ", $afile);
						$path=str_replace("\\", "/", $path);
					}
				} else echo "Error: missing fields.";
			} // end option
		} 
	}

	if($manageoption == "archive" && DEMO != "yes"){
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		if($os != "1" && $os !="3"){ 
			$archive="archive-".time().".tar.gz";
			$Backend->Query($sid,'', "command:_:cd $path ; tar -pczf $archive $fileslist", $fname);
		} else {
			$archive="archive-".time().".zip";
			$Backend->Query($sid,'', "\$MAINDIR\bin\zip.exe:_:-q \$MAINDIR$path/$archive $fileslist", $fname);
		}
	}
}

if ($mode == "upload" && DEMO != "yes" && ALLOWUPLOADS == "yes"){
 
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();

	$GameCP->SecureHome($fname, $path);

	set_time_limit(99999);
	if($_FILES['userfile']['name']){
		$uploaddir = $upldir;
		$uploadfilea=$_FILES['userfile']['name'];
		$uploadfile = $uploaddir . $_FILES['userfile']['name'];
		$uploadedfile = $_FILES['userfile']['name'];
		$file=$uploadedfile;
		$tmpfile = $_FILES['userfile']['tmp_name'];
		if(substr($path, -1) != "/")$path=$path."/";

		$ext = pathinfo($uploadfile);
		$extention =  $ext["extension"];

		if(in_array($extention, $badExtensions)){
			$errormsg="File extension is invalid";
			if(is_file($tmpfile)) unlink($tmpfile);
			$uploadok="2";
		} else {
			if (!is_uploaded_file($_FILES['userfile']['tmp_name'])) { 
				$errormsg="Unable to upload to web-server";
				$uploadok="2";
			} else {
				$uploadfile=$_FILES['userfile']['tmp_name'];

				if($os != "1" && $os !="3"){ 
					$uploadpath=str_replace("/home/$fname/", "", str_replace(":_:", "\ ",$path));
				} else { 
					$uploadpath=str_replace("/home/$fname", "", $path);
					$uploadpath=str_replace("/", "\\", $uploadpath);
					$uploadfile=str_replace("/home/$fname", "", $uploadfile);
				}

				$GameCP->loadIncludes("ftp");
				$FTP=new FTP();
				if(!$FTP->Transfer($sid, $fname, $_SESSION['filepass'], $uploadedfile, $uploadfile, "put", $uploadpath)){
					if($_SESSION['gamecp']['ftp_error']){
						$errormsg=$_SESSION['gamecp']['ftp_error'];
						unset($_SESSION['gamecp']['ftp_error']);
					} else $errormsg="Unable to copy file to remote server";
					$uploadok="2";
				}else $uploadok="1";

				if(is_file($uploadfile)) unlink($uploadfile);

			}
		}
	}
}

if ($mode == "extract" && DEMO != "yes"){
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();

	$file = basename($afile); 
	$ext = pathinfo($file);
	$extention = $ext["extension"];
	if(!in_array($extention, $badExtensions)) $mode = "doextract";
}

if ($mode == "wget" && $wgeturl && DEMO != "yes"){
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();

	$wgeturl=$wgeturl;
	$file = basename($wgeturl); 
	$ext = pathinfo($file);
	$extention =  $ext["extension"];
	if(in_array($extention, $badExtensions)){
		echo "File extension is invalid.";
	} else {
		$GameCP->SecureHome($fname, $path);
		$file=str_replace('..','', $file);


		set_time_limit(99999);
		if($os != "1" && $os !="3"){ 
			$path=str_replace(":_:", "\ ", $path);
			$Backend->QueryResponse($sid, $winport, "downloadfile:_:$wgeturl:_:$path/$file", $fname);
		} else {
			$path=str_replace("/", "\\", $path);
			$Backend->QueryResponse($sid, $winport, "downloadfile:_:$wgeturl:_:\$MAINDIR$path\\$file");
			$path=str_replace("\\", "/", $path);
		}
		
		$mode = "doextract";

	}
}

if($mode == "doextract" && DEMO != "yes"){
	if(DISABLEXTRACT == "no"){
		$GameCP->loadIncludes("game");
		$Game=new Game();
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		$determinExtract=$Game->Extract($extention, $os);
		if($determinExtract != false){
			$EXTRACT=$determinExtract[0];
			$EXTRACTMODE=$determinExtract[1];
			$EXTRACTFILE=$path."/".$file;
			$EXTRACTDIR=$path;

			if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "5"){ 
				$fname=$_SESSION['gamecp']['fileuser'];
			} else $fname = $_SESSION['gamecp']['userinfo']['username'];

			$GameCP->SecureHome($fname, $path);
			$file=str_replace('..','', $file);

			if($os != "1"){ 
				$Backend->Query($sid,'', "command:_:cd $path ; $EXTRACT $EXTRACTMODE \"$file\"", $fname);
			} else {
				$batch="\$MAINDIR\bin\\$EXTRACT \"\$MAINDIR$EXTRACTFILE\" $EXTRACTMODE \"\$MAINDIR$EXTRACTDIR\""; 
				$Backend->Query($sid, $winport, "command:_:$batch", $fname);
			}
			$path=str_replace("\ ", ":_:", $path);
		}
	}
}

if($mode == "remove" && DEMO != "yes"){
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "5"){ 
		$fname=$_SESSION['gamecp']['fileuser'];
	} else $fname = $_SESSION['gamecp']['userinfo']['username'];
	if($afile && $path) {

		$GameCP->SecureHome($fname, $path);
		$afile=str_replace('..','', $afile);
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		if($os != "1"){ 
			$path=str_replace(":_:", "\ ", $path);
			$path=str_replace(" ", "\ ", $path);
			$afile=str_replace(" ", "\ ", $afile);
			$Backend->QueryResponse($sid, $winport, "command:_:rm -f $afile", $fname);
			$path=str_replace("\ ", ":_:", $path);
		} else {
			$afile=str_replace("/", "\\", $_REQUEST['afile']);
			$afile=str_replace(":_:", " ", $_REQUEST['afile']);
			$bfile=$path.DIRECTORY_SEPARATOR.$newname;
			$Backend->QueryResponse($sid, $winport, "deletefile:_:\$MAINDIR".$afile);
			$path=str_replace("\\", "/", $path);
			$afile=str_replace("\\", "/", $afile);
		}
		$path = $path;
	} else echo "Error: missing fields."; 
}

if($mode == "rename" && DEMO != "yes"){
	$ext = pathinfo($newname);

	if(in_array($newname, $Panel->InvalidFiles())) FMError("Invalid file name.", false);
	if(isset($ext["extension"])){
		if(in_array($ext["extension"], $Panel->InvalidUploads())) FMError("Invalid file extension.", false);
		if(in_array($ext["extension"], $Panel->InvalidExtensions())) FMError("Invalid file extension.", false);
	}

	if($afile != "" && $newname != "") {
		$GameCP->SecureHome($fname, $path);
		$afile=str_replace('..','', $afile);
		$newname=str_replace('..','', $newname);

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		if($os != "1" && $os !="3"){ 
			$path=str_replace(":_:", "\ ", $path);
			$Backend->Query($sid, '',"command:_:mv \"$path/$afile\" \"$path/$newname\"", $fname);
			$path=str_replace("\ ", ":_:", $path);
		} else {
			$path=str_replace("/", "\\", $path);
			$afile=str_replace("/", "\\", $afile);
			$afile=$path.DIRECTORY_SEPARATOR.$afile;
			$bfile=$path.DIRECTORY_SEPARATOR.$newname;

			$Backend->Query($sid, $winport, "renamefile:_:\$MAINDIR$path\\".$_REQUEST['afile'].":_:\$MAINDIR$bfile");
			$path=str_replace("\\", "/", $path);
			$afile=str_replace("\\", "/", $afile);
		}
	} else echo "File not selected."; 
}

if($mode == "mkdir" && DEMO != "yes"){
	if($newdir != "") {
		$GameCP->SecureHome($fname, $path);
		$newdir=str_replace('..','', $newdir);

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		if($os != "1" && $os !="3"){ 
			$path=str_replace(":_:", " ", $path);
			$Backend->Query($sid, '',"mkdir:_:\"$path/$newdir\"", $fname);

		} else {

			$path=str_replace("/", "\\", $path);
			$afile=str_replace("/", "\\", $afile);
			$afile=$path.DIRECTORY_SEPARATOR.$afile;
			$bfile=$path.DIRECTORY_SEPARATOR.$newname;
			$Backend->Query($sid, $winport, "mkdir:_:\$MAINDIR$path\\$newdir");
			$path=str_replace("\\", "/", $path);
			$afile=str_replace("\\", "/", $afile);
		}
	} else echo "Directory name missing."; 
}

if($mode == "mkfile" && DEMO != "yes"){
	if($newdir != "") {
		$GameCP->SecureHome($fname, $path);
		$newdir=str_replace('..','', $newdir);

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();
		if($os != "1" && $os !="3"){ 
			$path=str_replace(":_:", "\ ", $path);
			$Backend->Query($sid, '',"command:_:touch \"$path/$newdir\"", $fname);
			$path=str_replace("\ ", ":_:", $path);
		} else {
			$path=str_replace("/", "\\", $path);
			$afile=str_replace("/", "\\", $afile);
			$afile=$path.DIRECTORY_SEPARATOR.$afile;
			$bfile=$path.DIRECTORY_SEPARATOR.$newname;
			$Backend->Query($sid, $winport, "writefile:_:\$MAINDIR$path\\$newdir:_:");
			$path=str_replace("\\", "/", $path);
			$afile=str_replace("\\", "/", $afile);
		}
	} else echo "File name missing."; 
}

if($mode == "File Browser"){
	$path=$path;
}

if($mode == "Save Changes" && DEMO != "yes"){
	$content=$content;
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();

	$GameCP->SecureHome($fname, $ofile);

	if($os != "1"){ 

		$outfile=str_replace("//", "/", $ofile);
		$outfile=str_replace(":_:", " ", $outfile);
		$outfile=str_replace(" ", "\ ", $outfile);
		$content = str_replace("\r\n", "\n", $content); 
		$Backend->Query($sid, $winport, "writefile:_:$outfile:_:$content", $fname);

	} else {

		$outfile=str_replace(":_:", " ", $ofile);
		$outfile=str_replace("//", "/", $ofile);
		$outfile=str_replace("/", "\\", $outfile);
		$Backend->Query($sid, $winport, "writefileutf8:_:\$MAINDIR$outfile:_:$content");


	}
	sleep(2);
	if(isset($_SESSION['gamecp']['subaccount']) && in_array('5', $_SESSION['gamecp']['subuser']['perms']) && $_SESSION['gamecp']['subuser']['files'][0] != "/"){
	} 
	$_REQUEST['mode'] = "edit";
	$mode="edit";
}

?>