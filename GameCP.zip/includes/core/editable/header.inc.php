<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your system.
	
	

	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

if(!defined('_GAMECP_')) die("Invalid access");


if(isset($_SESSION['SmartyPaginate'])) unset($_SESSION['SmartyPaginate']);

if(track_user_pages == "true") $Event->EventLogAdd($_SESSION['gamecp']['userinfo']['username'], "User ". $_SESSION['gamecp']['userinfo']['username']. " is browsing a page.");

if(isset($loadIndex)){
	if ($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
		if(!isset($_SESSION['gamecp']['updateversiontime'])) $_SESSION['gamecp']['updateversiontime']=time();
		if(!isset($_SESSION['gamecp']['updateversion']) && (time() - $_SESSION['gamecp']['updateversiontime']) > 120){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$_SESSION['gamecp']['updateversion']=$Panel->GetLatestGCPDevBuild();
		}
		if(isset($_SESSION['gamecp']['updateversion']) && version_compare($_SESSION['gamecp']['updateversion']["Version"], $gcpVersion, ">") == TRUE) $smarty->assign("new_update", $_SESSION['gamecp']['updateversion']["Version"]);
	}

	$_REQUEST['mini']=true;
	$GameCP->generateNavigationStats();

	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes"){
		$currentSortQ = sql_query($safesql->query("SELECT indexsort FROM `usersubaccounts` WHERE id='%i' LIMIT 1;", array($_SESSION['gamecp']['subuser']['id']))) or die(mysql_error());
	} else $currentSortQ = sql_query($safesql->query("SELECT indexsort FROM users WHERE id='%i' LIMIT 1;", array($_SESSION['gamecp']['userinfo']['id']))) or die(mysql_error());

	$currentSort=mysql_fetch_array($currentSortQ);
	if($currentSort['indexsort']){
		$currentSort=unserialize($currentSort['indexsort']);

		$currentSortleft=unserialize($currentSort['left']);
		$currentSortright=unserialize($currentSort['right']);

		foreach($currentSortleft as $id => $mod){
			if(($mod == 'pendingbills' || $mod == 'billinggraphs')  && usebilling != "1") unset($currentSortleft[$id]);
			if($mod == 'supporttickets'  && usetickets != "1") unset($currentSortleft[$id]);
		}
		foreach($currentSortright as $id => $mod){
			if(($mod == 'pendingbills' || $mod == 'billinggraphs') && usebilling != "1") unset($currentSortright[$id]);
			if($mod == 'supporttickets' && usetickets != "1") unset($currentSortright[$id]);
		}



		$currentSort=array();
		$currentSort['left']=serialize($currentSortleft);
		$currentSort['right']=serialize($currentSortright);


	} else {
		/* default blocks */
		$currentSort=array();
		$currentSortleft=array();
		$currentSortright=array();

		/* left */
		if ($GameCP->totalGames > "0" && (!isset($_SESSION['gamecp']['subaccount']) || isset($_SESSION['gamecp']['subaccount']) &&  $_SESSION['gamecp']['subaccount'] && in_array("1", $_SESSION['gamecp']['subuser']['perms']))) $currentSortleft[]="activegames";
		if($GameCP->voiceEnabled) $currentSortleft[]="voiceservers";

		if (usebilling == "1" && !isset($_SESSION['gamecp']['basic'])){

			if((!isset($_SESSION['gamecp']['subaccount']) && $GameCP->billEnabled > "0") || (isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount']  && in_array("8", $_SESSION['gamecp']['subuser']['perms']) && $GameCP->billEnabled > "0")) $currentSortleft[]="pendingbills";
		}


		/* right */
		if (!isset($_SESSION['gamecp']['basic']) && usetickets == "1" && (!isset($_SESSION['gamecp']['subaccount']) || isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] && in_array("7", $_SESSION['gamecp']['subuser']['perms']))) $currentSortright[]="supporttickets";
		$currentSortright[]="news";
		if($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
			$currentSortright[]="helper";
			$currentSortright[]="verifier";
		}

		$currentSort['left']=serialize($currentSortleft);
		$currentSort['right']=serialize($currentSortright);
	}

	$smarty->assign("leftSort", unserialize($currentSort['left']));
	$smarty->assign("rightSort", unserialize($currentSort['right']));

	/* modules list */
	$sortableBlocks=array();

	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2"){
		$sortableBlocks[0]['item']="gamegraphs";
		$sortableBlocks[0]['name']="$LNG_GAMEGRAPHS";
		
		$sortableBlocks[1]['item']="usersonline";
		$sortableBlocks[1]['name']="$LNG_USERSONLINE";
	}


	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
		if(usebilling == "1" && !isset($_SESSION['gamecp']['basic'])){
			$sortableBlocks[2]['item']="billinggraphs";
			$sortableBlocks[2]['name']="$LNG_BILLINGGRAPHS";
		}

		$sortableBlocks[3]['item']="helper";
		$sortableBlocks[3]['name']="$LNG_HELPER";

		$sortableBlocks[4]['item']="verifier";
		$sortableBlocks[4]['name']="$LNG_INSTALLVERIFIER";
	}

	if (!isset($_SESSION['gamecp']['subaccount']) || isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] && in_array("1", $_SESSION['gamecp']['subuser']['perms'])){
		if($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
			$sortableBlocks[5]['item']="serverdetails";
			$sortableBlocks[5]['name']="$LNG_SERVERDETAILS";
		}
	}


	$sortableBlocks[6]['item']="news";
	$sortableBlocks[6]['name']="$LNG_NEWS";

	if (usetickets == "1" && (!isset($_SESSION['gamecp']['subaccount']) || isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] && in_array("7", $_SESSION['gamecp']['subuser']['perms']))){
		if(!isset($_SESSION['gamecp']['basic'])) $sortableBlocks[7]['item']="supporttickets";
		if(!isset($_SESSION['gamecp']['basic'])) $sortableBlocks[7]['name']="$LNG_TT";
	}

	if (usebilling == "1" && (!isset($_SESSION['gamecp']['subaccount']) && $GameCP->billEnabled > "0" || isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] && in_array("8", $_SESSION['gamecp']['subuser']['perms']) && $GameCP->billEnabled > "0")){
		if(!isset($_SESSION['gamecp']['basic'])) $sortableBlocks[8]['item']="pendingbills";
		if(!isset($_SESSION['gamecp']['basic'])) $sortableBlocks[8]['name']="$LNG_PENDINGBILLS";
	}

	if ($GameCP->totalGames > 0 && (!isset($_SESSION['gamecp']['subaccount']) || isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] && in_array("1", $_SESSION['gamecp']['subuser']['perms']))){

		$sortableBlocks[9]['item']="activegames";
		$sortableBlocks[9]['name']="$LNG_ACTIVEGAMES";

		$sortableBlocks[10]['item']="inactivegames";
		$sortableBlocks[10]['name']="$LNG_INACTIVEGAMES";
	}

	if($GameCP->voiceEnabled){
		$sortableBlocks[11]['item']="voiceservers";
		$sortableBlocks[11]['name']="$LNG_VOICESERVERS";
	}

	$sortableBlocks[12]['item']="controlicons";
	$sortableBlocks[12]['name']="$LNG_ICONPANEL";

	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
		$sortableBlocks[13]['item']="recentorders";
		$sortableBlocks[13]['name']="$LNG_INSTALLQUEUE";
		$sortableBlocks[14]['item']="machines";
		$sortableBlocks[14]['name']="$LNG_MACHINE_OVERVIEW";
	}

	$missingBlocks=array();
	foreach($sortableBlocks as $block){	
		if(!@in_array($block['item'], @unserialize(@$currentSort['left'])) && !@in_array($block['item'], @unserialize(@$currentSort['right']))) $missingBlocks[]=$block;
	}

	$smarty->assign("missingBlocks", $missingBlocks);
}

/* custom ticket links based on settings */
if (usetickets == "3"){
	$ttlink=tturl;
}elseif(usetickets == "5"){
	$ttlink=rtrim(tteSupport,"/")."/dologin.php?username=".$_SESSION['gamecp']['userinfo']['email']."&amp;password=".$_SESSION['gamecp']['user']['password']."";
}elseif(usetickets == "4"){
	$ttlink=tteSupport."?loginemail=".$_SESSION['gamecp']['userinfo']['username']."&amp;loginpassword=".$_SESSION['gamecp']['user']['password']."&amp;_a=login&amp;_m=core";
}elseif(usetickets == "1") $ttlink="$url/system/tt.php?mode=viewactive";
$smarty->assign("ttlink", $ttlink);


/* custom tools */
if($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$themeRows=$Panel->GetDirContents(path."/includes/tools/", true);
	foreach($themeRows as $r){
		$ext=pathinfo($r, PATHINFO_EXTENSION);
		if($ext == 'php' && is_file(path.'/includes/tools/'.$r)) require_once(path.'/includes/tools/'.$r);
	}
}

$smarty->display('headers/header.tpl');

$template = $url. "/includes/template/" .$TEMPLATE; 

?>