<?php
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


if(!defined('_GAMECP_')) die("Invalid access");

if(EMAIL == "text/html") {
	$linevar = "<br />";
} else $linevar = "\r\n";

switch($mailmode){
	case "game":

		if($UserIPInfo["name"]) $UserGameInfo .="Game Server:  ". $UserIPInfo["name"]  .$linevar;
		if($UserIPInfo['ip']) $UserGameInfo .="Server IP: ". $UserIPInfo['ip'].":".$UserIPInfo['port'] .$linevar;
		if($UserIPInfo['alias']){
			$UserGameInfo .="FTP IP: ". $UserIPInfo['alias'] .$linevar;
		} elseif($UserIPInfo['ip']) $UserGameInfo .="FTP IP: ". $UserIPInfo['ip'] .$linevar;
		if($UserIPInfo["rconpass"]) $UserGameInfo .="Rcon: ". $UserIPInfo["rconpass"] .$linevar;
		if($UserIPInfo["name"]) $UserGameInfo .="$linevar";

	break;
	case "voice":

		if($voiceType) $UserGameInfo .="Voice Server:  ". $voiceType  .$linevar;
		if($UserIPInfo['ip']) $UserGameInfo .="Server IP: ". $UserIPInfo['ip'].":".$UserIPInfo['port'] .$linevar;
		if($voiceType == "Teamspeak 2") $UserGameInfo .="Admin URL: http://". $UserIPInfo['ip'].":14534/login.tscmd?username=". $UserIPInfo['user']."&password=". $UserIPInfo['pass']."&serverport=". $UserIPInfo['port'].$linevar;
		if($voiceType) $UserGameInfo .="$linevar";

	break;
	case "bill":

		if($billDetails["product"]){
			if($billDetails['description']){
				$BillDetails .= currencyChar. "" . $billDetails['gross'].currencyChar2." - ". $billDetails["product"]  .": ". $billDetails["package"]  . " (".$billDetails['description'].")".$linevar;
			} else $BillDetails .= currencyChar. "" . $billDetails['gross'].currencyChar2." - ". $billDetails["product"]  .": ". $billDetails["package"]  .$linevar;
		}

	break;

}

?>