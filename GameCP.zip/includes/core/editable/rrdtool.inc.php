<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


/* 
GameCP rrdtool generation

Called from servermonitor.php 
- first function creates user graphs
- second function creates overall graphs

*/

$daily="Daily";
$hourly="Hourly";
$monthly="Monthly";
$weekly="Weekly";
$playersTxt="Players";
$yearly="Yearly";

if(DIRECTORY_SEPARATOR == '\\'){
	$fontpath=' --font DEFAULT:0:c:/windows/fonts/arial.ttf';
} else $fontpath='';


function rrdToolUpdate( $dir, $graph, $values){
	global $GameCP;
	if(DIRECTORY_SEPARATOR == '\\'){
		$graph=str_replace("/", "\\", $graph);
		$dir=str_replace("/", "\\", $dir);
	}
	return "rrdtool update ". trim($graph) ." N:".trim($values)."\r\n";
}

function rrdToolCreate( $dir, $graph, $time){
	global $GameCP;
	if(DIRECTORY_SEPARATOR == '\\'){
		$graph=str_replace("/", "\\", $graph);
		$dir=str_replace("/", "\\", $dir);
	}
	return "rrdtool create ". $graph ." --step ". stepdelay ." --start $time DS:cpuid:GAUGE:". stepdelay*2 .":U:U DS:free:GAUGE:". stepdelay*2 .":U:U DS:load:GAUGE:". stepdelay*2 .":U:U RRA:AVERAGE:0.5:1:288 RRA:AVERAGE:0.5:6:336 RRA:AVERAGE:0.5:24:372 RRA:AVERAGE:0.5:288:351\r\n";
}


function rrdToolCreate2( $dir, $graph, $time){
	global $GameCP;
	if(DIRECTORY_SEPARATOR == '\\'){
		$graph=str_replace("/", "\\", $graph);
		$dir=str_replace("/", "\\", $dir);
	}
	return "rrdtool create ". $graph ." --step ". stepdelay ." --start $time DS:speed:GAUGE:". stepdelay*2 .":U:U DS:limit:GAUGE:". stepdelay*2 .":U:U RRA:AVERAGE:0.5:1:288 RRA:AVERAGE:0.5:6:336 RRA:AVERAGE:0.5:24:372 RRA:AVERAGE:0.5:288:351\r\n";
}

function rrdToolCreateUsage( $dir, $graph, $time){
	global $GameCP;
	if(DIRECTORY_SEPARATOR == '\\'){
		$graph=str_replace("/", "\\", $graph);
		$dir=str_replace("/", "\\", $dir);
	}
	return "rrdtool create ". $graph ." --step ". stepdelay ." --start $time DS:cpu:GAUGE:". stepdelay*2 .":U:U DS:mem:GAUGE:". stepdelay*2 .":U:U RRA:AVERAGE:0.5:1:288 RRA:AVERAGE:0.5:6:336 RRA:AVERAGE:0.5:24:372 RRA:AVERAGE:0.5:288:351\r\n";
}

function rrdToolGraph( $dir, $graph, $start, $label, $font, $idlecolor, $plyrcolor,$limitcolor, $playersTxt){
	global $GameCP;
	if(DIRECTORY_SEPARATOR == '\\'){
		$graph=str_replace("/", "\\", $graph);
		$dir=str_replace("/", "\\", $dir);
	}
	return "rrdtool graph $graph $font --start -$start -a PNG --units-exponent 0 --alt-y-mrtg -w 180 -h 45 --vertical-label $label DEF:cpu_idle=graph.rrd:cpuid:AVERAGE DEF:free_mem=graph.rrd:free:AVERAGE DEF:cpu_load=graph.rrd:load:AVERAGE AREA:cpu_idle".$idlecolor.":idle_cpu LINE1:free_mem".$plyrcolor.":free_memory LINE1:cpu_load".$limitcolor.":cpu_load\r\n";
}

function rrdToolGraphUsage( $dir, $graph, $start, $label, $font, $plyrcolor, $playersTxt, $limitcolor){
	global $GameCP;
	if(DIRECTORY_SEPARATOR == '\\'){
		$graph=str_replace("/", "\\", $graph);
		$dir=str_replace("/", "\\", $dir);
	}
	return "rrdtool graph $graph $font --start -$start -a PNG --units-exponent 0 --alt-y-mrtg -w 180 -h 45 --vertical-label $label DEF:cpu=graph.rrd:cpu:AVERAGE DEF:mem=graph.rrd:mem:AVERAGE AREA:cpu".$plyrcolor.":cpu LINE1:mem".$limitcolor.":mem\r\n";
}

function rrdToolGraph2( $dir, $graph, $start, $label, $font, $plyrcolor, $playersTxt, $limitcolor){
	global $GameCP;
	if(DIRECTORY_SEPARATOR == '\\'){
		$graph=str_replace("/", "\\", $graph);
		$dir=str_replace("/", "\\", $dir);
	} 
	return "rrdtool graph $graph $font --start -$start -a PNG --units-exponent 0 --alt-y-mrtg -w 180 -h 45 --vertical-label $label DEF:players=graph.rrd:speed:AVERAGE DEF:plyrlimit=graph.rrd:limit:AVERAGE AREA:players".$plyrcolor.":players LINE1:plyrlimit".$limitcolor.":plyrlimit\r\n";
}

function rrdToolGraph3( $dir, $graph, $start, $label, $font, $plyrcolor, $playersTxt, $limitcolor){
	global $GameCP;
	if(DIRECTORY_SEPARATOR == '\\'){
		$graph=str_replace("/", "\\", $graph);
		$dir=str_replace("/", "\\", $dir);
	}
	return "rrdtool graph $graph $font --color CANVAS#e4e4e4 --only-graph --start -$start -a PNG --units-exponent 0 --alt-y-mrtg -w 165 -h 14 -t $label --vertical-label $playersTxt DEF:players=graph.rrd:speed:AVERAGE DEF:plyrlimit=graph.rrd:limit:AVERAGE AREA:players".$plyrcolor.":players LINE1:plyrlimit".$limitcolor.":plyrlimit\r\n";
}

function rrdtoolMachines( $free, $loadavg, $idle){
	global $GameCP, $statsdir, $graph, $weekly, $monthly, $hourly,$daily, $yearly,$playersTxt, $fontpath;
	
	$loadavg=str_replace(".", "", $loadavg);
	$time=time();

	// load
	$limitcolor="#000000";
	// mem #BCD2EE - light blue
	$plyrcolor="#CC3232";

	$idlecolor="#BCD2EE";

	$playersTxt="Usage";
	$font="-c BACK#ffffff -c GRID#cccccc -c MGRID#cccccc -c FRAME#cccccc -c ARROW#000000 $fontpath";


	if(is_dir(path."/includes/stats/machines") && is_writeable(path."/includes/stats/machines")){
		$dir=$statsdir;
		$gr="";
		/* build stats info */
		if(!is_dir($statsdir)) mkdir($statsdir);
		chdir($statsdir);
		if (!is_file($graph)){
			/* fresh rrd db */
			if(debugging == "1") echo " --- Creating: ".trim("N:$idle:$free:$loadavg")." $graph\n";
			$gr.=rrdToolCreate( $dir, $graph, $time);
			$gr.=rrdToolUpdate( $dir, $graph, "0:0:0");

		} else {
			/* update the rrd db */
			if(debugging == "1") echo " --- Updating: N:".trim("$idle:$free:$loadavg")." $graph\n";
			$gr.=rrdToolUpdate( $dir, $graph, trim("$idle:$free:$loadavg"));
		}

		$gr.=rrdToolGraph( $dir, "hourly_graph.png", "1h", $hourly, $font, $idlecolor, $plyrcolor,$limitcolor,$playersTxt);
		$gr.=rrdToolGraph( $dir, "daily_graph.png", "1d", $daily, $font, $idlecolor, $plyrcolor,$limitcolor,$playersTxt);
		$gr.=rrdToolGraph( $dir, "weekly_graph.png", "1w", $weekly, $font, $idlecolor, $plyrcolor,$limitcolor,$playersTxt);
		$gr.=rrdToolGraph( $dir, "monthly_graph.png", "1m", $monthly, $font, $idlecolor, $plyrcolor,$limitcolor,$playersTxt);
		$gr.=rrdToolGraph( $dir, "yearly_graph.png", "1y", $yearly, $font, $idlecolor, $plyrcolor,$limitcolor,$playersTxt);
		exeGraph( $dir, $gr);

	}
}

function rrdtoolUsage( $cpu, $mem){
	global $statsdir, $graph, $weekly, $monthly, $hourly,$daily,$yearly,$playersTxt, $fontpath;

	$time=time();
	$limitcolor="#0000CD";
	$plyrcolor="#00FF00";
	$font="-c BACK#ffffff -c GRID#cccccc -c MGRID#cccccc -c FRAME#cccccc -c ARROW#000000 $fontpath";

	if(is_dir(path."/includes/stats") && is_writeable(path."/includes/stats/")){

		set_time_limit("12000");

		/* build stats info */
		if(!is_dir($statsdir)) mkdir($statsdir);
		chdir($statsdir);
		$dir=$statsdir;
		$gr="";
		if (!is_file($graph)){
			/* fresh rrd db */
			if(debugging == "1") echo " --- Creating: N:$cpu:$mem $graph\n";
			$gr.=rrdToolCreateUsage( $dir, $graph, $time);
			$gr.=rrdToolUpdate( $dir, $graph, "0:0");
		} else {
			/* update the rrd db */
			if(debugging == "1") echo " --- Updating: N:$cpu:$mem $graph\n";
			$gr.=rrdToolUpdate( $dir, $graph, "$cpu:$mem");
		}
		$gr.=rrdToolGraphUsage( $dir, "hourly_graph.png", "1h", $hourly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraphUsage( $dir, "daily_graph.png", "1d", $daily, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraphUsage( $dir, "weekly_graph.png", "1w", $weekly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraphUsage( $dir, "monthly_graph.png", "1m", $monthly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraphUsage( $dir, "yearly_graph.png", "1y", $yearly, $font, $plyrcolor,$playersTxt, $limitcolor);
		exeGraph( $dir, $gr);

	}
}

function rrdtool1( $players, $playerlimit){
	global $statsdir, $graph, $weekly, $monthly, $hourly,$daily,$yearly,$playersTxt, $fontpath;

	$time=time();
	$limitcolor="#0000CD";
	$plyrcolor="#00FF00";
	$font="-c BACK#ffffff -c GRID#cccccc -c MGRID#cccccc -c FRAME#cccccc -c ARROW#000000 $fontpath";

	if(is_dir(path."/includes/stats") && is_writeable(path."/includes/stats/")){

		set_time_limit("12000");

		/* build stats info */
		if(!is_dir($statsdir)) mkdir($statsdir);
		chdir($statsdir);
		$dir=$statsdir;
		$gr="";
		if (!is_file($graph)){
			/* fresh rrd db */
			if(debugging == "1") echo " --- Creating: N:$players:$playerlimit $graph\n";
			$gr.=rrdToolCreate2( $dir, $graph, $time);
			$gr.=rrdToolUpdate( $dir, $graph, "0:0");
		} else {
			/* update the rrd db */
			if(debugging == "1") echo " --- Updating: N:$players:$playerlimit $graph\n";
			$gr.=rrdToolUpdate( $dir, $graph, "$players:$playerlimit");
		}


		$gr.=rrdToolGraph2( $dir, "hourly_graph.png", "1h", $hourly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "daily_graph.png", "1d", $daily, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "weekly_graph.png", "1w", $weekly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "monthly_graph.png", "1m", $monthly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "yearly_graph.png", "1y", $yearly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph3( $dir, "box_graph.png", "1h", $hourly, $font, $plyrcolor,$playersTxt, $limitcolor);
		exeGraph( $dir, $gr);

	}
}

function rrdtool2( $overalltotal, $overalllimit){
	global $weekly, $monthly, $hourly,$daily,$yearly,$playersTxt, $fontpath;

	$time=time();
	$limitcolor="#0000CD";
	$plyrcolor="#00FF00";
	$statsdir=path."/includes/stats";
	$graph=$statsdir."/graph.rrd";

	$font="-c BACK#ffffff -c GRID#cccccc -c MGRID#cccccc -c FRAME#cccccc -c ARROW#000000 $fontpath";



	if(is_dir(path."/includes/stats") && is_writeable(path."/includes/stats/")){
		if(!is_dir($statsdir)) mkdir($statsdir);
		chdir($statsdir);
		$dir=$statsdir;
		$gr="";
		if (!is_file($graph)){
			if(debugging == "1") echo " - Creating overall graph N:$overalltotal:$overalllimit\n";
			if(debugging == "1") echo "------------------------------------------------------------\n";
			$gr.=rrdToolCreate2( $dir, $graph, $time);
			$gr.=rrdToolUpdate( $dir, $graph, "0:0");
		} else {
			if(debugging == "1") echo " - Creating overall graph N:$overalltotal:$overalllimit\n";
			if(debugging == "1") echo "------------------------------------------------------------\n";
			$gr.=rrdToolUpdate( $dir, $graph, "$overalltotal:$overalllimit");
		}



		$gr.=rrdToolGraph2( $dir, "hourly_graph.png", "1h", $hourly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "daily_graph.png", "1d", $daily, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "weekly_graph.png", "1w", $weekly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "monthly_graph.png", "1m", $monthly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph3( $dir, "daily_minigraph.png", "1d", $daily, $font, $plyrcolor,$playersTxt, $limitcolor);
		exeGraph( $dir, $gr);
	
	}
}

function rrdtoolServerPlayers($sid, $overalltotal, $overalllimit){
	global $weekly, $monthly, $hourly,$daily,$yearly,$playersTxt, $fontpath;

	$time=time();
	$limitcolor="#0000CD";
	$plyrcolor="#00FF00";
	$statsdir=path."/includes/stats/machines/$sid/players";
	$graph=$statsdir."/graph.rrd";

	$font="-c BACK#ffffff -c GRID#cccccc -c MGRID#cccccc -c FRAME#cccccc -c ARROW#000000 $fontpath";

	if(is_dir(path."/includes/stats/machines/$sid/") && is_writeable(path."/includes/stats/machines/$sid/")){

		if(!is_dir($statsdir)) mkdir($statsdir);
		chdir($statsdir);

		$dir=$statsdir;
		$gr="";
		if (!is_file($graph)){
			if(debugging == "1") echo " - Creating player graph file for $sid N:$overalltotal:$overalllimit\n";
			if(debugging == "1") echo "------------------------------------------------------------\n";
			$gr.=rrdToolCreate2( $dir, $graph, $time);
			$gr.=rrdToolUpdate( $dir, $graph, "0:0");
		} else {
			if(debugging == "1") echo " - Updating player graph for $sid N:$overalltotal:$overalllimit\n";
			$gr.=rrdToolUpdate( $dir, $graph, "$overalltotal:$overalllimit");
		}



		$gr.=rrdToolGraph2( $dir, "hourly_graph.png", "1h", $hourly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "daily_graph.png", "1d", $daily, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "weekly_graph.png", "1w", $weekly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "monthly_graph.png", "1m", $monthly, $font, $plyrcolor,$playersTxt, $limitcolor);
		$gr.=rrdToolGraph2( $dir, "yearly_graph.png", "1y", $yearly, $font, $plyrcolor,$playersTxt, $limitcolor);
		
		$gr.=rrdToolGraph3( $dir, "daily_minigraph.png", "1d", $daily, $font, $plyrcolor,$playersTxt, $limitcolor);
		exeGraph( $dir, $gr);
	}
}

function exeGraph( $dir, $gr){
	global $Backend, $GameCP;

	if(rrdUseEXEC == "true"){
		if(DIRECTORY_SEPARATOR == '\\'){
			$dir=str_replace("/", "\\", $dir);
			$gr=str_replace("rrdtool", path."\\includes\\cron\\rrdtool.exe", $gr);
			$gr.="\r\nexit";
			$filename = "$dir\\run-stats.bat";
			$cmd=$filename;
		} else { 
			$gr="#!/bin/bash\r\n$gr";
			$gr=str_replace("\r", "", $gr);
			$filename = "$dir/run-stats.sh";
			$cmd="bash ".$filename;
		}

		if (is_writable($dir)) {
			if ($handle = fopen($filename, 'w+')) {

				if (fwrite($handle, $gr) === FALSE){
					echo "--- Couldnt create stats script ($filename)";
				} else {
					chdir($dir);
					exec($cmd)."\n";
					chdir(path);
				}
				
				fclose($handle);
			}
		}
		if(is_file($filename)) unlink($filename);

	} else {
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$sid=$Panel->GetMasterID();
		if($sid){

			if(DIRECTORY_SEPARATOR == '\\'){
				$dir=str_replace("/", "\\", $dir);
				$gr="cd $dir\r\n$gr";
				$Backend->QueryResponse($sid, '', "writefile:_:\$MAINDIRgamecp-graph.bat:_:$gr\r\ndel /F gamecp-graph.bat\r\nexit");
				$Backend->Query($sid, '',"\$MAINDIRgamecp-graph.bat");
			} else {
				$gr="#!/bin/bash\r\ncd $dir\r\n$gr";
				$gr=str_replace("\r", "", $gr);
				$Backend->QueryResponse($sid, '', "writefile:_:gamecp-graph.sh:_:$gr");
				$Backend->Query($sid, '',"command:_:bash gamecp-graph.sh ; rm -f gamecp-graph.sh ");
			}
		}
	}
}

?>