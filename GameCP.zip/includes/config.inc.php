<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

# This is not a config file to edit!
define("_GAMECP_", "gamecp");

require_once('mysql.inc.php'); 
require_once('core/includes/gamecp/settings.inc.php'); 

if((isset($_SESSION['gamecp']['security']['path']) && $_SESSION['gamecp']['security']['path'] != path) || (isset($_SESSION['gamecp']['security']['url']) && $_SESSION['gamecp']['security']['url'] != url)){
	$ajax='';
	if(isset($_REQUEST['ajax'])) $ajax='?ajax=true';
	header("location: ../index.php".$ajax); 
}

?>