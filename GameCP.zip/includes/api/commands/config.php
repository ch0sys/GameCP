<?php 
if( !defined("_GAMECP_") ) 
{
    exit( "Invalid access" );
}

switch( $_REQUEST["command"] ) 
{
    case "config_restore":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $Game->ConfigRestore($_REQUEST["item_id"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "config_list":
        $list = $this->ListRecords("userconfigs", $_REQUEST);
        if( is_array($list) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "total" => $list["total"], "result" => $list["result"] ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "config_view":
        $userConfigInfo = $Panel->GetUserConfig($_REQUEST["item_id"]);
        if( is_array($userConfigInfo) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $userConfigInfo ));
        }
        else
        {
            $this->Error("Failed to perform action, no service found");
        }

        break;
    case "config_delete":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $Game->ConfigRemove($_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "config_edit":
        if( $this->EditRow("userconfigs", $_REQUEST["item_id"], $_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "config_fetch":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $item = $Game->ConfigFetch($_REQUEST["item_id"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $item ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "config_create":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $cfg_id = $Game->ConfigCreateV2($_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $cfg_id ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "config_execute":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $Game->ConfigExecute($_REQUEST["item_id"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    default:
        $this->Error("Unable to determine command");
        break;
}

