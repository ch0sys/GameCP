<?php 
if( !defined("_GAMECP_") ) 
{
    exit( "Invalid access" );
}

switch( $_REQUEST["command"] ) 
{
    case "service_console":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        $list = $Game->ConsoleLog($_REQUEST["item_id"], "viewlog");
        $this->DisplayOutput(array( "error" => "0", "result" => $list ));
        break;
    case "service_addon_list":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        $list = $Game->GetAddons($_REQUEST["item_id"]);
        if( is_array($list) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $list ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_addon_run":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $Game->RunAddon($_REQUEST["item_id"], $_REQUEST["addon_id"], $_REQUEST["action"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_update":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $Game->Update($_REQUEST["item_id"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_reinstall":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $Game->Reinstall($_REQUEST["item_id"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_rcon":
        $GameCP->loadIncludes("rcon");
        $Rcon = new Rcon();
        if( $Rcon->SendV2($_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_quickmod":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $Game->QuickMod($_REQUEST["item_id"], $_REQUEST["mod"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_changemap":
        $GameCP->loadIncludes("rcon");
        $Rcon = new Rcon();
        if( $Rcon->ChangeMap($_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_query":
        $GameCP->loadIncludes("query");
        $Query = new Query();
        $serverStatus = $Query->GameQ($_REQUEST["item_id"]);
        break;
    case "service_suspend":
        $GameCP->loadIncludes("suspend");
        $Suspend = new Suspend();
        if( isset($_REQUEST["action"]) && $_REQUEST["action"] == "unsuspend" ) 
        {
            $task = $Suspend->GameRestore($_REQUEST["item_id"]);
        }
        else
        {
            $task = $Suspend->Game($_REQUEST["item_id"]);
        }

        if( $task ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_edit":
        if( $this->EditRow("usergames", $_REQUEST["item_id"], $_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_list":
        $list = $this->ListRecords("usergames", $_REQUEST);
        if( is_array($list) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "total" => $list["total"], "result" => $list["result"] ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_delete":
        $GameCP->loadIncludes("user");
        $User = new User();
        if( $User->RemoveGame($_REQUEST["item_id"], "no", "no", "yes", true, true, true, true) == "removed" ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_view":
        $userGameInfo = $Panel->GetUserGame($_REQUEST["item_id"]);
        if( is_array($userGameInfo) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $userGameInfo ));
        }
        else
        {
            $this->Error("Failed to perform action, no service found");
        }

        break;
    case "service_create":
        if( !in_array($this->user_level, array( "ADMIN", "MANAGER", "RESELLER" )) ) 
        {
            return $this->Error("Permission denied");
        }

        if( $result = $this->CreateService($_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $result, "id_type", "queue" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "service_control":
        if( !in_array($_REQUEST["action"], array( "stop", "start", "restart" )) ) 
        {
            return $this->Error("Invalid action");
        }

        $GameCP->loadIncludes("control");
        $Control = new Control();
        if( $Control->Usergame($_REQUEST["item_id"], $_REQUEST["action"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    default:
        $this->Error("Unable to determine command");
        break;
}

