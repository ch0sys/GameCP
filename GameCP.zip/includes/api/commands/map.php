<?php 
if( !defined("_GAMECP_") ) 
{
    exit( "Invalid access" );
}

switch( $_REQUEST["command"] ) 
{
    case "map_list":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        $list = $Game->MapList($_REQUEST["item_id"], $_REQUEST);
        if( is_array($list) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $list ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "map_add":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $Game->MapControl($_REQUEST["item_id"], $_REQUEST["item"], "add") ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "map_delete":
        $GameCP->loadIncludes("game");
        $Game = new Game();
        if( $Game->MapControl($_REQUEST["item_id"], $_REQUEST["item"], " delete") ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    default:
        $this->Error("Unable to determine command");
        break;
}

