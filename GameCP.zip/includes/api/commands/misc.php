<?php 
if( !defined("_GAMECP_") ) 
{
    exit( "Invalid access" );
}

switch( $_REQUEST["command"] ) 
{
    case "notify":
        if( $this->user_level != "ADMIN" && $this->user_level != "MANAGER" ) 
        {
            return $this->Error("Permission denied");
        }

        $GameCP->loadIncludes("email");
        $Email = new Email();
        if( $_REQUEST["subject"] == "" ) 
        {
            $_REQUEST["subject"] = " ";
        }

        if( $_REQUEST["body"] == "" ) 
        {
            $_REQUEST["body"] = " ";
        }

        $userInfo = $Panel->GetUser($_REQUEST["item_id"]);
        if( is_array($userInfo) ) 
        {
            $Email->userid = $userInfo["id"];
            $show_result = $userInfo["email"];
            $Email->emailsubject = utf8_encode($_REQUEST["subject"]);
            $Email->emailbody = utf8_encode($_REQUEST["body"]);
            $Email->usegamedata = true;
            $Email->usevoicedata = true;
            $Email->usebilldata = true;
            $Email->ReplaceStuff();
            $Email->send();
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "auth":
        $this->DisplayOutput(array( "error" => "0", "result" => $this->user_key, "userlevel" => $this->user_level ));
        break;
    case "version":
        $this->DisplayOutput(array( "error" => "0", "result" => $this->api_version ));
        break;
    case "myprofile":
        $this->DisplayOutput(array( "error" => "0", "result" => $this->user_info ));
        break;
    default:
        $this->Error("Unable to determine command");
        break;
}

