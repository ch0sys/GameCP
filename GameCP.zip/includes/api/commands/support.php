<?php 
if( !defined("_GAMECP_") ) 
{
    exit( "Invalid access" );
}

switch( $_REQUEST["command"] ) 
{
    case "ticket_reply":
        if( $user_id = $this->ValidateItemID("customerid", $_REQUEST["user_id"]) ) 
        {
            if( !$Permissions->Check($_REQUEST["item_id"], "support", "ticket_reply") ) 
            {
                return $this->Error("Permission denied");
            }

            $GameCP->loadIncludes("support");
            $Support = new Support();
            if( $this->api_type == "android" ) 
            {
                $_REQUEST["reply"] = nl2br($_REQUEST["reply"]);
            }

            if( $Support->Reply($user_id, $_REQUEST["item_id"], $_REQUEST["status"], $_REQUEST["resolved"], utf8_encode($_REQUEST["reply"]), utf8_encode($_REQUEST["summary"])) ) 
            {
                $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
            }
            else
            {
                $this->Error("Failed to perform action");
            }

        }

        break;
    case "ticket_edit":
        if( $this->EditRow("ttsystem", $_REQUEST["item_id"], $_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "ticket_list":
        $list = $this->ListRecords("ttsystem", $_REQUEST);
        if( is_array($list) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "total" => $list["total"], "result" => $list["result"] ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "ticket_delete":
        $GameCP->loadIncludes("support");
        $Support = new Support();
        if( $Support->Remove($_REQUEST["item_id"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "ticket_view":
        $result = $Panel->GetTicket($_REQUEST["item_id"]);
        if( is_array($result) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $result ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "ticket_create":
        if( $user_id = $this->ValidateItemID("customerid", $_REQUEST["user_id"]) ) 
        {
            $GameCP->loadIncludes("support");
            $Support = new Support();
            $tid = $Support->Create($user_id, utf8_encode($_REQUEST["title"]), utf8_encode($_REQUEST["subject"]), utf8_encode($_REQUEST["summary"]), utf8_encode($_REQUEST["message"]), utf8_encode($_REQUEST["reply"]));
            if( is_numeric($tid) ) 
            {
                $this->DisplayOutput(array( "error" => "0", "result" => $tid ));
            }
            else
            {
                $this->Error("Failed to perform action");
            }

        }

        break;
    default:
        $this->Error("Unable to determine command");
        break;
}

