<?php 
if( !defined("_GAMECP_") ) 
{
    exit( "Invalid access" );
}

switch( $_REQUEST["command"] ) 
{
    case "voice_control":
        if( !in_array($_REQUEST["action"], array( "stop", "start", "restart" )) ) 
        {
            return $this->Error("Invalid action");
        }

        $GameCP->loadIncludes("control");
        $Control = new Control();
        if( $Control->Uservoice($_REQUEST["item_id"], $_REQUEST["action"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "voice_suspend":
        $GameCP->loadIncludes("suspend");
        $Suspend = new Suspend();
        if( isset($_REQUEST["action"]) && $_REQUEST["action"] == "unsuspend" ) 
        {
            $task = $Suspend->VoiceRestore($_REQUEST["item_id"]);
        }
        else
        {
            $task = $Suspend->Voice($_REQUEST["item_id"]);
        }

        if( $task ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "voice_edit":
        if( $this->EditRow("uservoice", $_REQUEST["item_id"], $_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "voice_list":
        $list = $this->ListRecords("uservoice", $_REQUEST);
        if( is_array($list) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "total" => $list["total"], "result" => $list["result"] ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "voice_delete":
        $GameCP->loadIncludes("voice");
        $Voice = new Voice();
        if( $Voice->Remove($_REQUEST["item_id"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "voice_view":
        $userGameInfo = $Panel->GetUserGame($_REQUEST["item_id"]);
        if( is_array($userGameInfo) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $userGameInfo ));
        }
        else
        {
            $this->Error("Failed to perform action, no service found");
        }

        break;
    default:
        $this->Error("Unable to determine command");
        break;
}

