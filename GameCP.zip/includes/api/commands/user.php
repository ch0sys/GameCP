<?php 
if( !defined("_GAMECP_") ) 
{
    exit( "Invalid access" );
}

switch( $_REQUEST["command"] ) 
{
    case "user_suspend":
        $GameCP->loadIncludes("suspend");
        $Suspend = new Suspend();
        ob_start();
        if( isset($_REQUEST["action"]) && $_REQUEST["action"] == "unsuspend" ) 
        {
            $task = $Suspend->UserRestore($_REQUEST["item_id"]);
        }
        else
        {
            $task = $Suspend->User($_REQUEST["item_id"]);
        }

        $results = ob_get_contents();
        ob_end_clean();
        if( $task ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action," . $results);
        }

        break;
    case "user_edit":
        if( $this->EditRow("users", $_REQUEST["item_id"], $_REQUEST, array( "password" )) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "user_list":
        $list = $this->ListRecords("users", $_REQUEST);
        if( is_array($list) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "total" => $list["total"], "result" => $list["result"] ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "user_delete":
        $GameCP->loadIncludes("user");
        $User = new User();
        if( $User->Remove($_REQUEST["item_id"], true, true) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "user_view":
        $userInfo = $Panel->GetUser($_REQUEST["item_id"]);
        if( is_array($userInfo) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $userInfo ));
        }
        else
        {
            $this->Error("Failed to perform action, no user found");
        }

        break;
    case "user_changepassword":
        if( $GameCP->SetPassword($_REQUEST["item_id"], $_REQUEST["password"], $_REQUEST["subuser"], $_REQUEST["update_servers"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action, password not changed");
        }

        break;
    default:
        $this->Error("Unable to determine command");
        break;
}

