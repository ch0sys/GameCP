<?php 
if( !defined("_GAMECP_") ) 
{
    exit( "Invalid access" );
}

switch( $_REQUEST["command"] ) 
{
    case "files_list":
        $GameCP->loadIncludes("files");
        $Files = new Files($_REQUEST["item_id"]);
        if( $list = $Files->ListFiles($_REQUEST["item_id"], $_REQUEST["path"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $list ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "files_mkfile":
        $GameCP->loadIncludes("files");
        $Files = new Files($_REQUEST["item_id"]);
        if( $Files->CreateFile($_REQUEST["item_id"], $_REQUEST["path"], $_REQUEST["item"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "files_mkdir":
        $GameCP->loadIncludes("files");
        $Files = new Files($_REQUEST["item_id"]);
        if( $Files->CreateFolder($_REQUEST["item_id"], $_REQUEST["path"], $_REQUEST["item"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "files_rename":
        $GameCP->loadIncludes("files");
        $Files = new Files($_REQUEST["item_id"]);
        if( $Files->RenameFile($_REQUEST["item_id"], $_REQUEST["path"], $_REQUEST["item"], $_REQUEST["new_item"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "files_delete":
        $GameCP->loadIncludes("files");
        $Files = new Files($_REQUEST["item_id"]);
        if( $Files->DeleteFileFolder($_REQUEST["item_id"], $_REQUEST["path"], $_REQUEST["item"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "files_edit":
        $GameCP->loadIncludes("files");
        $Files = new Files($_REQUEST["item_id"]);
        if( $content = $Files->Edit($_REQUEST["item_id"], $_REQUEST["path"], $_REQUEST["item"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $content ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "files_save":
        $GameCP->loadIncludes("files");
        $Files = new Files($_REQUEST["item_id"]);
        if( $Files->Save($_REQUEST["item_id"], $_REQUEST["path"], $_REQUEST["item"], $_REQUEST["content"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    default:
        $this->Error("Unable to determine command");
        break;
}

