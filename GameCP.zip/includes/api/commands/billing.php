<?php 
if( !defined("_GAMECP_") ) 
{
    exit( "Invalid access" );
}

switch( $_REQUEST["command"] ) 
{
    case "bill_refund":
        $GameCP->loadIncludes("billing");
        $Billing = new Billing();
        if( $Billing->Refund($_REQUEST["item_id"], $_REQUEST["total"], $_REQUEST["type"], $_REQUEST["payment_id"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "bill_credit":
        $GameCP->loadIncludes("billing");
        $Billing = new Billing();
        if( $Billing->Credit($_REQUEST["item_id"], $_REQUEST["total"], $_REQUEST["addtobill"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "bill_pay":
        $GameCP->loadIncludes("billing");
        $Billing = new Billing();
        $pay = $Billing->AddPayment($_REQUEST["item_id"], $_REQUEST["total"], $_REQUEST["subscr_id"], $_REQUEST["transaction_id"], $_REQUEST["gateway"], $_REQUEST["fee"], $_REQUEST["date"], $_REQUEST["notify"]);
        if( "0" <= $pay ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "bill_notify":
        if( $item_id = $this->ValidateItemID("customerid", $_REQUEST["item_id"]) && ($bill_id = $this->ValidateItemID("billid", $_REQUEST["bill_id"])) ) 
        {
            if( !$Permissions->Check($_REQUEST["item_id"], "user", "bill_refund", array( "USER" )) ) 
            {
                return $this->Error("Permission denied");
            }

            $GameCP->loadIncludes("billing");
            $Billing = new Billing();
            if( $Billing->NotifyPayment($_REQUEST["item_id"], true, $bill_id, $_REQUEST["status"], $_REQUEST["total"], $_REQUEST["message"]) ) 
            {
                $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
            }
            else
            {
                $this->Error("Failed to perform action");
            }

        }

        break;
    case "bill_edit":
        if( $this->EditRow("billing", $_REQUEST["item_id"], $_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "bill_list":
        $list = $this->ListRecords("billing", $_REQUEST);
        if( is_array($list) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "total" => $list["total"], "result" => $list["result"] ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "bill_delete":
        $GameCP->loadIncludes("billing");
        $Billing = new Billing();
        if( $Billing->Remove($_REQUEST["item_id"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "bill_view":
        $GameCP->loadIncludes("billing");
        $Billing = new Billing();
        if( $bill_info = $Billing->InvoiceData("", $_REQUEST["item_id"]) ) 
        {
            $bill_info[2]["services"] = unserialize($bill_info[2]["services"]);
            $bill_info[2]["promo"] = unserialize($bill_info[2]["promo"]);
            $bill_info[2]["taxes"] = unserialize($bill_info[2]["taxes"]);
            $bill_info["payments"] = $bill_info[0];
            $bill_info["invoice_items"] = $bill_info[1];
            $bill_info["details"] = $bill_info[2];
            $bill_info["due_date"] = $bill_info[3];
            $bill_info["date"] = $bill_info[4];
            unset($bill_info[0]);
            unset($bill_info[1]);
            unset($bill_info[2]);
            unset($bill_info[3]);
            unset($bill_info[4]);
            $this->DisplayOutput(array( "error" => "0", "result" => $bill_info ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "bill_create":
        $GameCP->loadIncludes("billing");
        $Billing = new Billing();
        if( $bill_id = $Billing->AddBill($_REQUEST["invoice_term"], $_REQUEST["item_id"], $_REQUEST["date"], $_REQUEST["status"], $_REQUEST["total"], $_REQUEST["fee"], $_REQUEST["subscr_id"], $_REQUEST["promotion"]) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => $bill_id ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "bill_createitem":
        $GameCP->loadIncludes("billing");
        $Billing = new Billing();
        if( $billitem_id = $Billing->AddSubBill($_REQUEST["item_id"], $_REQUEST["client_id"], $_REQUEST["product_id"], $_REQUEST["total"], $_REQUEST["fee"], $_REQUEST["description"], $_REQUEST["taxed"]) ) 
        {
            $Billing->UpdateBillTotal($_REQUEST["item_id"]);
            $this->DisplayOutput(array( "error" => "0", "result" => $billitem_id ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    case "bill_edititem":
        $GameCP->loadIncludes("billing");
        $Billing = new Billing();
        if( $this->EditRow("userbills", $_REQUEST["item_id"], $_REQUEST) ) 
        {
            $this->DisplayOutput(array( "error" => "0", "result" => "success" ));
        }
        else
        {
            $this->Error("Failed to perform action");
        }

        break;
    default:
        $this->Error("Unable to determine command");
        break;
}

