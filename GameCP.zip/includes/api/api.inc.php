<?php 

class Api
{
    public $format = "gamecp";
    public $api_version = "2.0";
    public $api_type = "gamecp";
    public $authorized = false;
    public $error = "";
    public $error_details = "";
    public $result = "";
    public $user_key = "";
    public $user_info = "";
    public $user_level = "";
    public $user_subaccount = false;

    public function __construct()
    {
        global $GameCP;
        if( isset($_REQUEST["format"]) && $_REQUEST["format"] != "" ) 
        {
            if( $_REQUEST["format"] == "xml" ) 
            {
                $this->format = "xml";
            }
            else
            {
                if( $_REQUEST["format"] == "gamecp" ) 
                {
                    $this->format = "gamecp";
                }
                else
                {
                    if( $_REQUEST["format"] == "json" || $_REQUEST["format"] == "" ) 
                    {
                        $this->format = "json";
                    }

                }

            }

        }

        if( isset($_REQUEST["api_version"]) && $_REQUEST["api_version"] != "" && $_REQUEST["api_version"] <= $this->api_version ) 
        {
            $this->api_version = $GameCP->whitelist($_REQUEST["api_version"], "clean");
        }

        if( isset($_REQUEST["api_type"]) && $_REQUEST["api_type"] != "" ) 
        {
            $this->api_type = $GameCP->whitelist($_REQUEST["api_type"], "clean");
        }

        if( preg_match("/Basic/s", gcplickey) ) 
        {
            return $this->Error("A Trial or Full license is required to enable the API.");
        }

        $this->Validate();
    }

    public function Validate()
    {
        global $Event;
        if( isset($_REQUEST["command"]) && $_REQUEST["command"] == "auth" ) 
        {
            $this->authorized = $this->ValidateUser($_REQUEST["username"], $_REQUEST["password"]);
            $Event->EventLogAdd("system", "API Connection (auth) " . $_REQUEST["command"] . " made from " . $_SERVER["REMOTE_ADDR"] . "  @ " . time());
        }
        else
        {
            if( isset($_REQUEST["key"]) ) 
            {
                $this->authorized = $this->ValidateKey($_REQUEST["key"]);
                $Event->EventLogAdd("system", "API Connection (key) " . $_REQUEST["command"] . " made from " . $_SERVER["REMOTE_ADDR"] . "  @ " . time());
            }
            else
            {
                if( isset($_SESSION["gamecp"]["userinfo"]["username"]) && isset($_SESSION["gamecp"]["user"]["password"]) && isset($_SESSION["gamecp"]["userinfo"]["ulevel"]) ) 
                {
                    if( isset($_SESSION["gamecp"]["subaccount"]) && $_SESSION["gamecp"]["subaccount"] == "yes" ) 
                    {
                        $this->user_subaccount = true;
                    }

                    $this->authorized = $this->ValidateInternalUser();
                }
                else
                {
                    $this->error = "Unauthorized access.";
                }

            }

        }

    }

    public function ValidateInternalUser()
    {
        if( $_SESSION["gamecp"]["security"]["path"] != path || $_SESSION["gamecp"]["security"]["url"] != url ) 
        {
            return false;
        }

        $this->GetUserInfo($_SESSION["gamecp"]["userinfo"]["username"]);
        return true;
    }

    public function ValidateUser($user, $pass)
    {
        global $GameCP;
        global $Event;
        $Login = $GameCP->Login($user, $pass, true);
        switch( $Login ) 
        {
            case "0":
                $this->SetUserKey($user);
                $this->GetUserInfo($user);
                return true;
            case "1":
                $this->error = "Invalid user";
                $Event->EventLogAdd("system", "API Connection (login failure) " . $this->error . " made from " . $_SERVER["REMOTE_ADDR"] . "  @ " . time());
                return false;
            case "2":
                $this->error = "Invalid password";
                $Event->EventLogAdd("system", "API Connection (login failure) " . $this->error . " made from " . $_SERVER["REMOTE_ADDR"] . "  @ " . time());
                return false;
            case "3":
                $this->error = "To many login failures";
                $Event->EventLogAdd("system", "API Connection (login failure) " . $this->error . " made from " . $_SERVER["REMOTE_ADDR"] . "  @ " . time());
                return false;
            default:
                $this->error = "Authentication failure";
                $Event->EventLogAdd("system", "API Connection (login failure) " . $this->error . " made from " . $_SERVER["REMOTE_ADDR"] . "  @ " . time());
                return false;
        }
    }

    public function ValidateKey($key)
    {
        global $GameCP;
        global $safesql;
        $q = sql_query($safesql->query("SELECT * FROM users WHERE api_key='%s' AND api_ip='%s' AND apiaccess !='no' LIMIT 1;", array( $GameCP->whitelist($_REQUEST["key"], "clean"), $GameCP->whitelist($_SERVER["REMOTE_ADDR"], "clean") ))) or exit( mysql_error() );
        if( mysql_num_rows($q) == "1" ) 
        {
            $userDetails = mysql_fetch_assoc($q);
            $this->GetUserInfo($userDetails["username"]);
            return true;
        }

        $q = sql_query($safesql->query("SELECT * FROM usersubaccounts WHERE api_key='%s' AND api_ip='%s' LIMIT 1;", array( $GameCP->whitelist($_REQUEST["key"], "clean"), $GameCP->whitelist($_SERVER["REMOTE_ADDR"], "clean") ))) or exit( mysql_error() );
        if( mysql_num_rows($q) == "1" ) 
        {
            $userDetails = mysql_fetch_assoc($q);
            $this->user_subaccount = true;
            $this->GetUserInfo($userDetails["name"]);
            return true;
        }

        $this->error = "Authentication failure";
        return false;
    }

    public function SetUserKey($user)
    {
        global $GameCP;
        global $safesql;
        $this->user_key = md5(rand(0, 10000000));
        if( $this->user_subaccount ) 
        {
            $table = "usersubaccounts";
        }
        else
        {
            $table = "users";
        }

        sql_query($safesql->query("" . "UPDATE " . $table . " SET api_key='%s', api_ip='%s' WHERE name='%s' LIMIT 1;", array( $GameCP->whitelist($this->user_key, "clean"), $GameCP->whitelist($_SERVER["REMOTE_ADDR"], "clean"), $GameCP->whitelist($user, "clean") ))) or exit( mysql_error() );
    }

    public function SetSubAccount()
    {
        $this->user_info["permissions"] = $this->user_info["perms"];
        $this->user_info["userlevel"] = "0";
    }

    public function GetUserInfo($user)
    {
        global $GameCP;
        global $Panel;
        $this->user_info = $Panel->GetUser("", $user, $this->user_subaccount);
        if( $this->user_subaccount ) 
        {
            $this->SetSubAccount();
        }

        if( $this->user_info["permissions"] ) 
        {
            $tmpinfo = unserialize($this->user_info["permissions"]);
            if( is_array($tmpinfo) ) 
            {
                $this->user_info["permissions"] = $tmpinfo;
            }
            else
            {
                $this->user_info["permissions"] = array(  );
            }

            unset($tmpinfo);
        }
        else
        {
            $this->user_info["permissions"] = array(  );
        }

        switch( $this->user_info["userlevel"] ) 
        {
            case "0":
                $this->user_level = "USER";
                break;
            case "1":
                $this->user_level = "ADMIN";
                break;
            case "2":
                $this->user_level = "MANAGER";
                break;
            case "3":
                $this->user_level = "SUPPORT";
                break;
            case "4":
                $this->user_level = "RESELLER";
        }
    }

    public function Error($error, $errorno = 1)
    {
        if( $this->error_details ) 
        {
            $error .= ", " . $this->error_details;
        }

        $this->DisplayOutput(array( "error" => $errorno, "result" => strip_tags($error) ));
        return false;
    }

    public function DisplayOutput($output)
    {
        if( $this->format == "json" ) 
        {
            $result = json_encode($output);
        }
        else
        {
            if( $this->format == "gamecp" ) 
            {
                $this->result = $output;
                $result = $output;
            }
            else
            {
                if( $this->format == "xml" ) 
                {
                    header("Content-type: text/xml");
                    $result = "<xml version=\"1.0\" encoding=\"utf-8\">";
                    $result .= "<gamecp>";
                    $result .= $this->Array2XML($output);
                    $result .= "</gamecp></xml>";
                }
                else
                {
                    $result = $output;
                }

            }

        }

        exit( $result );
    }

    public function Array2XML($array_item)
    {
        $xml = "";
        foreach( $array_item as $element => $value ) 
        {
            if( is_array($value) ) 
            {
                $xml .= "" . "<" . $element . ">" . $this->Array2XML($value) . "" . "</" . $element . ">";
            }
            else
            {
                if( $value == "" ) 
                {
                    $xml .= "" . "<" . $element . " />";
                }
                else
                {
                    $xml .= "" . "<" . $element . ">" . $value . "" . "</" . $element . ">";
                }

            }

        }
        return $xml;
    }

    public function GetServiceID($id, $type)
    {
        global $GameCP;
        global $safesql;
        $bypass = array( "billid", "ticketid", "configs" );
        $built_intypes = array( "gamecp", "android", "ios" );
        if( in_array($this->api_type, $built_intypes) || in_array($type, $bypass) ) 
        {
            return $id;
        }

        if( !$id ) 
        {
            $this->error_details = "missing id";
            return false;
        }

        switch( $type ) 
        {
            case "customerid":
                $query = mysql_query($safesql->query("SELECT id FROM users WHERE billingid = '%i' LIMIT 1", array( $GameCP->whitelist($id, "int") ))) or exit( "MySQL Error: " . mysql_error() );
                break;
            case "gameid":
                $query = mysql_query($safesql->query("SELECT id FROM usergames WHERE billingid = '%i' LIMIT 1", array( $GameCP->whitelist($id, "int") ))) or exit( "MySQL Error: " . mysql_error() );
                break;
            case "voiceid":
                $query = mysql_query($safesql->query("SELECT id FROM uservoice WHERE billingId = '%i' LIMIT 1", array( $GameCP->whitelist($id, "int") ))) or exit( "MySQL Error: " . mysql_error() );
        }
        if( $query && mysql_num_rows($query) == 1 ) 
        {
            $rvalue = mysql_fetch_array($query);
            $rvalue = $rvalue["id"];
        }
        else
        {
            $rvalue = null;
        }

        $_REQUEST["item_id"] = $rvalue;
        return $rvalue;
    }

    public function GetRowContent($table, $id, $exclusion = array(  ))
    {
        global $GameCP;
        global $safesql;
        $results = array(  );
        $keys = array(  );
        $data = sql_query($safesql->query("SELECT * FROM %s WHERE id='%i' LIMIT 1", array( $GameCP->whitelist($table, "clean"), $GameCP->whitelist($id, "int") )));
        $res = mysql_fetch_assoc($data);
        if( is_array($res) && 0 < count($res) ) 
        {
            foreach( $res as $var => $val ) 
            {
                if( !in_array($var, $exclusion) ) 
                {
                    $keys[] = $var;
                    $results[$var] = $val;
                }

            }
        }

        return array( "results" => $results, "keys" => $keys );
    }

    public function EditRow($table, $id, $data, $exclusion = array(  ))
    {
        global $GameCP;
        global $safesql;
        global $Permissions;
        $sql_querya = "";
        $sql_data = array(  );
        $default_data = $this->GetRowContent($table, $id, array( "id", "cid" ));
        foreach( $data as $d => $a ) 
        {
            if( !in_array($d, $default_data["keys"]) ) 
            {
                unset($data[$d]);
            }

        }
        $data = array_merge($default_data["results"], $data);
        $sql_querya = $safesql->query("UPDATE %s SET ", array( $GameCP->whitelist($table, "clean") ));
        foreach( $data as $var => $val ) 
        {
            if( !in_array($var, $exclusion) ) 
            {
                $sql_querya .= "`" . $GameCP->whitelist($var, "clean") . "`='%s', ";
                $sql_data[] = $GameCP->whitelist($val, "clean");
            }

        }
        $sql_querya = rtrim($sql_querya, ", ");
        $sql_query = $safesql->query("" . $sql_querya . " WHERE id='" . $id . "'", $sql_data);
        return sql_query($sql_query);
    }

    public function GetStatusVar($table, $status)
    {
        switch( $table ) 
        {
            case "usergames":
                switch( $status ) 
                {
                    case "All":
                        return "";
                    case "Active":
                        return "1";
                    case "Inactive":
                        return "0";
                    case "Suspended":
                        return "2";
                }
                break;
            case "uservoice":
            case "All":
                return "";
            case "Active":
                return "1";
            case "Inactive":
                return "0";
            case "Suspended":
                return "2";
            case "users":
                switch( $status ) 
                {
                    case "All":
                        return "";
                    case "Active":
                        return "1";
                    case "Inactive":
                        return "0";
                }
                break;
            default:
                return $status;
        }
    }

    public function ListRecords($table, $data)
    {
        global $GameCP;
        global $safesql;
        global $Permissions;
        $sql_all = " ";
        $sql_order = " ";
        $search_exclude = array(  );
        $status_field = "status";
        $default = array( "client_id" => "", "limit" => "10", "start" => "0", "status" => "All", "sort" => "", "direction" => "ASC", "search" => "", "search_fields" => array(  ) );
        $data = array_merge($default, $data);
        $sql_querya = $safesql->query("SELECT SQL_CALC_FOUND_ROWS U.name, X.* , X.id as 'item_id', U.id as 'user_id' FROM users U, %s X WHERE U.id = X.cid ", array( $table ));
        $sql_query_alt = $safesql->query("SELECT SQL_CALC_FOUND_ROWS X.* , X.id as 'item_id' FROM %s X, %s U WHERE X.id = U.id ", array( $table, $table ));
        $sql_perm = $Permissions->SQLQuery("", array(  ), $table);
        $sql_queryb = $sql_perm[0];
        $sql_data = $sql_perm[1];
        $table_data = $this->GetColumns($table, $search_exclude);
        switch( $table ) 
        {
            case "ttsystem":
                $status = array( "All", "Open", "Closed", "On Hold", "In Progress", "Reply" );
                $sql_all = "AND (status='Open' OR status='Reply' OR status='Client Reply' OR status='Admin Reply') ";
                $sql_order = "`updated`";
                break;
            case "billing":
                $status = array( "All", "Pending", "Completed", "Canceled", "Refunded" );
                $sql_order = "`date`";
                break;
            case "users":
                $sql_querya = $sql_query_alt;
                $status_field = "X.active";
                $status = array( "All", "Active", "Inactive" );
                $sql_order = "`username`";
                break;
            case "usergames":
                $status = array( "All", "Active", "Inactive", "Suspended" );
                $status_field = "X.active";
                $sql_order = "`ip`, `port`";
                break;
            case "uservoice":
                $status = array( "All", "Active", "Inactive", "Suspended" );
                $status_field = "X.active";
                $sql_order = "`ip`, `port`";
                break;
            case "service_addons":
                $status = array( "All", "Active", "Inactive", "Suspended" );
                $status_field = "X.active";
                $sql_order = "`ip`, `port`";
                break;
            case "userconfigs":
                $status = array( "All" );
                $sql_querya = $safesql->query("SELECT SQL_CALC_FOUND_ROWS U.name, X.* , X.id as 'item_id', U.id as 'user_id' FROM users U, usergames UG, %s X WHERE U.id = UG.cid AND X.ugid = UG.id AND UG.id='%i' ", array( $table, $data["item_id"] ));
                $sql_order = "`id`";
        }
        if( $data["sort"] && in_array($data["sort"], $table_data["col_array"]) ) 
        {
            $sql_order = $data["sort"];
        }

        if( !in_array($data["status"], $status) ) 
        {
            $this->error_details = "invalid status";
            return false;
        }

        $status_code = $this->GetStatusVar($table, $data["status"]);
        if( strtoupper($data["direction"]) != "DESC" && strtoupper($data["direction"]) != "ASC" ) 
        {
            $data["direction"] = "DESC";
        }

        if( $data["client_id"] ) 
        {
            $sql_queryb .= "AND U.id='%i' ";
            $sql_data[] = $GameCP->whitelist($data["client_id"], "int");
        }

        if( is_array($data["search_fields"]) && 0 < count($data["search_fields"]) ) 
        {
            foreach( $data["search_fields"] as $field => $string ) 
            {
                $sql_queryb .= "AND X.`" . $field . "`='%s' ";
                $sql_data[] = $string;
            }
        }

        if( $data["status"] == "All" ) 
        {
            $sql_queryb .= $sql_all;
        }
        else
        {
            $sql_queryb .= "AND " . $status_field . "='%s' ";
            $sql_data[] = $status_code;
        }

        if( $data["search"] ) 
        {
            $sql_queryb .= "AND CONCAT_WS(" . $table_data["col_string"] . ") LIKE '%%s%'";
            $sql_data[] = $GameCP->whitelist($data["search"], "clean");
        }

        $sql_queryb .= " ORDER BY " . $sql_order . " " . $data["direction"] . " ";
        $sql_query = $safesql->query("" . $sql_querya . " " . $sql_queryb, $sql_data);
        return $this->GetList($sql_query, $table, $data["start"], $data["limit"]);
    }

    public function GetColumns($table, $exclusion = array(  ))
    {
        global $GameCP;
        global $safesql;
        $result = "";
        $result_array = array(  );
        $sql_query = sql_query($safesql->query("SHOW columns FROM %s ", array( $table )));
        while( $row = mysql_fetch_assoc($sql_query) ) 
        {
            if( !in_array($row["Field"], $exclusion) ) 
            {
                $result .= "X." . $row["Field"] . ",";
                $result_array[] = $row["Field"];
            }

        }
        return array( "col_string" => rtrim($result, ","), "col_array" => $result_array );
    }

    public function GetList($sql_query, $type, $start = "0", $limit = "10")
    {
        global $GameCP;
        global $safesql;
        $end = $start + $limit;
        if( $start == "all" ) 
        {
            $sqlLimited = $sql_query;
        }
        else
        {
            $sqlLimited = $sql_query . $safesql->query(" LIMIT %i, %i", array( $GameCP->whitelist($start, "int"), $GameCP->whitelist($limit, "int") ));
        }

        $result = sql_query($sqlLimited) or exit( mysql_error() );
        $rowsQ = sql_query("SELECT FOUND_ROWS() as total");
        $rows = mysql_fetch_assoc($rowsQ);
        $res = array(  );
        while( $re = mysql_fetch_assoc($result) ) 
        {
            $res[] = $re;
        }
        switch( $type ) 
        {
            case "users":
                foreach( $res as $r => $d ) 
                {
                    unset($res[$r]["password"]);
                }
                break;
            case "usergames":
                foreach( $res as $r => $d ) 
                {
                    $res[$r]["lastplayers"] = unserialize($res[$r]["lastplayers"]);
                }
                break;
            case "billing":
                foreach( $res as $r => $d ) 
                {
                    $res[$r]["services"] = unserialize($res[$r]["services"]);
                }
        }
        return array( "result" => $res, "total" => $rows["total"] );
    }

    public function CreateService($data)
    {
        global $GameCP;
        global $Panel;
        global $safesql;
        if( !$data["date"] ) 
        {
            $data["date"] = time();
        }

        if( $data["existinguser"] ) 
        {
            $existingsignup = $data["existinguser"];
            $uname = sql_query($safesql->query("SELECT name FROM users where id='%i' LIMIT 1", array( $GameCP->whitelist($data["existinguser"], "clean") ))) or exit( mysql_error() );
            if( mysql_num_rows($uname) != "1" ) 
            {
                $this->error_details = "User #" . $GameCP->whitelist($data["existinguser"], "clean") . " does not exist, not adding.";
                return false;
            }

            $udata = mysql_fetch_array($uname);
            $data["user_name"] = $udata["name"];
        }
        else
        {
            $existingsignup = false;
            if( !$data["user_name"] ) 
            {
                $totalClientsQ = sql_query("SELECT id FROM users ORDER BY id DESC LIMIT 1;") or exit( mysql_error() );
                $totalClients = mysql_fetch_array($totalClientsQ);
                $lastId = $totalClients["id"]++;
                $data["user_name"] = "server" . $lastId;
                unset($totalClientsQ);
                unset($totalClients);
                unset($lastId);
            }

            $uname = sql_query($safesql->query("SELECT name FROM users where name='%s' LIMIT 1", array( $GameCP->whitelist($data["user_name"], "clean") ))) or exit( mysql_error() );
            if( mysql_num_rows($uname) == "1" && $existingsignup == false ) 
            {
                $this->error_details = "User " . $GameCP->whitelist($data["user_name"], "clean") . " already exists, not adding.";
                return false;
            }

        }

        $invalidnames = $Panel->InvalidNames();
        if( in_array($data["user_name"], $invalidnames) ) 
        {
            $this->error_details = "Username " . $GameCP->whitelist($data["user_name"], "clean") . " not allowed.";
            return false;
        }

        unset($invalidnames);
        if( !$data["service_id"] && $data["gameInstall"] == "yes" ) 
        {
            $gamesQ = sql_query("SELECT id FROM game WHERE `active` = '1' LIMIT 1;") or exit( mysql_error() );
            $games = mysql_fetch_array($gamesQ);
            $data["service_id"] = $games["id"];
            unset($gamesQ);
            unset($games);
        }

        if( $data["add_bill"] == "yes" ) 
        {
            if( $data["invoice_term"] == "onetime" ) 
            {
                $daystill = "0";
            }
            else
            {
                if( $data["invoice_term"] == "hourly" ) 
                {
                    $daystill = "1";
                }
                else
                {
                    if( $data["invoice_term"] == "monthly" ) 
                    {
                        $daystill = "31";
                    }
                    else
                    {
                        if( $data["invoice_term"] == "quarterly" ) 
                        {
                            $daystill = "91";
                        }
                        else
                        {
                            if( $data["invoice_term"] == "semiannualy" ) 
                            {
                                $daystill = "182";
                            }
                            else
                            {
                                if( $data["invoice_term"] == "annualy" ) 
                                {
                                    $daystill = "365";
                                }
                                else
                                {
                                    if( $data["invoice_term"] == "2years" ) 
                                    {
                                        $daystill = "730";
                                    }
                                    else
                                    {
                                        $daystill = "31";
                                    }

                                }

                            }

                        }

                    }

                }

            }

            if( $data["gamepack"] ) 
            {
                $packageInfo = sql_query($safesql->query("SELECT cost as 'monthly', fee, name, quarterly, semiannualy, annauly, 2years, slots, rate as 'hourly', id FROM prices WHERE id='%i' ORDER BY pid, rank", array( $GameCP->whitelist($data["gamepack"], "int") ))) or exit( mysql_error() );
                $gpackdata = mysql_fetch_array($packageInfo);
                if( !$data["gamecost"] ) 
                {
                    $data["gamecost"] = $gpackdata[$data["invoice_term"]];
                }

                if( !$data["gamefee"] ) 
                {
                    $data["gamefee"] = $gpackdata["fee"];
                }

            }

            if( $data["voicepack"] ) 
            {
                $packageInfo = sql_query($safesql->query("SELECT cost as 'monthly', fee, name, quarterly, semiannualy, annauly, 2years, slots, rate as 'hourly', id FROM prices WHERE id='%i' ORDER BY pid, rank", array( $GameCP->whitelist($data["voicepack"], "int") ))) or exit( mysql_error() );
                $gpackdata = mysql_fetch_array($packageInfo);
                if( !$data["voicecost"] ) 
                {
                    $data["voicecost"] = $gpackdata[$data["invoice_term"]];
                }

                if( !$data["voicefee"] ) 
                {
                    $data["voicefee"] = $gpackdata["fee"];
                }

            }

        }
        else
        {
            $daystill = "";
        }

        $defaults = array( "fuserlevel" => "0", "fmanager" => "2", "loginpath" => "no", "installtype" => "install", "fmip" => "no", "flimit" => "+1", "orderpage" => "1", "startserver" => "yes", "subdirectory" => "yes" );
        $queue_details = array( "orderpage" => "1", "subdirectory" => $data["subdirectory"], "invoice_term" => $data["invoice_term"], "existinguser" => $data["existinguser"], "fuserlevel" => $data["userlevel"], "fname" => $data["user_name"], "fusername" => $data["user_name"], "femail" => $data["email"], "pid" => $data["service_id"], "fpassword" => $data["password"], "fip" => $data["ip"], "fport" => $data["port"], "phone" => $data["phone"], "address" => utf8_encode($data["address"]), "city" => utf8_encode($data["city"]), "state" => utf8_encode($data["state"]), "country" => utf8_encode($data["country"]), "fnote" => utf8_encode($data["extrainfo"]), "extrainfo" => $data["extrainfo"], "zip" => $data["zip"], "clienturl" => $data["clienturl"], "installtype" => $data["installtype"], "firstname" => utf8_encode($data["firstname"]), "lastname" => utf8_encode($data["lastname"]), "payment" => $data["payment"], "address2" => $data["address2"], "loginpath" => $data["loginpath"], "today" => $data["today"], "fconfig" => $data["default_config"], "fport" => $data["default_port"], "fstartmap" => $data["default_startmap"], "fmaxclients" => $data["max_clients"], "fpubpriv" => $data["pubpriv"], "date" => $data["date"], "status" => $data["invoice_status"], "gross" => $data["invoice_gross"], "fee" => $data["invoice_fee"], "daystill" => $daystill, "startserver" => $data["start_server"], "fsendinfo" => $data["notify_client"], "addbill" => $data["add_bill"], "ordergame" => array( "id" => $data["gamepack"], "cost" => $data["gamecost"], "fee" => $data["gamefee"] ), "ordervoice" => array( "id" => $data["voicepack"], "cost" => $data["voicecost"], "fee" => $data["voicefee"] ), "fmip" => $data["mark_ip_used"], "queueNULL" => $data["queue"], "voiceInstall" => $data["voice_install"], "voiceType" => $data["voic_type"], "voiceMaxClients" => $data["voice_max_clients"], "RCONPASSWORD" => $data["default_rconpass"], "SPECPASSWORD" => $data["default_specpass"], "PRIVPASSWORD" => $data["default_privpass"], "subscr_id" => $data["subscr_id"], "HOSTNAME" => $data["default_hostname"], "MOTD" => $data["default_motd"], "WEBSITE" => $data["clienturl"], "freseller" => $data["reseller_id"], "start_time" => $data["start_time"], "end_time" => $data["end_time"], "voiceName" => $data["voice_name"], "voiceIP" => $data["voice_ip"], "voicePort" => $data["voice_port"], "taxvoice" => $data["tax_voice"], "taxproduct" => $data["tax_product"], "subdirectory" => $data["subdirectory"], "location" => $data["location"], "existingsignup" => $existingsignup, "billingid" => $data["billing_id"], "voicebillingid" => $data["voice_billing_id"], "servicebillingid" => $data["service_billing_id"], "flimit" => $data["flimit"], "promo" => $data["promo"], "paidPrice" => $data["paidPrice"], "transactionid" => $data["transactionid"], "suspend_notpaid" => $data["suspend_notpaid"], "paddons" => $data["paddons"], "taxaddon" => $data["taxaddon"], "fmanager" => $data["file_manager"], "demo" => $data["demo"] );
        foreach( $queue_details as $q => $d ) 
        {
            if( isset($defaults[$q]) && $d == "" ) 
            {
                $queue_details[$q] = $defaults[$q];
            }

        }
        sql_query($safesql->query("INSERT INTO queue SET ref='1', user='%s',`mod`='%s', rundate='%s';", array( $GameCP->whitelist($data["user_name"], "clean"), serialize($queue_details), strtotime($data["queue_date"]) ))) or exit( mysql_error() );
        $qid = mysql_insert_id();
        $Panel->ExecQueue($qid);
        return $qid;
    }

}


