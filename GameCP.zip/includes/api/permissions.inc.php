<?php 

class Permissions extends Api
{
    public function Check($id, $type, $command = "", $exclude = array(  ))
    {
        global $GameCP;
        global $Panel;
        if( in_array($this->user_level, $exclude) ) 
        {
            return false;
        }

        if( in_array($command, $this->user_info["permissions"]) ) 
        {
            return false;
        }

        if( $this->user_level == "ADMIN" || $this->user_level == "MANAGER" ) 
        {
            return true;
        }

        if( $this->user_subaccount ) 
        {
            $id = $this->user_info["cid"];
        }

        switch( $type ) 
        {
            case "configs":
                $lookup = $Panel->GetUserConfig($id);
                $results = $Panel->GetUserGame($lookup["ugid"]);
                break;
            case "user":
                $results = $Panel->GetUser($id);
                break;
            case "service":
                $lookup = $Panel->GetUserGame($id);
                $results = $Panel->GetUser($lookup["cid"]);
                break;
            case "voice":
                $lookup = $Panel->GetUserVoice($id);
                $results = $Panel->GetUser($lookup["cid"]);
                break;
            case "billing":
                $lookup = $Panel->GetBill($id);
                $results = $Panel->GetUser($lookup["cid"]);
                break;
            case "support":
                $lookup = $Panel->GetTicket($id);
                $results = $Panel->GetUser($lookup["cid"]);
        }
        if( $this->user_level == "RESELLER" && $results["rsid"] == $this->user_info["id"] ) 
        {
            return true;
        }

        if( $this->user_level == "USER" && $this->user_info["id"] == $results["id"] ) 
        {
            return true;
        }

        return false;
    }

    public function SQLSubUser($sql_queryb = "", $sql_data = array(  ), $table = "")
    {
        $game_restrictiontables = array( "usergames", "userconfigs" );
        if( in_array($table, $game_restrictiontables) && $this->user_subaccount && $this->user_info["games"] ) 
        {
            $game_restriction = unserialize($this->user_info["games"]);
            if( is_array($game_restriction) && 0 < count($game_restriction) ) 
            {
                $games = implode(",", $game_restriction);
                if( !$games ) 
                {
                    $games = "''";
                }

                $game_idfield = "";
                if( $table == "usergames" ) 
                {
                    $game_idfield = "X.id";
                }

                if( $table == "userconfigs" ) 
                {
                    $game_idfield = "X.ugid";
                }

                if( $game_idfield ) 
                {
                    $sql_queryb .= "" . "AND " . $game_idfield . " IN (" . $games . ") ";
                }

            }

        }

        return array( $sql_queryb, $sql_data );
    }

    public function SQLQuery($sql_queryb = "", $sql_data = array(  ), $table = "")
    {
        global $GameCP;
        if( $this->user_level == "RESELLER" ) 
        {
            $sql_queryb .= "AND (U.rsid='%i' OR U.id='%i') ";
            $sql_data[] = $GameCP->whitelist($this->user_info["id"], "int");
            $sql_data[] = $GameCP->whitelist($this->user_info["id"], "int");
        }

        if( $this->user_level == "USER" ) 
        {
            if( $this->user_subaccount ) 
            {
                $id = $this->user_info["cid"];
            }
            else
            {
                $id = $this->user_info["id"];
            }

            $sql_queryb .= "AND U.id='%i' ";
            $sql_data[] = $GameCP->whitelist($id, "int");
        }

        if( $this->user_subaccount ) 
        {
            $sub_user = $this->SQLSubUser($sql_queryb, $sql_data, $table);
            $sql_queryb = $sub_user[0];
            $sql_data = $sub_user[1];
        }

        return array( $sql_queryb, $sql_data );
    }

}


