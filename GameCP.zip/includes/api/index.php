<?php 
require_once("../mysql.inc.php");
require_once("include.inc.php");
require_once("api.inc.php");
require_once("commands.inc.php");
require_once("permissions.inc.php");
define("_GAMECP_", "gamecp");
$API = new Api();
$Permissions = new Permissions();
$Commands = new Commands();
if( MAINTENANCE == "yes" ) 
{
}

if( $API->format != "gamecp" ) 
{
    $Commands->RunCommand();
}


