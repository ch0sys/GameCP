<?php 
$time = microtime();
$time = explode(" ", $time);
$time = $time[1] + $time[0];
$start = $time;
@ini_set("magic_quotes_runtime", false);
@ini_set("zend.ze1_compatibility_mode", "0");
if( function_exists("date_default_timezone_set") && function_exists("date_default_timezone_get") ) 
{
    @date_default_timezone_set(@date_default_timezone_get());
}

if( !isset($_SESSION) ) 
{
    session_start();
}

$settingsRows = sql_query("SELECT * FROM settings", "constant settings") or exit( mysql_error() );
while( $srow = mysql_fetch_assoc($settingsRows) ) 
{
    if( !defined($srow["name"]) ) 
    {
        define($srow["name"], $srow["value"]);
    }

}
unset($settingsRows);
unset($srow);
if( function_exists("mysql_set_charset") ) 
{
    mysql_set_charset(sqlcharset);
}
else
{
    mysql_query("SET NAMES " . sqlcharset);
}

define("_GAMECP_", "gamecp");
$TEMPLATE = "x";
$template = "x";
$lang = "en";
$GameCPSettings = array(  );
$template_dir = path . "/includes/cache/";
require_once(path . "/includes/core/includes/gamecp/hooks.inc.php");
require_once(path . "/includes/core/classes/mysql/SafeSQL.class.php");
require_once(path . "/includes/core/classes/gamecp/class.inc.php");
require_once(path . "/includes/core/classes/gamecp/event.inc.php");
require_once(path . "/includes/smarty/libs/Smarty.class.php");
require_once(path . "/includes/core/includes/gamecp/smarty.inc.php");
$safesql = new SafeSQL_MySQL();
$GameCP = new GameCP();
$Event = new Event();
$GameCP->loadIncludes("panel");
$Panel = new Panel();
error_reporting(0);
function sql_query($query, $reason = FALSE)
{
    return mysql_query($query);
}


