<?php 

class Commands extends Api
{
    public function ValidateItemID($type, $item_id)
    {
        global $GameCP;
        global $Permissions;
        $item_id = $GameCP->whitelist($item_id, "int");
        if( !in_array($type, array( "customerid", "gameid", "voiceid", "billid", "support", "configs" )) ) 
        {
            return $this->Error("Type lookup failure");
        }

        $item_id = $this->GetServiceID($item_id, $type);
        if( !isset($item_id) ) 
        {
            return $this->Error("Missing required field");
        }

        if( !$item_id ) 
        {
            return $this->Error("Unable to locate " . $type);
        }

        return $item_id;
    }

    public function GetCommands($command)
    {
        $commands = array(  );
        $commands["user_changepassword"] = array( "idtype" => "customerid", "permtype" => "users", "exclude" => array( "USER" ) );
        $commands["service_control"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["voice_control"] = array( "idtype" => "voiceid", "permtype" => "voice", "exclude" => array(  ) );
        $commands["user_suspend"] = array( "idtype" => "customerid", "permtype" => "user", "exclude" => array( "USER" ) );
        $commands["service_suspend"] = array( "idtype" => "gameid", "permtype" => "user", "exclude" => array( "USER" ) );
        $commands["voice_suspend"] = array( "idtype" => "voiceid", "permtype" => "voice", "exclude" => array( "USER" ) );
        $commands["user_edit"] = array( "idtype" => "customerid", "permtype" => "user", "exclude" => array(  ) );
        $commands["service_edit"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["voice_edit"] = array( "idtype" => "voiceid", "permtype" => "voice", "exclude" => array(  ) );
        $commands["bill_edit"] = array( "idtype" => "billid", "permtype" => "billing", "exclude" => array(  ) );
        $commands["user_edit"] = array( "idtype" => "customerid", "permtype" => "users", "exclude" => array(  ) );
        $commands["ticket_edit"] = array( "idtype" => "support", "permtype" => "support", "exclude" => array(  ) );
        $commands["service_delete"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array( "USER" ) );
        $commands["voice_delete"] = array( "idtype" => "voiceid", "permtype" => "voice", "exclude" => array( "USER" ) );
        $commands["bill_delete"] = array( "idtype" => "billid", "permtype" => "billing", "exclude" => array( "USER" ) );
        $commands["ticket_delete"] = array( "idtype" => "support", "permtype" => "support", "exclude" => array( "USER" ) );
        $commands["user_delete"] = array( "idtype" => "customerid", "permtype" => "users", "exclude" => array( "USER" ) );
        $commands["service_view"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["voice_view"] = array( "idtype" => "voiceid", "permtype" => "voice", "exclude" => array(  ) );
        $commands["user_view"] = array( "idtype" => "customerid", "permtype" => "user", "exclude" => array(  ) );
        $commands["bill_view"] = array( "idtype" => "billid", "permtype" => "billing", "exclude" => array(  ) );
        $commands["ticket_view"] = array( "idtype" => "support", "permtype" => "support", "exclude" => array(  ) );
        $commands["bill_create"] = array( "idtype" => "customerid", "permtype" => "user", "exclude" => array( "USER" ) );
        $commands["bill_createitem"] = array( "idtype" => "billid", "permtype" => "billing", "exclude" => array( "USER" ) );
        $commands["bill_edititem"] = array( "idtype" => "billid", "permtype" => "billing", "exclude" => array( "USER" ) );
        $commands["bill_refund"] = array( "idtype" => "billid", "permtype" => "billing", "exclude" => array( "USER" ) );
        $commands["bill_credit"] = array( "idtype" => "billid", "permtype" => "billing", "exclude" => array( "USER" ) );
        $commands["bill_pay"] = array( "idtype" => "billid", "permtype" => "billing", "exclude" => array( "USER" ) );
        $commands["notify"] = array( "idtype" => "customerid", "permtype" => "user", "exclude" => array( "USER" ) );
        $commands["service_addon_list"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["service_update"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["service_reinstall"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["service_addon_run"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["service_rcon"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["service_quickmod"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["service_changemap"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["service_console"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["map_list"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["map_add"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["map_delete"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["files_list"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["files_mkfile"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["files_mkdir"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["files_rename"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["files_delete"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["files_edit"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["files_save"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["config_restore"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["config_create"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["config_list"] = array( "idtype" => "gameid", "permtype" => "service", "exclude" => array(  ) );
        $commands["config_view"] = array( "idtype" => "configs", "permtype" => "configs", "exclude" => array(  ) );
        $commands["config_delete"] = array( "idtype" => "configs", "permtype" => "configs", "exclude" => array(  ) );
        $commands["config_edit"] = array( "idtype" => "configs", "permtype" => "configs", "exclude" => array(  ) );
        $commands["config_execute"] = array( "idtype" => "configs", "permtype" => "service", "exclude" => array(  ) );
        $commands["config_fetch"] = array( "idtype" => "configs", "permtype" => "service", "exclude" => array(  ) );
        if( isset($commands[$command]) ) 
        {
            return $commands[$command];
        }

    }

    public function ValidateCommand($command)
    {
        global $Permissions;
        $cmdinfo = $this->GetCommands($command);
        if( is_array($cmdinfo) ) 
        {
            if( $item_id = $this->ValidateItemID($cmdinfo["idtype"], $_REQUEST["item_id"]) ) 
            {
                if( !$Permissions->Check($item_id, $cmdinfo["permtype"], $command, $cmdinfo["exclude"]) ) 
                {
                    $this->Error("Permission denied");
                    return false;
                }

            }
            else
            {
                $this->Error("Permission denied");
                return false;
            }

        }

        return true;
    }

    public function RunCommand()
    {
        global $GameCP;
        global $Permissions;
        global $Panel;
        $this->error = "";
        $this->error_details = "";
        $this->result = "";
        if( $this->authorized == true ) 
        {
            if( !isset($_REQUEST["command"]) ) 
            {
                return false;
            }

            if( !$this->ValidateCommand($_REQUEST["command"]) ) 
            {
                return false;
            }

            if( preg_match("/service_/", $_REQUEST["command"]) ) 
            {
                include("commands/service.php");
            }
            else
            {
                if( preg_match("/files_/", $_REQUEST["command"]) ) 
                {
                    include("commands/file.php");
                }
                else
                {
                    if( preg_match("/bill_/", $_REQUEST["command"]) ) 
                    {
                        include("commands/billing.php");
                    }
                    else
                    {
                        if( preg_match("/ticket_/", $_REQUEST["command"]) ) 
                        {
                            include("commands/support.php");
                        }
                        else
                        {
                            if( preg_match("/voice_/", $_REQUEST["command"]) ) 
                            {
                                include("commands/voice.php");
                            }
                            else
                            {
                                if( preg_match("/config_/", $_REQUEST["command"]) ) 
                                {
                                    include("commands/config.php");
                                }
                                else
                                {
                                    if( preg_match("/user_/", $_REQUEST["command"]) ) 
                                    {
                                        include("commands/user.php");
                                    }
                                    else
                                    {
                                        if( preg_match("/map_/", $_REQUEST["command"]) ) 
                                        {
                                            include("commands/map.php");
                                        }
                                        else
                                        {
                                            include("commands/misc.php");
                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }
        else
        {
            $this->Error($this->error);
        }

    }

}


